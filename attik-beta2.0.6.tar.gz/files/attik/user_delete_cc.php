<?php 
require_once('includes/control_session.php');

$DESTINATION_PAGE = "user_cc.php";

$ID = trim(addslashes($_SESSION['ITEMDELETE']));

if (empty($ID)) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDSELECT';
	header("Location:$DESTINATION_PAGE");
}
else {
	$SQL = "SELECT id FROM controlcenter.user WHERE id = '$ID' AND id = '$USER'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSU013F"));
	if (mysql_affected_rows() == 1){
		$_SESSION['SHOW_MSG'] = 'ME_CANTREMOVEUSERSIGNED';
	}else {
	
		$SQL = "SELECT id FROM controlcenter.profile WHERE create_profile = '1' AND read_profile = '1' AND ";
		$SQL .= "read_user = '1' AND create_user = '1'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSU010F"));
		$RESULTP = mysql_affected_rows();
	
		$SQL = "SELECT id FROM controlcenter.user WHERE id_pro IN (SELECT id FROM controlcenter.profile WHERE ";
		$SQL .= "create_profile = '1' AND read_profile = '1' AND read_user = '1' AND create_user = '1' )";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSU012F"));
		$RESULTT = mysql_affected_rows();
	
		$SQL = "SELECT id FROM controlcenter.user WHERE id_pro IN (SELECT id FROM controlcenter.profile WHERE ";
		$SQL .= "create_profile = '1' AND read_profile = '1' AND read_user = '1' AND create_user = '1' ) AND id = '$ID'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSU011F"));
		$RESULTU = mysql_affected_rows();
		
		if (($RESULTU == 1) && ($RESULTP == 1) && ($RESULTT == 1)) {
			$_SESSION['SHOW_MSG'] = 'ME_THIUNIQUEUSERWITHPRIVILEGIES';
		}else{
			$SQL = "DELETE FROM controlcenter.user WHERE id = '$ID'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCDU008F"));
			if ( mysql_affected_rows() !=0 )
			{
				if ($LOG_AUDITOR != 0){
					auditor('ICCDU008S', $ADDRIP, $USER, '0');
				}
				$_SESSION['SHOW_MSG'] = 'F_SUCESS';
			}else {
					if ($LOG_AUDITOR != 0){
						auditor('ICCDU008F', $ADDRIP, $USER, '0');
					}
					$_SESSION['SHOW_MSG'] = 'F_FAILURE';
			}
		}
	}
	unset($_SESSION['ITEMDELETE']);
	header("Location:$DESTINATION_PAGE");
}
?>