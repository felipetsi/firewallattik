<?php 
require_once('includes/control_session.php');

$DESTINATION_PAGE = "interface_run_cc.php";
$THISPAGE = "interface_cc.php";

// Load the profile of user autenticanted
$SQL = "SELECT change_config FROM controlcenter.profile WHERE ";
$SQL .= "id IN (SELECT id_pro FROM controlcenter.user WHERE id = '$USER')";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSI001F"));
$DATA_USER = mysql_fetch_array($RS);

$INTERFACE = trim(addslashes($_POST['interface']));
if ((empty($INTERFACE))&&(empty($_SESSION['INTERFACE'])))
{
	$INTERFACE = 1;
	$_SESSION['INTERFACE'] = $INTERFACE;
}
elseif(!empty($INTERFACE)){
	$_SESSION['INTERFACE'] = $INTERFACE;
}
else {
	$INTERFACE = $_SESSION['INTERFACE'];
}
// Load the item selected
if (!empty($_POST['list']))
{
	$_SESSION['ITEMID'] = $_POST['list'];
	$ITEMID = $_SESSION['ITEMID'];
} else {
	$ITEMID = $_SESSION['ITEMID'];
}
$_SESSION['ITEMDELETE'] = $ITEMID;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>..:: IncTI - Firewall ::..</title>
<script language="javascript">
var thispage = "interface_cc.php";
var deletepage = "interface_delete_cc.php";
</script>
<link href="includes/style_cc.css" rel="stylesheet" type="text/css" />
</head>
<body onload="verifyInterface();">
<?php 
require_once('includes/top.php');
?>
<script language="javascript">
function confirmDeleteSelected()
{
	document.getElementById('background_transparent').style.display="inline";
	document.getElementById('box_delete').style.display="table";
}
function yesdeleteSelected()
{
	window.location=deletepage;
}
function nodeleteSelected()
{
	document.getElementById('box_delete').style.display="none";
	document.getElementById('background_transparent').style.display="none";
}
function verifyInterface()
{
	if(document.frminterface.name.value == "lo")
	{
		document.getElementById('maskIface').style.display="none";
		document.frminterface.mask.value="";
	}
	else
	{
		document.getElementById('maskIface').style.display="table";
	}
}
function clickBackgroudTrabsparent()
{
	nodeleteSelected();
}
</script>
<div id="background_transparent" onclick="javascript:clickBackgroudTrabsparent();"></div>
<div id="box_delete"><?php echo("$S_WANT_DELETE?");?> 
	<div class="space_confirm_box">
		<input type="button" value="<?php echo $B_YES;?>" onclick="javascript:yesdeleteSelected();" />
		<input type="button" value="<?php echo $B_NO;?>" onclick="javascript:nodeleteSelected();" />
	</div>	
</div>

<div id="main"> <!--Main-->
<?php require_once('cc_menu_configuration.php');?>
<?php require_once('cc_menu_network_configuration.php');?>
	<div id="contet_rigth">
<?php
if ($DATA_USER['change_config'] == 1) {

// Load the user selected
if (!empty($ITEMID)){
	if ($INTERFACE == 1) {
		$SQL = "SELECT * FROM controlcenter.interface WHERE id = '$ITEMID'";
	} else {
		$SQL = "SELECT * FROM controlcenter.interface WHERE vid = '$ITEMID'";
	}
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSI002F"));
	if((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1)){
			auditor('IFWSI002S', $ADDRIP, $USER, '0');
	}
	$ARRAY = mysql_fetch_array($RS);
}
?>

<!--Start add-->
<form class="insert_border" action="<?php echo $DESTINATION_PAGE;?>" method="post" name="frminterface">
<?php if ($INTERFACE == 1) { ?>
	<input type="hidden" name="id" value="<?php echo $ARRAY['id'];?>" />
<?php } else { ?>
	<input type="hidden" name="id" value="<?php echo $ARRAY['vid'];?>" />
<?php }?>
<div class="title_general" > <?php echo $T_INTERFACE; ?> </div>
<div id="contet_rigth_data">
		<div align="right" class="left_name"><u><?php echo $T_DESCRIPTION;?></u> </div>
			<div> <input type="text" name="description" size="20" maxlength="30" value="<?php if(!empty($_SESSION['EX_DESCRIPTION'])) { echo $_SESSION['EX_DESCRIPTION'];} else { echo $ARRAY['description'];}?>"  autocomplete="off" /></div>

	<? if($INTERFACE == 1){?>
		<div align="right" class="left_name"><u><?php echo $F_NAME;?></u> </div>
			<div> <input type="text" name="name" size="20" maxlength="6" value="<?php if(!empty($_SESSION['EX_NAME'])) { echo $_SESSION['EX_NAME'];} else { echo $ARRAY['name'];}?>"  autocomplete="off" onchange="javascript:verifyInterface(this);" /></div>
	<?php } else {?>
		<div align="right" class="left_name"><u><?php echo $F_INTERFACE;?></u> </div>
			<div> 
				<select name="iface">
					<option></option>
					<? $SQL = "SELECT id,description FROM controlcenter.interface WHERE vid = '0'";
					$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCVS001S"));
					$OBJ = mysql_fetch_array($RS);
					$f = 0;
					do {
						if(($ARRAY['id'] == $OBJ['id'])||($_SESSION['ITEMID'] == $OBJ['id'])){
							$sel = 'selected="selected"';
						} else {
							$sel = "";
						}?>
						<option <?php echo $sel;?> value="<?php echo $OBJ['id'];?>"> <?php echo $OBJ['description'];?> </option><?php
						$VLANID[$f];
						$f++;
					}while($OBJ = mysql_fetch_array($RS));?>
				</select>
			</div>
			
		<div align="right" class="left_name"><u><?php echo $F_VLANID;?></u> </div>
			<div> 
				<select name="vlanid">
					<option></option>
					<?php
					$SQL = "SELECT vid FROM controlcenter.interface WHERE vid != '0'";
					$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSI006F"));
					$OBJ = mysql_fetch_array($RS);
					$f = 0;
					do{
						$VIDUSED[$f] = $OBJ['vid'];
						$f++;
					}while($OBJ = mysql_fetch_array($RS));
					for ($f = 1; $f < 1000; $f++) {
						if ((!in_array($f,$VIDUSED))||($f == $ITEMID)) {
							if (($f == $ITEMID)||($f == $_SESSION['VID'])) {
								$sel = 'selected="selected"';
							} else {
								$sel = "";
							}?>
							<option <?php echo $sel;?> value="<?php echo $f;?>"> <?php echo $f;?> </option>
						<?php }
					}?>
				</select>
			</div>
	<?php }?>
		
		<div align="right" class="left_name"><u><?php echo $F_IP;?></u> </div>
			<div> <input type="text" name="ip" size="20" maxlength="15" value="<?php if(!empty($_SESSION['EX_IP'])) { echo $_SESSION['EX_IP'];} else { echo $ARRAY['ip'];}?>"  autocomplete="off" /></div>
			
		<div id="maskIface">
		<div align="right" class="left_name"><?php echo $F_MASK;?> </div>
			<input type="text" name="mask" size="20" maxlength="15" value="<?php if(!empty($_SESSION['EX_MASK'])) { echo $_SESSION['EX_MASK'];} else { echo $ARRAY['mask'];}?>"  autocomplete="off" />
		</div>
			
	</div>
	<div id="contet_rigth_img">

		<img src="@img/icons/ethernet-card-Vista-128x128.png" />	

	</div>	
<div class="title_general">
	<input type="submit" value="<?php if (empty($ARRAY['id'])){ echo $B_ADD_NEW;} else { echo $B_UPDATE;}?>" />
	<input type="button" value="<?php echo $B_CLEAR;?>" onclick="javascript:window.location=thispage" />
	<input type="button" value="<?php echo $B_DELETE;?>" onClick="javascript:confirmDeleteSelected();" />
</div>
</form>
<!--End add-->

<!-- Start list-->
<div class="title_general"><?php echo $T_INTERFACE_LIST;?></div>
<form class="insert_border" action="<?php echo $THISPAGE;?>" method="post" name="objselect">
<select class="select_list" name="list" size="20" ondblclick="javascript:document.objselect.submit()">
<?php
	$SQL = "SELECT id, name, description, ip FROM controlcenter.interface WHERE vid = '0' ORDER BY name";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSI003F"));
	$ARRAY = mysql_fetch_array($RS);
	$cor = 1;	
	do{
	if ($INTERFACE == 1) {
		if ($ITEMID == $ARRAY['id']) {
			$sel = 'selected="selected"';
		} else {
				$sel = "";
		}
	}
	if($INTERFACE == 1){
		if(!empty($ARRAY['id'])){
		?>
		<option <?php if(verifyInterface($ARRAY['name']) != "ok"){ echo 'style="background:#FF0000"'; } else {if ( $cor == 1 ){ echo 'style="background:'.$COLOR_LINE_SELECT.'"'; $cor = 0;}else{$cor = 1;}}?> value="<?php echo $ARRAY['id'];?>" <?php echo $sel;?> ><?php echo $ARRAY['description']." : ".$ARRAY['ip']; ?></option><?php 
		}
	} else { ?>
		
		<?php 
		$ID = $ARRAY['id'];
		$SQL = "SELECT vid, description, ip, mask FROM controlcenter.interface WHERE vid != '0' AND id_iface = '$ID' ORDER BY name";
		$RSOBJ = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSI005F"));
		$OBJ = mysql_fetch_array($RSOBJ);
		$cor1 = 1;
		if(mysql_affected_rows() != 0) { ?>
			<optgroup label="<?php echo $ARRAY['description']; ?>">
			<?php
			do { 
				if ($ITEMID == $OBJ['vid']) {
					$sel = 'selected="selected"';
				} else {
					$sel = "";
				}
				if(!empty($OBJ['vid'])){
			?>
				<option <?php if ( $cor1 == 1 ){ echo 'style="background:'.$COLOR_LINE_SELECT.'"'; $cor1=0;}else{$cor1=1;}?> value="<?php echo $OBJ['vid'];?>" <?php echo $sel;?> ><?php echo $OBJ['vid']." - ".$OBJ['description']." : ".$OBJ['ip']; if(!empty($OBJ['mask'])){ echo " / ".$OBJ['mask'];} $cor=0; ?></option><?php 
				}
			} while($OBJ = mysql_fetch_array($RSOBJ)); ?>
		</optgroup>
		<?php }
		}
	}while ($ARRAY =  mysql_fetch_array($RS));?>
</select>
</form>
	</div>
<?php 
}?>
<div class="version_general">
<?php
echo $VERSIONCC;
?>
</div>

</div>
</body>
</html>
<?php
unset($_SESSION['ITEMID']);
unset($_SESSION['EX_DESCRIPTION']);
unset($_SESSION['EX_NAME']);
unset($_SESSION['EX_IP']);
unset($_SESSION['EX_MASK']);
unset($_SESSION['VID']);
?>