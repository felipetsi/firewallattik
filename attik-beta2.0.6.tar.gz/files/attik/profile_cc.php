<?php 
require_once('includes/control_session.php');

$DESTINATION_PAGE = "profile_run_cc.php";
$THISPAGE = "profile_cc.php";

// Load the profile of user autenticanted
$SQL = "SELECT create_profile, read_profile FROM controlcenter.profile WHERE ";
$SQL .= "id IN (SELECT id FROM controlcenter.profile WHERE id in ";
$SQL .= "(SELECT id_pro FROM controlcenter.user WHERE id = '$USER'))";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSP009F"));
$DATA_USER = mysql_fetch_array($RS);

// Load the item selected
if (!empty($_POST['list']))
{
	$_SESSION['ITEMID'] = $_POST['list'];
	$ITEMID = $_SESSION['ITEMID'];
} else {
	$ITEMID = $_SESSION['ITEMID'];
}
$_SESSION['ITEMDELETE'] = $ITEMID;
$ARRAY = explode("@",$ITEMID);
$IDP = $ARRAY[0];
$IDPF = $ARRAY[1];
$IDPV = $ARRAY[2];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title><?php echo $TITLE; ?></title>
<script language="javascript">
	var thispage = "profile_cc.php";
	var deletepage = "profile_delete_cc.php";
</script>
<link href="includes/style_cc.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
require_once('includes/top.php');
?>
<div id="main"> <!--Main-->
<?php require_once('cc_menu_configuration.php');?>
	<div id="contet_rigth"><?php
if ($DATA_USER['create_profile'] == 1) {

// Load the profile selected
$SQL = "SELECT * FROM controlcenter.profile WHERE id = '$IDP'";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSP010F"));
	//Auditor
	if ((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1))
	{
		auditor('ICCSP010S', $ADDRIP, $USER, '0');
	}
$ARRAY = mysql_fetch_array($RS);
$SQL = "SELECT * FROM controlcenter.profilefw WHERE id = '$IDPF'";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSP010F"));
$ARRAYF = mysql_fetch_array($RS);

$SQL = "SELECT * FROM controlcenter.profilevpn WHERE id = '$IDPV'";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSP010F"));
$ARRAYV = mysql_fetch_array($RS);
?>
<script language="javascript">
function confirmDeleteSelected()
{
	document.getElementById('background_transparent').style.display="inline";
	document.getElementById('box_delete').style.display="table";	
}
function yesdeleteSelected()
{
	window.location=deletepage;
}
function nodeleteSelected()
{
	document.getElementById('box_delete').style.display="none";
	document.getElementById('background_transparent').style.display="none";
}
function clickBackgroudTrabsparent()
{
	nodeleteSelected();
}
</script>
<div id="background_transparent" onclick="javascript:clickBackgroudTrabsparent();"></div>
<div id="box_delete"><?php echo("$S_WANT_DELETE?");?> 
	<div class="space_confirm_box">
		<input type="button" value="<?php echo $B_YES;?>" onclick="javascript:yesdeleteSelected();" />
		<input type="button" value="<?php echo $B_NO;?>" onclick="javascript:nodeleteSelected();" />
	</div>	
</div>

<!--Start add-->
<form class="insert_border" name="fobject" action="<?php echo $DESTINATION_PAGE;?>" method="post">
<input type="hidden" name="id" value="<?php echo $ARRAY['id']."@".$ARRAY['id_profw']."@".$ARRAY['id_provpn'];?>" />
<div class="title_general" > <?php echo $T_PROFILE; ?> </div>
<div align="right" class="left_name_2"><u><?php echo $F_NAME;?></u></div>
	<div> <input type="text" size="25" maxlength="20" name="name" value="<?php if(!empty($_SESSION['EX_NAME'])) { echo $_SESSION['EX_NAME'];} else { echo $ARRAY['name'];}?>" autocomplete="off"/></div>
<div class="sub_title"><?php echo $T_GENERAL_CONFIG;?></div>
<div align="right" class="left_name_2"><?php echo $F_CREATE_USER;?> </div>
	<div> <input type="checkbox" name="c_user" value="1" <?php if ($ARRAY['create_user'] == 1){ echo 'checked="checked"';}?> /></div>

<div align="right" class="left_name_2"><?php echo $F_READ_USER;?> </div>
	<div> <input type="checkbox" name="r_user" value="1" <?php if ($ARRAY['read_user'] == 1){ echo 'checked="checked"';}?> /></div>
	
<div align="right" class="left_name_2"><?php echo $F_CREATE_PROFILE;?> </div>
	<div> <input type="checkbox" name="c_profile" value="1" <?php if ($ARRAY['create_profile'] == 1){ echo 'checked="checked"';}?> /></div>

<div align="right" class="left_name_2"><?php echo $F_READ_PROFILE;?> </div>
	<div> <input type="checkbox" name="r_profile" value="1" <?php if ($ARRAY['read_profile'] == 1){ echo 'checked="checked"';}?> /></div>
<div align="right" class="left_name_2"><?php echo $F_READ_LOG;?> </div>
	<div> <input type="checkbox" name="r_log" value="1" <?php if ($ARRAY['read_log'] == 1){ echo 'checked="checked"';}?> /></div>
<div align="right" class="left_name_2"><?php echo $F_CHANGE_CONFIG;?> </div>
	<div> <input type="checkbox" name="c_config" value="1" <?php if ($ARRAY['change_config'] == 1){ echo 'checked="checked"';}?> /></div>
<div class="sub_title"><?php echo $T_PROFILEFIREWALL;?></div>
<div align="right" class="left_name_2"><?php echo $F_CREATE_RULE;?> </div>
	<div> <input type="checkbox" name="c_rule" value="1" <?php if ($ARRAYF['create_rule'] == 1){ echo 'checked="checked"';}?> /></div>

<div align="right" class="left_name_2"><?php echo $F_READ_RULE;?> </div>
	<div> <input type="checkbox" name="r_rule" value="1" <?php if ($ARRAYF['read_rule'] == 1){ echo 'checked="checked"';}?> /></div>

<div align="right" class="left_name_2"><?php echo $F_READ_REPORT;?> </div>
	<div> <input type="checkbox" name="r_report" value="1" <?php if ($ARRAYF['read_report'] == 1){ echo 'checked="checked"';}?> /></div>
	
<div align="right" class="left_name_2"><?php echo $F_CREATE_NET;?> </div>
	<div> <input type="checkbox" name="c_net" value="1" <?php if ($ARRAYF['create_net'] == 1){ echo 	'checked="checked"';}?> /></div>
			
<div align="right" class="left_name_2"><?php echo $F_READ_NET;?> </div>
	<div> <input type="checkbox" name="r_net" value="1" <?php if ($ARRAYF['read_net'] == 1){ echo 'checked="checked"';}?> /></div>

<div align="right" class="left_name_2"><?php echo $F_CREATE_PROTOCOL;?> </div>
	<div> <input type="checkbox" name="c_protocol" value="1" <?php if ($ARRAYF['create_protocol'] == 1){ echo 'checked="checked"';}?> /></div>
	
<div align="right" class="left_name_2"><?php echo $F_READ_PROTOCOL;?> </div>
	<div> <input type="checkbox" name="r_protocol" value="1" <?php if ($ARRAYF['read_protocol'] == 1){ echo 'checked="checked"';}?> /></div>
<?php /*
<div align="right" class="left_name_2"><?php echo $F_MOD_PROXY;?> </div>
	<div> <input type="checkbox" name="m_proxy" value="1" <?php if ($ARRAY['mod_proxy'] == 1){ echo 'checked="checked"';}?> /></div>

<div align="right" class="left_name_2"><?php echo $F_MOD_IDS;?> </div>
	<div> <input type="checkbox" name="m_ids" value="1" <?php if ($ARRAY['mod_ids'] == 1){ echo 'checked="checked"';}?> /></div>
	
<div align="right" class="left_name_2"><?php echo $F_MOD_SERV_MAIL;?> </div>
	<div> <input type="checkbox" name="m_serv_mail" value="1" <?php if ($ARRAY['mod_serv_mail'] == 1){ echo 	'checked="checked"';}?> /></div>
			
<div align="right" class="left_name_2"><?php echo $F_MOD_SMTP_RELAY;?> </div>
	<div> <input type="checkbox" name="m_mail_relay" value="1" <?php if ($ARRAY['mod_smtp_relay'] == 1){ echo 'checked="checked"';}?> /></div>

<div align="right" class="left_name_2"><?php echo $F_MOD_WEB;?> </div>
	<div> <input type="checkbox" name="m_web" value="1" <?php if ($ARRAY['mod_web'] == 1){ echo 'checked="checked"';}?> /></div>*/?>

<div class="sub_title"><?php echo $T_PROFILEVPN;?></div>
<div align="right" class="left_name_2"><?php echo $F_MOD_VPN_CREATE;?> </div>
	<div> <input type="checkbox" name="c_vpn" value="1" <?php if ($ARRAYV['create_conn'] == 1){ echo 'checked="checked"';}?> /></div>	
<div align="right" class="left_name_2"><?php echo $F_MOD_VPN_READ;?> </div>
	<div> <input type="checkbox" name="r_vpn" value="1" <?php if ($ARRAYV['read_conn'] == 1){ echo 'checked="checked"';}?> /></div>	


<script language="javascript">
function selectAll()
{
	document.fobject.c_rule.checked = true;
	document.fobject.r_rule.checked = true;
	document.fobject.r_report.checked = true;
	document.fobject.r_net.checked = true;
	document.fobject.c_net.checked = true;
	document.fobject.c_protocol.checked = true;
	document.fobject.r_protocol.checked = true;
	
	document.fobject.c_user.checked = true;
	document.fobject.r_user.checked = true;
	document.fobject.c_profile.checked = true;
	document.fobject.r_profile.checked = true;
	document.fobject.r_log.checked = true;
	document.fobject.c_config.checked = true;
	document.fobject.c_vpn.checked = true;
	document.fobject.r_vpn.checked = true;
}
function unSelectAll()
{
	document.fobject.c_rule.checked = false;
	document.fobject.r_rule.checked = false;
	document.fobject.r_report.checked = false;
	document.fobject.r_net.checked = false;
	document.fobject.c_net.checked = false;
	document.fobject.c_protocol.checked = false;
	document.fobject.r_protocol.checked = false;
	
	document.fobject.c_user.checked = false;
	document.fobject.r_user.checked = false;
	document.fobject.c_profile.checked = false;
	document.fobject.r_profile.checked = false;
	document.fobject.r_log.checked = false;
	document.fobject.c_config.checked = false;
	document.fobject.c_vpn.checked = false;
	document.fobject.r_vpn.checked = false;
}
</script>
<div class="title_general">		
	<input type="submit" value="<?php if (empty($ARRAY['id'])){ echo $B_ADD_NEW;} else { echo $B_UPDATE;}?>" />
	<input type="button" value="<?php echo $B_CLEAR;?>" onclick="javascript:window.location=thispage" />
	<?php
	if (($DATA_USER['create_profile'] == 1)&&($DATA_USER['read_profile'] == 1)){?>
	<input type="button" value="<?php echo $B_DELETE;?>" onClick="javascript:confirmDeleteSelected();" />
	<?php }?>
	<input type="button" value="<?php echo $L_SELECTALL;?>" onclick="javascript:selectAll();" />
	<input type="button" value="<?php echo $L_UNSELECTALL;?>" onclick="javascript:unSelectAll();" /> 
</div>
</form>
<!--End add-->
<?php }
if ($DATA_USER['read_profile'] == 1) {
?>
<!-- Start list-->
<div class="title_general"><?php echo $T_PROFILE_LIST?></div>
<form class="insert_border" action="<?php echo $THISPAGE;?>" method="post" name="objselect">
<select class="select_list_2" name="list" size="20" ondblclick="javascript:document.objselect.submit()" >
<?php
	$SQL = "SELECT * FROM controlcenter.profile ORDER BY name";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSP012F"));
	$ARRAY = mysql_fetch_array($RS);
	$cor = 1;	
	do{
	if ($IDP == $ARRAY['id']) {
		$sel = 'selected="selected"';
	} else {
			$sel = "";
	}
	
	if ( $cor == 1 )
		{
		?>
		<option value="<?php echo $ARRAY['id']."@".$ARRAY['id_profw']."@".$ARRAY['id_provpn'];?>" <?php echo $sel;?> ><?php echo $ARRAY['name']; $cor=0;?></option>
		<?php 
		} else { ?>
		<option style="background:<?php echo $COLOR_LINE_SELECT;?>" value="<?php echo $ARRAY['id']."@".$ARRAY['id_profw']."@".$ARRAY['id_provpn'];?>" <?php echo $sel;?> ><?php echo $ARRAY['name']; $cor=1;?></option>
		<?php
		} 
	}while ($ARRAY =  mysql_fetch_array($RS));?>
</select>
<?php 
}?>
</form>
</div> <!--content rigth-->
<div class="version_general">
<?php
echo $VERSIONCC;
?>
</div>
</div> <!--main-->
</body>
</html>
<?php
unset($_SESSION['EX_NAME']);
unset($_SESSION['SHOW_MSG']);
unset($_SESSION['ITEMID']);
?>