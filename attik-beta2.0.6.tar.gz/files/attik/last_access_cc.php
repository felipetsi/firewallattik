<?php 
require_once('includes/control_session.php');

$THISPAGE = "last_access_cc.php";

// Load the profile of user autenticanted
$SQL = "SELECT read_log FROM controlcenter.profile WHERE ";
$SQL .= "id IN (SELECT id_pro FROM controlcenter.user WHERE id = '$USER')";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSC001F"));
$DATA_USER = mysql_fetch_array($RS);

// Load the item selected
$STARTINTERVAL = substr(trim(addslashes($_POST['startInterval'])),0,10);
$ENDINTERVAL = substr(trim(addslashes($_POST['endInterval'])),0,10);

$ARRAYSTART = explode("/",$STARTINTERVAL);
$ARRAYEND = explode("/",$ENDINTERVAL);

if ( ((sizeof($ARRAYSTART) < 3) || (sizeof($ARRAYEND) < 3)) && (!empty($STARTINTERVAL) || !empty($ENDINTERVAL)) ||
	 ( ($ARRAYSTART[2] > 3000) || ($ARRAYSTART[1] > 31) || ($ARRAYSTART[0] > 12) ) )
{
	$_SESSION['SHOW_MSG'] = 'ME_DATEINVALID';
	$_SESSION['EX_STARTINTERVAL'] = $STARTINTERVAL;
	$_SESSION['EX_ENDINTERVAL'] = $ENDINTERVAL;
	header("Location:$THISPAGE");
} else {
	$DATE_S = "$ARRAYSTART[2]-$ARRAYSTART[0]-".($ARRAYSTART[1]-1);
	$DATE_E = "$ARRAYEND[2]-$ARRAYEND[0]-".($ARRAYEND[1]+1);
	if (!empty($STARTINTERVAL) && !empty($ENDINTERVAL)){
		// Just mount the String SQL
		$SQLLASTACCESS = "SELECT * FROM controlcenter.log_access WHERE moment > '$DATE_S' AND moment < '$DATE_E' ORDER BY moment";
	} else {
		$SQLLASTACCESS = "SELECT * FROM controlcenter.log_access ORDER BY moment";
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $TITLE; ?></title>
<script language="javascript">
function setFocus(){
	document.formDate.startInterval.focus();
}
function dateFormat(obj){
	if ((obj.value.length == 2) || (obj.value.length == 5))
	{
		obj.value = obj.value + "/";
	}
}
</script>
<link href="includes/style_cc.css" rel="stylesheet" type="text/css" />
</head>
<body onload="javascript: setFocus();">
<?php
require_once('includes/top.php'); 
?>
<div id="main"> <!--Main-->
<?php require_once('cc_menu_configuration.php');?>
	<div id="contet_rigth"><?php
if ($DATA_USER['read_log'] == 1) {
?>
<!--Start add-->
<form class="insert_border" action="<?php echo $THISPAGE;?>" method="post" name="formDate">
<div class="title_general" > <?php echo $T_LAST_ACCESS; ?> </div>
<div align="right" class="left_name_1"><font class="title_option"><?php echo $F_INTERVAL;?> </font> </div>
	<div>
		<input type="text" name="startInterval" onkeypress="javascript: dateFormat(this);" size="10" maxlength="10" value="<?php echo $_SESSION['EX_STARTINTERVAL'];?>" />
		<a href="javascript:void(0)" onClick="if(self.gfPop)gfPop.fPopCalendar(document.formDate.startInterval);return false;" HIDEFOCUS>
			<img name="cal" align="absmiddle" src="@img/calendar.gif" width="34" height="22" border="0">
		</a>
		<input type="text" name="endInterval" onkeypress="javascript: dateFormat(this);" size="10" maxlength="10" value="<?php echo $_SESSION['EX_ENDINTERVAL'];?>" />
		<a href="javascript:void(0)" onClick="if(self.gfPop)gfPop.fPopCalendar(document.formDate.endInterval);return false;" HIDEFOCUS>
			<img name="cal" align="absmiddle" src="@img/calendar.gif" width="34" height="22" border="0">
		</a>
		<input type="submit" value="<?php echo $L_FILTER;?>" />
	</div>
	<?php echo $S_JUST_NUMBER;?>
</form>

<iframe width=199 height=178 name="gToday:normal:agenda.js" id="gToday:normal:agenda.js" src="includes/calendar/ipopeng.php" scrolling="no" frameborder="0" style="visibility:visible; z-index:999; position:absolute; top:-500px; left:-500px;">
</iframe>

<!-- Start list-->
<div class="title_general"><?php echo $T_ACCESS_LIST; ?></div>
<select class="select_list_3" name="list" size="20">
<?php
	$RS = mysql_query($SQLLASTACCESS) or (die("$ME_OCCURREDEERRORINTERNAL ICCSC002F"));
	$ARRAY = mysql_fetch_array($RS);
	$cor = 1;	
	do{
		if(!empty($ARRAY['moment'])){
			?>
			<option
			<?php 
			if ($ARRAY['status'] == 0){
				if ($red == 0) {
					echo 'style="background-color:#FF3131;"'; $red = 1;
				} else {
					echo 'style="background-color:#FF0202;"'; $red = 0;
				}
			} else {
				if ($gree == 0) {
					echo 'style="background-color:#4EFF4E;"'; $gree = 1;
				} else {
					echo 'style="background-color:#00B700;"'; $gree = 0;
				}
			}?>	>
				<?php echo (formatData($ARRAY['moment'])." - ".$ARRAY['login']. " - "); if ($ARRAY['status'] == 0) { echo $S_FAIL;} else{echo $S_SUCESS;} $cor=0;?></option>
			<?php
		}
	}while ($ARRAY =  mysql_fetch_array($RS));?>
</select>
<?php 
}?>
</div> <!--content rigth-->
<div class="version_general">
<?php
echo $VERSIONCC;
?>
</div>
</div> <!--Main-->
</body>
</html>
<?php
unset($_SESSION['EX_STARTINTERVAL']);
unset($_SESSION['EX_ENDINTERVAL']);
}
?>