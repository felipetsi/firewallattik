<?php 
require_once('includes/control_session.php');
require_once('includes/functions.php');
require('configuration/directory.php');
$DESTINATION_PAGE = "general_conf_cc.php";

$SUPORT = substr(trim(addslashes($_POST['suport'])),0,1);
$AUDIT = substr(trim(addslashes($_POST['audit'])),0,1);
$FIREWALL_STATE_FULL = substr(trim(addslashes($_POST['fw_state_full'])),0,1);
$RULE = substr(trim(addslashes($_POST['rule'])),0,1);
$BAKUP = substr(trim(addslashes($_POST['backup'])),0,1);
$KEEP_BAKUP = substr(trim(addslashes($_POST['keepBackup'])),0,20);
$LANG = trim(addslashes($_POST['language']));
$LOG = substr(trim(addslashes($_POST['log'])),0,20);
$GRAPH = substr(trim(addslashes($_POST['graph'])),0,20);
$PASSWORD = substr(trim(addslashes($_POST['password'])),0,40);
$REPASSWORD = substr(trim(addslashes($_POST['repassword'])),0,40);
$PORTHTTPSER = substr(trim(addslashes($_POST['porthttpserver'])),0,5);
$TITLE_NAME_ADITIONAL = substr(trim(addslashes($_POST['title_aditional'])),0,20);
$TIME_OUT_CONN_DATA_BASE = substr(trim(addslashes($_POST['timeoutconnbd'])),0,4);

if ($PASSWORD != $REPASSWORD){
	$_SESSION['SHOW_MSG'] = 'ME_DIFFERENT_PASSWORD';
	header("Location:$DESTINATION_PAGE");
} else {
	if ($SUPORT == "") {
		$SUPORT = 0;	
	}
	if ($AUDIT == "") {
		$AUDIT = 0;	
	}
	if ($FW_STATE_FULL == "") {
		$FW_STATE_FULL = 0;	
	}
	if ($RULE == "") {
		$RULE = 0;	
	}
	if ($LANG == "") {
		$LANG = "english";	
	}
	if (empty($LOG)){
		$LOG = "-1";
	}
	if (empty($GRAPH)){
		$GRAPH = "-1";
	}
	if ($BAKUP == "") {
		$BAKUP = 1;
	}
	if (empty($KEEP_BAKUP)) {
		$KEEP_BAKUP = "-1";
	}
	
	if(($INCTI_SUPORT_REMOTE == 1) && ($SUPORT == 0))
	{
		$COMMAND = "sed -i 's/\$INCTI_SUPORT_REMOTE = 1/\$INCTI_SUPORT_REMOTE = 0/' ";
		$COMMAND .= "configuration/variablegeneral.php";
		exec($COMMAND,$RETURN);
			if (!empty($RETURN) && ($LOG_AUDITOR == 1))
			{
				auditor('ICCXG003F', $ADDRIP, $USER, '0');
			}
		inctiRemotoSuport(0);
	}elseif(($INCTI_SUPORT_REMOTE == 0) && ($SUPORT == 1)){	
		$COMMAND = "sed -i 's/\$INCTI_SUPORT_REMOTE = 0/\$INCTI_SUPORT_REMOTE = 1/' ";
		$COMMAND .= "configuration/variablegeneral.php";
		exec($COMMAND,$RETURN);
			if (!empty($RETURN) && ($LOG_AUDITOR == 1))
			{
				auditor('ICCXG005F', $ADDRIP, $USER, '0');
			}
		inctiRemotoSuport(1);
	}
	
	if(($LOG_AUDITOR == 1) && ($AUDIT == 0))
	{	
		$COMMAND = "sed -i 's/\$LOG_AUDITOR = 1/\$LOG_AUDITOR = 0/' ";
		$COMMAND .= "configuration/variablegeneral.php";
		exec($COMMAND,$RETURN);
			if (!empty($RETURN) && ($LOG_AUDITOR == 1))
			{
				auditor('ICCXG007F', $ADDRIP, $USER, '0');
			}
	}elseif(($LOG_AUDITOR == 0) && ($AUDIT == 1)){
		$COMMAND = "sed -i 's/\$LOG_AUDITOR = 0/\$LOG_AUDITOR = 1/' ";
		$COMMAND .= "configuration/variablegeneral.php";
		exec($COMMAND,$RETURN);
			if (!empty($RETURN) && ($LOG_AUDITOR == 1))
			{
				auditor('ICCXG009F', $ADDRIP, $USER, '0');
			}
	}
	
	if(($FW_STATE_FULL == 1) && ($FIREWALL_STATE_FULL == 0))
	{	
		$COMMAND = "sed -i 's/\$FW_STATE_FULL = 1/\$FW_STATE_FULL = 0/' ";
		$COMMAND .= "configuration/variablegeneral.php";
		exec($COMMAND,$RETURN);
			if (!empty($RETURN) && ($LOG_AUDITOR == 1))
			{
				auditor('-', $ADDRIP, $USER, '0');
			}
	}elseif(($FW_STATE_FULL == 0) && ($FIREWALL_STATE_FULL == 1)){
		$COMMAND = "sed -i 's/\$FW_STATE_FULL = 0/\$FW_STATE_FULL = 1/' ";
		$COMMAND .= "configuration/variablegeneral.php";
		exec($COMMAND,$RETURN);
			if (!empty($RETURN) && ($LOG_AUDITOR == 1))
			{
				auditor('-', $ADDRIP, $USER, '0');
			}
	}

	if(($APPLY_RULE_REAL_TIME == 1) && ($RULE == 0))
	{	
		$COMMAND = "sed -i 's/\$APPLY_RULE_REAL_TIME = 1/\$APPLY_RULE_REAL_TIME = 0/' ";
		$COMMAND .= "configuration/variablegeneral.php";
		exec($COMMAND,$RETURN);
			if (!empty($RETURN) && ($LOG_AUDITOR == 1))
			{
				auditor('ICCXG011F', $ADDRIP, $USER, '0');
			}
	}elseif(($APPLY_RULE_REAL_TIME == 0) && ($RULE == 1)){
		$COMMAND = "sed -i 's/\$APPLY_RULE_REAL_TIME = 0/\$APPLY_RULE_REAL_TIME = 1/' ";
		$COMMAND .= "configuration/variablegeneral.php";
		exec($COMMAND,$RETURN);
			if (!empty($RETURN) && ($LOG_AUDITOR == 1))
			{
				auditor('ICCXG013F', $ADDRIP, $USER, '0');
			}
	}
	
	if($CREATE_BACKUP_AUTO != $BAKUP)
	{
		$COMMAND = "sed -i 's/\$CREATE_BACKUP_AUTO = "."$CREATE_BACKUP_AUTO"."/\$CREATE_BACKUP_AUTO = "."$BAKUP"."/' ";
		$COMMAND .= "configuration/variablegeneral.php";
		exec($COMMAND,$RETURN);
			if (!empty($RETURN) && ($LOG_AUDITOR == 1))
			{
				auditor('ICCXG016F', $ADDRIP, $USER, '0');
			}
	}

	if($TIME_TO_KEEP_BACKUP != $KEEP_BAKUP)
	{
		$COMMAND = "sed -i 's/\$TIME_TO_KEEP_BACKUP = "."$TIME_TO_KEEP_BACKUP"."/\$TIME_TO_KEEP_BACKUP = "."$KEEP_BAKUP"."/' ";
		$COMMAND .= "configuration/variablegeneral.php";
		exec($COMMAND,$RETURN);
			if (!empty($RETURN) && ($LOG_AUDITOR == 1))
			{
				auditor('ICCXG016F', $ADDRIP, $USER, '0');
			}
	}
	
	if($DEFAULT_LANGUAGE != $LANG)
	{
		$COMMAND = "sed -i 's/\$DEFAULT_LANGUAGE = \""."$DEFAULT_LANGUAGE"."\"/\$DEFAULT_LANGUAGE = \""."$LANG"."\"/' ";
		$COMMAND .= "configuration/variablegeneral.php";
		exec($COMMAND,$RETURN);
			if (!empty($RETURN) && ($LOG_AUDITOR == 1))
			{
				auditor('ICCXG015F', $ADDRIP, $USER, $LANG);
			}
	}
	if($TIME_TO_KEEP_LOG != $LOG)
	{
		$COMMAND = "sed -i 's/\$TIME_TO_KEEP_LOG = "."$TIME_TO_KEEP_LOG"."/\$TIME_TO_KEEP_LOG = "."$LOG"."/' ";
		$COMMAND .= "configuration/variablegeneral.php";
		exec($COMMAND,$RETURN);
			if (!empty($RETURN) && ($LOG_AUDITOR == 1))
			{
				auditor('ICCXG016F', $ADDRIP, $USER, $LOG);
			}
	}
	
	if($TIME_TO_KEEP_GRAPH != $GRAPH)
	{
		$COMMAND = "sed -i 's/\$TIME_TO_KEEP_GRAPH = "."$TIME_TO_KEEP_GRAPH"."/\$TIME_TO_KEEP_GRAPH = "."$GRAPH"."/' ";
		$COMMAND .= "configuration/variablegeneral.php";
		exec($COMMAND,$RETURN);
			if (!empty($RETURN) && ($LOG_AUDITOR == 1))
			{
				auditor('ICCXG018F', $ADDRIP, $USER, $GRAPH);
			}
	}
	if(!empty($PASSWORD) && ($PASSWORD == $REPASSWORD))
	{
		require_once('/var/.incti/.access/.access_exec.php');
		$COMMAND = "mysql -u inctiuser -p$INCTIPW -e \"SET PASSWORD FOR inctiuser@localhost = PASSWORD( '$PASSWORD' )\"";
		exec($COMMAND,$RETURN);
			if (!empty($RETURN) && ($LOG_AUDITOR == 1))
			{
				auditor('ICCXG020F', $ADDRIP, $USER, $GRAPH);
			}
		$COMMAND = "echo '<?php \$INCTIPW = \"$PASSWORD\"; ?>' > /var/.incti/.access/.access_exec.php";
		exec($COMMAND,$RETURN);
			if (!empty($RETURN) && ($LOG_AUDITOR == 1))
			{
				auditor('ICCXG020F', $ADDRIP, $USER, $GRAPH);
			}
	}
	if(empty($PORTHTTPSER)){
		$PORTHTTPSER = "80";
	}
	if(!empty($PORTHTTPSER))
	{
		$COMMAND = "echo $PORTHTTPSER  > $FILEPORTHTTPSERVER";
		exec($COMMAND,$RETURN);
			if (!empty($RETURN) && ($LOG_AUDITOR == 1))
			{
				auditor('ICCXG002F', $ADDRIP, $USER, $GRAPH);
			}
	}
	
	if(!empty($TIME_OUT_CONN_DATA_BASE))
	{
		$COMMAND = "sed -i 's/\$TIME_OUT_CONN_DB = "."$TIME_OUT_CONN_DB"."/\$TIME_OUT_CONN_DB = "."$TIME_OUT_CONN_DATA_BASE"."/' ";
		$COMMAND .= "configuration/variablegeneral.php";
		exec($COMMAND,$RETURN);
			if (!empty($RETURN) && ($LOG_AUDITOR == 1))
			{
				auditor('ICCXG021F', $ADDRIP, $USER, '0');
			}
	}
	
	$COMMAND = "sed -i '/\$NAME_ADD_TITLE = \"/Id' configuration/variablegeneral.php ";
	exec($COMMAND,$RETURN);
	$COMMAND = "sed -i '4i\$NAME_ADD_TITLE = \"$TITLE_NAME_ADITIONAL\";' configuration/variablegeneral.php ";
	exec($COMMAND,$RETURN);
		if (!empty($RETURN) && ($LOG_AUDITOR == 1))
		{
			auditor('ICCXG021F', $ADDRIP, $USER, $GRAPH);
		}
		
	if(empty($RETURN)) {
		$_SESSION['SHOW_MSG'] = 'F_SUCESS';
	}
	header("Location:$DESTINATION_PAGE");
}
?>