<?php 
require_once('includes/control_session.php');
require('configuration/directory.php');
$THISPAGE = "failover_cc.php";
$DESTINATION_PAGE = "failover_run_cc.php";

// Load the profile of user autenticanted
$SQL = "SELECT change_config FROM controlcenter.profile WHERE ";
$SQL .= "id IN (SELECT id_pro FROM controlcenter.user WHERE id = '$USER')";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSU001F"));
$DATA_USER = mysql_fetch_array($RS);

// Load the item selected
if (!empty($_POST['list']))
{
	$_SESSION['ITEMID'] = $_POST['list'];
	$ITEMID = $_SESSION['ITEMID'];
} else {
	$ITEMID = $_SESSION['ITEMID'];
}
if(($IP != "") && (verifyIp($IP) != "ok")) {
	$_SESSION['SHOW_MSG'] = 'ME_INVALIDIP';
} else {
	$_SESSION['ITEMDELETE'] = $ITEMID;
}
$DOWN_IFACE = trim(addslashes($_POST['ifacedown']));
if ($DOWN_IFACE == 1)
{
	$COMMAND = "sudo killall ucarp";
	exec($COMMAND,$RETURN);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $TITLE; ?></title>
<script language="javascript">
	var thispage = "failover_cc.php";
	var deletepage = "failover_delete_cc.php";
</script>
<link href="includes/style_cc.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
require_once('includes/top.php'); 
?>
<div id="main"> <!--Main-->
<?php require_once('cc_menu_configuration.php');?>
	<div id="contet_rigth"><?php
if ($DATA_USER['change_config'] == 1) {

// Load the user selected
$SQL = "SELECT * FROM controlcenter.failover WHERE virtual_ip = '$ITEMID'";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSN004F"));
	//Auditor
	if ((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1))
	{
		auditor('ICCSU002S', $ADDRIP, $USER, '0');
	}
$DATA = mysql_fetch_array($RS);
?>
<script language="javascript">
function confirmDeleteSelected()
{
	document.getElementById('background_transparent').style.display="inline";
	document.getElementById('box_delete').style.display="table";	
}
function yesdeleteSelected()
{
	window.location=deletepage;
}
function nodeleteSelected()
{
	document.getElementById('box_delete').style.display="none";
	document.getElementById('background_transparent').style.display="none";
}
function clickBackgroudTrabsparent()
{
	nodeleteSelected();
}
function down_iface()
{
	document.formdown.submit();
}
</script>
<div id="background_transparent" onclick="javascript:clickBackgroudTrabsparent();"></div>
<div id="box_delete"><?php echo("$S_WANT_DELETE?");?> 
	<div class="space_confirm_box">
		<input type="button" value="<?php echo $B_YES;?>" onclick="javascript:yesdeleteSelected();" />
		<input type="button" value="<?php echo $B_NO;?>" onclick="javascript:nodeleteSelected();" />
	</div>	
</div>
<!--Start add-->
<form class="insert_border" action="<?php echo $DESTINATION_PAGE;?>" method="post">

<input type="hidden" name="id" value="<?php echo $ITEMID;?>" />
		<div class="title_general"><?php echo $T_FAILOVER_INFO;?></div>

		<div id="object">
			<div align="right" class="left_name"><u><?php echo $F_INTERFACE;?></u></div>
			<div> 
				<select name="interface">
					<option> </option>
					<?php
					$SQL = "SELECT name,description FROM controlcenter.interface ORDER BY name";
					$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSN004F"));
					$ARRAY = mysql_fetch_array($RS);
					$cor = 1;	
					do{
						if (($ARRAY['name'] == $DATA['name_ifa']) || ($_SESSION['NAME_IFACE'] == $ARRAY['name'])) {
							$sel = 'selected="selected"';
						} else {
							$sel = "";
						}
					
						?>
						<option value="<?php echo $ARRAY['name'];?>" <?php echo $sel; if($cor==1){echo 'style="background:'.$COLOR_LINE_SELECT.'"'; $cor=0;}else($cor=1)?> ><?php echo $ARRAY['description'];?>
						</option>
						<?php 
					}while ($ARRAY = mysql_fetch_array($RS));?>
				</select>
			</div>
				
			<div align="right" class="left_name"><u><?php echo $F_IDENTIFICATION;?></u></div>
				<div>
				<select name="identification">
					<option> </option>
						<?php
						$cor = 1;
						for ($COUNT = 1; $COUNT < 256; $COUNT++)
						{
							if (($COUNT == $DATA['identification'])||($_SESSION['IDENTIFICATION'] == $COUNT)) {
								$sel = 'selected="selected"';
							} else {
									$sel = "";
							}
							?>
							<option value="<?php echo $COUNT;?>" <?php if ( $cor == 1 ){echo 'style="background:'."$COLOR_LINE_SELECT".'"'; $cor=0;}else{$cor=1;} echo $sel;?> ><?php echo $COUNT;?>
							</option>
						<?php
						} ?>
				</select>
				</div>
				
			<div align="right" class="left_name"><u><?php echo $F_SKEW;?></u></div>
				<div>
				<select name="skew">
					<option> </option>
						<?php
						$cor = 1;
						for ($COUNT = 1; $COUNT < 256; $COUNT++)
						{
							if (($COUNT == $DATA['skew'])||($_SESSION['SKEW'] == $COUNT)) {
								$sel = 'selected="selected"';
							} else {
									$sel = "";
							}
							?>
							<option value="<?php echo $COUNT;?>" <?php echo $sel;  if ( $cor == 1 ){echo ' style="background:'."$COLOR_LINE_SELECT".'"'; $cor=0;}else{$cor=1;} ?> ><?php echo $COUNT;?>
							</option>
						<?php
						} ?>
				</select>
				</div>

			<div align="right" class="left_name"><?php echo $F_MASTER;?></div>
				<select name="master">
					<option> </option>
						<?php
						$cor = 1;
						for ($COUNT = 1; $COUNT < 256; $COUNT++)
						{
							if (($COUNT == $DATA['master'])||($_SESSION['MASTER'] == $COUNT)) {
								$sel = 'selected="selected"';
							} else {
									$sel = "";
							}
							?>
							<option value="<?php echo $COUNT;?>" <?php echo $sel;  if ( $cor == 1 ){echo ' style="background:'."$COLOR_LINE_SELECT".'"'; $cor=0;}else{$cor=1;} ?> ><?php echo $COUNT;?>
							</option>
						<?php
						} ?>
				</select>
				</div>
												
			<div align="right" class="left_name"><u><?php echo $F_VIRTUAL_IP;?></u></div>
				<div> <input type="text" size="20" maxlength="40" name="virtual_ip" value="<?php if (!empty($_SESSION['VIRTUALIP'])){echo $_SESSION['VIRTUALIP'];} else {echo $DATA['virtual_ip'];}?>" /></div>

			<div align="right" class="left_name"><u>*<?php echo $F_PASSWORD;?></u></div>
				<div> <input type="password" size="20" maxlength="40" name="password" value="<?php if (!empty($_SESSION['PASSWORD'])){echo $_SESSION['PASSWORD'];}?>" /></div>
				
			<div align="right" class="left_name"><u>*<?php echo $F_REPASSWORD;?></u></div>
				<div> <input type="password" size="20" maxlength="40" name="repassword" value="<?php if (!empty($_SESSION['PASSWORD'])){echo $_SESSION['PASSWORD'];}?>" /></div>

<div class="title_general">
	<input type="submit" value="<?php if (empty($DATA['name_ifa'])){ echo $B_ADD_NEW;} else { echo $B_UPDATE;}?>" />
	<input type="button" value="<?php echo $B_CLEAR;?>" onclick="javascript:window.location=thispage" />
	<input type="button" value="<?php echo $B_DELETE;?>" onClick="javascript:confirmDeleteSelected();" />
	<?php if (verifyIfaceFailoverUpDown() == "ok"){ echo '<input type="button" value="'.$B_DONW.'" onClick="javascript:down_iface();"/>';}?>
	<?php if(!empty($ITEMID)){ ?> <font id="small_alert">* <?php echo $S_FILL_JUST_CHANGE;?></font><?php }?>
</div>
</form>
<form action="<?php echo $THISPAGE;?>" method="post" name="formdown">
	<input type="hidden" name="ifacedown" value="1" />
</form>
<!--End add-->
<?php }
if ($DATA_USER['change_config'] == 1) {
?>
<!-- Start list-->
<div class="title_general"><?php echo $$T_FAILOVER_LIST;?></div>
<form class="insert_border" action="<?php echo $THISPAGE;?>" method="post" name="objselect">
<select class="select_list_1" name="list" size="20" onclick="javascript:document.objselect.submit()">
<?php
	$SQL = "SELECT * FROM controlcenter.failover ORDER BY virtual_ip";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCFS001F"));
	$ARRAY = mysql_fetch_array($RS);
	$cor = 0;	
	do{
	if(!empty($ARRAY['virtual_ip'])){
		if ($ITEMID == $ARRAY['virtual_ip']) {
			$sel = 'selected="selected"';
		} else {
				$sel = "";
		}?>
			<option <?php if(verifyIfaceFailover($ARRAY['virtual_ip']) == "ok"){ if($cor==1){ echo 'style="background-color:'.$COLOR_LINE_SELECT.'"'; $cor=0;}else{$cor=1;}}else{echo 'class="line_obj_list_fail"';}?>  value="<?php echo $ARRAY['virtual_ip'];?>" <?php echo $sel;?> ><?php echo $ARRAY['virtual_ip']; echo " - ".file_get_contents($FILEFAILOVERLOG);?></option>
			<?php
		}
	}while ($ARRAY =  mysql_fetch_array($RS));?>
</select>
<?php 
}?>
</form>
</div> <!--content rigth-->
<div class="version_general">
<?php
echo $VERSIONCC;
?>
</div>
</div> <!--Main-->
</body>
</html>
<?php
unset($_SESSION['SHOW_MSG']);
unset($_SESSION['ITEMID']);
unset($_SESSION['ENABLE']);
unset($_SESSION['NAME_IFACE']);
unset($_SESSION['VID_IFACE']);
unset($_SESSION['IDENTIFICATION']);
unset($_SESSION['SKEW']);
unset($_SESSION['PRIORITY']);
unset($_SESSION['INTERVAL']);
unset($_SESSION['PASSWORD']);
unset($_SESSION['REPASSWORD']);
unset($_SESSION['VIRTUALIP']);
unset($_SESSION['MASTER']);
?>