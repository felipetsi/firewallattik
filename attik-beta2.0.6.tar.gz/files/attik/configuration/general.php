<?php //This file content the variables general, selected for like the of administrator.
require_once('variablegeneral.php');

// Define the name aditional
$IPSERVER = $_SERVER['SERVER_ADDR'];
if(empty($NAME_ADD_TITLE)){
	$NAME_ADD_TITLE = $IPSERVER;
}

// The color for line of object HTML select
$COLOR_LINE_SELECT = "#e5e5cb";

// Titles
$TITLE = "..:: @ttik - $NAME_ADD_TITLE ::..";
$TITLE_FW = "..:: @ttik : Firewall - $NAME_ADD_TITLE ::..";
$TITLE_PX = "..:: @ttik : Proxy - $NAME_ADD_TITLE::..";
$TITLE_VPN = "..:: @ttik : Virtual Private Network (VPN) - $NAME_ADD_TITLE::..";
$TITLE_NAME_SOLUTION = "@ttik Security Solution";

//Define the first page of default
$DEFAULT_PAGE_MOD = "modules/firewall/firewall.php";
$DEAFULT_CONF_CC = "/attik/profile_cc.php";
$DEFAULT_PAGE_FW = "rule_fw.php";
$DEFAULT_PAGE_PW = "rule_px.php";

//Version and name of Control Center
$VERSIONCC = "@ttik -Beta - 2.0.6 _ 2013";

// Root diretory 
$ROOT_DIR = "/var/www/attik"

?>
