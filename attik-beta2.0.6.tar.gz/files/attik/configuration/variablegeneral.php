<?php 
//Pemit changes
//Title set
$NAME_ADD_TITLE = "";
//Enable remote suportt
$INCTI_SUPORT_REMOTE = 0;
//Content the default language.
$DEFAULT_LANGUAGE = "portugues";

// LOGs to auditor
$LOG_AUDITOR = 0;

//Apply rule in real time
$APPLY_RULE_REAL_TIME = 0;

//Time to keep log in days
$TIME_TO_KEEP_LOG = -1;

//Time to keep graphs in days
$TIME_TO_KEEP_GRAPH = -1;

//Create backup automaticaly
$CREATE_BACKUP_AUTO = 1;
//Keep backup to time in day
$TIME_TO_KEEP_BACKUP = -1;

//Time to expire session in minutes
$TIME_TO_EXPIRE_SESSION = 5;

//Time out to connection in data base
$TIME_OUT_CONN_DB = 1;

//Time out to connection in data base
$FW_STATE_FULL = 1;

?>
