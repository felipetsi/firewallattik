<?php
$DIRROTINES = "/var/.incti/.rot";
$DIRPASSWDDB = "/var/.incti/.access";
$DIRBACKUPDB = "/var/.incti/backup";

$FILEPASSWDDB = "$DIRPASSWDDB/.access_exec.php";
$FILEFAILOVERCONF = "/var/.incti/.failover.conf";
$FILEVIPUP = "/var/.incti/.failover-up.sh";
$FILEVIPDOWN = "/var/.incti/.failover-donw.sh";
$FILEFAILOVERLOG =  "/var/.incti/.failover.log";
$DIRHOMEPAGES = "/var/www/attik";
$FILEPORTHTTPSERVER = '/var/.incti/.access/httpd_port.php';
$FILEROUTESH = "/var/.incti/.route.sh";
$FILEPARTITIONINSTALED = "/var/.incti/partitioninstaled";
$FILELOGVPN="/var/.incti/.connection_vpn.log";
?>
