<?php //This file content the list IP's IncTI Security.
$INCTI_IP_LIST = array(
	/*0 => "201.22.148.94"*/);
?>