<?php //Este arquivo cont�m a tradu��o do aplicativo em Portugu�s
//T�tulos
$T_CONNECTION_VPN = "Conex�o VPN";
$T_PHASE_I = "Fase I";
$T_PHASE_II = "Fase II";
$T_CONNECTION_VPN_LIST = "Lista de conex�es VPN";
$T_LEFT_IP = "IP da Interface Local";
$T_LEFT_SUBNET = "Rede Local";
$T_RIGHT_IP = "IP do Gateway da Direita";
$T_RIGHT_SUBNET = "Rede da Direita";
$T_AUTO = "M�todo Auto";
$T_NAME_CONNECTION = "Nome da conex�o";
$T_LOCAL_VPN_CONFIG = "Configura��o local";
$T_REMOTE_VPN_CONFIG = "Configura��o do gateway remoto";

//Campos
$F_LEFT_IP = "IP da interface local: ";
$F_LEFT_SUBNET = "Rede local: ";
$F_RIGHT_IP = "IP do gateway da direita: ";
$F_RIGHT_SUBNET = "Rede da direita: ";
$F_AUTO = "M�todo auto: ";
$F_PASSWORD = "Senha: ";

// Fase I
$F_METHOD_AUTHENTICATION = "Autentication mode: ";
$F_ALGORITHM_CRIPTO = "Criptography algorithm: ";
$F_ALGORITHM_HASH = "Integrity algorithm: ";
$F_LIFE_TIME_IKE = "Life time IKE: ";
$F_NEGOCIATTION_MODE = "Negociation mode: ";
$F_PERFECT_FORWARD_SECRECY = "Enable PFS: ";
// Fase II
$F_LIFE_TIME_IPSEC = "Life time IPSEC: ";
$F_RSA = "RSA";
$F_PSK = "PSK - Public shared key";
$F_CERTIFICATE = "Certification";

// Unit time
$SECOND = "Segundo";
$MINUTE = "Minuto";
$HOUR = "Hora";
$DAY = "Dia";

?>