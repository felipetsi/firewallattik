<?php //This file content the translation of application in English to reports of firewall module
//Texts
$REPORT_DAILY = "Observe o gr�fico di�rio.";
$REPORT_SERVICE = "Este gr�fico abaixo mostra a frequ�ncia dos protocolos que passaram pelo firewall.";
$T_HISTORY = "Historico";
$REFERENCEGRAPH = "Este gr�fico � referente ao dia";
?>