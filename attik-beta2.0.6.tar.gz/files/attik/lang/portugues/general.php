<?php //This file content the translation of application in English
//Titles
$T_AUTENTICATION = "Autentica��o";
$T_CHANGE_PASSWOR = "� necess�rio modificar sua senha";
$T_USER = "Usu�rio";
$T_USER_LIST = "Lista de usu�rios";
$T_PROFILE = "Perfil";
$T_PROFILEFIREWALL = "M�dulo firewall";
$T_PROFILEPROXY = "M�dulo proxy";
$T_PROFILEVPN = "M�dulo VPN";
$T_PROFILE_LIST = "Lista de Perfis";
$T_LAST_ACCESS = "�ltimos acessos";
$T_ACCESS_LIST = "Lista de acessos";
$T_INCTI_SUPORTT = "Suporte remoto pela IncTI Security";
$T_GENERAL_CONFIG = "Configura��o geral";
$T_DEFAULT_LANG = "Idioma padr�o";
$T_AUDITORY = "Auditoria";
$T_APPLY_RULE_REAL_TIME = "Aplicar as regras em tempo real";
$T_ENABLE_FIREWALL_STATE_FULL = "Habilitar firewall em modo state full";
$T_KEEP_ADITORY_TIME = "Tempo para manter os logs armazenado";
$T_KEEP_GRAPH_TIME = "Tempo para manter os gr�ficos armazenados";
$T_CREATE_BACKUP_DAILY_AUTO = "Criar backup di�rio automaticamente";
$T_KEEP_BACKUP = "Tempo para manter o backup criado automaticamente";
$T_DESCRIPTION = "Descri��o";
$T_PASSWORD_USER_DATABASE = "Senha do usu�rio de banco de dados do Attik";
$T_BACKUP = "Backup";
$T_BACKUP_LIST = "Lista de Backup";
$T_UPDATE_INFO = "Atualiza��o do Control Center";
$T_FAILOVER = "Redund�ncia";
$T_FAILOVER_LIST = "Lista de configura��es para redund�ncia";
$T_INTERFACE_LIST = "Lista de Dispositivos de Rede";
$T_INTERFACE = "Interface";
$T_FAILOVER_INFO = "Redund�ncia de ativos";
$T_ROUTE_TABLE = "Tabela de rotas";
$T_ROUTE_LIST = "Lista de rotas";
$T_DESTINATION = "Destino";
$T_MASK = "M�scara";
$T_GATEWAY = "Gateway";
$T_TEST_CONNECTION = "Teste de conectividade";
$T_RESULT = "Resultado";
$T_COUNT = "Quantidade";
$T_ACTION = "A��o";
$T_COMMENT = "Coment�rio";
$T_HTTPSERVER_PORT = "Porta do servidor WEB";
$T_ADITIONAL_NAME = "T�tulo da p�gina";
$T_FIREWALL_LIST = "Lista de firewalls";
$T_FIREWALL_LIST_DETAILS = "Detalhe do Firewall";
$T_TIME_OUT_CONN_DB = "Tempo limite para conectar em banco de dados de firewall remoto";

//Filds
$F_SUCESS = "Opera��o realizada com sucesso";
$F_FAILURE = "A opera��o falhou ou nenhum campo foi modificado";
$F_NAME = "Nome: ";
$F_NO_FILD_CHANGE = "Nenhum campo foi modificado";
$F_INTERVAL = "Intervalo: ";
$F_TIME_IN_DAY = "Tempo em dias: ";
$F_CREATED = "Criado em: ";
$F_CREATOR = "Criado por: ";
$F_DESCRIPTION = "Descri��o: ";
$F_LANGUAGE = "Idioma: ";
$F_INTERFACE = "Interface: ";
$F_VLANID = "Vlan ID: ";
$F_MASK = "M�scara: ";
$F_NETWORK = "Rede: ";
$F_GATEWAY = "Gateway: ";
$F_PORT = "Porta: ";
$F_TITLE_ADITIONAL = "T�tulo: ";
$F_TYPE = "Tipo: ";
$F_LOCAL = "Local";
$F_GLOBAL = "Global";
$F_TIME_OUT_CONN_BD = "Tempo em segundos:";
	//-User
	$F_FULLNAME = "Nome completo: ";
	$F_LOGIN = "Login: ";
	$F_PASSWORD = "Senha: ";
	$F_REPASSWORD = "Re-senha: ";
	$F_CHANGE_PASSWORD = "Modificar senha: ";
	$F_SELECT_PROFILE = "Perfil: ";
	$D_DEPARTMENT = "Departamento: ";
	$F_ROOM = "Sala: ";
	$F_IP = "Endere�o IP: ";
	$F_MAC = "Endere�o MAC: ";
	$F_PHONE = "Telefone: ";
	$F_MOBILE = "Celular: ";
	
	//-Profilefw
	$F_CREATE_RULE = "Criar regras: ";
	$F_READ_RULE = "Ler regras: ";
	$F_READ_REPORT = "Ler relat�rios: ";
	$F_CREATE_NET = "Criar Rede, Topologia e Servidor: ";
	$F_READ_NET = "Ler Rede, Topologia e Servidor: ";
	$F_CREATE_PROFILE = "Criar perfil: ";
	$F_READ_PROFILE = "Ler perfil: ";
	$F_CREATE_PROTOCOL = "Criar protocolo: ";
	$F_READ_PROTOCOL = "Ler protocolo: ";
	
	//-Profile
	$F_MOD_IDS = "IDS: ";
	$F_MOD_SERV_MAIL = "Servidor de E-mail: ";
	$F_MOD_SMTP_RELAY = "Filtro de Spam: ";
	$F_MOD_WEB = "Servidor WEB: ";
	$F_MOD_VPN_CREATE = "Criar conex�o VPN: ";
	$F_MOD_VPN_READ = "Listar conex�o VPN: ";
	$F_CREATE_USER = "Criar usu�rio: ";
	$F_READ_USER = "Ler usu�rio: ";
	$F_READ_LOG = "Ler log: ";
	$F_CHANGE_CONFIG = "Gerenciar configura��es, rede e backup: ";
	
	//-Suportt remote
	$F_ENABLE = "Habilitar: ";
	$F_DISABLE = "Disabilitar: ";
	
	//Auditory
	$F_OPERATION = "Opera��o: ";
	
	//Failover
	$F_IDENTIFICATION = "Identifica��o: ";
	$F_PRIORITY = "Prioridade: ";
	$F_VIRTUAL_IP = "IP virtual: ";
	
	$F_ALERT_REMOVE = "Existe rede associada a este interface";
	$F_MASTER = "Prefer�ncia prim�rio:";
	$F_SKEW = "Skew";
	
//Buttons
$B_LOGON = "Logon";
$B_CHANGE = "Modificar";
$B_NEXT = "Pr�ximo";
$B_ADD_NEW = "Adicionar";
$B_UPDATE = "Atualizar";
$B_DELETE = "Remover";
$B_CLEAR = "Limpar";
$B_CREATE_BKP = "Cria backup agora";
$B_RESTORE_BKP = "Restorar este backup";
$B_EDIT = "Editar";
$B_SEARCH = "Procurar";
$B_SHOW_ALL = "Mostrar todos";
$B_YES = "Sim";
$B_NO = "N�o";
$B_RUN = "Executar";
$B_DOWNLOAD = "Baixar arquivo";
$B_DONW = "Desativa";
$B_FILTER = "Filtrar";
$B_ACTIVATE = "Ativar";

//Message of error
$ME_LOGINORPASSWORD = "Usu�rio ou senha inv�lido";
$ME_DIFFERENT_PASSWORD = "As senhas digitadas s�o diferentes";
$ME_NEEDSELECT = "� necess�rio selecionar um item";
$ME_NEEDFILL = "� necess�rio preencher todos os campos sublinhados";
$ME_NAMEEXIST = "Este nome j� est� cadastrado";
$ME_DONTHAVEPERMITION = "Voc� n�o tem permiss�o para fazer esta opera��o";
$ME_OCCURREDEERRORINTERNAL = "Ocorreu o seguinte erro interno: ";
$ME_HAVEPROFILEASSOCIATED = "Existe Perfil associado a este Perfil de Firewall. Voc� n�o pode remov�-lo.";
$ME_HAVEUSERASSOCIATED = "Existe usu�rio associado a este Perfil. Voc� n�o pode remov�-lo.";
$ME_THIUNIQUEUSERWITHPRIVILEGIES = "Este � o �nico usu�rio com privil�gios para adicionar novos usu�rios. Voc� n�o pode remov�-lo.";
$ME_INVALIDIP = "O endere�o IP digitado � inv�lido";
$ME_INVALIDMASK = "A m�scara digitada � inv�lida";
$ME_DATEINVALID = "A data digitada � inv�lida. � necess�rio utilizar o seguinte modelo: 08/25/2008, que equivale � MM/DD/AAAA";
$ME_THISUNIQUEPROFILEPRIVILEGIES = "Este � o �nico Perfil com privil�gios para gerenciar Perfil. Voc� n�o pode atualiz�-lo sem a op��o de Criar e Ler Perfil e usu�rio.";
$ME_CANTREMOVEUSERSIGNED = "Voc� n�o pode remover um usu�rio autenticado.";
$ME_INVALIDINTERFACE = "Interface inv�lida, n�o reconhecida pelo sistema operacional";
$ME_NAMEORIPEXIST = "Este nome ou endere�o IP j� est� cadastrado";
$ME_INVALIDROUTE = "Rota inv�lida";
//$ME_INTERFACEASSOCIATED = "Esta interface j� est� associada a um outro endere�o virtual";
$ME_IPASSOCIATED = "O endere�o IP digitado j� est� em uso por um outro endere�o virtual ou interface";
$ME_JUSTLETTERANDNUMBER = "Somente letras e n�meros � permitido";
$ME_NOT_EXIST_FILE_BKP = "O arquivo de backup n�o est� diposn�vel";
$ME_INTERFACEINUSE = "A interface digitada j� possui um IP virtual de redund�ncia associado a ela"; // NOVO
$ME_TRIED_DUPLICATED = "J� existe um registro com esses dados";
//Links
$L_OUT = "Sair";
$L_CONFIGURATIONG_CC = "Painel de Configura��o";
$L_USER = "Usu�rio";
$L_PROFILE = "Perfil";
$L_PROFILEFW = "Perfil FW";
$L_SELECTALL = "Marcar todos";
$L_UNSELECTALL = "Desmarcar todos";
$L_LASTACCESS = "Acessos";
$L_FILTER = "Filtrar";
$L_GENERAL = "Geral";
$L_AUDITORY = "Auditoria";
$L_BACKUP = "Backup";
$L_UPDATE = "Atualizar";
$L_FAILOVER = "Redund�ncia";
$L_INTERFACE = "Interface f�sica";
$L_INTERFACE_VLAN = "Interface virtual";
$L_ROTE = "Rota";
$L_NETWORK = "Rede";
$L_TEST_CONNECTION = "Ping";
$L_CONFIGURATION = "Configura��o";
$L_WIZARD = "Assistente";
$L_REPORT = "Relat�rio";
$L_APPLY_RULES = "Aplicar regras";
$L_RULES = "Regras";
$L_LICENSE = "Licen�a";
$L_FIREWALLS = "Firewalls";
$L_APPLY_VPN_CONN = "Aplicar conex�es";
$L_VIEW_VPN_CON_LOG = "Visualizar log";

//Sentences
$S_FILL_JUST_CHANGE = "Preencha este campo somente se for alterar a senha";
$S_CHANGE_PASSOWRD = "Modificar a senha no pr�ximo logon";
$S_FAIL = "Falhou";
$S_SUCESS = "Suceso";
$S_JUST_NUMBER = "Somente n�meros";
$S_ALLWAY = "-1 para nunca apagar";
$S_REST = "Restante";
$S_NOW = "Agora";
$S_WANT_DELETE = "Voc� realmente quer remover o(s) item(ns)";
$S_SELECTED = "selecionado(s)";

//Work
$W_IMAGE = "Imagem";
?>
