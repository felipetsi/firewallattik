<?php //This file content the translation of application in English in related description the attack
//Name
$SynCookies = "Syn Cookie";
$Multicast = "Multicast";
$BackOrifice = "Back Orifice";
$Netbus = "Netbus";
$Trin00 = "Trin00";
$TraceRoute = "Trace Route";
$SynFlood = "Syn Flood";
$ShealtScan = "Healt Scan";
$IPSpoofing = "IP Spoofing";
$cmd = "cmd.exe";

//Description
$Dsyncookies = "N�o cria nenhuma regra a mais, somente faz a configura��o em arquivos do kernel. Este tipo de ataque";
$Dmulticast = "Ataque do tipo multicast";
$Dbackorifice = "Ataque do worms Back Orifice";
$Dnetbus = "Ataque do tipo Netbus";
$Dtrin00 = "Ataque do tipo Trin00";
$Dtraceroute = "Ataques que podem ser originados do Trace Route";
$DsynFlood = "Ataques do tipo Syn Flood";
$Dhealtscan = "Ataque do tipo Healt Scan";
$Dipspoofing = "Ataque de IP Spoofing";
$Dcmd = "Ataque que solicita um prompt do windows a um servidor IIS";

?>