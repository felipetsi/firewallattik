<?php //Este arquivo cont�m a tradu��o do aplicativo em Portugu�s
//T�tulos
$T_USER = "Usu�rio";
$T_GROUP = "Grupo";
//Senten�as

//Campos
	
//Mensagem de erro

//Links

//Field IPTABLES

// Unit time

// Command of insert rule
?>