<?php //Este arquivo cont�m a tradu��o do aplicativo em Portugu�s
//T�tulos
$T_TOPOLOGY = "Topologia";
/*$T_TOPOLOGY_LIST = "Lista de Topologia";
$T_TOPOLOGY_SELECT = "Selecione a topologya de sua rede";*/
$T_NETWORK = "Rede";
$T_NETWORK_LIST = "Lista de Rede";
$T_PROTOCOL = "Protocolo";
$T_SERVICE = "Porta de servi�o";
$T_DESTINATION_PORT = "Porta Dest.";
$T_SOURCE_PORT = "Porta Org.";
$T_SERVICE_LIST = "Lista de Servi�o";
$T_INTERFACE_ENTRY = "Interf. entrad.";
$T_INTERFACE_EXIT = "Interf. sa�da";
//$T_SERVER = "Servidor";
//$T_SERVER_LIST = "Lista de Servidor";
$T_PORT = "Porta";
$T_SOURCE = "Origem";
$T_DESTINATION_CUT = "Dest";
$T_DESTINATION = "Destino";
$T_DIRECTION = "Dire��o";
$T_ATTRIBUTE = "Op��es avan�adas";
$T_REDIRECT_TO = "Para o IP";
$T_WEEKLY = "Semanalmente";
$T_MONTHLY = "Mensalmente";
$T_GRAPH_OF_SERVICE = "Gr�ficos de servi�os";
$T_GRAPH_OF_PROTOCOL = "Gr�fico de protocolos da camada de transporte e rede";
$T_GRAPH_WEEKLY = "Gr�fico semanal";
$T_GRAPH_MONTHLY = "Gr�fico mensal";
$T_OR = "ou";
$T_DIRECTION_LIST = "Lista de Dire��o";
$T_POLICY_DIRECTION = "Pol�tica da Dire��o";
$T_PERSONAL_DIRECTION_LIST = "Lista de Dire��es customizadas";
$T_ADD_COMMAND = "Status";
$T_ATTACK_PROTECTION = "Prote��o autom�tica";
$T_SELECTED = "Selecionados"; 
$T_AVAILABLE = "Dispon�veis"; 
$T_MONITOR = "Tr�fego";
$T_MONITOR_TRAFIC = "An�lise de tr�fego";
$T_SET_MARK = "Valor";
$T_EXPORT_RULE = "Exportar";
	
//Senten�as
$S_SELECTPROTOCOL = "Selecione os protocolos que ser�o permitidos a passagem neste fluxo";
$S_TO = "para";
$S_NET = "Rede";
$S_HOST = "M�quina";
$S_ANY = "Qualquer";
$S_SELECTED = "selecionada(s)";
$S_RULE = "regra(s)";

//Campos
$F_IMG = "Imagem";
//$F_SELECT_POSITIONFW = "Selecione a topologia";
$F_INTERFACE_IP = "IP da interface";
$F_PROTOCOL = "Protocolo:";
$F_PROTOCOLLAYERTRANS = "Protocolo da camada de transporte";
$F_ALL = "Todas";
$F_GENERATE_GRAPH = "Generate graph:";
$F_ERROR_SYNC_RULES = "A atualiza��o do objeto falhou. Clique e atualize todas as regras para corrigir o problema";
$F_STATUS_EXPORT_OK = "Ok";
$F_STATUS_EXPORT_FAIL = "Falhou";
	//-Rede
	$F_CLASS = "Classe de IP";
	$F_INTERFACE = "Interface";
	$F_IP = "Endere�o IP";
	//-Protocolos
	$F_SELECT_PROTOCOL = "Selecione o protocolo";

	//Servidores
	$F_MAC = "Endere�o MAC";
	$F_NETWORK = "Rede:";
	$F_OUT_NETWORK = "Fora da rede";
	//Regras
	$F_RULE_UP = "Mover esta regra para cima";
	$F_RULE_DOWN = "Mover esta regra para baixo";
	//Configura��es gerais do firewall
	$F_DIRECTION = "Dire��o";
	$F_ACTION = "A��o";
	//Dire��es pessoais
	$F_CREATE_ALSO_ACTION = "Tamb�m criar a��o";
	//Prote��o contra ataques
	$F_ATTACK = "Ataque:";
	$F_APPLY = "Aplicar:";
	//An�lise de tr�fego
	$F_FIELD = "Campo ";
	$F_MAX_LINE = "N� max. de linhas:";
	$F_TIME_REFRESH = "Tempo de atualiza��o: ";
	
//Mensagem de erro
$ME_NAMEORCLASSEXIST = "Este nome ou classe de IP j� est� cadastrado";
$ME_NODELETE = "Nenhum item deletado";
$ME_NAMEORPORTEXIST = "Este nome ou porta j� est� cadastrado";
$ME_INVALIDMAC = "O endere�o MAC digitado � inv�lido";
$ME_INVALIDPORT = "A porta digitada � inv�lida";
$ME_INVALIDCLASS = "A classe de IP digitada � inv�lida";
$ME_RULEEXIST = "Esta regra j� est� cadastrada";
$ME_JUSTLETTER = "Somente letras � permitido. N�o � poss�vel colocar n�meros ou outro tipo de caractere";
$ME_NAMEEXISTORDIRECTIONACTION = "Este nome de Dire��o ou A��o j� est� cadastrado";
$ME_NEEDSELECTSTARTANDENDTIME = "Se voc� quer controlar por tempo � necess�rio selecionar um intervalo completo";
$ME_NEEDFILLADDRORPORT = "Para fazer NAT voc� precisa preencher o endere�o ou porta para redirecionamento";
$ME_OVER_FLOW_PORT = "O n�mero m�ximo de portas permitidas em uma �nica regra � 15";
$ME_TOPOLOGY_NET_INSUFFICIENT = "A quantidade de rede cadastrada na topologia � insuficiente para executar o assistente. � necess�rio ter ao menos duas";
$ME_INVALIDPORTDIGITED = "Nos campos reservados para porta, � permitido apenas n�mero e separa��o com v�rgula";
$ME_INVALIDLIMITDIGITED = "No campo limite � permitido apenas n�meros";
$ME_INSUFFICIENT_HOSTSERVER = "Para iniciar o assitente � necess�rio selecionar ao menos dois endere�os de rede";
$ME_INVELIDSELECTPORTPROTOCOL = "Com a nega��o do protocolo TCP ou UDP n�o � poss�vel utilizar portas";
$ME_HAVERULEASSOCIATED = "Existe regra de firewall associada a este item. Utilize a busca na p�gina de regra e edite-a antes";
$ME_VALUESETMARKINVALID = "Valor definir na marca��o de pacote invalido";
$ME_RULEEXPORTED_CANTCHAGE = "Esta � uma regra exportada de outro firewall e por isso n�o pode ser modificada e nem removida";

//Links
$L_PROTOCOL = "Protocolo";
//$L_POSITIONFW = "Topologia";
//$L_SERVER = "Servidor";
$L_FILTER = "Filtragem";
$L_NAT = "Nat";
$L_MANGLE = "Tos";
$L_BALANCE = "Equil�brio de carga";
$L_DEFAULT_POLICY = "Pol�tica padr�o";
$L_FORM_RULE_ADD = "Forma de adi��o de regra";
$L_PERSONAL_CHAINS = "Dire��o customizada";
$L_ATTACK_PROTECTION = "Prote��o autom�tica";
$L_ADDRESS = "Endere�o";
$L_LOG = "Monitor";

//Field IPTABLES
$NEW = "Nova";
$ESTABLISHED = "Estabelecida";
$RELATED = "Relacionada";
$INVALID = "Inv�lida";

$filter = "Filter";
$nat = "Nat";
$mangle = "Mangle";

$limit = "Limite";
$smultiport = "S. portas";
$dmultiport = "D. portas";
$state = "Estado";
$string = "Palavra";
$mac = "MAC origem";

$INPUT = "Entrada";
$OUTPUT = "Sa�da";
$FORWARD = "Encaminhamento";
$PREROUTING = "Pr�-roteamento";
$POSTROUTING = "Pos-roteamento";

$ACCEPT = "Aceitar";
$DROP = "Negar";
$REDIRECT = "Redirecionar";
$REJECT = "Rejeitar";
$RETURN = "Retornar";
$QUEUE = "Fila";
$DNAT = "Dnat";
$SNAT = "Snat";
$MASQUERADE = "Mascarar";
$TOS16 = "Espera M�nima";//"Minimize delay";
$TOS8 = "Proc. M�ximo";//"Maximize throughput";
$TOS4 = "Conf. M�xima";//"Maximize reliability";
$TOS2 = "Custo M�nimo";//"Minimize cost";
$TOS0 = "Normal";//"Normal service";
$MARK = "Marcar";
$LOG = "Logar";

// Unit time
$SECOND = "Segundo";
$MINUTE = "Minuto";
$HOUR = "Hora";
$DAY = "Dia";

// Command of insert rule
$A = "Inserir no final";
$I = "Inserir no in�cio";
$S = "Desabilitar";
?>