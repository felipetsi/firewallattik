<?php //This file content the translation of application in English in related description the attack
//Name
$SynCookies = "Syn Cookie";
$Multicast = "Multicast";
$BackOrifice = "Back Orifice";
$Netbus = "Netbus";
$Trin00 = "Trin00";
$TraceRoute = "Trace Route";
$SynFlood = "Syn Flood";
$ShealtScan = "Healt Scan";
$IPSpoofing = "IP Spoofing";
$cmd = "cmd.exe";

//Description
$Dsyncookies = "It doesn�t create any other rules, it only makes a configuration in kernel files. This type of attack.";
$Dmulticast = "Multicast attack";
$Dbackorifice = "Worms Back Orifice attack";
$Dnetbus = "Netbus attack";
$Dtrin00 = "Trin00 attack";
$Dtraceroute = "Attacks that can be originated from Trace Route";
$DsynFlood = "Syn Flood atack";
$Dhealtscan = "Health Scan attack";
$Dipspoofing = "IP Spoofing attack";
$Dcmd = "Attack that require a windows prompt to a IIS server";

?>