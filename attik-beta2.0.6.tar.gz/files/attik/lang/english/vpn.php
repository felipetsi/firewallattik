<?php //Este arquivo cont�m a tradu��o do aplicativo em Portugu�s
//T�tulos
$T_CONNECTION_VPN = "Connection VPN";
$T_PHASE_I = "Phase I";
$T_PHASE_II = "Phase II";
$T_CONNECTION_VPN_LIST = "Connection VPN list";
$T_LEFT_IP = "IP Local Gateway";
$T_LEFT_SUBNET = "Local Subnet";
$T_RIGHT_IP = "Gateway IP Right";
$T_RIGHT_SUBNET = "Right Subnet";
$T_AUTO = "Auto Method";
$T_NAME_CONNECTION = "Connection Name";
$T_LOCAL_VPN_CONFIG = "Local configuration";
$T_REMOTE_VPN_CONFIG = "Remote gateway configuration";

//Campos
$F_LEFT_IP = "IP local gateway: ";
$F_LEFT_SUBNET = "Local subnet: ";
$F_RIGHT_IP = "Gateway IP Right: ";
$F_RIGHT_SUBNET = "Right Subnet: ";
$F_AUTO = "Auto Method: ";
$F_PASSWORD = "Password: ";

// Fase I
$F_METHOD_AUTHENTICATION = "Autentication mode: ";
$F_ALGORITHM_CRIPTO = "Criptography algorithm: ";
$F_ALGORITHM_HASH = "Integrity algorithm: ";
$F_LIFE_TIME_IKE = "Life time IKE: ";
$F_NEGOCIATTION_MODE = "Negociation mode: ";
$F_PERFECT_FORWARD_SECRECY = "Enable PFS: ";
// Fase II
$F_LIFE_TIME_IPSEC = "Life time IPSEC: ";
$F_RSA = "RSA";
$F_PSK = "PSK - Public shared key";
$F_CERTIFICATE = "Certification";

// Unit time
$SECOND = "Second";
$MINUTE = "Minute";
$HOUR = "Hour";
$DAY = "Day";
?>
