<?php //Este arquivo cont�m a tradu��o do aplicativo em Portugu�s
//T�tulos
$T_TOPOLOGY = "Topology";
$T_TOPOLOGY_LIST = "Topology list";
$T_TOPOLOGY_SELECT = "Select net topology";
$T_NETWORK = "Network";
$T_NETWORK_LIST = "Network list";
$T_PROTOCOL = "Protocol";
$T_SERVICE = "Service port";
$T_DESTINATION_PORT = "Dest. port";
$T_SOURCE_PORT = "Source port";
$T_SERVICE_LIST = "Service list";
$T_INTERFACE_ENTRY = "Interface entry";
$T_INTERFACE_EXIT = "Interface exit";
$T_SERVER = "Server";
$T_SERVER_LIST = "Server list";
$T_PORT = "Port";
$T_SOURCE = "Source";
$T_DESTINATION_CUT = "Dest";
$T_ACTION = "Action";
$T_DIRECTION = "Direction";
$T_ATTRIBUTE = "Advanced options";
$T_COMMENT = "To";
$T_REDIRECT_TO = "Para";
$T_WEEKLY = "Weekly";
$T_MONTHLY = "Monthly";
$T_GRAPH_OF_SERVICE = "Graph of service";
$T_GRAPH_OF_PROTOCOL = "Graph of protocol form the transport layer and network";
$T_GRAPH_WEEKLY = "Graph weekly";
$T_GRAPH_MONTHLY = "Graph monthly";
$T_OR = "or";
$T_DIRECTION_LIST = "Direction list";
$T_POLICY_DIRECTION = "Policy direction";
$T_PERSONAL_DIRECTION_LIST = "Personal direction list";
$T_ADD_COMMAND = "Status";
$T_ATTACK_PROTECTION = "Attack protection";
$T_SELECTED = "Selected";
$T_AVAILABLE = "Available";
$T_MONITOR = "Traffic";
$T_MONITOR_TRAFIC = "Traffic analysis";
$T_SET_MARK = "Value";
$T_EXPORT_RULE = "Export";

//Senten�as
$S_SELECTPROTOCOL = "Select protocol that will be allowed to pass in this flow";
$S_TO = "to";
$S_NET = "Net";
$S_HOST = "Host";
$S_ANY = "Any";
$S_SELECTED = "Selected";
$S_RULE = "Rule";

//Campos
$F_IMG = "Image";
$F_SELECT_POSITIONFW = "Select topology";
$F_INTERFACE_IP = "Interface ip";
$F_PROTOCOL = "Protocol:";
$F_PROTOCOLLAYERTRANS = "Protocol layer transport";
$F_ALL = "All";
$F_GENERATE_GRAPH = "Generate graph:";
$F_ERROR_SYNC_RULES = "The update of object failed. Click and update all rules to correct this problem";
$F_STATUS_EXPORT_OK = "Ok";
$F_STATUS_EXPORT_FAIL = "Failed";
	//-Rede
	$F_CLASS = "IP class";
	$F_INTERFACE = "Interface";
	$F_IP = "IP address";
	//-Protocolos
	$F_SELECT_PROTOCOL = "Select protocol";

	//Servidores
	$F_MAC = "MAC address";
	$F_NETWORK = "Network:";
	$F_OUT_NETWORK = "Out of network";
	//Regras
	$F_RULE_UP = "Move this rule up";
	$F_RULE_DOWN = "Move this rule down";
	//Configura��es gerais do firewall
	$F_DIRECTION = "Direction";
	$F_ACTION = "Action";
	//Dire��es pessoais
	$F_CREATE_ALSO_ACTION = "Create also action";
	//Prote��o contra ataques
	$F_ATTACK = "Attack:";
	$F_APPLY = "Apply:";
	//An�lise de tr�fego
	$F_FIELD = "Field ";
	$F_MAX_LINE = "N� max. of lines:";
	$F_TIME_REFRESH = "Time to update: ";
	
//Mensagem de erro
$ME_NAMEORCLASSEXIST = "This name or IP class exist";
$ME_NODELETE = "No item deleted";
$ME_NAMEORPORTEXIST = "This name or port exist";
$ME_INVALIDMAC = "Invalid MAC address";
$ME_INVALIDPORT = "Invalid port";
$ME_INVALIDCLASS = "Invalid IP class";
$ME_RULEEXIST = "This rule exist";
$ME_JUSTLETTER = "Just letter is allowed. It is not allwed numbers or another character";
$ME_NAMEEXISTORDIRECTIONACTION = "This name of direction action exist";
$ME_NEEDSELECTSTARTANDENDTIME = "If you want to control for time you need to select  a start and end time";
$ME_NEEDFILLADDRORPORT = "To do NAT you need to fill the address or redirection port";
$ME_OVER_FLOW_PORT = "Over flow port. The number of ports allowed in a single rule is 15";
$ME_TOPOLOGY_NET_INSUFFICIENT = "Topology net is insufficient to run the wizard";
$ME_INVALIDPORTDIGITED = "In the fields reserveds to port is allowed only numbers and comma separation";
$ME_INVALIDLIMITDIGITED = "In the limit field is allowed only numbers";
$ME_INSUFFICIENT_HOSTSERVER = "To start the wizard you need to select at least two network address";
$ME_INVELIDSELECTPORTPROTOCOL = "With the denial of the TCP or UDP port can't be used";
$ME_HAVERULEASSOCIATED = "Have rule of firewall associated with this. Locate and edit this before";
$ME_VALUESETMARKINVALID = "Invalid mark value";
$ME_RULEEXPORTED_CANTCHAGE = "This one rule exported from other firewall and can't will changed and removed";

//Links
$L_PROTOCOL = "Protocol";
//$L_POSITIONFW = "Topology";
//$L_SERVER = "Server";
$L_FILTER = "Filter";
$L_NAT = "Nat";
$L_MANGLE = "Tos";
$L_BALANCE = "Load balance";
$L_DEFAULT_POLICY = "Default policy";
$L_FORM_RULE_ADD = "Form of add rule";
$L_PERSONAL_CHAINS = "Personal chains";
$L_ATTACK_PROTECTION = "Auto protection";
$L_ADDRESS = "Address";
$L_LOG = "Monitor";

//Field IPTABLES
$NEW = "New";
$ESTABLISHED = "Established";
$RELATED = "Related";
$INVALID = "Invalid";

$filter = "Filter";
$nat = "Nat";
$mangle = "Mangle";

$limit = "Limit";
$smultiport = "S. ports";
$dmultiport = "D. ports";
$state = "State";
$string = "String";
$mac = "Source MAC";

$INPUT = "Input";
$OUTPUT = "Output";
$FORWARD = "Forward";
$PREROUTING = "Pre routing";
$POSTROUTING = "Post routing";

$ACCEPT = "Accept";
$DROP = "Drop";
$REDIRECT = "Redirect";
$REJECT = "Reject";
$RETURN = "Return";
$QUEUE = "Queue";
$DNAT = "Dnat";
$SNAT = "Snat";
$MASQUERADE = "Masquerade";
$TOS16 = "Min.delay";//"Minimize delay";
$TOS8 = "Max. throughput";//"Maximize throughput";
$TOS4 = "Max. reliability";//"Maximize reliability";
$TOS2 = "Min. cost";//"Minimize cost";
$TOS0 = "Normal";//"Normal service";
$MARK = "Mark";
$LOG = "Log";

// Unit time
$SECOND = "Second";
$MINUTE = "Minute";
$HOUR = "Hour";
$DAY = "Day";

// Command of insert rule
$A = "Insert in the end";
$I = "Insert in the beginning";
$S = "Disable";
?>
