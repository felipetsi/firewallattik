<?php //This file content the translation of application in English
//Titles
$T_AUTENTICATION = "Authentication";
$T_CHANGE_PASSWOR = "Change password";
$T_USER = "User";
$T_USER_LIST = "User list";
$T_PROFILE = "Profile";
$T_PROFILEFIREWALL = "Firewall module";
$T_PROFILEPROXY = "Proxy module";
$T_PROFILEVPN = "VPN module";
$T_PROFILE_LIST = "Profile list";
$T_LAST_ACCESS = "Last access";
$T_ACCESS_LIST = "Access list";
$T_INCTI_SUPORTT = "IncTI security remote support";
$T_GENERAL_CONFIG = "General configuration";
$T_DEFAULT_LANG = "Default language";
$T_AUDITORY = "Audit";
$T_APPLY_RULE_REAL_TIME = "Apply rules in real time";
$T_ENABLE_FIREWALL_STATE_FULL = "Enable state full mode";
$T_KEEP_ADITORY_TIME = "Keep adit time";
$T_KEEP_GRAPH_TIME = "Keep graph time";
$T_CREATE_BACKUP_DAILY_AUTO = "Create daily backup automatic";
$T_KEEP_BACKUP = "Keep backup time";
$T_DESCRIPTION = "Description";
$T_PASSWORD_USER_DATABASE = "Password user database";
$T_BACKUP = "Backup";
$T_BACKUP_LIST = "Backup list";
$T_UPDATE_INFO = "Control Center update";
$T_FAILOVER = "Failover";
$T_FAILOVER_LIST = "Failover configuration list";
$T_INTERFACE_LIST = "Interface list";
$T_INTERFACE = "Interface";
$T_FAILOVER_INFO = "Failover info";
$T_ROUTE_TABLE = "Route table";
$T_ROUTE_LIST = "Route list";
$T_DESTINATION = "Destination";
$T_MASK = "Mask";
$T_GATEWAY = "Gateway";
$T_TEST_CONNECTION = "Conectivity test";
$T_RESULT = "Result";
$T_COUNT = "Quantity";
$T_HTTPSERVER_PORT = "Port of WEB Server";
$T_ADITIONAL_NAME = "Title of page";
$T_FIREWALL_LIST = "Firewalls list";
$T_FIREWALL_LIST_DETAILS = "Firewall details";
$T_TIME_OUT_CONN_DB = "Time out to remote data base connection";

//Filds
$F_SUCESS = "Operation realized with success";
$F_FAILURE = "The operation failed or no fild was changed";
$F_NAME = "Name: ";
$F_NO_FILD_CHANGE = "No fild was changed";
$F_INTERVAL = "Interval: ";
$F_TIME_IN_DAY = "Time in day: ";
$F_CREATED = "Created in: ";
$F_CREATOR = "Creator: ";
$F_DESCRIPTION = "Description: ";
$F_LANGUAGE = "Language: ";
$F_INTERFACE = "Interface: ";
$F_VLANID = "Vlan ID: ";
$F_MASK = "Mask: ";
$F_NETWORK = "Network: ";
$F_GATEWAY = "Gateway: ";
$F_PORT = "Port: ";
$F_TITLE_ADITIONAL = "Title: ";
$F_TYPE = "Type: ";
$F_LOCAL = "Local";
$F_GLOBAL = "Global";
$F_TIME_OUT_CONN_BD = "Time in second: ";
	//-User
	$F_FULLNAME = "Full name: ";
	$F_LOGIN = "Login: ";
	$F_PASSWORD = "Password: ";
	$F_REPASSWORD = "Repassword: ";
	$F_CHANGE_PASSWORD = "Change password: ";
	$F_SELECT_PROFILE = "Profile: ";
	$D_DEPARTMENT = "Department: ";
	$F_ROOM = "Room: ";
	$F_IP = "IP address: ";
	$F_MAC = "MAC address: ";
	$F_PHONE = "Phone: ";
	$F_MOBILE = "Mobile: ";
	
	//-Profilefw
	$F_CREATE_RULE = "Create rules: ";
	$F_READ_RULE = "Read rules: ";
	$F_READ_REPORT = "Read report: ";
	$F_CREATE_NET = "Create net, topology and server: ";
	$F_READ_NET = "Read net, topology and server: ";
	$F_CREATE_PROFILE = "Create profile: ";
	$F_READ_PROFILE = "Read profile: ";
	$F_CREATE_PROTOCOL = "Create protocol: ";
	$F_READ_PROTOCOL = "Read protocol: ";
	
	//-Profile
	$F_MOD_IDS = "IDS: ";
	$F_MOD_SERV_MAIL = "Server E-mail: ";
	$F_MOD_SMTP_RELAY = "Spam filter: ";
	$F_MOD_WEB = "WEB server: ";
	$F_MOD_VPN_CREATE = "Create VPN connection: ";
	$F_MOD_VPN_READ = "View VPN connection: ";
	$F_CREATE_USER = "Create User: ";
	$F_READ_USER = "Read User: ";
	$F_READ_LOG = "Read Log: ";
	$F_CHANGE_CONFIG = "Manager configuration, network and backup: ";
	
	//-Suportt remote
	$F_ENABLE = "Enable: ";
	$F_DISABLE = "Disable: ";
	
	//Auditory
	$F_OPERATION = "Operation: ";
	
	//Failover
	$F_IDENTIFICATION = "Identification: ";
	$F_PRIORITY = "Priority: ";
	$F_VIRTUAL_IP = "Virtual IP: ";
	
	$F_ALERT_REMOVE = "There is an interface associated to this network";
	$F_MASTER = "Preference master:";
	$F_SKEW = "Skew";
	
//Buttons
$B_LOGON = "Logon";
$B_CHANGE = "Change";
$B_NEXT = "Next";
$B_ADD_NEW = "Add";
$B_UPDATE = "Update";
$B_DELETE = "Delete";
$B_CLEAR = "Clear";
$B_CREATE_BKP = "Create backup";
$B_RESTORE_BKP = "Restore backup";
$B_EDIT = "Edit";
$B_SEARCH = "Search";
$B_SHOW_ALL = "Show all";
$B_YES = "Yes";
$B_NO = "No";
$B_RUN = "Run";
$B_DOWNLOAD = "Download";
$B_DONW = "Donw";
$B_FILTER = "Filter";
$B_ACTIVATE = "Activate";

//Message of error
$ME_LOGINORPASSWORD = "Invalid login or password";
$ME_DIFFERENT_PASSWORD = "The passwords typed are differents ";
$ME_NEEDSELECT = "You need to select one item";
$ME_NEEDFILL = "You need to fill all the underlined fields";
$ME_NAMEEXIST = "This name already exist";
$ME_DONTHAVEPERMITION = "You don�t have the permition to do this operation";
$ME_OCCURREDEERRORINTERNAL = "Occurred the follwing internal error";
$ME_HAVEPROFILEASSOCIATED = "There is a profile associated to this Firewwall profile. You can�t remove";
$ME_HAVEUSERASSOCIATED = "There is a user associated to this profile. You can�t remove";
$ME_THIUNIQUEUSERWITHPRIVILEGIES = "This is the unique user with privilegies for add other new user. You can't remove.";
$ME_INVALIDIP = "Ivalid IP";
$ME_INVALIDMASK = "Invalid Mask";
$ME_DATEINVALID = "Invalid date. It�s necessary to use the following model: 08/25/2008, that is equivalent to MM/DD/AAAA";
$ME_THISUNIQUEPROFILEPRIVILEGIES = "This is the unique profile with privilegies for managing profile. You can�t upadate it without the Create and Read Profile and user option.";
$ME_CANTREMOVEUSERSIGNED = "You can�t remove a signed user.";
$ME_INVALIDINTERFACE = "Invalid interface, it wasn�t recognized for the system.";
$ME_NAMEORIPEXIST = "This name or IP already exist.";
$ME_INVALIDROUTE = "Invalid route";
//$ME_INTERFACEASSOCIATED = "This interface is already associated to another virtual address.";
$ME_IPASSOCIATED = "The IP is already being used for another virtual address or interface.";
$ME_JUSTLETTERANDNUMBER = "Just letter and number are allowed.";
$ME_NOT_EXIST_FILE_BKP = "There isn�t a backup file.";
$ME_TRIED_DUPLICATED = "Have record with these data";
//Links
$L_OUT = "Out";
$L_CONFIGURATIONG_CC = "Configuration panel";
$L_USER = "User";
$L_PROFILE = "Profile";
$L_PROFILEFW = "Profile FW";
$L_SELECTALL = "Select all";
$L_UNSELECTALL = "Unselect all";
$L_LASTACCESS = "Access";
$L_FILTER = "Filter";
$L_GENERAL = "General";
$L_AUDITORY = "Audit";
$L_BACKUP = "Backup";
$L_UPDATE = "Update";
$L_FAILOVER = "Failover";
$L_INTERFACE = "Physical interface";
$L_INTERFACE_VLAN = "Virtual interface";
$L_ROTE = "Route";
$L_NETWORK = "Network";
$L_TEST_CONNECTION = "Ping";
$L_CONFIGURATION = "Configuration";
$L_RULES = "Rules";
$L_REPORT = "Report";
$L_APPLY_RULES = "Apply rules";
$L_WIZARD = "Wizard";
$L_LICENSE = "License";
$L_FIREWALLS = "Firewalls";
$L_APPLY_VPN_CONN = "Apply connections";
$L_VIEW_VPN_CON_LOG = "Log View";


//Sentences
$S_FILL_JUST_CHANGE = "Fill this fild only if you will change your password";
$S_CHANGE_PASSOWRD = "Change the password in the next logon";
$S_FAIL = "Fail";
$S_SUCESS = "Succes";
$S_JUST_NUMBER = "Just number";
$S_ALLWAY = "-1 if you never want to delete it";
$S_REST = "Rest";
$S_NOW = "Now";
$S_WANT_DELETE = "You really want to remove the iten";
$S_SELECTED = "Selected";

//Work
$W_IMAGE = "Image";
?>
