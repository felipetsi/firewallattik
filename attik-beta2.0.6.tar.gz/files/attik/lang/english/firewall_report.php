<?php //This file content the translation of application in English to reports of firewall module
//Texts
$REPORT_DAILY = "Note the daily graph.";
$REPORT_SERVICE = "This graph below shows the frequency of the protocols that passed through the firewall.";
$T_HISTORY = "History";
$REFERENCEGRAPH = "This is the reference graph";
?>