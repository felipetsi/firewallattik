<?php 
include('../../includes/control_session.php');
include('../../configuration/general.php');
include('conn_db_cc_fw.php');
$FILE_LANG = "general.php";
include("/var/www/controlcenter/$LANG/$FILE_LANG"); 
$_SESSION['FILE_LANG'] = "firewall.php";

$DESTINATION_PAGE = "initial.php";
$THISPAGE = "update_password.php";

$USER = $_SESSION['USER'];

$PASSWD = trim(addslashes($_POST['password']));
if (!empty($PASSWD))
{
	$PASSWORD = sha1(trim(addslashes($_POST['password'])));
	$REPASSWORD = sha1(trim(addslashes($_POST['repassword'])));
	if ($PASSWORD != $REPASSWORD){
		$_SESSION['SHOW_MSG'] = "$ME_DIFFERENT_PASSWORD";
		header ("Location: $THISPAGE");
	} else {
		$SQL = "UPDATE controlcenter.user SET password = '$PASSWORD', change_password = '0' WHERE id = '$USER'";
		$RS = mysql_query($SQL) or (die('UPDATE: '.mysql_error()));
		header ("Location: $DESTINATION_PAGE");
	}
} else {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title><?php echo $TITLE_FW; ?></title>

<link href="../../includes/style_cc.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
if (!empty($_SESSION['SHOW_MSG'])){?>
	<div align="center" id="show_msg">
		<?php echo ($_SESSION['SHOW_MSG']); ?>	</div>
<?php }

include('../../includes/top.php');

<div id="main"> <!--Main-->
	<div class="title_general" > <?php echo $T_CHANGE_PASSWOR; ?> </div>
	<form action="<?php echo $THISPAGE;?>" method="post" >

		<div align="right" class="left_name"><?php echo $F_PASSWORD;?>:</div>
			<div><input type="password" name="password" size="15" maxlength="50" /></div>
		<div align="right" class="left_name"><?php echo $F_REPASSWORD;?>:</div>
			<div><input type="password" name="repassword" size="15" maxlength="50"/></div>
		<div align="right" class="left_name"><input type="submit" value="<?php echo $B_CHANGE;?>" /></div>

	</form>	
</div>
</body>
</html>
<?php
unset($_SESSION['SHOW_MSG']);
?>