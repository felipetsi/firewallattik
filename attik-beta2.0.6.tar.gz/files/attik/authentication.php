<?php
session_start();
require_once('includes/conn_db_cc.php');
require_once('configuration/general.php');

$DESTINATION_BACK = "logon.php";
$DESTINATION_PAGE = $DEFAULT_PAGE_MOD;
$DESTINATION_PAGE_CH_PASS = "update_password.php";

$LOGIN=substr(trim(addslashes($_POST['login'])),0,20);
$PASSWORD=sha1(substr(trim(addslashes($_POST['passwd'])),0,40));
$AIP=$_SERVER['REMOTE_ADDR'];

$SQL = "SELECT id, change_password FROM controlcenter.user WHERE login='$LOGIN' AND password='$PASSWORD'";
$RS1 = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCST001F"));
if (mysql_affected_rows() == 0){
	$_SESSION['SHOW_MSG'] = "ME_LOGINORPASSWORD";
	$_SESSION['EX_NAME'] = $LOGIN;
	if ($LOG_AUDITOR == 1)
	{
		$STATUS = 0;
		$SQL = "INSERT INTO controlcenter.log_access (address, login, status) VALUES ('$AIP', '$LOGIN', '$STATUS')";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCIT002F"));
	}
	header("Location: $DESTINATION_BACK");
} else {
	if ($LOG_AUDITOR == 1)
	{
		$STATUS = 1;
		$SQL = "INSERT INTO controlcenter.log_access (address, login, status) VALUES ('$AIP', '$LOGIN', '$STATUS')";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCIT003F"));
	}
	$ARRAY = mysql_fetch_array($RS1);
	$_SESSION['USER'] = $ARRAY['id'];
	if ($ARRAY['change_password'] == 1) {
		header("Location: $DESTINATION_PAGE_CH_PASS");
	} else {
		header("Location: $DESTINATION_PAGE");
	}
}?>