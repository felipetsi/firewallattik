<?php 
require_once('includes/control_session.php');

//Variable need becase various moment is use, including the top for change language
$THISPAGE = "update_cc.php";
$DESTINATION_PAGE = "update_run_cc.php";

// Load the profile of user autenticanted
$USER = $_SESSION['USER'];
$SQL = "SELECT change_config FROM controlcenter.profile WHERE ";
$SQL .= "id IN (SELECT id_pro FROM controlcenter.user WHERE id = '$USER')";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG001F"));
$DATA_USER = mysql_fetch_array($RS);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $TITLE; ?></title>
<link href="includes/style_cc.css" rel="stylesheet" type="text/css" />
<script language="javascript">
function verifyOptBkp(vi){
	if (vi == 'e' ) {
		document.getElementById('keep_backup').style.visibility="visible";
	} else {
		document.getElementById('keep_backup').style.visibility="hidden";
	}
}
</script>
</head>
<body onload="javascript:verifyOptBkp('<?php if($CREATE_BACKUP_AUTO == 1){ echo "e";} else { echo "d";};?>')">
<?php 
require_once('includes/top.php'); 
?>
<div id="main"> <!--Main-->
<?php require_once('cc_menu_configuration.php');?>

<div id="contet_rigth"> <!-- Rigth -->
<?php
if ($DATA_USER['change_config'] == 1) {
?>
<!--Start add-->
<form class="insert_border" action="<?php echo $DESTINATION_PAGE;?>" method="post" name="frmgeneral">
<div class="title_general" > <?php echo $T_GENERAL_CONFIG;?> </div>
<div id="contet_rigth_data">
<div class="sub_title"><?php echo $T_UPDATE_INFO;?></div>

	<iframe src="update_temp_cc.php" width="100%" frameborder="0" name="principal" style="height:400px">
	
	</iframe>

</div>
	<div id="contet_rigth_img">

		<img src="@img/icons/update-128x128.png" />	

	</div>	

<div class="title_general">		
	<input type="submit" value="<?php echo $B_UPDATE;?>" />
</div>
</form>
<!--End add-->
<?php }?>
</div>
<div class="version_general">
<?php
echo $VERSIONCC;
?>
</div>

</div> <!--Main-->

</body>
</html>
<?php
unset($_SESSION['EX_ACTION']);
unset($_SESSION['ITEMID']);
?>