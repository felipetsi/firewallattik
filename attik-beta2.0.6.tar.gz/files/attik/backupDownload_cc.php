<?php
require_once('includes/control_session.php');
require('configuration/directory.php');
$DESTINATION_DIR="backup";
$DESTINATION_PAGE = "backup_cc.php";
$ID = trim(addslashes($_POST['id']));
if(!empty($ID)){
	$FILETARGET = str_replace(":","-",str_replace(" ", "_", $ID)).".its";
	$COMMAND = "cp $DIRBACKUPDB/$FILETARGET $DESTINATION_DIR";
	exec($COMMAND,$RETURN);
	if (empty($RETURN)){
		$_SESSION['SHOW_MSG'] = 'F_SUCESS';
		if ($LOG_AUDITOR == 1){
			auditor('ICCXB011S', $ADDRIP, $USER, $ID);
		}
	}else {
		$_SESSION['SHOW_MSG'] = 'F_FAILURE';
		if($LOG_AUDITOR == 1){
			auditor('ICCXB011F', $ADDRIP, $USER, $ID);
		}
	}
}
header("Location:$DESTINATION_DIR/$FILETARGET");
?>