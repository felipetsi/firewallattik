<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php require_once('../../includes/control_session.php');
require_once('../../configuration/directory.php');

$DESTINATION_PAGE = "vpn_run.php";
$THISPAGE = "vpn.php";

// Load the profile of user autenticanted
$SQL = "SELECT create_conn, read_conn FROM controlcenter.profilevpn WHERE id IN ";
$SQL .= "(SELECT id_profw FROM controlcenter.profile WHERE id IN (SELECT id_pro FROM ";
$SQL .= "controlcenter.user WHERE id = '$USER'))";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL SVPSV001F"));
$DATA_USER = mysql_fetch_array($RS);

$_SESSION['FILE_LANG'] = "vpn.php";

// Load the item selected
if (!empty($_POST['vpnconnection']))
{
	$_SESSION['ITEMID'] = $_POST['vpnconnection'];
	$ITEMID = $_SESSION['ITEMID'];
} else {
	$ITEMID = $_SESSION['ITEMID'];
}

$_SESSION['ITEMDELETE'] = $ITEMID;

?>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
  <title><?php echo $TITLE_VPN; ?></title>
  <script language="javascript">
	var thispage = "vpn.php";
	var deletepage = "vpn_delete.php";
  </script>
  <link href="../../includes/style_cc.css" rel="stylesheet" type="text/css" />
  <link href="style_vpn.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php 
require_once('../../includes/top.php');
require_once('vpn_menu.php');
?>
<script language="javascript">
function confirmDeleteSelected()
{
	document.getElementById('box_delete').style.display="table";
}
function yesdeleteSelected()
{
	window.location=deletepage;
}
function nodeleteSelected()
{
	document.getElementById('box_delete').style.display="none";
}
var arrayCheck = new Array();
var p = 0;
var arrayCheck = new Array();
var p = 0;
function selectCheck(elementValue, elementName)
{
	if (elementName == true)
	{
		arrayCheck.push(elementValue);
	}
	else
	{
		for (p=0; p < arrayCheck.length; p++)
		{
			if (arrayCheck[p] == elementValue)
			{
				arrayCheck.splice(p, 1);
			}
		}
	}
}
</script>
<div id="box_delete"><?php echo("$S_WANT_DELETE?");?>
<div class="space_confirm_box"> <input value="<?php echo $B_YES;?>" onclick="javascript:yesdeleteSelected();" type="button" />
<input value="<?php echo $B_NO;?>"
 onclick="javascript:nodeleteSelected();" type="button" />
</div>
</div>
<div id="main"><!--Main-->
<?php if ($DATA_USER['create_conn'] == 1) {

// Load the user selected
$SQL = "SELECT * FROM cc_vpn.vpnconnection WHERE id = '$ITEMID'";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL -"));
if((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1)){
		auditor('-', $ADDRIP, $USER, '0');
}
$ARRAY = mysql_fetch_array($RS);
?>
<!--Start add-->
<form class="insert_border" action="<?php echo $DESTINATION_PAGE;?>" method="post">
<div>
  <input name="id" value="<?php echo $ARRAY['id'];?>" type="hidden" />
  <div class="title_general_vpn"><?php echo ($T_CONNECTION_VPN);?> </div>
  <div id="contet_rigth_data">
  <div class="sub_title"><?php echo $T_LOCAL_VPN_CONFIG;?></div>
  <div class="left_name" align="right"><u><?php echo $F_NAME;?></u></div>
  <div> <input size="30" maxlength="20" name="name" value="<?php if(!empty($_SESSION['EX_NAME'])) { echo $_SESSION['EX_NAME'];} else { echo $ARRAY['name']; }?>" autocomplete="off" type="text" /></div>
  <div class="left_name" align="right"><u><?php echo $F_LEFT_IP;?></u></div>
  <div> 
  	<select name="left_ip" style="width:250px;">
	<option></option>
	<?php
	$SQL = "SELECT id,name,description,ip FROM controlcenter.interface";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL -"));
	$OBJ = mysql_fetch_array($RS);
	do{	
	if ($OBJ['id'] == $ARRAY['left_ip'])
	{ 
		$sel = 'selected="selected"'; 
	} 
	else {
		$sel = ''; 
	}
	?>
		<option <?php echo $sel;?> value="<?php echo $OBJ['id'];?>"> <?php echo $OBJ['ip'].' - '.$OBJ['description'].'('.$OBJ['name'].')';?> </option><?php
	}while($OBJ = mysql_fetch_array($RS));
	?>
	</select>
  </div>
  <div class="left_name" align="right"><u><?php echo $F_LEFT_SUBNET;?></u></div>
  <div>
  	<select name="left_subnet" style="width:250px;">
	<option></option>
	<?php
	$SQL = "SELECT id,name,ip,mask FROM cc_firewall.network_address";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL -"));
	$OBJ = mysql_fetch_array($RS);
	if((mysql_affected_rows() > 0)){
		do{
			if ($OBJ['id'] == $ARRAY['left_subnet'])
			{ 
				$sel = 'selected="selected"'; 
			} 
			else {
				$sel = ''; 
			}
			?>
			<option <?php echo $sel;?> value="<?php echo $OBJ['id'];?>"> <?php echo $OBJ['ip'].'/'.$OBJ['mask'].'('.$OBJ['name'].')';?> </option><?php
		}while($OBJ = mysql_fetch_array($RS));
	}
	?>
	</select>
  </div>
  <div class="sub_title"><?php echo $T_REMOTE_VPN_CONFIG;?></div>
  <div class="left_name" align="right"><u><?php echo $F_RIGHT_IP;?></u></div>
  <div> 
  	<select name="right_ip" style="width:250px;">
	<option></option>
	<?php
	$SQL = "SELECT id,name,ip,mask FROM cc_firewall.network_address";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL -"));
	$OBJ = mysql_fetch_array($RS);
	if((mysql_affected_rows() > 0)){
		do{
			if ($OBJ['id'] == $ARRAY['right_ip'])
			{ 
				$sel = 'selected="selected"'; 
			} 
			else {
				$sel = ''; 
			}
			?>
			<option <?php echo $sel;?> value="<?php echo $OBJ['id'];?>"> <?php echo $OBJ['ip'].'/'.$OBJ['mask'].'('.$OBJ['name'].')';?> </option><?php
		}while($OBJ = mysql_fetch_array($RS));
	}
	?>
	</select>
   </div>
  <div class="left_name" align="right"><u><?php echo $F_RIGHT_SUBNET;?></u></div>
  <div> 
  	<select name="right_subnet" style="width:250px;">
	<option></option>
	<?php
	$SQL = "SELECT id,name,ip,mask FROM cc_firewall.network_address";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL -"));
	$OBJ = mysql_fetch_array($RS);
	if((mysql_affected_rows() > 0)){
		do{
			if ($OBJ['id'] == $ARRAY['right_subnet'])
			{ 
				$sel = 'selected="selected"'; 
			} 
			else {
				$sel = ''; 
			}
			?>
			<option <?php echo $sel;?> value="<?php echo $OBJ['id'];?>"> <?php echo $OBJ['ip'].'/'.$OBJ['mask'].'('.$OBJ['name'].')';?> </option><?php
		}while($OBJ = mysql_fetch_array($RS));
	}
	?>
	</select>
  <div class="left_name" align="right"><u><?php echo $F_PASSWORD;?></u></div>
  <div> <input size="30" maxlength="100" name="password" value="<?php if(!empty($_SESSION['EX_PASSWORD'])) { echo $_SESSION['EX_PASSWORD'];} else { echo $ARRAY['password']; }?>" autocomplete="off" type="text" /></div>
  <div class="left_name" align="right"><u><?php echo $F_AUTO;?></u></div>
  <div>
  <select name="auto" style="width:250px;">
  <option> </option>
  <option value="start" <?php if ($ARRAY['auto'] == 'start'){ echo 'selected="selected"'; } elseif(($_SESSION['EX_AUTO']) == 'start'){ echo 'selected="selected"';}?>>Start</option>
  <option value="add" <?php if ($ARRAY['auto'] == 'add'){ echo 'selected="selected"'; } elseif(($_SESSION['EX_AUTO']) == 'add'){ echo 'selected="selected"';}?>>Add</option>
  <option value="ignore" <?php if ($ARRAY['auto'] == 'ignore'){ echo 'selected="selected"'; } elseif(($_SESSION['EX_AUTO']) == 'ignore'){ echo 'selected="selected"';}?>>Ignore</option>
  </select> 
  </div>
  </div>
  </div>
  <div id="contet_rigth_img"> <img src="../../@img/icons/protocol-128x128.png" /> </div>
  
  <div class="title_general_vpn"> <input value="<?php if (empty($ARRAY['id'])){ echo $B_ADD_NEW;} else { echo $B_UPDATE;}?>" type="submit" /> <input value="<?php echo $B_CLEAR;?>"
 onclick="javascript:window.location=thispage" type="button" />
  <input value="<?php echo $B_DELETE;?>"
 onclick="javascript:confirmDeleteSelected();" type="button" /></div>
</form>
<!--End add-->
<?php }

if ($DATA_USER['read_conn'] == 1) {

?><!-- Start list-->

<div class="vpn_show_line_title">
	<div class="r_sppaccing_title"></div>
	<div class="r_sppaccing_check">

	</div>
	<div class="title_name_vpn_conn"><?php echo $T_NAME_CONNECTION;?></div>
	<div class="title_ip_vpn_conn"><?php echo $T_LEFT_IP;?></div>
	<div class="title_subnet_vpn_conn"><?php echo $T_LEFT_SUBNET;?></div>
	<div class="title_ip_vpn_conn"><?php echo $T_RIGHT_IP;?></div>			
	<div class="title_subnet_vpn_conn"><?php echo $T_RIGHT_SUBNET;?></div>
	<div class="title_auto_vpn_conn"><?php echo $T_AUTO;?></div>
</div>
<div id="r_show_conn_vpn"><!--Rules list-->
<?php $SQL = "SELECT * FROM cc_vpn.vpnconnection ORDER BY name";
$RS1 = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL -"));
$OTHER = mysql_fetch_array($RS1);
$COUNT = 0;
$SELECTCHECK = "";
if (mysql_affected_rows() > 0)
{
	do{
	$COUNT++;
	if ($OTHER['id'] == $ITEMID) {
		$SELECTCHECK='checked="checked"';
	} else {
		$SELECTCHECK="";
	}
	?>
	<form action="<?php echo $THISPAGE;?>" name="<?php echo ("formvpnlistconn".$COUNT);?>" method="post">	
	<?php
	$COMMAND = "cat $FILELOGVPN |grep ".$OTHER['name']."|grep established";
	exec($COMMAND,$RETURN);
	?>
	<div class="<?php if(!empty($RETURN[0])){ echo 'select_line_color_selected';}
					elseif ($cor == 1) {echo 'select_line_color'; $cor=0;}
					elseif ($cor == 1){echo 'select_line'; $cor=0;}
					else { echo 'select_line_color_fail';}?> " <?php echo 'onclick="javascript: document.formvpnlistconn'.$COUNT.'.vpnconnection.checked=true; document.formvpnlistconn'.$COUNT.'.submit();")';?>>
		<div class="r_sppaccing_title" style="height:20px;"></div>
		<div class="r_sppaccing_check" style="height:20px;">
			<input type="checkbox" value="<?php echo $OTHER['id'];?>" id=<?php echo $OTHER['id'];?> name="vpnconnection" <?php echo 'onclick="javascript: document.formvpnlistconn'.$COUNT.'.vpnconnection.checked=true; document.formvpnlistconn'.$COUNT.'.submit();")'; ?> <?php echo $SELECTCHECK;?> />
		</div>
		<div class="name_vpn_conn">
			<label for="<?php echo $OTHER['id'];?>">
				<?php echo $OTHER['name'];?>
			</label>
		</div>
		<div class="ip_vpn_conn">
			<label for="<?php echo $OTHER['id'];?>">
				<?php 
					$SQL = "SELECT ip FROM controlcenter.interface WHERE id = ".$OTHER['left_ip'];
					$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL -"));
					$OBJ = mysql_fetch_array($RS);
					echo $OBJ['ip'];
				?>
			</label>
		</div>
		<div class="subnet_vpn_conn">
			<label for="<?php echo $OTHER['id'];?>">
				<?php 
					$SQL = "SELECT CONCAT(ip,'/',mask) as subnet FROM cc_firewall.network_address WHERE id = ".$OTHER['left_subnet'];
					$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL -"));
					$OBJ = mysql_fetch_array($RS);
					echo $OBJ['subnet'];
				?>
			</label>
		</div>
		<div class="ip_vpn_conn">
			<label for="<?php echo $OTHER['id'];?>">
				<?php 
					$SQL = "SELECT ip FROM cc_firewall.network_address WHERE id = ".$OTHER['right_ip'];
					$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL -"));
					$OBJ = mysql_fetch_array($RS);
					echo $OBJ['ip'];
				?>
			</label>
		</div>
		<div class="subnet_vpn_conn">
			<label for="<?php echo $OTHER['id'];?>">
				<?php 
					$SQL = "SELECT CONCAT(ip,'/',mask) as subnet FROM cc_firewall.network_address WHERE id = ".$OTHER['right_subnet'];
					$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL -"));
					$OBJ = mysql_fetch_array($RS);
					echo $OBJ['subnet'];
				?>
			</label>
		</div>
		<div class="auto_vpn_conn">
			<label for="<?php echo $OTHER['id'];?>">
				<?php echo $OTHER['auto'];;?>
			</label>
		</div>
	</div>
	</form>
<?php }while ($OTHER = mysql_fetch_array($RS1));	
}?>

</div><!--Rules list-->
</form>
</div>
<?php }?>
<div class="version_general"> <?php echo $VERSIONCC;?> </div>

<?php unset($_SESSION['SHOW_MSG']);

unset($_SESSION['ITEMID']);

?></div>
</body>
</html>
<?php
unset($_SESSION['ITEMID']);
unset($_SESSION['EX_NAME']);
unset($_SESSION['EX_LEFT_IP']);
unset($_SESSION['EX_LEFT_SUBNET']);
unset($_SESSION['EX_RIGHT_IP']);
unset($_SESSION['EX_RIGHT_SUBNET']);
unset($_SESSION['EX_AUTO']);
?>