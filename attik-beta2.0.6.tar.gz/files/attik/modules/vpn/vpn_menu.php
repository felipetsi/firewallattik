<div id="menu_options"> <!--Main--> 
<a href="vpn.php">
	<div class="button_mod">
		<img src="/attik/@img/icons/build-16x16.gif" align="absmiddle"/>
		<?php echo $L_CONFIGURATION;?>
	</div>
</a>
<?php /*<a href="vpn.php">
	<div class="button_mod">
		 <img src="/attik/@img/icons/log-16x16.png" />
		<?php echo $L_VIEW_VPN_CON_LOG;?>
	</div>
</a>*/?>
	<div class="button_mod">

	</div>
	<div class="button_mod">

	</div>
<a href="apply_modified_run_vpn.php">
	<div class="button_mod">
				<img src="/attik/@img/icons/Ok-16x16.png" align="absmiddle"/>
		<?php echo $L_APPLY_VPN_CONN;?>
	</div>
</a>
</div>