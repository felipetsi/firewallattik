<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php require_once('../../includes/control_session.php');



$DESTINATION_PAGE = "vpn_run.php";

$THISPAGE = "vpn.php";

// Load the profile of user autenticanted

$SQL = "SELECT create_conn, read_conn FROM controlcenter.profilevpn WHERE id IN ";

$SQL .= "(SELECT id_profw FROM controlcenter.profile WHERE id IN (SELECT id_pro FROM ";

$SQL .= "controlcenter.user WHERE id = '$USER'))";

$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL SVPSV001F"));

$DATA_USER = mysql_fetch_array($RS);



$_SESSION['FILE_LANG'] = "vpn.php";



// Load the item selected

if (!empty($_POST['list']))

{

	$_SESSION['ITEMID'] = $_POST['list'];

	$ITEMID = $_SESSION['ITEMID'];

} else {

	$ITEMID = $_SESSION['ITEMID'];

}

$_SESSION['ITEMDELETE'] = $ITEMID;

?>
  <meta http-equiv="Content-Type"
 content="text/html; charset=iso-8859-1" />
  <title>&lt;?php echo $$TITLE_VPN; ?&gt;</title>
  <script language="javascript">
var thispage = "vpn.php";
var deletepage = "vpn_delete.php";
  </script>
  <link href="../../includes/style_cc.css" rel="stylesheet"
 type="text/css" />
</head>
<body>
<?php require_once('../../includes/top.php');

require_once('vpn_menu.php');

?>
<script language="javascript">
function confirmDeleteSelected()
{
	document.getElementById('box_delete').style.display="table";
}
function yesdeleteSelected()
{
	window.location=deletepage;
}
function nodeleteSelected()
{
	document.getElementById('box_delete').style.display="none";
}
</script>
<div id="box_delete"><?php echo("$S_WANT_DELETE?");?>
<div class="space_confirm_box"> <input
 value="<?php echo $B_YES;?>"
 onclick="javascript:yesdeleteSelected();" type="button" />
<input value="<?php echo $B_NO;?>"
 onclick="javascript:nodeleteSelected();" type="button" />
</div>
</div>
<div id="main"><!--Main--><?php //require_once('fw_menu_configuration.php');?>
<div id="contet_rigth"><?php if ($DATA_USER['create_conn'] == 1) {



// Load the user selected

$SQL = "SELECT * FROM cc_firewall.application WHERE id = '$ITEMID'";

$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSA002F"));

if((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1)){

		auditor('IFWSA002S', $ADDRIP, $USER, '0');

}

$ARRAY = mysql_fetch_array($RS);

?>
<!--Start add-->
<form class="insert_border"
 action="<?php echo $DESTINATION_PAGE;?>" method="post"><input
 name="id" value="<?php echo $ARRAY['id'];?>"
 type="hidden" />
  <div class="title_general_vpn"><?php echo ($T_CONNECTION_VPN);?> </div>
  <div id="contet_rigth_data">
  <div class="left_name" align="right"><u><?php echo $F_NAME;?></u></div>
  <div> <input size="20" maxlength="20"
 name="name"
 value="<?php if(!empty($_SESSION['EX_NAME'])) { echo $_SESSION['EX_NAME'];} else { echo $ARRAY['name']; }?>"
 autocomplete="off" type="text" /></div>
  <div class="sub_title"><?php echo $T_PHASE_I;?></div>
  <div class="left_name" align="right"><u><?php echo $F_METHOD_AUTHENTICATION;?></u></div>
  <div>
<!--  <select name="method_auth">
  <option value="rsa"><?php echo $F_RSA;?></option>
  <option value="psk"><?php echo $F_PSK;?></option>
  <option value="certificate"><?php echo $F_CERTIFICATE;?></option>
  </select> 
  </div>
  <div class="left_name" align="right"><?php echo $F_ALGORITHM_CRIPTO;?></div>
  <div>
  <select name="algorithm_crypto">
  <option value="rsa"><?php echo $F_RSA;?></option>
  <option value="psk"><?php echo $F_PSK;?></option>
  <option value="certificate"><?php echo $F_CERTIFICATE;?></option>
  </select>
  </div>
  <div class="left_name" align="right"><?php echo $F_ALGORITHM_HASH;?></div>
  <div>
  <select name="algorithm_hash">
  <option value="rsa"><?php echo $F_RSA;?></option>
  <option value="psk"><?php echo $F_PSK;?></option>
  <option value="certificate"><?php echo $F_CERTIFICATE;?></option>
  </select>
  </div>
  <div class="left_name" align="right"><?php echo $F_LIFE_TIME_IKE;?></div>
  <div> <input size="20" maxlength="10"
 name="life_time_ike"
 value="<?php if (!empty($_SESSION['EX_DESC'])) { echo $_SESSION['EX_DESC'];} else { echo $ARRAY['description'];}?>"
 autocomplete="off" type="text" /> </div>
  <div class="left_name" align="right"><?php echo $F_NEGOCIATTION_MODE;?></div>
  <div>
  <select name="negociattion_mode">
  <option value="rsa"><?php echo $F_RSA;?></option>
  <option value="psk"><?php echo $F_PSK;?></option>
  <option value="certificate"><?php echo $F_CERTIFICATE;?></option>
  </select>
  </div>
  <div class="left_name" align="right"><?php echo $F_PERFECT_FORWARD_SECRECY;?></div>
  <div>
  <select name="pfs">
  <option value="yes"><?php echo $B_YES;?></option>
  <option value="no"><?php echo $B_NO;?></option>
  </select>
  </div>
  <div class="sub_title"><?php echo $T_PHASE_II;?></div>
  <div class="left_name" align="right"><?php echo $F_ALGORITHM_CRIPTO;?></div>
  <div>
  <select name="algorithm_cripto">
  <option value="rsa"><?php echo $F_RSA;?></option>
  <option value="psk"><?php echo $F_PSK;?></option>
  <option value="certificate"><?php echo $F_CERTIFICATE;?></option>
  </select>
  </div>
  <div class="left_name" align="right"><?php echo $F_ALGORITHM_HASH;?></div>
  <div>
  <select name="algorithm_hash">
  <option value="rsa"><?php echo $F_RSA;?></option>
  <option value="psk"><?php echo $F_PSK;?></option>
  <option value="certificate"><?php echo $F_CERTIFICATE;?></option>
  </select> !-->
  </div>
  <div class="left_name" align="right"><?php echo $F_LIFE_TIME_IPSEC;?></div>
  <div> <input size="20" maxlength="10"
 name="life_time_ipsec"
 value="<?php if (!empty($_SESSION['EX_DESC'])) { echo $_SESSION['EX_DESC'];} else { echo $ARRAY['description'];}?>"
 autocomplete="off" type="text" /> </div>
  </div>
  <div id="contet_rigth_img"> <img
 src="../../@img/icons/protocol-128x128.png" /> </div>
  <div class="title_general_vpn"> <input
 value="<?php if (empty($ARRAY['id'])){ echo $B_ADD_NEW;} else { echo $B_UPDATE;}?>"
 type="submit" /> <input value="<?php echo $B_CLEAR;?>"
 onclick="javascript:window.location=thispage" type="button" />
  <input value="<?php echo $B_DELETE;?>"
 onclick="javascript:confirmDeleteSelected();" type="button" /></div>
</form>
<!--End add-->
<?php }

if ($DATA_USER['read_conn'] == 1) {

?><!-- Start list-->
<div class="title_general_fw"><?php echo $T_CONNECTION_VPN_LIST;?></div>
<form class="insert_border" action="<?php echo $THISPAGE;?>"
 method="post" name="objselect">
  <select class="select_list" name="list" size="20"
 ondblclick="javascript:document.objselect.submit()">
<?php $SQL = "SELECT id, name FROM cc_vpn.connection ORDER BY name";

$RS1 = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL SVPSV002F"));

$OTHER = mysql_fetch_array($RS1);

	do{

	if ($IDP == $ARRAY['id']) {

		$sel = 'selected="selected"';

	} else {

			$sel = "";

	}

	
	if ( $cor == 1 )

		{

		?>
  <option value="<?php echo $ARRAY['id'];?>"><?php echo $sel;?>
&gt;<?php echo $ARRAY['name']; $cor=0;?></option>
<?php } else { ?>
  <option style="" value="<?php echo $ARRAY['id'];?>"><?php echo $sel;?>
&gt;<?php echo $ARRAY['name']; $cor=1;?></option>
<?php } 

	}while ($ARRAY =  mysql_fetch_array($RS));?>
  </select>
</form>
</div>
<?php }?>
<div class="version_general"><?php echo $VERSIONCC;

?>
</div>
</div>
<?php unset($_SESSION['SHOW_MSG']);

unset($_SESSION['ITEMID']);

?>
</body>
</html>
