#!/bin/sh

export REPORTTYPE="graphservice"

/var/www/controlcenter/modules/firewall/.generate_history.sh
