#!/bin/bash
#################################################################
# 			This script whill apply the rules 					#
#               Create by Felipe Pereira da Silva               #
#               Created in 27/11/2013                           #
#               Version: 1.0                                    #
#################################################################

# User'DB
USERDB="attikuser"
# Password of user'DB
PASSWDDB=$(cat /var/.incti/.access/.access_exec.php | sed 's/.*$INCTIPW = "//' | sed 's/".*//')

# LOG file
FILELOGVPN="/var/.incti/.connection_vpn.log"
FILEIPSECCONF="/etc/ipsec.conf";
FILEIPSECSECRET="/etc/ipsec.secret";
FILEIPSECCONFPERSONAL="/etc/ipsec.conf.personal";
FILEIPSECSECRETPERSONAL="/etc/ipsec.secret.personal";

# Create the file of configuration vpn file
echo > $FILELOGVPN;
chmod 775 $FILELOGVPN
echo > $FILELOGVPN
chmod 775 $FILEIPSECSECRET
echo > $FILEIPSECSECRET

# The default configuration 	
sudo chmod 666 $FILEIPSECCONF
echo '# This file is modified just with Attik interface. If You want create outher connection without Attik interface, user the file /etc/ipsec.conf.personal and /etc/ipsec.secret.personal
# basic configuration
config setup
	interfaces=%defaultroute
	klipsdebug=none
	plutodebug=none

conn %default
	authby=secret
	ike=3des-sha1
	ikelifetime=24h
	pfs=yes
	keylife=1h
	esp=3des-sha1
	auth=esp
	aggrmode=no' > $FILEIPSECCONF
	
# Apply the connections
mysql -u $USERDB -p$PASSWDDB -e "SELECT id FROM cc_vpn.vpnconnection" | sed '1d' | \
while read IDCONN
do
	LEFT_IP=$(mysql -u $USERDB -p$PASSWDDB -e "SELECT ip FROM controlcenter.interface WHERE id IN (SELECT left_ip FROM cc_vpn.vpnconnection WHERE id = $IDCONN)" | sed '1d')
	LEFT_SUBNET=$(mysql -u $USERDB -p$PASSWDDB -e "SELECT CONCAT(ip,'/',mask) FROM cc_firewall.network_address WHERE id IN (SELECT left_subnet FROM cc_vpn.vpnconnection WHERE id = $IDCONN)" | sed '1d')
	RIGHT_IP=$(mysql -u $USERDB -p$PASSWDDB -e "SELECT ip FROM cc_firewall.network_address WHERE id IN (SELECT right_ip FROM cc_vpn.vpnconnection WHERE id = $IDCONN)" | sed '1d')
	RIGHT_SUBNET=$(mysql -u $USERDB -p$PASSWDDB -e "SELECT CONCAT(ip,'/',mask) FROM cc_firewall.network_address WHERE id IN (SELECT right_subnet FROM cc_vpn.vpnconnection WHERE id = $IDCONN)" | sed '1d')
	AUTO=$(mysql -u $USERDB -p$PASSWDDB -e "SELECT auto FROM cc_vpn.vpnconnection WHERE id = $IDCONN" | sed '1d')
	NAME=$(mysql -u $USERDB -p$PASSWDDB -e "SELECT name FROM cc_vpn.vpnconnection WHERE id = $IDCONN" | sed '1d')
		
# Create the connection
echo "
conn $NAME
	left=$LEFT_IP
	leftsubnet=$LEFT_SUBNET
	leftid=$LEFT_IP
	right=$RIGHT_IP
	rightsubnet=$RIGHT_SUBNET
	rightid=$RIGHT_IP
	auto=$AUTO" >> $FILEIPSECCONF
	
	PASSWORD=$(mysql -u $USERDB -p$PASSWDDB -e "SELECT password FROM cc_vpn.vpnconnection WHERE id = $IDCONN" | sed '1d')
echo "$LEFT_IP $RIGHT_IP: PSK \"$PASSWORD\"" >> $FILEIPSECSECRET

done

sudo chmod 644 /etc/ipsec.conf
sudo /etc/init.d/ipsec restart
sudo ipsec auto --status > $FILELOGVPN