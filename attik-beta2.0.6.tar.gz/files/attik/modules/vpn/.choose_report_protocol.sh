#!/bin/sh

export REPORTTYPE="graphprotocol"

/var/www/controlcenter/modules/firewall/.generate_history.sh
