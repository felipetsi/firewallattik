<?php 
require_once('../../includes/control_session.php');
require_once('includes/functions.php');

$DESTINATION_PAGE = "vpn.php";
$ID = trim(addslashes($_POST['id']));
$NAME = substr(trim(addslashes($_POST['name'])),0,100);
$LEFT_IP = substr(trim(addslashes($_POST['left_ip'])),0,10);
$LEFT_SUBNET = substr(trim(addslashes($_POST['left_subnet'])),0,10);
$RIGHT_IP = substr(trim(addslashes($_POST['right_ip'])),0,10);
$RIGHT_SUBNET = substr(trim(addslashes($_POST['right_subnet'])),0,10);
$PASSWORD = substr(trim(addslashes($_POST['password'])),0,100);
$AUTO = substr(trim(addslashes($_POST['auto'])),0,10);

if (((empty($NAME)) || (empty($LEFT_IP)) || (empty($LEFT_SUBNET)) || (empty($RIGHT_IP)) || (empty($RIGHT_SUBNET)) || (empty($AUTO)))) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDFILL';
	$_SESSION['ITEMID'] = $ID;
	$_SESSION['EX_NAME'] = $NAME;
	$_SESSION['EX_LEFT_IP'] = $LEFT_IP;
	$_SESSION['EX_LEFT_SUBNET'] = $LEFT_SUBNET;
	$_SESSION['EX_RIGHT_IP'] = $RIGHT_IP;
	$_SESSION['EX_RIGHT_SUBNET'] = $RIGHT_SUBNET;
	$_SESSION['EX_PASSWORD'] = $PASSWORD;
	$_SESSION['EX_AUTO'] = $AUTO;
	header("Location:$DESTINATION_PAGE");
}
else {
	$SQL = "SELECT * FROM cc_vpn.vpnconnection WHERE name = '$NAME' AND id <> '$ID' ";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL -"));
	if ( mysql_affected_rows() != 0 )
	{
		if($LOG_AUDITOR == 1){
		auditor('-', $ADDRIP, $USER, $NAME);
		}
		$_SESSION['SHOW_MSG'] = 'ME_NAMEORCLASSEXIST';
		$_SESSION['ITEMID'] = $ID;
		$_SESSION['EX_NAME'] = $NAME;
		$_SESSION['EX_LEFT_IP'] = $LEFT_IP;
		$_SESSION['EX_LEFT_SUBNET'] = $LEFT_SUBNET;
		$_SESSION['EX_RIGHT_IP'] = $RIGHT_IP;
		$_SESSION['EX_RIGHT_SUBNET'] = $RIGHT_SUBNET;
		$_SESSION['EX_PASSWORD'] = $PASSWORD;
		$_SESSION['EX_AUTO'] = $AUTO;
		header("Location:$DESTINATION_PAGE");
	}
	else {
	if (empty($ID)) {
		$SQL = "INSERT INTO cc_vpn.vpnconnection (name, left_ip, left_subnet, right_ip, right_subnet, password, auto) ";
		$SQL .= "VALUES ('$NAME', '$LEFT_IP', '$LEFT_SUBNET', '$RIGHT_IP', '$RIGHT_SUBNET', '$PASSWORD', '$AUTO')";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL -"));
	}
	else {
		$SQL = "UPDATE cc_vpn.vpnconnection SET name='$NAME', left_ip='$LEFT_IP', left_subnet='$LEFT_SUBNET', ";
		$SQL .= "right_ip='$RIGHT_IP', right_subnet = '$RIGHT_SUBNET', password='$PASSWORD', auto = '$AUTO' WHERE id = '$ID' ";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL -")); 
	}
	if ( mysql_affected_rows() != 0) {
		$FILEIPSECCONF="/etc/ipsec.conf";
		$FILEIPSECSECRET="/etc/ipsec.secret";
		$FILEIPSECCONFPERSONAL="/etc/ipsec.conf.personal";
		$FILEIPSECSECRETPERSONAL="/etc/ipsec.secret.personal";
		
		//$SQL = "SELECT DISTINCT v.id, v.name,v.auto,i.ip as lef_ip,CONCAT(n.ip,'/', n.mask) AS lef_subnet, n.ip as right_ip,CONCAT(n.ip,'/',n.mask) AS right_sunet FROM cc_vpn.vpnconnection v,controlcenter.interface i, cc_firewall.network_address n WHERE (v.left_ip IN (SELECT id FROM controlcenter.interface WHERE id='$LEFT_IP')) AND (v.left_subnet IN (SELECT id FROM cc_firewall.network_address WHERE id='$LEFT_SUNET')) AND (v.right_ip IN (SELECT id FROM cc_firewall.network_address WHERE id='$RIGHT_IP')) AND (v.right_subnet IN (SELECT id FROM cc_firewall.network_address WHERE id='$RIGHT_SUBNET'));";
		
		if($LOG_AUDITOR == 1){
		auditor('-', $ADDRIP, $USER, '0');
		}
		$_SESSION['SHOW_MSG'] = 'F_SUCESS';
	} else {
			if($LOG_AUDITOR == 1){
			auditor('-', $ADDRIP, $USER, '0');
			}
			$_SESSION['SHOW_MSG'] = 'F_FAILURE';
		}
	header("Location:$DESTINATION_PAGE");
	}
}
?>