<?php 
include('../../includes/control_session.php');

$DESTINATION_PAGE = "servernet_fw.php";

$ID = trim(addslashes($_SESSION['ITEMDELETE']));

if (empty($ID)) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDSELECT';
	header("Location:$DESTINATION_PAGE");
}
else {
	$SQL = "DELETE FROM cc_firewall.hostserver WHERE id = '$ID'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDS013F"));
	if ( mysql_affected_rows() !=0 )
	{
		if($LOG_AUDITOR == 1){
			auditor('IFWDS013S', $ADDRIP, $USER, '0');
		}
		$_SESSION['SHOW_MSG'] = 'F_SUCESS';
	}else {
		if($LOG_AUDITOR == 1){
			auditor('IFWDS013F', $ADDRIP, $USER, '0');
		}
		$_SESSION['SHOW_MSG'] = 'F_FAILURE';
	}
		unset($_SESSION['ITEMDELETE']);
		header("Location:$DESTINATION_PAGE");
}
?>