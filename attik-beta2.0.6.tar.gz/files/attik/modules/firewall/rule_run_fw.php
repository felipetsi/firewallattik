<?php 
require_once('../../includes/control_session.php');
require_once('includes/functions.php');
require_once('configuration/general.php');

$DATE_NOW = date('Y-m-d H:i:s');

//Select the table of page
$TABLE = trim(addslashes($_SESSION['TABLE']));
$DESTINATION_PAGE = "rule_fw.php";

$_SESSION['TRYINSERTRULE'] = 1;
$DIRECTION = substr(trim(addslashes($_POST['direction'])),0,3);
$IDSELECTED = trim(addslashes($_POST['id']));
$_SESSION['ITEMID']	= $IDSELECTED;
$SIFACE = substr(trim(addslashes($_POST['s_interface'])),0,6);
$SOURCE = explode("@",trim(addslashes($_POST['vsource'])));
$DESTINATION = explode("@",trim(addslashes($_POST['vdestination'])));
$SPORT = explode("@",trim(addslashes($_POST['vselsport'])));
$DPORT = explode("@",trim(addslashes($_POST['vseldport'])));
$EXPORTFW = explode("@",trim(addslashes($_POST['vselexport'])));
$DIFACE = substr(trim(addslashes($_POST['d_interface'])),0,6);
$PROTO = substr(trim(addslashes($_POST['proto'])),0,3);
$COMMANDADD = substr(trim(addslashes($_POST['selcommandadd'])),0,1);
$TIME_START = substr(trim(addslashes($_POST['hour_start'])),0,2);
$TIME_STOP = substr(trim(addslashes($_POST['hour_end'])),0,2);
$ACTION = substr(trim(addslashes($_POST['action'])),0,3);
$COMMENT = substr(trim(addslashes($_POST['comment'])),0,150);
$MMAC = replaceMAC(substr(trim(addslashes($_POST['mac'])),0,17));
$MSTRING = substr(trim(addslashes($_POST['string'])),0,127);
$ARRAY_FIREWALL_EXPORTED = array();

$SIFACE_COND = substr(trim(addslashes($_POST['s_interface_condition'])),0,1);
$SOURCE_COND = substr(trim(addslashes($_POST['source_condition'])),0,1);
$SPORT_COND = substr(trim(addslashes($_POST['selsport_condition'])),0,1);
$PROTO_COND = substr(trim(addslashes($_POST['proto_condition'])),0,1);
$DIFACE_COND = substr(trim(addslashes($_POST['d_interface_condition'])),0,1);
$DESTINATION_COND = substr(trim(addslashes($_POST['destination_condition'])),0,1);
$DPORT_COND = substr(trim(addslashes($_POST['seldport_condition'])),0,1);
$MAC_COND = substr(trim(addslashes($_POST['mac_condition'])),0,1);
$STRING_COND = substr(trim(addslashes($_POST['string_condition'])),0,1);
$STATE_COND = substr(trim(addslashes($_POST['state_condition'])),0,1);
$SETMARK = substr(trim(addslashes($_POST['setmark'])),0,19);

$MSTATE = substr(trim(addslashes($_POST['state'])),0,10);
$MLIMIT = substr(trim(addslashes($_POST['limit'])),0,4);
$UNIT_TIME = substr(trim(addslashes($_POST['type_time'])),0,1);
if (!empty($MLIMIT))
{
	if (empty($UNIT_TIME))
	{
		$UNIT_TIME = "s";
	}
	$MLIMITTEMP = $MLIMIT;
	$MLIMIT = ($MLIMITTEMP."/".$UNIT_TIME);
}
if (empty($COMMANDADD))
{
	$COMMANDADD = "A";
}
$TOADDRESS = trim(addslashes($_POST['selnatnet']));
$TOPORT = trim(addslashes($_POST['selnatapp']));
if(eregi("[^0-9,:]", $TOPORT, $regs)) {
	$TOPORTINVALID = "invalid";
} else {
	$TOPORTINVALID = verifyPort($TOPORT);
}
$EXPORTED = substr(trim(addslashes($_POST['exported'])),0,1);
function sessionVariablesandredir(){
	$_SESSION['DIRECTION'] = $DIRECTION;
	$_SESSION['SIFACE'] = $SIFACE;
	$_SESSION['SOURCE'] = $SOURCE;
	$_SESSION['DIFACE'] = $DIFACE;
	$_SESSION['DESTINATION'] = $DESTINATION;
	$_SESSION['DPORT'] = $DPORT;
	$_SESSION['SPORT'] = $SPORT;
	$_SESSION['EXPORTFW'] = $EXPORTFW;
	$_SESSION['PROTO'] = $PROTO;
	$_SESSION['COMMANDADD'] = $COMMANDADD;
	$_SESSION['TIMESTART'] = $TIME_START;
	$_SESSION['TIMEEND'] = $TIME_STOP;
	$_SESSION['COMMENT'] = $COMMENT;
	$_SESSION['limit'] = $MLIMIT;
	$_SESSION['state'] = $MSTATE;
	$_SESSION['mac'] = $MMAC;
	$_SESSION['string'] = $MSTRING;
	$_SESSION['ACTION'] = $ACTION;
	$_SESSION['SIFACE_COND'] = $SIFACE_COND;
	$_SESSION['DIFACE_COND'] = $DIFACE_COND;
	$_SESSION['SOURCE_COND'] = $SOURCE_COND;
	$_SESSION['DESTINATION_COND'] = $DESTINATION_COND;
	$_SESSION['SPORT_COND'] = $SPORT_COND;
	$_SESSION['DPORT_COND'] = $DPORT_COND;
	$_SESSION['PROTO_COND'] = $PROTO_COND;
	$_SESSION['MAC_COND'] = $MAC_COND;
	$_SESSION['STRING_COND'] = $STRING_COND;
	$_SESSION['STATE_COND'] = $STATE_COND;
} 
// Verify if option selected was to search or add/update
$SEARCH = substr(trim(addslashes($_POST['ind_search'])),0,1);
if ($SEARCH == 1)
{
	unset($_SESSION['SQL_SEARCH']);
	$_SESSION['SQL_SEARCH'] = "SELECT DISTINCT r.id, ";
	$_SESSION['SQL_SEARCH'] .= "r.id_s_iface, r.id_d_iface, r.status, r.applied, ";
	$_SESSION['SQL_SEARCH'] .= "ac.name as action, r.id_pro, d.name as direction FROM cc_firewall.rulefw r, cc_firewall.action ac, ";
	$_SESSION['SQL_SEARCH'] .= "cc_firewall.direction d WHERE ";
	$_SESSION['SQL_SEARCH'] .= "r.id_tab_dir_act IN (SELECT id FROM  cc_firewall.tab_dir_act WHERE id_act = ac.id ) AND ";
	$_SESSION['SQL_SEARCH'] .= "r.id_tab_dir_act IN (SELECT id FROM  cc_firewall.tab_dir_act WHERE id_dir = d.id ) AND ";
	$_SESSION['SQL_SEARCH'] .= "r.id_tab_dir_act IN (SELECT id FROM cc_firewall.tab_dir_act ";
	if((!empty($DIRECTION))||(!empty($ACTION))){$_SESSION['SQL_SEARCH'] .= " WHERE ";}
	if(!empty($DIRECTION)){$_SESSION['SQL_SEARCH'] .= "id_dir = '$DIRECTION' "; if(!empty($ACTION)){$_SESSION['SQL_SEARCH'] .= " AND ";}}
	if(!empty($ACTION)){$_SESSION['SQL_SEARCH'] .= "id_act = '$ACTION' ) ";}else{$_SESSION['SQL_SEARCH'] .= ") ";}

	if(!empty($SIFACE)){$_SESSION['SQL_SEARCH'] .= "AND r.id_s_iface = '$SIFACE' ";}
	if(!empty($DIFACE)){$_SESSION['SQL_SEARCH'] .= "AND r.id_d_iface = '$DIFACE' ";}
	if(!empty($PROTO)){$_SESSION['SQL_SEARCH'] .= "AND r.id_pro = '$PROTO' ";}
	if(!empty($SOURCE[0])){$SEARSHTEMP = $SOURCE[0]; $SQL="SELECT id_rul FROM cc_firewall.rul_net WHERE ";
							$SQL.="id_net = $SEARSHTEMP AND position = 's'";
							$RS = mysql_query($SQL); $SEARSHTEMP = mysql_fetch_array($RS); $F=1;
							do{
								if(($F == 1)&&($F == mysql_affected_rows())){
									$_SESSION['SQL_SEARCH'] .= "AND ( r.id=".$SEARSHTEMP['id_rul'].") ";
								} elseif(($F == 1)&&($F < mysql_affected_rows())){
									$_SESSION['SQL_SEARCH'] .= "AND ( r.id=".$SEARSHTEMP['id_rul']." ";
								} elseif($F == mysql_affected_rows()) {
									$_SESSION['SQL_SEARCH'] .= "OR r.id=".$SEARSHTEMP['id_rul'].") ";
								} else {
									$_SESSION['SQL_SEARCH'] .= "OR r.id=".$SEARSHTEMP['id_rul']." ";
								}
								$F++;
							}while($SEARSHTEMP = mysql_fetch_array($RS));}
	if(!empty($DESTINATION[0])){$SEARSHTEMP = $DESTINATION[0]; $SQL="SELECT id_rul FROM cc_firewall.rul_net WHERE ";
							$SQL.="id_net = $SEARSHTEMP AND position = 'd'";
							$RS = mysql_query($SQL); $SEARSHTEMP = mysql_fetch_array($RS); $F=1;
							do{
								if(($F == 1)&&($F == mysql_affected_rows())){
									$_SESSION['SQL_SEARCH'] .= "AND ( r.id=".$SEARSHTEMP['id_rul'].") ";
								} elseif(($F == 1)&&($F < mysql_affected_rows())){
									$_SESSION['SQL_SEARCH'] .= "AND ( r.id=".$SEARSHTEMP['id_rul']." ";
								} elseif($F == mysql_affected_rows()) {
									$_SESSION['SQL_SEARCH'] .= "OR r.id=".$SEARSHTEMP['id_rul'].") ";
								} else {
									$_SESSION['SQL_SEARCH'] .= "OR r.id=".$SEARSHTEMP['id_rul']." ";
								}
								$F++;
							}while($SEARSHTEMP = mysql_fetch_array($RS));}
	if(!empty($SPORT[0])){$SEARSHTEMP = $SPORT[0]; $SQL="SELECT id_rul FROM cc_firewall.rule_app WHERE ";
							$SQL.="id_app = $SEARSHTEMP AND position = 's'";
							$RS = mysql_query($SQL); $SEARSHTEMP = mysql_fetch_array($RS); $F=1;
							do{
								if(($F == 1)&&($F == mysql_affected_rows())){
									$_SESSION['SQL_SEARCH'] .= "AND ( r.id=".$SEARSHTEMP['id_rul'].") ";
								} elseif(($F == 1)&&($F < mysql_affected_rows())){
									$_SESSION['SQL_SEARCH'] .= "AND ( r.id=".$SEARSHTEMP['id_rul']." ";
								} elseif($F == mysql_affected_rows()) {
									$_SESSION['SQL_SEARCH'] .= "OR r.id=".$SEARSHTEMP['id_rul'].") ";
								} else {
									$_SESSION['SQL_SEARCH'] .= "OR r.id=".$SEARSHTEMP['id_rul']." ";
								}
								$F++;
							}while($SEARSHTEMP = mysql_fetch_array($RS));}
	if(!empty($DPORT[0])){$SEARSHTEMP = $DPORT[0]; $SQL="SELECT id_rul FROM cc_firewall.rule_app WHERE ";
							$SQL.="id_app = $SEARSHTEMP AND position = 'd'";
							$RS = mysql_query($SQL); $SEARSHTEMP = mysql_fetch_array($RS); $F=1;
							do{
								if(($F == 1)&&($F == mysql_affected_rows())){
									$_SESSION['SQL_SEARCH'] .= "AND ( r.id=".$SEARSHTEMP['id_rul'].") ";
								} elseif(($F == 1)&&($F < mysql_affected_rows())){
									$_SESSION['SQL_SEARCH'] .= "AND ( r.id=".$SEARSHTEMP['id_rul']." ";
								} elseif($F == mysql_affected_rows()) {
									$_SESSION['SQL_SEARCH'] .= "OR r.id=".$SEARSHTEMP['id_rul'].") ";
								} else {
									$_SESSION['SQL_SEARCH'] .= "OR r.id=".$SEARSHTEMP['id_rul']." ";
								}
								$F++;
							}while($SEARSHTEMP = mysql_fetch_array($RS));}
	if(!empty($COMMANDADD)){$_SESSION['SQL_SEARCH'] .= "AND r.command = '$COMMANDADD' ";}
	if(!empty($COMMENT)){$_SESSION['SQL_SEARCH'] .= "AND r.commentfw = '$COMMENT' ";}
	if(!empty($TIME_START)){$_SESSION['SQL_SEARCH'] .= "AND r.id IN (SELECT id_rul FROM cc_firewall.rul_vartime WHERE status_order = 's' AND id_vartime = '$TIME_START') ";}
	if(!empty($TIME_STOP)){$_SESSION['SQL_SEARCH'] .= "AND r.id IN (SELECT id_rul FROM cc_firewall.rul_vartime WHERE status_order = 'e' AND id_vartime = '$TIME_STOP') ";}
	if(!empty($MLIMIT)){$_SESSION['SQL_SEARCH'] .= "AND r.id IN (SELECT id_rul FROM cc_firewall.rul_atr WHERE id_atr IN (SELECT id FROM cc_firewall.atribute_module WHERE name = '$MLIMIT' AND id_mod IN (SELECT id FROM cc_firewall.module WHERE name = 'limit'))) ";}
	if(!empty($MSTRING)){$_SESSION['SQL_SEARCH'] .= "AND r.id IN (SELECT id_rul FROM cc_firewall.rul_atr WHERE id_atr IN (SELECT id FROM cc_firewall.atribute_module WHERE name = '$MSTRING' AND id_mod IN (SELECT id FROM cc_firewall.module WHERE name = 'string'))) ";}
	if(!empty($MMAC)){$_SESSION['SQL_SEARCH'] .= "AND r.id IN (SELECT id_rul FROM cc_firewall.rul_atr WHERE id_atr IN (SELECT id FROM cc_firewall.atribute_module WHERE name = '$MMAC' AND id_mod IN (SELECT id FROM cc_firewall.module WHERE name = 'mac'))) ";}
	$STATES = explode("@",$MSTATE);
	for($f=0; $f < sizeof($STATES); $f++)
	{
		$STATE = $STATES[$f];
		if(!empty($STATE)){$_SESSION['SQL_SEARCH'] .= "AND r.id IN (SELECT id_rul FROM cc_firewall.rul_atr WHERE id_atr IN (SELECT id FROM cc_firewall.atribute_module WHERE id = '$STATE' AND id_mod IN (SELECT id FROM cc_firewall.module WHERE name = 'state'))) ";}
	}
	if(!empty($TOADDRESS)){$_SESSION['SQL_SEARCH'] .= "AND r.id IN (SELECT id_rul FROM cc_firewall.rule_extend WHERE extend1 = '$TOADDRESS') ";}
	if(!empty($TOPORT)){$_SESSION['SQL_SEARCH'] .= "AND r.id IN (SELECT id_rul FROM cc_firewall.rule_extend WHERE extend2 = '$TOPORT') ";}
	header("Location:$DESTINATION_PAGE");
}
else 
{
	if ($EXPORTED == '1')
		{
			$_SESSION['SHOW_MSG'] = 'ME_RULEEXPORTED_CANTCHAGE';
			sessionVariablesandredir();
			header("Location:$DESTINATION_PAGE");
		}
	elseif (empty($DIRECTION) || empty($ACTION))
		{
			$_SESSION['SHOW_MSG'] = 'ME_NEEDFILL';
			sessionVariablesandredir();
			header("Location:$DESTINATION_PAGE");
		}
	elseif(eregi("[^0-9]", $MLIMITTEMP, $regs))
		{
			$_SESSION['SHOW_MSG'] = 'ME_INVALIDLIMITDIGITED';
			sessionVariablesandredir();
			header("Location:$DESTINATION_PAGE");
		}
	elseif ((!empty($TIME_START) && (empty($TIME_STOP))) || (empty($TIME_START) && (!empty($TIME_STOP))))
		{
			$_SESSION['SHOW_MSG'] = 'ME_NEEDSELECTSTARTANDENDTIME';
			sessionVariablesandredir();
			header("Location:$DESTINATION_PAGE");
		}
	elseif(($MMAC != "") && (verifyMAC($MMAC) != "ok"))
		{
			$_SESSION['SHOW_MSG'] = 'ME_INVALIDMAC';
			sessionVariablesandredir();
			header("Location:$DESTINATION_PAGE");
		}
	else
		{
			$SQL = "SELECT id FROM cc_firewall.action WHERE (name = 'DNAT' OR name = 'SNAT') AND id = '$ACTION'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR052F"));
			if ( (mysql_affected_rows() != 0) && (empty($TOADDRESS) && (empty($TOPORT)) ) )
			{
				$_SESSION['SHOW_MSG'] = 'ME_NEEDFILLADDRORPORT';
				sessionVariablesandredir();
				header("Location:$DESTINATION_PAGE");
			}
			else
			{				
				//Select the associated beteween Table, Direction and Action
				$SQL = "SELECT tda.id, d.name as direction, a.name as action FROM ";
				$SQL .= "cc_firewall.tab_dir_act tda, cc_firewall.direction d, cc_firewall.action a ";
				$SQL .= "WHERE d.id = tda.id_dir AND a.id = tda.id_act AND d.id = '$DIRECTION' AND a.id = '$ACTION' AND ";
				$SQL .= "id_tab IN (SELECT id FROM cc_firewall.tablefw WHERE name = '$TABLE')";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR002F"));
				$ARRAY = mysql_fetch_array($RS);
				$ID_TAB_DIR_ACT = $ARRAY['id'];
				$DIRECTION = $ARRAY['direction'];
				$ACTION = $ARRAY['action'];
				
				$STATES = explode("@",$MSTATE);
				
				$SQL = "SELECT name FROM controlcenter.interface WHERE id = '$SIFACE'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR056F"));
				$ARRAY = mysql_fetch_array($RS);
				$SIFACENAME = $ARRAY['name'];
				$SQL = "SELECT name FROM controlcenter.interface WHERE id = '$DIFACE'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR057F"));
				$ARRAY = mysql_fetch_array($RS);
				$DIFACENAME = $ARRAY['name'];
				$SQL = "SELECT name FROM cc_firewall.protocol WHERE id = '$PROTO'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR058F"));
				$ARRAY = mysql_fetch_array($RS);
				$PROTOCOL = $ARRAY['name'];
				
				if((($PROTOCOL=='tcp')||($PROTOCOL=='udp'))&&($PROTO_COND==1)&&((sizeof($SPORT)>1)||(sizeof($DPORT)>1)))
				{
					$_SESSION['SHOW_MSG'] = 'ME_INVELIDSELECTPORTPROTOCOL';
					sessionVariablesandredir();
					header("Location:$DESTINATION_PAGE");
				}elseif(($ACTION == "MARK")&&(($SETMARK > 9999999999999999999)||($SETMARK == ""))||(eregi("[^0-9,:]", $SETMARK, $regs)))
				{
					$_SESSION['SHOW_MSG'] = 'ME_VALUESETMARKINVALID';
					sessionVariablesandredir();
					header("Location:$DESTINATION_PAGE");
				}
				else{
				
				// Max port in one rule
				$MAXPORTNUMBER = 15;
				$APP_RANGE_S = 0;
				$APP_RANGE_D = 0;
				$LENGARRAY = sizeof($SPORT);
				$k = 0;
				// Number of port of application multiple 15
				$APP_RANGE_S = ceil($LENGARRAY/$MAXPORTNUMBER);
				for($p = 1; $p <= $APP_RANGE_S; $p++){
					for($f = 0; (($k < $LENGARRAY)&&($f < $MAXPORTNUMBER)); $f++){
						$SPORTID = $SPORT[$k];
						$SQL = "SELECT port FROM cc_firewall.application WHERE id = '$SPORTID'";
						$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR116F"));
						$ARRAY = mysql_fetch_array($RS);
						$LEGNPORTAPP = sizeof(explode(":",$ARRAY['port']));
						if($LEGNPORTAPP > 1){
							$APP_RANGE_S++;
							$f = $MAXPORTNUMBER;
							$SPORTNUMBERARRAY[sizeof($SPORTNUMBERARRAY)] = $ARRAY['port'];
						} else {
							if(($LENGARRAY > 1)&&($f > 0)) {
								$SPORTNUMBERARRAY[$p-1] = $ARRAY['port'].",".$SPORTNUMBERARRAY[$p-1];
							} else {
								$SPORTNUMBERARRAY[sizeof($SPORTNUMBERARRAY)] = $ARRAY['port'];
							}
						}
						$k++;
					}
				}

				$LENGARRAY = sizeof($DPORT);
				$k = 0;
				// Number of port of application multiple 15
				$APP_RANGE_D = ceil($LENGARRAY/$MAXPORTNUMBER);
				for($p=1; $p <= $APP_RANGE_D; $p++){
					for($f = 0; (($k < $LENGARRAY)&&($f < $MAXPORTNUMBER)); $f++){
						$DPORTID = $DPORT[$k];
						$SQL = "SELECT port FROM cc_firewall.application WHERE id = '$DPORTID'";
						$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR117F"));
						$ARRAY = mysql_fetch_array($RS);
						$LEGNPORTAPP = sizeof(explode(":",$ARRAY['port']));
						if($LEGNPORTAPP > 1){
							$APP_RANGE_D++;
							$f = $MAXPORTNUMBER;
							$DPORTNUMBERARRAY[sizeof($DPORTNUMBERARRAY)] = $ARRAY['port'];
						} else {
							if(($LENGARRAY > 1)&&($f > 0)) {
								$DPORTNUMBERARRAY[$p-1] = $ARRAY['port'].",".$DPORTNUMBERARRAY[$p-1];
							} else {
								$DPORTNUMBERARRAY[sizeof($DPORTNUMBERARRAY)] = $ARRAY['port'];
							}
						}
						$k++;
					}
				}
				
				if(empty($SIFACE)){
					$SIFACE_COND = 0;
				} if(empty($DIFACE)){
					$DIFACE_COND = 0;
				} if(sizeof($SOURCE) < 1){
					$SOURCE_COND = 0;
				} if(sizeof($DESTINATION) < 1){
					$DESTINATION_COND = 0;
				} if(sizeof($SPORT) < 1){
					$SPORT_COND = 0;
				} if(sizeof($DPORT) < 1){
					$DPORT_COND = 0;
				} if(empty($PROTO)){
					$PROTO_COND = 0;
				} if(empty($MMAC)){
					$MAC_COND = 0;
				} if(empty($MSTRING)){
					$STRING_COND = 0;
				} if(empty($MSTATE)){
					$STATE_COND = 0;
				}

				//Insert the rule
				if (empty($IDSELECTED))
					{
						$SQL = "INSERT INTO cc_firewall.rulefw (id_s_iface, id_d_iface, id_pro, ";
						$SQL .= "command, id_tab_dir_act, id_user, commentfw, date_created, last_update, ";
						$SQL .= "status, applied, s_iface_condition, d_iface_condition, source_condition, ";
						$SQL .= "destination_condition, sport_condition, dport_condition, proto_condition, ";
						$SQL .= "mac_condition, string_condition,state_condition) VALUE ('$SIFACE', '$DIFACE', ";
						$SQL .= "'$PROTO', '$COMMANDADD', '$ID_TAB_DIR_ACT', '$USER', '$COMMENT', '$DATE_NOW', ";
						$SQL .= "'$DATE_NOW','1','0','$SIFACE_COND','$DIFACE_COND','$SOURCE_COND','$DESTINATION_COND', ";
						$SQL .= "'$SPORT_COND','$DPORT_COND','$PROTO_COND','$MAC_COND','$STRING_COND','$STATE_COND')";
						$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR004F"));
						
						$ID_RULE = mysql_insert_id();
						if ($TABLE == "nat")
						{
							if ((!empty($ID_RULE)) && (!empty($TOADDRESS)))
							{
								$SQL = "INSERT INTO cc_firewall.rule_nat_net (id_rul, id_net) VALUES ";
								$SQL .= "('$ID_RULE', '$TOADDRESS')";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR005F"));
							}
							if ((!empty($ID_RULE)) && (!empty($TOPORT)))
							{
								$SQL = "INSERT INTO cc_firewall.rule_nat_app (id_rul, id_app) VALUES ";
								$SQL .= "('$ID_RULE', '$TOPORT')";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR006F"));
							}
						}elseif ($TABLE == "mangle")
						{
							if ((!empty($ID_RULE)) && ($ACTION == "MARK") && (!empty($SETMARK)))
							{
								$SQL = "INSERT INTO cc_firewall.rule_mangle_value (id_rul, setmark) VALUES ";
								$SQL .= "('$ID_RULE', '$SETMARK')";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR127F"));
							}
						}
						if (!empty($TIME_START))
							{
								//Insert the start time
								$SQL = "INSERT INTO cc_firewall.rul_vartime (id_rul, id_vartime, status_order) ";
								$SQL .= "VALUES ('$ID_RULE', '$TIME_START','s')";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR008F"));
								// Insert the end time
								$SQL = "INSERT INTO cc_firewall.rul_vartime (id_rul, id_vartime, status_order) ";
								$SQL .= "VALUES ('$ID_RULE', '$TIME_STOP','e')";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR009F"));
							}
						for ($count = 0; $count < sizeof($STATES); $count++)
						{
							if(!empty($STATES[$count]))
							{
								$ID_ATR = $STATES[$count];
								$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
								$SQL .= "('$ID_RULE', '$ID_ATR')";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR010F"));
							}
						}
						// Insert address, ports and firewall list
						for($f = 0; $f < sizeof($SOURCE); $f++)
						{
							if(!empty($SOURCE[$f]))
							{
								$NETADDRESS = $SOURCE[$f];
								$SQL = "INSERT INTO cc_firewall.rul_net VALUES('$ID_RULE','$NETADDRESS','s')";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR111S"));
							}
						}
						for($f = 0; $f < sizeof($DESTINATION); $f++)
						{
							if(!empty($DESTINATION[$f]))
							{
								$NETADDRESS = $DESTINATION[$f];
								$SQL = "INSERT INTO cc_firewall.rul_net VALUES('$ID_RULE','$NETADDRESS','d')";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR112S"));
							}
						}
						for($f = 0; $f < sizeof($SPORT); $f++)
						{
							if(!empty($SPORT[$f]))
							{
								$PORTAPP = $SPORT[$f];
								$SQL = "INSERT INTO cc_firewall.rule_app VALUES('$ID_RULE','$PORTAPP','s')";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR113S"));
							}
						}
						for($f = 0; $f < sizeof($DPORT); $f++)
						{
							if(!empty($DPORT[$f]))
							{
								$PORTAPP = $DPORT[$f];
								$SQL = "INSERT INTO cc_firewall.rule_app VALUES('$ID_RULE','$PORTAPP','d')";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR114S"));
							}
						}
						if (!empty($EXPORTFW[0]))
						{
							for($f = 0; $f < sizeof($EXPORTFW); $f++)
							{
								if(!empty($EXPORTFW[$f]))
								{
									$FWEXPORTID = $EXPORTFW[$f];
									$SQL = "SELECT ip FROM controlcenter.firewall_list WHERE id='$FWEXPORTID'";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR137F"));
									$ARRAY = mysql_fetch_array($RS);
									$FWADDRESS = $ARRAY['ip'];
									$test_conn = test_connect_in_other_fw($FWADDRESS,$TIME_OUT_CONN_DB);
									if($test_conn == 1)
									{
										exportRuleFw($SIFACE,$DIFACE,$PROTO,$COMMANDADD,$TABLE,$DIRECTION,$ACTION,$USER,$COMMENT,$DATE_NOW,$DATE_NOW,$SIFACE_COND,$DIFACE_COND,$SOURCE_COND,$DESTINATION_COND,$SPORT_COND, $DPORT_COND,$PROTO_COND,$MAC_COND,$STRING_COND,$STATE_COND,$SPORTNUMBERARRAY, $DPORTNUMBERARRAY,$SOURCE,$DESTINATION,$MLIMIT,$MMAC,$MSTRING,$STATES,$TOADDRESS,$TOPORT,$SETMARK,'I',$TIME_START,$TIME_STOP,$FWADDRESS);
		
										$ID_RULE_EXPORTED = $_SESSION['ID_RULE_EXPORTED'];
										unset($_SESSION['ID_RULE_EXPORTED']);
										$STATUS_RULE_EXPORTED = $_SESSION['STATUS_RULE_EXPORT'];
										unset($_SESSION['STATUS_RULE_EXPORT']);
										$SQL = "INSERT INTO cc_firewall.rule_firewall_list (id_rul, id_fw,id_rul_fw_exported,status) VALUES('$ID_RULE','$FWEXPORTID','$ID_RULE_EXPORTED','$STATUS_RULE_EXPORTED')";
										$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR130Fx1"));
										if($STATUS_RULE_EXPORTED == "1")
										{
											//array_push($ARRAY_FIREWALL_EXPORTED,$ID_RULE_EXPORTED."@".$FWADDRESS."@".$_SESSION['SIFACE_NAME_EXPORTED']."@".$_SESSION['DIFACE_NAME_EXPORTED']);
											$ARRAY_FIREWALL_EXPORTED[] = $ID_RULE_EXPORTED."@".$FWADDRESS."@".$_SESSION['SIFACE_NAME_EXPORTED']."@".$_SESSION['DIFACE_NAME_EXPORTED'];
											unset($_SESSION['SIFACE_NAME_EXPORTED']);
											unset($_SESSION['DIFACE_NAME_EXPORTED']);
										}
									}
									else
									{
										$STATUS_RULE_EXPORTED = 0;
										$SQL = "INSERT INTO cc_firewall.rule_firewall_list (id_rul, id_fw,id_rul_fw_exported,status) VALUES('$ID_RULE','$FWEXPORTID','','$STATUS_RULE_EXPORTED')";
										$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR130Fx2"));
									}
								}
							}
						}
						if (!empty($MLIMIT))
						{
							$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'limit'";
							$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR011F"));
							if (mysql_affected_rows() != 0)
							{
								$ARRAY = mysql_fetch_array($RS);
								$ID = $ARRAY['id'];
								$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
								$SQL .= "('$ID', '$MLIMIT')";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR012F"));
								if (mysql_affected_rows() != 0)
								{
									$ID = mysql_insert_id();
									$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
									$SQL .= "('$ID_RULE', '$ID')";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR013F"));
								}
							}
						}
						if (!empty($MMAC))
						{
							$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'mac'";
							$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR014F"));
							if (mysql_affected_rows() != 0) 
							{
								$ARRAY = mysql_fetch_array($RS);
								$ID = $ARRAY['id'];
								$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
								$SQL .= "('$ID', '$MMAC')";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR015F"));
								if (mysql_affected_rows() != 0)
								{
									$ID = mysql_insert_id();
									$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
									$SQL .= "('$ID_RULE', '$ID')";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR016F"));
								}								
							}
						}
						if (!empty($MSTRING))
						{
							$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'string'";
							$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR017F"));
							if (mysql_affected_rows() != 0) 
							{
								$ARRAY = mysql_fetch_array($RS);
								$ID = $ARRAY['id'];
								$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
								$SQL .= "('$ID', '$MSTRING')";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR018F"));
								if (mysql_affected_rows() != 0)
								{
									$ID = mysql_insert_id();
									$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
									$SQL .= "('$ID_RULE', '$ID')";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR019F"));
								}
							}
						}
					}
					else
						{						
						$SQL = "UPDATE cc_firewall.rulefw SET id_s_iface='$SIFACE', id_d_iface='$DIFACE', ";
						$SQL .= "id_pro='$PROTO', ";
						$SQL .= "command='$COMMANDADD', id_tab_dir_act='$ID_TAB_DIR_ACT', ";
						$SQL .= "id_user='$USER', commentfw='$COMMENT', last_update='$DATE_NOW', applied = '0', ";
						$SQL .= "source_condition='$SOURCE_COND', destination_condition='$DESTINATION_COND', ";
						$SQL .= "s_iface_condition='$SIFACE_COND', d_iface_condition='$DIFACE_COND', ";
						$SQL .= "proto_condition='$PROTO_COND', mac_condition='$MAC_COND', string_condition='$STRING_COND', ";
						$SQL .= "state_condition='$STATE_COND', sport_condition='$SPORT_COND', dport_condition='$DPORT_COND' ";
						$SQL .= "WHERE id = '$IDSELECTED'";
						$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR026F"));
						
						//Store the value of variable tha will be used after
						$ID_RULE = $IDSELECTED;
						
						// If table nat insert the extends digited
						if ($TABLE == "nat")
						{
							// Delete the field network_address in rule
							$SQL = "DELETE FROM cc_firewall.rule_nat_net WHERE id_rul = '$ID_RULE'";
							$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR118F"));
							// Delete the field application in rule
							$SQL = "DELETE FROM cc_firewall.rule_nat_app WHERE id_rul = '$ID_RULE'";
							$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR007F"));

							if ((!empty($ID_RULE)) && (!empty($TOADDRESS)))
							{
								$SQL = "INSERT INTO cc_firewall.rule_nat_net (id_rul, id_net) VALUES ";
								$SQL .= "('$ID_RULE', '$TOADDRESS')";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR005F"));
							}
							if ((!empty($ID_RULE)) && (!empty($TOPORT)))
							{
								$SQL = "INSERT INTO cc_firewall.rule_nat_app (id_rul, id_app) VALUES ";
								$SQL .= "('$ID_RULE', '$TOPORT')";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR006F"));
							}
						}elseif ($TABLE == "mangle")
						{
							// Delete the field value of mark pakage
							$SQL = "DELETE FROM cc_firewall.rule_mangle_value WHERE id_rul = '$ID_RULE'";
							$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR128F"));
							
							if ((!empty($ID_RULE)) && ($ACTION == "MARK") && (!empty($SETMARK)))
							{
								$SQL = "INSERT INTO cc_firewall.rule_mangle_value (id_rul, setmark) VALUES ";
								$SQL .= "('$ID_RULE', '$SETMARK')";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR127F"));
							}
						}
						
						// Delete the variable time refereced in rule
						$SQL = "DELETE FROM cc_firewall.rul_vartime WHERE id_rul = '$ID_RULE'";
						$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR030F"));
						
						if (!empty($TIME_START))
						{
							//Insert the start time
							$SQL = "INSERT INTO cc_firewall.rul_vartime (id_rul, id_vartime, status_order) ";
							$SQL .= "VALUES ('$IDSELECTED', '$TIME_START','s')";
							$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR031F"));
							// Insert the end time
							$SQL = "INSERT INTO cc_firewall.rul_vartime (id_rul, id_vartime, status_order) ";
							$SQL .= "VALUES ('$IDSELECTED', '$TIME_STOP','e')";
							$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR032F"));
						}
						
						// Delete the attributes
						$SQL = "DELETE FROM cc_firewall.atribute_module WHERE id IN (SELECT id_atr FROM ";
						$SQL .= "cc_firewall.rul_atr WHERE id_rul = '$IDSELECTED') AND id_mod IN (SELECT id FROM ";
						$SQL .= "cc_firewall.module WHERE definitive <> '1')";
						$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR033F"));
						
						// Delete the associated (rul_atr)
						$SQL = "DELETE FROM cc_firewall.rul_atr WHERE id_rul = '$IDSELECTED'";
						$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR034F"));
						
						// Delete the address, ports and firewalls exported
						$SQL = "DELETE FROM cc_firewall.rul_net WHERE id_rul = '$IDSELECTED'";
						$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR034F"));
						
						$SQL = "DELETE FROM cc_firewall.rule_app WHERE id_rul = '$IDSELECTED'";
						$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR034F"));
						
						$ID_RULE = $IDSELECTED;
						for ($count = 0; $count < sizeof($STATES); $count++)
							{
								if(!empty($STATES[$count]))
								{
									$ID_ATR = $STATES[$count];
									$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
									$SQL .= "('$ID_RULE', '$ID_ATR')";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR035F"));
								}
							}
						
						// Insert address, ports and firewalls exported
						for($f = 0; $f < sizeof($SOURCE); $f++)
						{
							if(!empty($SOURCE[$f]))
							{
								$NETADDRESS = $SOURCE[$f];
								$SQL = "INSERT INTO cc_firewall.rul_net VALUES('$ID_RULE','$NETADDRESS','s')";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR111S"));
							}
						}
						for($f = 0; $f < sizeof($DESTINATION); $f++)
						{
							if(!empty($DESTINATION[$f]))
							{
								$NETADDRESS = $DESTINATION[$f];
								$SQL = "INSERT INTO cc_firewall.rul_net VALUES('$ID_RULE','$NETADDRESS','d')";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR112S"));
							}
						}
						// Verify the firewall no more exported
						$SQL = "SELECT id_rul_fw_exported,id_fw FROM cc_firewall.rule_firewall_list WHERE ";
						$SQL .= "id_rul = '$ID_RULE'";
						$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR145F"));
						$ARRAY = mysql_fetch_array($RS);
						do 
						{
							$SEARCH_TO = $ARRAY['id_rul_fw_exported'];
							$IDFWEXPORTED = $ARRAY['id_fw'];
							$SQL = "SELECT ip FROM controlcenter.firewall_list WHERE id='$SEARCH_TO'";
							$RS_EXPORTED = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR147F"));
							$ARRAY_EXPORTED = mysql_fetch_array($RS_EXPORTED);
							$FWADDRESS = $ARRAY_EXPORTED['ip'];
							if((array_search("$SEARCH_TO", $EXPORTFW)) == false){
								$test_conn = test_connect_in_other_fw($FWADDRESS,$TIME_OUT_CONN_DB);
								if($test_conn == 1)
								{
									deleteExportedRuleFw($ID_RULE,$SEARCH_TO,$TABLE,$FWADDRESS);
									
									$CONN_FW_EXPORT = connect_in_other_fw($FWADDRESS);
								
									$SQL = "DELETE FROM cc_firewall.rulefw WHERE id = '$ID_RULE_EXPORTED'";
									$RSOBJ = mysql_query($SQL,$CONN_FW_EXPORT) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR148F"));
									
									// Delete the rule mounted
									$SQL = "DELETE FROM cc_firewall.rulefwrun WHERE id = '$ID_RULE_EXPORTED'";
									$RSOBJ = mysql_query($SQL,$CONN_FW_EXPORT) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR149F"));

									// Just go to back connection to localhost database.
									$SQL = "SELECT id FROM controlcenter.language WHERE id = 1";
									$RSOBJ = mysql_query($SQL,connect_in_other_fw('127.0.0.1'));
								}
							}
							/*// Delete the association this rule to Firewall exported
							$SQL = "DELETE FROM cc_firewall.rule_firewall_list WHERE id_rul = '$ID_RULE' ";
							$SQL .= "AND id_fw = '$IDFWEXPORTED' ";
							$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR130Fx3"));*/
						}while($ARRAY = mysql_fetch_array($RS));
						
						// Clear the exported firewall's array 
						$EXCEPTION_SQL_QUERY = "";
						for($f = 0; $f < sizeof($EXPORTFW); $f++)
						{
							if((!empty($EXPORTFW[$f]))&&((array_search("$SEARCH_TO", $EXPORTFW)) == false))
							{
								$EXCEPTION_SQL_QUERY .= " AND id_fw <> ".$EXPORTFW[$f];
							}
						}
															
						$SQL = "DELETE FROM cc_firewall.rule_firewall_list WHERE id_rul = '$ID_RULE' $EXCEPTION_SQL_QUERY";
						$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR130Fx3"));
						
						if (!empty($EXPORTFW[0]))
						{
							for($f = 0; $f < sizeof($EXPORTFW); $f++)
							{
								if(!empty($EXPORTFW[$f]))
								{
									$FWEXPORTID = $EXPORTFW[$f];
									$SQL = "SELECT ip FROM controlcenter.firewall_list WHERE id='$FWEXPORTID'";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR137F"));
									$ARRAY = mysql_fetch_array($RS);
									$FWADDRESS = $ARRAY['ip'];
	
									// Delete the rule in exported firewall and local
									$SQL = "SELECT id_rul_fw_exported FROM cc_firewall.rule_firewall_list WHERE ";
									$SQL .= "id_rul = '$IDSELECTED' AND id_fw = '$FWEXPORTID'";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR138F"));
									$ARRAY = mysql_fetch_array($RS); 
									$ID_RULE_EXPORTED = $ARRAY['id_rul_fw_exported'];
									$test_conn = test_connect_in_other_fw($FWADDRESS,$TIME_OUT_CONN_DB);
									if($test_conn == 1)
									{
										if(!empty($ID_RULE_EXPORTED))
										{
											deleteExportedRuleFw($ID_RULE,$ID_RULE_EXPORTED,$TABLE,$FWADDRESS);
											exportRuleFw($SIFACE,$DIFACE,$PROTO,$COMMANDADD,$TABLE,$DIRECTION,$ACTION,$USER,$COMMENT,$DATE_NOW,$DATE_NOW,$SIFACE_COND,$DIFACE_COND,$SOURCE_COND,$DESTINATION_COND,$SPORT_COND, $DPORT_COND,$PROTO_COND,$MAC_COND,$STRING_COND,$STATE_COND,$SPORTNUMBERARRAY, $DPORTNUMBERARRAY,$SOURCE,$DESTINATION,$MLIMIT,$MMAC,$MSTRING,$STATES,$TOADDRESS,$TOPORT,$SETMARK,$ID_RULE_EXPORTED,$TIME_START,$TIME_STOP,$FWADDRESS);
										} else {
											exportRuleFw($SIFACE,$DIFACE,$PROTO,$COMMANDADD,$TABLE,$DIRECTION,$ACTION,$USER,$COMMENT,$DATE_NOW,$DATE_NOW,$SIFACE_COND,$DIFACE_COND,$SOURCE_COND,$DESTINATION_COND,$SPORT_COND, $DPORT_COND,$PROTO_COND,$MAC_COND,$STRING_COND,$STATE_COND,$SPORTNUMBERARRAY, $DPORTNUMBERARRAY,$SOURCE,$DESTINATION,$MLIMIT,$MMAC,$MSTRING,$STATES,$TOADDRESS,$TOPORT,$SETMARK,'I',$TIME_START,$TIME_STOP,$FWADDRESS);
										}
		
										$ID_RULE_EXPORTED = $_SESSION['ID_RULE_EXPORTED'];
										unset($_SESSION['ID_RULE_EXPORTED']);
										$STATUS_RULE_EXPORTED = $_SESSION['STATUS_RULE_EXPORT'];
										unset($_SESSION['STATUS_RULE_EXPORT']);
										
										/*$SQL = "INSERT INTO cc_firewall.rule_firewall_list (id_rul, id_fw,id_rul_fw_exported,status) VALUES('$ID_RULE','$FWEXPORTID','$ID_RULE_EXPORTED','$STATUS_RULE_EXPORTED')";*/
										$SQL = "UPDATE cc_firewall.rule_firewall_list SET id_rul_fw_exported = $ID_RULE_EXPORTED WHERE ";
										$SQL.= "id_rul = $ID_RULE AND id_fw = $ID_RULE_EXPORTED";
										$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR130Fx4"));
		
										if($STATUS_RULE_EXPORTED == "1")
										{
											//array_push($ARRAY_FIREWALL_EXPORTED,$ID_RULE_EXPORTED."@".$FWADDRESS."@".$_SESSION['SIFACE_NAME_EXPORTED']."@".$_SESSION['DIFACE_NAME_EXPORTED']);
											$ARRAY_FIREWALL_EXPORTED[] = $ID_RULE_EXPORTED."@".$FWADDRESS."@".$_SESSION['SIFACE_NAME_EXPORTED']."@".$_SESSION['DIFACE_NAME_EXPORTED'];
											unset($_SESSION['SIFACE_NAME_EXPORTED']);
											unset($_SESSION['DIFACE_NAME_EXPORTED']);
										}
									} 
									 else 
									{
										$SQL = "UPDATE cc_firewall.rule_firewall_list SET status='0' WHERE id_rul = '$ID_RULE' ";
										$SQL .= "AND id_fw = '$FWEXPORTID'";
										$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR146F"));

										$SQL = "SELECT id_rul_fw_exported FROM cc_firewall.rule_firewall_list WHERE ";
										$SQL .= "id_rul = '$ID_RULE' AND id_fw = '$FWEXPORTID' ";
										$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR150F"));

										if(mysql_affected_rows() == 0)
										{
											$SQL = "INSERT INTO cc_firewall.rule_firewall_list (id_rul, id_fw,id_rul_fw_exported,status) VALUES('$ID_RULE','$FWEXPORTID','0','0')";
											$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR142F"));
										}
									}
								}
							}
						}
						for($f = 0; $f < sizeof($SPORT); $f++)
						{
							if(!empty($SPORT[$f]))
							{
								$PORTAPP = $SPORT[$f];
								$SQL = "INSERT INTO cc_firewall.rule_app VALUES('$ID_RULE','$PORTAPP','s')";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR113S"));
							}
						}
						for($f = 0; $f < sizeof($DPORT); $f++)
						{
							if(!empty($DPORT[$f]))
							{
								$PORTAPP = $DPORT[$f];
								$SQL = "INSERT INTO cc_firewall.rule_app VALUES('$ID_RULE','$PORTAPP','d')";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR114S"));
							}
						}
						if (!empty($MLIMIT))
						{
							$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'limit'";
							$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR036F"));
							if (mysql_affected_rows() != 0) 
							{
								$ARRAY = mysql_fetch_array($RS);
								$ID = $ARRAY['id'];
								$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
								$SQL .= "('$ID', '$MLIMIT')";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR037F"));
								if (mysql_affected_rows() != 0)
								{
									$ID = mysql_insert_id();
									$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
									$SQL .= "('$ID_RULE', '$ID')";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR038F"));
								}
							}
						}
						if (!empty($MMAC))
						{
							$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'mac'";
							$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR039F"));
							if (mysql_affected_rows() != 0) 
							{
								$ARRAY = mysql_fetch_array($RS);
								$ID = $ARRAY['id'];
								$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
								$SQL .= "('$ID', '$MMAC')";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR040F"));
								if (mysql_affected_rows() != 0)
								{
									$ID = mysql_insert_id();
									$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
									$SQL .= "('$ID_RULE', '$ID')";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR041F"));
								}								
							}
						}
						if (!empty($MSTRING))
						{
							$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'string'";
							$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR042F"));
							if (mysql_affected_rows() != 0) 
							{
								$ARRAY = mysql_fetch_array($RS);
								$ID = $ARRAY['id'];
								$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
								$SQL .= "('$ID', '$MSTRING')";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR043F"));
								if (mysql_affected_rows() != 0)
								{
									$ID = mysql_insert_id();
									$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
									$SQL .= "('$ID_RULE', '$ID')";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR044F"));
								}
							}
						}						
							// Delete the rule in table to execute for before will insert
							$SQL = "DELETE FROM cc_firewall.rulefwrun WHERE id = '$IDSELECTED'";
							$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR119F"));
					}
					if ($COMMANDADD != "S") 
					{
 
							if (!empty($TIME_START))
							{
								$SQL = "SELECT name FROM cc_firewall.variable_time WHERE id='$TIME_START'";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR143F"));
								$ARRAY = mysql_fetch_array($RS);
								$TIME_START = $ARRAY['name'];
								$SQL = "SELECT name FROM cc_firewall.variable_time WHERE id='$TIME_STOP'";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR144F"));
								$ARRAY = mysql_fetch_array($RS);
								$TIME_STOP = $ARRAY['name'];
							}
							
							$MSTATE = "";
							for ($f = 0; $f < sizeof($STATES); $f++)
							{
								if(!empty($STATES[$f]))
								{
									$ID = $STATES[$f];
									$SQL = "SELECT name FROM cc_firewall.atribute_module WHERE id = '$ID'";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR054F"));
									$ARRAY = mysql_fetch_array($RS);
									if ($f != (sizeof($STATES)-1)) {
										$MSTATE .= $ARRAY['name'].",";
									} else {
										$MSTATE .= $ARRAY['name'];
									}
								}
							}
							if ($TABLE == "nat") {
							// Select the network value if nat table selected
							$SQL = "SELECT ip FROM cc_firewall.network_address WHERE id = '$TOADDRESS'";
							$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR126F"));
							$ARRAY = mysql_fetch_array($RS);
							$TOADDRESS = $ARRAY['ip'];
							// Select the application Value if nat table selected
							$SQL = "SELECT port FROM cc_firewall.application WHERE id = '$TOPORT'";
							$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR127F"));
							$ARRAY = mysql_fetch_array($RS);
							$TOPORT = $ARRAY['port'];
							}
							
							$k = 0;						
							do
							{
								$SPORTNUMBER = $SPORTNUMBERARRAY[$k];
								$m = 0;
								do
								{
									$DPORTNUMBER = $DPORTNUMBERARRAY[$m];
									$e = 0;
									do
									{
										$SOURCEID = $SOURCE[$e];
										$SQL = "SELECT ip,mask FROM cc_firewall.network_address WHERE id = '$SOURCEID'";
										$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR120F"));
										$ARRAY = mysql_fetch_array($RS);
										if(!empty($ARRAY['mask'])){
											$SOURCEIP = $ARRAY['ip']."/".$ARRAY['mask'];
										} else {
											$SOURCEIP = $ARRAY['ip'];
										}
										
										$p = 0;
										do
										{
											$DESTINATIONID = $DESTINATION[$p];
											$SQL = "SELECT ip,mask FROM cc_firewall.network_address WHERE id = '$DESTINATIONID'";
											$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR121F"));
											$ARRAY = mysql_fetch_array($RS);
											if(!empty($ARRAY['mask'])){
												$DESTINATIONIP = $ARRAY['ip']."/".$ARRAY['mask'];
											} else {
												$DESTINATIONIP = $ARRAY['ip'];
											}

										
											// Mount the rule in one line
											$RULE = "-t $TABLE -$COMMANDADD $DIRECTION ";
											if (!empty($SOURCEIP)){if($SOURCE_COND==0){$RULE .= "-s $SOURCEIP ";}
																	else{$RULE .= "! -s $SOURCEIP ";}}
											if (!empty($DESTINATIONIP)){if($DESTINATION_COND=="0"){$RULE .= "-d $DESTINATIONIP ";}
																	else{$RULE .= "! -d $DESTINATIONIP ";}}
											if (!empty($SIFACENAME)){if($SIFACE_COND==0){$RULE .= "-i $SIFACENAME ";}
																	else{$RULE .= "! -i $SIFACENAME ";}}
											if (!empty($DIFACENAME)){if($DIFACE_COND==0){$RULE .= "-o $DIFACENAME ";}
																	else{$RULE .= "! -o $DIFACENAME ";}}
											if (!empty($PROTOCOL)){if($PROTO_COND==0){$RULE .= "-p $PROTOCOL ";}
																	else{$RULE .= "! -p $PROTOCOL ";}}
											if (!empty($SPORTNUMBER)){if((($PROTOCOL=='tcp')||($PROTOCOL=='udp'))&&($PROTO_COND==0)){
												if($SPORT_COND==0){$RULE .= "-m multiport --sport $SPORTNUMBER ";}
																	else{$RULE .= "-m multiport ! --sport $SPORTNUMBER ";}}}
											if (!empty($DPORTNUMBER)){if((($PROTOCOL=='tcp')||($PROTOCOL=='udp'))&&($PROTO_COND==0)){
												if($DPORT_COND==0){$RULE .= "-m multiport --dport $DPORTNUMBER ";}
																	else{$RULE .= "-m multiport ! --dport $DPORTNUMBER ";}}}
											if (!empty($MLIMIT)){ $RULE .= "-m limit --limit $MLIMIT ";}
											if (!empty($MMAC)){if($MAC_COND==0){$RULE .= "-m mac --mac-source $MMAC ";}
																	else{$RULE .= "-m mac ! --mac-source $MMAC ";}}
											if (!empty($MSTRING)){if($STRING_COND==0){$RULE .= '-m string --algo bm --string "'.$MSTRING.'" ';}
																	else{$RULE .= '-m string --algo bm ! --string "'.$MSTRING.'" ';}}
											if (!empty($MSTATE)){if($STATE_COND==0){$RULE .= "-m state --state $MSTATE ";}
																	else{$RULE .= "-m state ! --state $MSTATE ";}}
											if (!empty($TIME_START)){$RULE .= "-m time --timestart $TIME_START --timestop $TIME_STOP ";}
											
											if (($TABLE == "nat") || ($TABLE == "filter")) {
												if (!empty($ACTION)){ $RULE .= "-j $ACTION ";}
												if ($TABLE == "nat") {
													if ((!empty($TOADDRESS))&&(!empty($TOPORT))){ 
														if($ACTION == "SNAT"){
															$RULE .= "--to-source $TOADDRESS:$TOPORT";
															}
														elseif($ACTION == "DNAT"){
															$RULE .= "--to-destination $TOADDRESS:$TOPORT";
															}
														elseif($ACTION == "REDIRECT") {
															$RULE .= "--to $TOADDRESS:$TOPORT";
														}
													}
													elseif ((!empty($TOADDRESS))&&(empty($TOPORT))){
														if($ACTION == "SNAT"){
															$RULE .= "--to-source $TOADDRESS";
															}
														elseif($ACTION == "DNAT"){
															$RULE .= "--to-destination $TOADDRESS";
															}
														elseif($ACTION == "REDIRECT") {
															$RULE .= "--to $TOADDRESS";
														}
													}
													elseif((empty($TOADDRESS))&&(!empty($TOPORT))) {
														$RULE .= "--to-port $TOPORT";
													}
												}
											}
											else{
												if (!empty($ACTION)){
													if(substr($ACTION,0,3) == "TOS"){$RULE .= "-j ".substr($ACTION,0,3);}
													else{$RULE .= "-j ".$ACTION;}
													
													if(substr($ACTION,0,3) == "TOS"){$RULE .= " --set-tos ".substr($ACTION,3,4);}
													elseif($ACTION == "MARK"){$RULE .= " --set-mark $SETMARK";}
													else{$RULE .= substr($ACTION,3,4);}
													}
												}
											if($ACTION == "LOG"){$RULE .= " --log-level 4 --log-prefix $KEY_LOG ";}
											// Insert the rule in table to execute
											$SQL = "INSERT INTO cc_firewall.rulefwrun (id, name) VALUES ('$ID_RULE', '$RULE')";
											$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR055F"));
											// Verify if will have export and do
											//print_r(sizeof($ARRAY_FIREWALL_EXPORTED));
												for($f = 0; $f < sizeof($ARRAY_FIREWALL_EXPORTED); $f++)
												{
													//*print_r($ARRAY_FIREWALL_EXPORTED[$f]);
													if(!empty($ARRAY_FIREWALL_EXPORTED[$f]))
													{
														$ARRAY = explode("@",$ARRAY_FIREWALL_EXPORTED[$f]);
														$ID_RULE_EXPORTED = $ARRAY[0];
														$EXPORTFW = $ARRAY[1];
														$SIFACE_NAME_EXPORT = $ARRAY[2];
														$DIFACE_NAME_EXPORT = $ARRAY[3];
														$test_conn = test_connect_in_other_fw($EXPORTFW,$TIME_OUT_CONN_DB);
														if($test_conn == 1)
														{
															if(!empty($SIFACE_NAME_EXPORT))
															{
																if($SOURCE_COND==0){
																	$RULE = str_replace('-i '.$SIFACENAME,'-i '.$SIFACE_NAME_EXPORT,$RULE);
																} else{
																	$RULE = str_replace('-i ! '.$SIFACENAME,'-i ! '.$SIFACE_NAME_EXPORT,$RULE);
																}
				
															} else {
																if($SOURCE_COND==0){
																	$RULE = str_replace('-i '.$SIFACENAME,'',$RULE);
																} else{
																	$RULE = str_replace('-i ! '.$SIFACENAME,'',$RULE);
																}
															}
															if(!empty($DIFACE_NAME_EXPORT))
															{
																if($DIFACE_COND==0){
																	$RULE = str_replace('-o '.$DIFACENAME,'-o '.$DIFACE_NAME_EXPORT,$RULE);
																} else{
																	$RULE = str_replace('-o ! '.$DIFACENAME,'-o ! '.$DIFACE_NAME_EXPORT,$RULE);
																}
															} else {
																if($DIFACE_COND==0){
																	$RULE = str_replace('-o '.$DIFACENAME,'',$RULE);
																} else{
																	$RULE = str_replace('-o ! '.$DIFACENAME,'',$RULE);
																}
															}
															$SQL = "INSERT INTO cc_firewall.rulefwrun (id, name) VALUES ('$ID_RULE_EXPORTED', '$RULE')";
															$RS = mysql_query($SQL,connect_in_other_fw($EXPORTFW)) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR135F"));
															// Just go to back connection to localhost database.
															$SQL = "SELECT id FROM controlcenter.language WHERE id = 1";
															$RS = mysql_query($SQL,connect_in_other_fw('127.0.0.1'));
														}
													}
												}
											$p++;
										}while($p < sizeof($DESTINATION));
									$e++;
								}while($e < sizeof($SOURCE));
								$m++;
							}while($m < sizeof($DPORTNUMBERARRAY));
							$k++;
						}while($k < sizeof($SPORTNUMBERARRAY));
					}
				}
				if($LOG_AUDITOR == 1){
						auditor('IFWXR051S', $ADDRIP, $USER, '0');
				}
				$_SESSION['SHOW_MSG'] = 'F_SUCESS';
				needApply('1');
				unset($_SESSION['DIRECTION']);
				unset($_SESSION['ID_RULE_EXPORTED']);
				header("Location:$DESTINATION_PAGE");
			}
		}
	}
?>