<div id="left_menu_report"><!-- Sub-menu -->
<div class="show_title_report">
	<?php 
		echo $T_HISTORY;
	?>
</div>
<?php 
if ($REPORT == "service") {

// Estudar is_ readable
		//$COMMAND = "/var/www/controlcenter/modules/firewall/.choose_report_service.sh";
		$COMMAND = "./.choose_report_service.sh";
	}
else {
		//$COMMAND = "/var/www/controlcenter/modules/firewall/.choose_report_protocol.sh";
		$COMMAND = "./.choose_report_protocol.sh";
	}
	system($COMMAND,$RESULT);
?>
</div> <!-- Sub-menu -->