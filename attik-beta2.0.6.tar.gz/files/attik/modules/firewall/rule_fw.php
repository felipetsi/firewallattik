<?php 
require_once('../../includes/control_session.php');
require_once('includes/variable_personal.php');
require_once('configuration/general.php');

$DESTINATION_PAGE = "rule_run_fw.php";
$THISPAGE = "rule_fw.php";
$PAGE_DELETE="rule_delete_fw.php";
$ALTERPOSITIONUP = "rule_alter_position_up_fw.php";
$ALTERPOSITIONDOWN = "rule_alter_position_down_fw.php";
$_SESSION['FILE_LANG'] = "firewall.php";

// Load the profile of user autenticanted
$SQL = "SELECT create_rule, read_rule FROM controlcenter.profilefw WHERE id IN ";
$SQL .= "(SELECT id_profw FROM controlcenter.profile WHERE id IN (SELECT id_pro FROM ";
$SQL .= "controlcenter.user WHERE id = '$USER'))";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR001F"));
$DATA_USER = mysql_fetch_array($RS);

//Storage in session for know tha page was send alter position of rule.
$_SESSION['SOURCE_PAGE'] = $THISPAGE;

// Define the page of sequence selected
$PAGE_SEQ_P = substr(trim(addslashes($_POST['page_seq'])),0,3);
if($PAGE_SEQ_P == "") {
	$PAGE_SEQ_P = $_SESSION['PAGE_SEQ_P'];
} else {
	$_SESSION['PAGE_SEQ_P'] = $PAGE_SEQ_P;
}
$PAGE_SEQ = ceil($PAGE_SEQ_P*$QUANTITY_RULE_SHOW);

//Select the table of page
$TABLE = trim(addslashes($_POST['type_rule']));
if (empty($TABLE))
{
	if (empty($_SESSION['TABLE']))
	{
		$TABLE = "filter";
		$_SESSION['TABLE'] = $TABLE;		
	}
	else
	{
		$TABLE = $_SESSION['TABLE'];
	}

}
else
{
	$_SESSION['PAGE_SEQ_P'] = 0;
	$PAGE_SEQ = 0;
	$PAGE_SEQ_P = 0;
	$_SESSION['TABLE'] = $TABLE;
}
switch ($TABLE){
	case "filtering": {
		$TABLE = "filter";
		$_SESSION['TABLE'] = $TABLE;
		break;
		}
	case "tos": {
		$TABLE = "mangle";
		$_SESSION['TABLE'] = $TABLE;
		break;
		}
	case "loadbalance": {
		$TABLE = "nat_load";
		$_SESSION['TABLE'] = $TABLE;
		break;
		}
}

// Destroy the variable for block that the user click in Back botton of browser
//unset($_SESSION['CONTROLBACK']);

// Direction selected
$DIRECTION = $_POST['direction'];
if (empty($DIRECTION))
{
	$DIRECTION = $_SESSION['DIRECTION'];
}
else 
{
	$_SESSION['DIRECTION'] = $DIRECTION;
	$_SESSION['DIRECTION2'] = $DIRECTION;;
}

// Select the object selected
$ID = $_POST['rule'];
if (!is_array($ID)){
	$ID = split(",",$ID);
}
$QTD_ITEM = sizeof($ID);
$ITEMID = trim(addslashes($ID[0]));
if (empty($ITEMID))
{
	$ITEMID = $_SESSION['ITEMID'];
}
else
{
	$_SESSION['ITEMID'] = $ITEMID;
}
$_SESSION['ITEMDELETE'] = $ID;
if(!empty($_POST['showall'])){
	unset($_SESSION['SQL_SEARCH']);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<!-- Load the javascript code -->
<SCRIPT TYPE="text/javascript" SRC="../../includes/filterlist.js"></SCRIPT>
<title><?php echo $TITLE_FW; ?></title>
<link href="../../includes/style_cc.css" rel="stylesheet" type="text/css" />
<link href="style_firewall_rule.css" rel="stylesheet" type="text/css" />
<?php
echo ('
<script language="javascript">
var thispage = "'.$THISPAGE.'";
var deletepage = "'.$PAGE_DELETE.'";
function positionPage()
{
	window.location="'.$THISPAGE.'#'.$ITEMID.'";
}
</script>');
?>
</head>
<?php if((!empty($ITEMID))||(!empty($_SESSION['TRYINSERTRULE']))){
echo '<body onload="javascript:changeAction(); verifyAction(); SelectCheckedAfter(); verifyProto(); showDetailSelected();" >';} else {
echo '<body onload="javascript:changeAction(); verifyAction(); SelectCheckedAfter(); verifyProto();" >';
}
require_once('../../includes/top.php');
require_once('fw_menu.php');
require_once('fw_menu_rule.php');
?>
<div id="main"> <!--Main-->

<?php 
if ($DATA_USER['create_rule'] == 1)//If of permition
{
	require_once('rule_details_fw.php');
} //If of permition

if ($DATA_USER['read_rule'] == 1) //If of permition
{
	//include('fw_menu_rule.php');
	require_once('rule_show_all_fw.php');
} //If of permition ?>
<script language="javascript">
positionPage();
</script>
<div class="version_general">
<?php
echo $VERSIONCC;
?>
</div>

</div><!--Main-->
</body>
</html>
<?php
unset($_SESSION['SIFACE']);
unset($_SESSION['SOURCE']);
unset($_SESSION['DIFACE']);
unset($_SESSION['DESTINATION']);
unset($_SESSION['PROTO']);
unset($_SESSION['DPORT']);
unset($_SESSION['SPORT']);
unset($_SESSION['EXPORTFW']);
unset($_SESSION['HOUR']);
unset($_SESSION['COMMENT']);
unset($_SESSION['limit']);
unset($_SESSION['state']);
unset($_SESSION['mac']);
unset($_SESSION['string']);
unset($_SESSION['smultiport']);
unset($_SESSION['dmultiport']);
unset($_SESSION['ACTION']);
unset($_SESSION['ITEMID']);
unset($_SESSION['COMMANDADD']);
unset($_SESSION['TIMESTART']);
unset($_SESSION['TIMEEND']);
unset($_SESSION['TRYINSERTRULE']);
unset($_SESSION['SIFACE_COND']);
unset($_SESSION['DIFACE_COND']);
unset($_SESSION['SOURCE_COND']);
unset($_SESSION['DESTINATION_COND']);
unset($_SESSION['SPORT_COND']);
unset($_SESSION['DPORT_COND']);
unset($_SESSION['PROTO_COND']);
unset($_SESSION['MAC_COND']);
unset($_SESSION['STRING_COND']);
unset($_SESSION['STATE_COND']);
if (!empty($ITEMID))
{
	unset($_SESSION['DIRECTION']);
}
?>