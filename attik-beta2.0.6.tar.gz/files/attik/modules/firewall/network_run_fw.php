<?php 
require_once('../../includes/control_session.php');
require_once('includes/functions.php');

$DESTINATION_PAGE = "network_fw.php";

$ID = trim(addslashes($_POST['id']));
$NAME = substr(trim(addslashes($_POST['name'])),0,20);
$DESCRIPTION = substr(trim(addslashes($_POST['description'])),0,100);
$CLASS = substr(trim(addslashes($_POST['class'])),0,18);
$MASK = substr(trim(addslashes($_POST['mask'])),0,18);
$GLOBAL = substr(trim(addslashes($_POST['localglobal'])),0,1);

if ((empty($NAME)) || (empty($CLASS))) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDFILL';
	$_SESSION['ITEMID'] = $ID;
	$_SESSION['EX_CLASS'] = $CLASS;
	$_SESSION['EX_MASK'] = $MASK;
	$_SESSION['EX_NAME'] = $NAME;
	$_SESSION['EX_DESCRIPTION'] = $DESCRIPTION;
	$_SESSION['GLOBAL'] = $GLOBAL;
	header("Location:$DESTINATION_PAGE");
}
elseif((!empty($CLASS)) && (verifyIp($CLASS) != "ok") && ($CLASS != "0.0.0.0") ||
((sizeof(explode("/",$CLASS)) > 1) && (!empty($MASK)) )){
	$_SESSION['SHOW_MSG'] = 'ME_INVALIDCLASS';
	$_SESSION['ITEMID'] = $ID;
	$_SESSION['EX_NAME'] = $NAME;
	$_SESSION['EX_CLASS'] = $CLASS;
	$_SESSION['EX_MASK'] = $MASK;
	$_SESSION['EX_DESCRIPTION'] = $DESCRIPTION;
	$_SESSION['GLOBAL'] = $GLOBAL;
	header("Location:$DESTINATION_PAGE");
}
elseif((verifyMask($MASK) != "ok")&&(!empty($MASK))){
	$_SESSION['SHOW_MSG'] = 'ME_INVALIDMASK';
	$_SESSION['ITEMID'] = $ID;
	$_SESSION['EX_NAME'] = $NAME;
	$_SESSION['EX_CLASS'] = $CLASS;
	$_SESSION['EX_MASK'] = $MASK;
	$_SESSION['EX_DESCRIPTION'] = $DESCRIPTION;
	$_SESSION['GLOBAL'] = $GLOBAL;
	header("Location:$DESTINATION_PAGE");
}
else { 
	if(empty($ID)){
		$ID = 0;
	}
	$SQL = "SELECT * FROM cc_firewall.network_address WHERE (name = '$NAME' OR (ip = '$CLASS' AND mask = '$MASK') ) ";
	$SQL .= "AND id != $ID";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSN008F"));
	if ( mysql_affected_rows() !=0 )
	{
		if($LOG_AUDITOR == 1){
			auditor('IFWSN008F', $ADDRIP, $USER, '0');
		}
		$_SESSION['SHOW_MSG'] = 'ME_NAMEORCLASSEXIST';
		$_SESSION['ITEMID'] = $ID;
		$_SESSION['EX_NAME'] = $NAME;
		$_SESSION['EX_CLASS'] = $CLASS;
		$_SESSION['EX_MASK'] = $MASK;
		$_SESSION['EX_DESCRIPTION'] = $DESCRIPTION;
		$_SESSION['GLOBAL'] = $GLOBAL;
		header("Location:$DESTINATION_PAGE");
	}
	else {
		if (empty($ID)) {
				
			$SQL = "INSERT INTO cc_firewall.network_address (name, ip, mask, description, global) "; 
			$SQL .= "VALUES ('$NAME', '$CLASS',  '$MASK', '$DESCRIPTION', '$GLOBAL')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIN009F"));
		}
		else {
			// Get the old value whould by change 
			$SQL = "SELECT ip,mask FROM cc_firewall.network_address WHERE id = '$ID'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSN014F"));
			$ARRAY = mysql_fetch_array($RS);
			if (empty($ARRAY['mask'])){
				$OLDVALUE = $ARRAY['ip'];
			} else {
				$OLDVALUE = $ARRAY['ip'].'/'.$ARRAY['mask'];
			}
			// Update the value
			$SQL = "UPDATE cc_firewall.network_address SET name='$NAME', ip='$CLASS', mask='$MASK', ";
			$SQL .= "description='$DESCRIPTION', global='$GLOBAL' WHERE id = '$ID' ";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUN010F"));
		}
		if (mysql_affected_rows() != 0) {
			if($LOG_AUDITOR == 1){
				auditor('IFWXN011S', $ADDRIP, $USER, '0');
			}
			$_SESSION['SHOW_MSG'] = 'F_SUCESS';
			if (!empty($ID)) {
				updateSyncRules("net",$ID,$OLDVALUE);
			}
		} else {
			if($LOG_AUDITOR == 1){
				auditor('IFWXN011F', $ADDRIP, $USER, '0');
			}
			$_SESSION['SHOW_MSG'] = 'F_FAILURE';
		}
		header("Location:$DESTINATION_PAGE");
	}
}
?>