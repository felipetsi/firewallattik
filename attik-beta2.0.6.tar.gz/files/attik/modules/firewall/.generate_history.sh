#!/bin/bash

# Home directory of attik pages
DIRHOMEPAGES="/var/www/attik"

for GRAPH_FILE in `ls $DIRHOMEPAGES/modules/firewall/graph/$REPORTTYPE*`
do
NAMEFILE=$(echo $GRAPH_FILE | cut -f2 -d "_" | cut -f1 -d "." | sed 's\-\/\' | sed 's\-\/\')
DATEFILE=$(echo $GRAPH_FILE | cut -f2 -d "_" | cut -f1 -d ".")

NAMEFORM=$(expr $NAMEFORM + 1)
echo '
<form action="report_fw.php" method="post" name="incti'"$NAMEFORM"'">
<a href="javascript:document.incti'"$NAMEFORM"'.submit();">
	<div class="button_date_report" onclick="javascript:document.'"$NAMEFORM"'.submit();">
		<input type="hidden" name="date_report" value="'"$DATEFILE"'" />
		<img src="$DIRHOMEPAGES/@img/icons/calendar-24x24.gif" align="absmiddle"/>
		'"$NAMEFILE"'
	</div>
</a>
</form>
'
done
