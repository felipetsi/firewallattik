<?php 
require_once('../../includes/control_session.php');?>
<html>
<head>
<?php echo '<meta http-equiv="refresh" content="'.$_SESSION['TIMEUPDATE'].'; URL=monitor_show_log_fw.php"/>';?>
<title>ShowLogMonitor</title>
<link href="../../includes/style_cc.css" rel="stylesheet" type="text/css" />
<link href="style_firewall_rule.css" rel="stylesheet" type="text/css" />
</head>

<body>
<select name="list" size="17" multiple="multiple" class="select_full_monitor" >
	<?php
	$FILTER = '|grep Attik';
	if(!empty($_SESSION['FIELD1'])){
		$FILTER .= "|grep -i ".$_SESSION['FIELD1'] ;
		if(!empty($_SESSION['FIELD2'])){
			$FILTER .= "|grep -i ".$_SESSION['FIELD2'];
			if(!empty($_SESSION['FIELD3'])){
				$FILTER .= "|grep -i ".$_SESSION['FIELD3'];
				if(!empty($_SESSION['FIELD4'])){
					$FILTER .= "|grep -i ".$_SESSION['FIELD4'];
					if(!empty($_SESSION['FIELD5'])){
						$FILTER .= "|grep -i ".$_SESSION['FIELD5'];
					}
				}
			}
		}
	}
	$COMMAND = 'sudo tail -n '.$_SESSION['MAXNUMLINE'].' /var/log/messages '."$FILTER".' | awk \'{print $1"  "$2"  "$3"  "$8"  "$9"  "$11"  "$12"  "$17"  "$18"  "$19"  "$20"  "$21}\'';
	echo $COMMAND;
	exec($COMMAND,$RETURN);
	$LENGTHARRAY=sizeof($RETURN);
	for ($f=1; $f <= $LENGTHARRAY; $f++)
	{?>
		<option ><?php echo $RETURN[$LENGTHARRAY-$f];?></option><?php
	}
	?>
</select>

</body>
</html>

