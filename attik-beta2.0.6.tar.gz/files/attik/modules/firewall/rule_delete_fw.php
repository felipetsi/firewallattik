<?php 
require_once('../../includes/control_session.php');
require_once('includes/functions.php');

$DESTINATION_PAGE = $_SESSION['SOURCE_PAGE'];

$_SESSION['PAGE_SEQ_P'] = ($_SESSION['PAGE_SEQ_P']-1);

//$IDARRAY = $_SESSION['ITEMDELETE'];
$ID = $_POST['rule'];
$EXPORTED = $_SESSION['EXPORTED'];
if (!is_array($ID)){
	$IDARRAY = split(",",$ID);
}

if ((sizeof($IDARRAY) == 0) || (empty($IDARRAY[0]))) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDSELECT';
	header("Location:$DESTINATION_PAGE");
}/* elseif ($EXPORTED == '1')
{
	$_SESSION['SHOW_MSG'] = 'ME_RULEEXPORTED_CANTCHAGE';
	header("Location:$DESTINATION_PAGE");
}*/
else {
	for ($F = 0; $F < sizeof($IDARRAY); $F++)
	{
		$ID = $IDARRAY[$F];
		
		// Delete the attributes
		$SQL = "DELETE FROM cc_firewall.atribute_module WHERE id IN (SELECT id_atr FROM ";
		$SQL .= "cc_firewall.rul_atr WHERE id_rul = '$ID') AND id_mod IN (SELECT id FROM ";
		$SQL .= "cc_firewall.module WHERE definitive <> '1')";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR068F"));
	
		// Delete the associated (rul_atr)
		$SQL = "DELETE FROM cc_firewall.rul_atr WHERE id_rul = '$ID'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR069F"));
		
		// Delete the associated network (rule_nat_app)
		$SQL = "DELETE FROM cc_firewall.rule_nat_net WHERE id_rul = '$ID'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR070F"));
		
		// Delete the associated application (rule_nat_app)
		$SQL = "DELETE FROM cc_firewall.rule_nat_app WHERE id_rul = '$ID'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR128F"));
		
		// Delete the associated varriable time
		$SQL = "DELETE FROM cc_firewall.rul_vartime WHERE id_rul = '$ID'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR071F"));
		
		// Delete the associated addres with rule
		$SQL = "DELETE FROM cc_firewall.rul_net WHERE id_rul = '$ID'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR115S"));

		// Delete the application associated to rule		
		$SQL = "DELETE FROM cc_firewall.rule_app WHERE id_rul = '$ID'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR034F"));
		
		// Delete the rule
		$SQL = "DELETE FROM cc_firewall.rulefw WHERE id = '$ID'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR072F"));
		
		// Delete the rule mounted
		$SQL = "DELETE FROM cc_firewall.rulefwrun WHERE id = '$ID'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR110S"));
		
		// Delete the rules exported to other firewalls
		$SQL = "SELECT f.ip,r.id_rul_fw_exported FROM controlcenter.firewall_list f, cc_firewall.rule_firewall_list r ";
		$SQL .= "WHERE f.id IN (SELECT id_fw FROM cc_firewall.rule_firewall_list WHERE id_rul = '$ID')";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR110S"));
		$ARRAY = mysql_fetch_array($RS);
		
		do
		{
			$test_conn = test_connect_in_other_fw($FWADDRESS,$TIME_OUT_CONN_DB);
			if($test_conn == 1)
			{
				$FWADDRESS = $ARRAY['ip'];
				$ID_RULE_EXPORTED = $ARRAY['id_rul_fw_exported'];
				deleteExportedRuleFw($ID, $ID_RULE_EXPORTED,$TABLE,$FWADDRESS);
				// Delete the rule
				// Established the conection
				$CONN_FW_EXPORT = connect_in_other_fw($FWADDRESS);
			
				$SQL = "DELETE FROM cc_firewall.rulefw WHERE id = '$ID_RULE_EXPORTED'";
				$RSOBJ = mysql_query($SQL,$CONN_FW_EXPORT) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR140F"));
				
				// Delete the rule mounted
				$SQL = "DELETE FROM cc_firewall.rulefwrun WHERE id = '$ID_RULE_EXPORTED'";
				$RSOBJ = mysql_query($SQL,$CONN_FW_EXPORT) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR141F"));
			} else {
				// Delete the association this rule to Firewall exported
				$SQL = "DELETE FROM cc_firewall.rule_firewall_list WHERE id_rul = '$ID'";
				$RSOBJ = mysql_query($SQL,connect_in_other_fw('127.0.0.1'));
			}
		}while($ARRAY = mysql_fetch_array($RS));
	}	
	if ( mysql_affected_rows() !=0 )
	{
		if($LOG_AUDITOR == 1){
				auditor('IFWDR072S', $ADDRIP, $USER, '0');
		}
		$_SESSION['SHOW_MSG'] = 'F_SUCESS';
		needApply('1');
	}else {
		if($LOG_AUDITOR == 1){
				auditor('IFWDR072F', $ADDRIP, $USER, '0');
		}
		$_SESSION['SHOW_MSG'] = 'F_FAILURE';
	}
		// Just go to back connection to localhost database.
		$SQL = "SELECT id FROM controlcenter.language WHERE id = 1";
		$RS = mysql_query($SQL,connect_in_other_fw('127.0.0.1'));
		unset($_SESSION['ITEMDELETE']);
		unset($_SESSION['SOURCE_PAGE']);
		header("Location:$DESTINATION_PAGE");
}
?>