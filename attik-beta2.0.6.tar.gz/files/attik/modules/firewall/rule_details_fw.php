<script language="javascript">
var actId = new Array();
var actName = new Array();
var outherProto = new Array();
var TcpProto = new Array();
var UdpProto = new Array();
var TcpProtoPort = new Array();
var TcpProtoName = new Array();
var UdpProtoPort = new Array();
var UdpProtoName = new Array();
var SNetSelectedN = new Array();
var SNetSelectedI = new Array();
var DNetSelectedN = new Array();
var DNetSelectedI = new Array();
var SAppSelectedN = new Array();
var SAppSelectedI = new Array();
var DAppSelectedN = new Array();
var DAppSelectedI = new Array();
var netName = new Array();
var netId = new Array();
var FirewallExportedSelectedN = new Array();
var FirewallExportedSelectedI = new Array();
var firewallListName = new Array();
var	firewallListId = new Array();
var objSelectRule = 0;
var NetworkNat = 0;
var ApplicationNat = 0;
var i = 0;
var f = 0;
var actSele = 0;
var dirinp = 0;
var dirout = 0;
var dirfor = 0;
var dirpos = 0;
var dirpre = 0;
var appName = 0;
var appId = 0;
var fistFindAvaiable = 0;
var fistFindSelected= 0;

function showDetailSelected()
{
	document.getElementById('r_show_rule_detail').style.display="table";
	document.getElementById('r_show_rule').style.height="136px";
}
function showDetails()
{
	if(document.getElementById('r_show_rule_detail').style.display=="none"){
		document.getElementById('r_show_rule_detail').style.display="table";
		document.getElementById('r_show_rule').style.height="136px";
	} else {
		document.getElementById('r_show_rule_detail').style.display="none";
		document.getElementById('r_show_rule').style.height="300px";
	}
}

function confirmDeleteSelected()
{
	document.getElementById('background_transparent').style.display="inline";
	document.getElementById('box_delete').style.display="table";
}
function yesdeleteSelected()
{
	setValuesCheck();
}
function nodeleteSelected()
{
	document.getElementById('box_delete').style.display="none";
	document.getElementById('background_transparent').style.display="none";
}
function selectPageSel($pageSeq)
{
	document.getElementById('page_seq').value=$pageSeq;
	document.formPageSeq.submit();
}
function findObj(source)
{
	if(source == 's')
	{
		if(fistFindSelected    == 0)
		{
			myfilterSelected = new filterlist(document.fobjselect.itemSelected); fistFindSelected= 1; myFilterTempSelected = myfilterSelected;
		}else{
			myfilterSelected = myFilterTempSelected; 
		}
	} else {
		if(fistFindAvaiable == 0)
		{
			myfilterAvaiable = new filterlist(document.fobjselect.itemAvailable); fistFindAvaiable = 1; myFilterTempAvaiable = myfilterAvaiable;
		}else{
			myfilterAvaiable = myFilterTempAvaiable; 
		}
	}
}
function addObjSelected(objSource,objDestination,flow)
{
	var len = objSource.length;
	var objHave = 0;
	if (flow == 'as')
	{
		document.fobjselect.filterselected.value=null;
	} else {
		document.fobjselect.filteravaiable.value=null;
	}
	for(var f = 0; f < len; f++)
	{
		if((objSource.options[f] != null) && (objSource.options[f].selected))
		{
			for(var p = 0; p < objDestination.length; p++)
			{
				if(objDestination.options[p].text == objSource.options[f].text)
				{
					objHave = 1;
				}
			}
			if(objHave != 1)
			{
				objDestination.options[objDestination.length] = new Option(objSource.options[f].text, objSource.options[f].value);
				len++;
				f++;
				objSource.options[f-1] = null;
				if(objSelectRule == 'source'){
					for (p=0; p < SNetSelectedN.length; p++)
					{
						SNetSelectedN.splice(p, 1);
						SNetSelectedI.splice(p, 1);
					}
				} else if(objSelectRule == 'destination') {
					for (p=0; p < DNetSelectedN.length; p++)
					{
						DNetSelectedN.splice(p, 1);
						DNetSelectedI.splice(p, 1);
					}
				} else if(objSelectRule == 'selsport'){
					for (p=0; p < SAppSelectedN.length; p++)
					{
						SAppSelectedN.splice(p, 1);
						SAppSelectedI.splice(p, 1);
					}
				} else if(objSelectRule == 'seldport') {
					for (p=0; p < DAppSelectedN.length; p++)
					{
						DAppSelectedN.splice(p, 1);
						DAppSelectedI.splice(p, 1);
					}
				}
				else if(objSelectRule == 'export') {
					//for (p=0; p < DNetSelectedN.length; p++)
					for (p=0; p < FirewallExportedSelectedN.length; p++)
					{
						FirewallExportedSelectedN.splice(p, 1);
						FirewallExportedSelectedI.splice(p, 1);
					}
				}
			}
		}
	}
varSelectItemSelected = document.fobjselect.itemSelected;
}
function createObj(selectedObjN,selectedObjI,allObjN,allObjI,objSelectRulePosted)
{
	objSelectRule = objSelectRulePosted;
	do
	{
		document.fobjselect.itemAvailable.options[document.fobjselect.itemAvailable.length - 1] = null;
	}while(document.fobjselect.itemAvailable.length > 0);
	do
	{
		document.fobjselect.itemSelected.options[document.fobjselect.itemSelected.length - 1] = null;
	}while(document.fobjselect.itemSelected.length > 0);

	for(var f = 0; f < allObjI.length; f++)
	{
	var objHave = 0;
		for(var p = 0; p < selectedObjI.length; p++)
		{
			if(allObjI[f] == selectedObjI[p])
			{
				objHave++;
			}
		}
		if(objHave > 0)
		{
			document.fobjselect.itemSelected[document.fobjselect.itemSelected.length] = new Option(allObjN[f], allObjI[f]);
		} else
		{
			document.fobjselect.itemAvailable[document.fobjselect.itemAvailable.length] = new Option(allObjN[f], allObjI[f]);
		}
	}
	document.fobjselect.filterselected.value=null;
	document.fobjselect.filteravaiable.value=null;
	document.getElementById('background_transparent').style.display="inline";
	document.getElementById('box_obj_selected').style.display="table";
}
function createObjSelected(dataName,dataValue,objtarget,vobjtarget)
{
	var len = objtarget.options.length;
	for(var f = 1; f < len; f++)
	{
		objtarget.options[objtarget.options.length - 1] = null;
	}
	vobjtarget.value = "";
	
	for(var f = 0; f < dataName.length; f++)
	{
		objtarget[f+1] = new Option(dataName[f], dataValue[f]);
		if((f+1) == dataName.length) {
			vobjtarget.value =  vobjtarget.value+objtarget.options[f+1].value;
		} else {
			vobjtarget.value =  vobjtarget.value+objtarget.options[f+1].value+"@";
		}
	}
}
function closeBoxObjAndSave()
{
	document.fobjselect.filterselected.value=null;
	document.fobjselect.filteravaiable.value=null;
	myfilterSelected = null;
	myFilterTempSelected = null;
	myfilterAvaiable = null;
	myFilterTempAvaiable = null;
	fistFindAvaiable = 0;
	fistFindSelected= 0;
	
	objtarget = document.fobjselect.itemSelected;
	if(objSelectRule == 'source')
	{
		for (p=0; p < SNetSelectedN.length; p++)
		{
			SNetSelectedN.splice(p, 1);
			SNetSelectedI.splice(p, 1);
		}
		
		for(f = 0; f < objtarget.length; f++)
		{
			SNetSelectedN[f] = objtarget.options[f].text;
			SNetSelectedI[f] = objtarget.options[f].value;
		}
	createObjSelected(SNetSelectedN,SNetSelectedI,document.formRule.source,document.formRule.vsource);
	}
	else if(objSelectRule == 'destination')
	{
		for (p=0; p < DNetSelectedN.length; p++)
		{
			DNetSelectedN.splice(p, 1);
			DNetSelectedI.splice(p, 1);
		}

		for(f = 0; f < objtarget.length; f++)
		{
			DNetSelectedN[f] = objtarget.options[f].text;
			DNetSelectedI[f] = objtarget.options[f].value;
		}
	createObjSelected(DNetSelectedN,DNetSelectedI,document.formRule.destination,document.formRule.vdestination);
	}
	else if(objSelectRule == 'selsport')
	{
		for (p=0; p < SAppSelectedN.length; p++)
		{
			SAppSelectedN.splice(p, 1);
			SAppSelectedI.splice(p, 1);
		}
		
		for(f = 0; f < objtarget.length; f++)
		{
			SAppSelectedN[f] = objtarget.options[f].text;
			SAppSelectedI[f] = objtarget.options[f].value;
		}
	createObjSelected(SAppSelectedN,SAppSelectedI,document.formRule.selsport,document.formRule.vselsport);
	}
	else if(objSelectRule == 'seldport')
	{
		for (p=0; p < DAppSelectedN.length; p++)
		{
			DAppSelectedN.splice(p, 1);
			DAppSelectedI.splice(p, 1);
		}

		for(f = 0; f < objtarget.length; f++)
		{
			DAppSelectedN[f] = objtarget.options[f].text;
			DAppSelectedI[f] = objtarget.options[f].value;
		}
	createObjSelected(DAppSelectedN,DAppSelectedI,document.formRule.seldport,document.formRule.vseldport);
	}
	else if(objSelectRule == 'export') 
	{
		for (p=0; p < FirewallExportedSelectedN.length; p++)
		{
			FirewallExportedSelectedN.splice(p, 1);
			FirewallExportedSelectedI.splice(p, 1);
		}

		for(f = 0; f < objtarget.length; f++)
		{
			FirewallExportedSelectedN[f] = objtarget.options[f].text;
			FirewallExportedSelectedI[f] = objtarget.options[f].value;
		}
	createObjSelected(FirewallExportedSelectedN,FirewallExportedSelectedI,document.formRule.selexport,document.formRule.vselexport)
	}
	document.getElementById('background_transparent').style.display="none";
	document.getElementById('box_obj_selected').style.display="none";
}
function closeBoxObj()
{
	document.getElementById('background_transparent').style.display="none";
	document.getElementById('box_obj_selected').style.display="none";
	document.fobjselect.filterselected.value=null;
	document.fobjselect.filteravaiable.value=null;
	myfilterSelected = null;
	myFilterTempSelected = null;
	myfilterAvaiable = null;
	myFilterTempAvaiable = null;
	fistFindAvaiable = 0;
	fistFindSelected= 0;
}
function clickBackgroudTrabsparent()
{
	nodeleteSelected();
	closeBoxObj();
	
}
</script>
<?php
$SQL = "SELECT id, name, ip, mask FROM cc_firewall.network_address ORDER BY name";
$RSOPT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR112F"));
$OBJ = mysql_fetch_array($RSOPT);
$F = 0;
do {
	if(!empty($OBJ['name']))
		{
		if(empty($OBJ['mask'])){
			$ADDR_LOOP = $OBJ['ip'];
		} else {
			$ADDR_LOOP = $OBJ['ip'].'/'.$OBJ['mask'];
		}
		echo ('
			<script language="javascript">
				netName['.$F.'] = "'.$OBJ['name'].': '.$ADDR_LOOP.'";
				netId['.$F.'] = "'.$OBJ['id'].'";
			</script>');
			$F++;
		}
	}while($OBJ = mysql_fetch_array($RSOPT));
?>
	<div id="background_transparent" onclick="javascript:clickBackgroudTrabsparent();"></div>
	<div id="box_obj_selected">
	<img src="../../@img/icons/close-16x16.png" onclick="javascript:closeBoxObj();" style="float:right;"/>
	<form name="fobjselect">
		<div class="box_obj_selected_left">
			<?php echo $T_SELECTED;?>
			<div class="box_find">
				
			<input class="input_find" type="text" name="filterselected" onKeyUp="javascript:findObj('s'); myfilterSelected.set(this.value);" /><img src="../../@img/icons/search-16x16.jpg" alt="<?php echo  $B_SEARCH;?>"/>
			</div>
			<select name="itemSelected" size="2" style="width:308px; height:160px; " ondblclick="javascript:addObjSelected(fobjselect.itemSelected,fobjselect.itemAvailable,'sa');">
				
			</select>
		</div>
		<div class="box_obj_selected_center">
			<input type="button" alt="+" onclick="javascript:addObjSelected(fobjselect.itemAvailable,fobjselect.itemSelected,'as');" value="<"><br />
			<input type="button" alt="-" onclick="javascript:addObjSelected(fobjselect.itemSelected,fobjselect.itemAvailable,'sa');" value=">"><br />
			<img src="../../@img/icons/Ok-16x16.png" onclick="javascript:closeBoxObjAndSave();" />
		</div>
		<div class="box_obj_selected_rigth">
			<?php echo $T_AVAILABLE;?>
			<div class="box_find">
				
			<input class="input_find" type="text" name="filteravaiable" onKeyUp="javascript:findObj('a'); myfilterAvaiable.set(this.value);"/><img src="../../@img/icons/search-16x16.jpg" alt="<?php echo  $B_SEARCH;?>"/>
			</div>
			<select name="itemAvailable" size="2" style="width:308px; height:160px;" ondblclick="javascript:addObjSelected(fobjselect.itemAvailable,fobjselect.itemSelected,'as');">
			</select>
		</div>
	</form>
	</div>
	
	<div id="box_delete"><?php echo("$S_WANT_DELETE $S_SELECTED?");?> 
		<div class="space_confirm_box">
			<input type="button" value="<?php echo $B_YES;?>" onclick="javascript:yesdeleteSelected();" />
			<input type="button" value="<?php echo $B_NO;?>" onclick="javascript:nodeleteSelected();" />
		</div>	
	</div>
<form action="<?php echo $DESTINATION_PAGE;?>" method="post" name="formRule">
<?php
if (empty($ITEMID)){
	$SHOWDETAILS = 'style="display:none"';
} else {
	$SHOWDETAILS = "";
}
?>
<div id="r_show_rule_detail" ><!--Show detail-->
<?php
		$SQL = "SELECT DISTINCT r.*, ";
		$SQL .= "ac.name as action, ac.id as id_action, t.id as id_table FROM ";
		$SQL .= "cc_firewall.rulefw r, cc_firewall.action ac, cc_firewall.tablefw t WHERE ";
		$SQL .= "t.id IN (SELECT id FROM cc_firewall.tablefw WHERE name = '$TABLE') "; 
		$SQL .= "AND ac.name IN (SELECT name FROM cc_firewall.action WHERE id IN ";
		$SQL .= "(SELECT tda.id_act FROM cc_firewall.tab_dir_act tda WHERE r.id_tab_dir_act = tda.id))";
		$SQL .= "AND CONCAT_WS('-', r.id) = '$ITEMID'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR073F"));
		$ARRAY = mysql_fetch_array($RS);
		
		$_SESSION['EXPORTED'] = $ARRAY['exported'];
?>
<div class="r_info"><!-- Information -->

<div class="r_box_info_left"><!-- Box left -->
	<div class="r_box_text">
		<u>
		<?php echo $T_DIRECTION;?></u><img src="../../@img/icons/direction-16x16.png" />:			
	</div>
	<div>
		<input type="hidden" value="<?php echo $ITEMID;?>" name="id" />
		<input type="hidden" name="vsource" value="" />
		<input type="hidden" name="vdestination" value="" />
		<input type="hidden" name="vselsport" value="" />
		<input type="hidden" name="vseldport" value="" />
		<input type="hidden" name="vselexport" value="" />
		<input type="hidden" name="exported" value="<?php echo $ARRAY['exported'];?>" />
		<select name="direction" onChange="javascript:changeAction()" class="select_left_details"/>
			<option></option>
			<?php 
			$IDDIR = $ARRAY['id_tab_dir_act'];
			$SQL = "SELECT id, name FROM cc_firewall.direction WHERE id IN (SELECT id_dir FROM cc_firewall.tab_dir_act ";
			$SQL .= "WHERE id_tab IN (SELECT id FROM cc_firewall.tablefw WHERE name = '$TABLE'))";
			$RSOPT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR074F"));
			$OBJ = mysql_fetch_array($RSOPT);

			do
			{
				$IDOP = $OBJ['id'];
				if($OBJ['name'] == "INPUT")
				{
				echo ('
				<script language="javascript">
				dirinp = '.$IDOP.'
				</script>');
				}
				elseif($OBJ['name'] == "OUTPUT")
				{
				echo ('
				<script language="javascript">
				dirout = '.$IDOP.'
				</script>');
				}
				elseif($OBJ['name'] == "FORWARD")
				{
				echo ('
				<script language="javascript">
				dirfor = '.$IDOP.'
				</script>');
				}
				elseif ($OBJ['name'] == "POSTROUTING")
				{
				echo ('
				<script language="javascript">
				dirpos = '.$IDOP.'
				</script>');
				}elseif($OBJ['name'] == "PREROUTING")
				{
				echo ('
				<script language="javascript">
				dirpre = '.$IDOP.'
				</script>');
				}
				$IDOBJ = $OBJ['id'];
				$IDS = $_SESSION['DIRECTION'];
				
				$SQL = "SELECT id, name FROM cc_firewall.direction WHERE (id IN ";
				$SQL .= "(SELECT id_dir FROM cc_firewall.tab_dir_act WHERE id = '$IDDIR') OR ";
				$SQL .= "id = '$IDS') AND id = '$IDOBJ'";
				$RSACT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR075F"));
								
				if (!empty($IDS) && ($IDS == $IDOBJ))
				{
					$sel = 'selected="selected"';
					$ARLY = 1;
				}
				elseif ((mysql_affected_rows() != 0) && ($ARLY != 1))
				{
					$sel = 'selected="selected"';
				}
				else
				{
					$sel = "";
				}
				
				if ( $cor == 1 )
				{ ?>
					<option value="<?php echo $OBJ['id'];?>" <?php echo $sel;?> >
						<?php echo ($$OBJ['name']); $cor=0;?></option>
					<?php 
				} else { ?>
					<option style="background:<?php echo $COLOR_LINE_SELECT;?>" value="<?php echo $OBJ['id'];?>" <?php echo $sel;?> >	
						<?php echo ($$OBJ['name']); $cor=1;?></option>
					<?php
				}
			}while($OBJ = mysql_fetch_array($RSOPT));?>
		</select>
		<?php
		if (!empty($ITEMID))
		{
		$IDACT = $ARRAY['id_tab_dir_act'];
		$SQL = "SELECT id FROM cc_firewall.action WHERE id IN (SELECT id_act FROM ";
		$SQL .= "cc_firewall.tab_dir_act WHERE CONCAT_WS('-', id) = '$IDACT' )";
		$RSOPT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR076F"));
		
		$OBJ = mysql_fetch_array($RSOPT);
		$OBJID = $OBJ['id'];
		echo ('
		<script language="javascript">
		actSele = '.$OBJID.';
		</script>');
		}

		$SQL = "SELECT id, name FROM cc_firewall.action WHERE id IN (SELECT id_act FROM ";
		$SQL .= "cc_firewall.tab_dir_act WHERE id_tab IN (SELECT id FROM cc_firewall.tablefw WHERE ";
		$SQL .= "name = '$TABLE')) ORDER BY name";
		$RSOPT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR077F"));
		$OBJ = mysql_fetch_array($RSOPT);
		$F = 0;

		do{
		$OBJID = $OBJ['id'];
		$OBJNAME = $$OBJ['name'];
		if ($OBJ['name'] == "DNAT")
		{
		echo ('
		<script language="javascript">
		actDnat = '.$OBJID.';
		</script>');
		$_SESSION['S_DNAT'] = $OBJID;
		}elseif ($OBJ['name'] == "SNAT")
		{
		echo ('
		<script language="javascript">
		actSnat = '.$OBJID.';
		</script>');
		$_SESSION['S_SNAT'] = $OBJID;
		}elseif ($OBJ['name'] == "REDIRECT")
		{
		echo ('
		<script language="javascript">
		actRedi = '.$OBJID.';
		</script>');
		}elseif ($OBJ['name'] == "MASQUERADE")
		{
		echo ('
		<script language="javascript">
		actMas = '.$OBJID.';
		</script>');
		}elseif ($OBJ['name'] == "RETURN")
		{
		echo ('
		<script language="javascript">
		actRetu = '.$OBJID.';
		</script>');
		}elseif ($OBJ['name'] == "QUEUE")
		{
		echo ('
		<script language="javascript">
		actQueu = '.$OBJID.';
		</script>');
		}elseif ($OBJ['name'] == "TOS0")
		{
		echo ('
		<script language="javascript">
		actTos0 = '.$OBJID.';
		</script>');
		}elseif ($OBJ['name'] == "TOS2")
		{
		echo ('
		<script language="javascript">
		actTos2 = '.$OBJID.';
		</script>');
		}elseif ($OBJ['name'] == "TOS4")
		{
		echo ('
		<script language="javascript">
		actTos4 = '.$OBJID.';
		</script>');
		}elseif ($OBJ['name'] == "TOS8")
		{
		echo ('
		<script language="javascript">
		actTos8 = '.$OBJID.';
		</script>');
		}elseif ($OBJ['name'] == "TOS16")
		{
		echo ('
		<script language="javascript">
		actTos16 = '.$OBJID.';
		</script>');
		}elseif ($OBJ['name'] == "MARK")
		{
		echo ('
		<script language="javascript">
		actMark = '.$OBJID.';
		</script>');
		}
		
		echo ('
		<script language="javascript">
		actId['.$F.'] = '.$OBJID.';
		actName['.$F.'] = "'.$OBJNAME.'";
		</script>');
		$F++;
		}while($OBJ = mysql_fetch_array($RSOPT));
		
		//Select the ID of protocol that don't is TCP and UDP for store variable on javascript and load the protocols in array
		$SQL = "SELECT id, name FROM cc_firewall.protocol WHERE id <> '0' ";
		$RSOPT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR078F"));
		$OBJ = mysql_fetch_array($RSOPT);
		$F = 0;
		do{
		if($OBJ['name'] == "tcp") {
			echo ('
				<script language="javascript">
					TcpProto['.$F.'] = '.$OBJ['id'].';
				</script>');
		} elseif($OBJ['name'] == "udp"){
			echo ('
				<script language="javascript">
					UdpProto['.$F.'] = '.$OBJ['id'].';
				</script>');
		} else {
		echo ('
			<script language="javascript">
				outherProto['.$F.'] = '.$OBJ['id'].';
			</script>');
		}
		$F++;
		}while($OBJ = mysql_fetch_array($RSOPT));
		
		if ($TABLE == "nat"){
				if(!empty($ITEMID)){
					$SQL = "SELECT id FROM cc_firewall.network_address ";
					$SQL .= "WHERE id IN (SELECT id_net FROM cc_firewall.rule_nat_net WHERE ";
					$SQL .= "CONCAT_WS('-', id_rul) = '$ITEMID') ORDER BY name";
					$RSOPT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR125F"));
					$OBJ = mysql_fetch_array($RSOPT);
					echo ('
						<script language="javascript">
							NetworkNat = "'.$OBJ['id'].'";
						</script>');
					$SQL = "SELECT id FROM cc_firewall.application ";
					$SQL .= "WHERE id IN (SELECT id_app FROM cc_firewall.rule_nat_app WHERE ";
					$SQL .= "CONCAT_WS('-', id_rul) = '$ITEMID') ORDER BY name";
					$RSOPT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR122F"));
					$OBJ = mysql_fetch_array($RSOPT);
					echo ('
						<script language="javascript">
							ApplicationNat = "'.$OBJ['id'].'";
						</script>');
				}
				echo '
				<script language="javascript">
				function clearObjNat()
				{
					while(document.formRule.selnatapp.length > 0)
					{
						document.formRule.selnatapp.options[document.formRule.selnatapp.length - 1] = null;
					}
				}
				function createObjNat()
				{
					var control = 0;
					document.formRule.selnatnet[0] = new Option("", "", true);
					for (f = 1; f < (netId.length+1); f++)
					{
						if((NetworkNat == netId[f-1])&&(control != 1))
						{
							boo = true;
							control = 1;
						} else {
							boo = false;
						}
						document.formRule.selnatnet[f] = new Option(netName[f-1], netId[f-1], boo);
					}
					var control = 0;
					document.formRule.selnatapp[0] = new Option("", "", true);
					for (f = 1; f < (appId.length+1); f++)
					{
						if((ApplicationNat == appId[f-1])&&(control != 1))
						{
							boo = true;
							control = 1;
						} else {
							boo = false;
						}
						document.formRule.selnatapp[f] = new Option(appName[f-1], appId[f-1], boo);
					}
				}</script>';
				
		} else {
			echo '<script language="javascript">
			function clearObjNat(){}
			function createObjNat(){}
			</script>';
		}
		
		?>
		<script language="javascript">
		function visibliOutherProto()
		{
			document.getElementById('box_dport').style.visibility="hidden";
			document.getElementById('box_sport').style.visibility="hidden";
		}
		function visibliProto()
		{
			document.getElementById('box_dport').style.visibility="visible";
			document.getElementById('box_sport').style.visibility="visible";
		}
			
		function verifyProto(){
			visibliProto();
			var control = 0;
			var seleProto = document.formRule.proto.value;
			var seleProtoCond = document.formRule.proto_condition.value;
			clearObjNat();
			for (i = 0; i < outherProto.length; i++)
			{
				if ((seleProto == outherProto[i])||(seleProto == "")||(seleProtoCond == 1))
				{
					visibliOutherProto();
					control = 1;
					break;
				}
			}
			if (control !=1) {
				if (seleProto == TcpProto)
				{
					appName=TcpProtoName;
					appId=TcpProtoPort;
				} else {
					appName=UdpProtoName;
					appId=UdpProtoPort;
				}
				createObjNat();
			}
		}
		
		function clearApp(){
			while(document.formRule.seldport.length > 1)
			{
				document.formRule.seldport.options[document.formRule.seldport.length - 1] = null;
			}
			while(document.formRule.selsport.length > 1)
			{
				document.formRule.selsport.options[document.formRule.selsport.length - 1] = null;
			}
			for (p=0; p < DAppSelectedN.length; p++)
			{
				DAppSelectedN.splice(p, 1);
				DAppSelectedI.splice(p, 1);
			}
			for (p=0; p < SAppSelectedN.length; p++)
			{
				SAppSelectedN.splice(p, 1);
				SAppSelectedI.splice(p, 1);
			}
			document.formRule.vselsport.value = "";
			document.formRule.vseldport.value = "";
		}
		</script>
		<?php 
		$SQL = "SELECT a.id, a.name, a.port, p.name as proto FROM cc_firewall.application a, cc_firewall.protocol p ";
		$SQL .="WHERE a.id_pro=p.id ORDER BY name";
		$RSOPT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR080F"));
		$OBJ = mysql_fetch_array($RSOPT);
		$F = 0;
		$P = 0;
		do
		{	
			if($OBJ['proto'] == "tcp") {
				echo ('
					<script language="javascript">
						TcpProtoPort['.$F.'] = '.$OBJ['id'].';
						TcpProtoName['.$F.'] = "'.$OBJ['name'].': '.$OBJ['port'].'";
					</script>');
			$F++;
			} elseif($OBJ['proto'] == "udp"){
				echo ('
					<script language="javascript">
						UdpProtoPort['.$P.'] = '.$OBJ['id'].';
						UdpProtoName['.$P.'] = "'.$OBJ['name'].': '.$OBJ['port'].'";
					</script>');
			$P++;
			}
		}while($OBJ = mysql_fetch_array($RSOPT));
		
		if ($TABLE == "filter")
		{
		?>
		<script language="javascript">
		function insertOpt()
		{
			for(i = 0; i < actId.length; i++)
			{
				f++;
				if (actSele == actId[i])
				{
					boo = true;
				}
				else
				{
					boo = false;
				}
				actId[i];
				document.formRule.action[f] = new Option(actName[i], actId[i], boo);
			}
		}
		
		function visibliFieldInput()
		{
			document.getElementById('s_ifa').style.visibility="visible";
			document.getElementById('d_ifa').style.visibility="hidden";
			document.formRule.d_interface[0]=new Option("", "", true);
			document.getElementById('mac').style.visibility="visible";
		}
		function visibliFieldOutput()
		{
			document.getElementById('s_ifa').style.visibility="hidden";
			document.formRule.s_interface[0]=new Option("", "", true);
			document.getElementById('d_ifa').style.visibility="visible";
			document.getElementById('mac').style.visibility="hidden";
			document.formRule.mac.value="";
		}
		function visibliFieldFor()
		{
			document.getElementById('s_ifa').style.visibility="visible";
			document.getElementById('d_ifa').style.visibility="visible";
			document.getElementById('mac').style.visibility="visible";
		}
		
		function changeAction(){
			f = 0;
			do
			{
				document.formRule.action.options[document.formRule.action.length - 1] = null;
			}while(document.formRule.action.length > 0);
			if (actSele == "")
			{
				document.formRule.action[0]=new Option("", "", true);
			}else
			{
				document.formRule.action[0]=new Option("", "", false);
			}
			
			if (document.formRule.direction.value == dirinp)
			{
				visibliFieldInput();
				insertOpt();
			}
			else if (document.formRule.direction.value == dirout)
			{
				visibliFieldOutput();
				insertOpt();
			}
			else
			{
				visibliFieldFor();
				insertOpt();
			}
		}
		function verifyAction(){
		}
		</script>
		<?php
		}elseif($TABLE == "nat")
		{	?>
		<script language="javascript">
		function insertOpt(excludeVar1, excludeVar2)
		{
			for(i = 0; i < actId.length; i++)
			{
				if ((actId[i] != excludeVar1) && (actId[i] != excludeVar2))
				{
					f++;
					if (actSele == actId[i])
					{
						boo = true;
					}
					else
					{
						boo = false;
					}
					document.formRule.action[f] = new Option(actName[i], actId[i], boo);
				}
			}
		}
		
		function visibliFieldInput()
		{
			document.getElementById('s_ifa').style.visibility="visible";
			document.getElementById('d_ifa').style.visibility="hidden";
			document.formRule.d_interface[0]=new Option("", "", true);
			document.getElementById('mac').style.visibility="visible";
		}
		function visibliFieldOutput()
		{
			document.getElementById('s_ifa').style.visibility="hidden";
			document.formRule.s_interface[0]=new Option("", "", true);
			document.getElementById('d_ifa').style.visibility="visible";
			document.getElementById('mac').style.visibility="hidden";
			document.formRule.mac.value="";
		}
		function visibliFieldFor()
		{
			document.getElementById('s_ifa').style.visibility="visible";
			document.getElementById('d_ifa').style.visibility="visible";
			document.getElementById('mac').style.visibility="visible";
		}
		function visibliFieldPre()
		{
			document.getElementById('d_ifa').style.visibility="hidden";
			document.getElementById('s_ifa').style.visibility="visible";
			document.getElementById('mac').style.visibility="visible";
		}
		
		function changeAction(){
			f = 0;
			do
			{
				document.formRule.action.options[document.formRule.action.length - 1] = null;
			}while(document.formRule.action.length > 0);
			if (actSele == "")
			{
				document.formRule.action[0]=new Option("", "", true);
			}else
			{
				document.formRule.action[0]=new Option("", "", false);
			}
			
			if (document.formRule.direction.value == dirout)
			{
				visibliFieldOutput();;
				insertOpt(actSnat, actMas);
			}
			else if (document.formRule.direction.value == dirpos)
			{
				visibliFieldOutput();
				insertOpt(actDnat, actRedi);
			}else
			{
				visibliFieldPre();
				insertOpt(actSnat, actMas);
			}
		}
		
		function verifyAction(){
			fDivaddr = document.getElementById('address');
			fDivPort = document.getElementById('port');
			if((document.formRule.action.value == actRedi))
			{
				if((document.formRule.proto.value != "")&&(document.formRule.string.value == ""))
				{
					fDivPort.style.visibility="visible";
					fDivaddr.style.visibility="hidden";
					document.formRule.selnatnet.value="";
				}
				else if (document.formRule.string.value != "")
				{
					fDivPort.style.visibility="visible";
					fDivaddr.style.visibility="visible";
				}
				else {
					fDivPort.style.visibility="hidden";
					document.formRule.selnatapp.value="";
					fDivaddr.style.visibility="hidden";
					document.formRule.selnatnet.value="";
				}
			}
			else if((document.formRule.action.value == actDnat) || (document.formRule.action.value == actSnat))
			{
				createObjNat();
				fDivaddr.style.visibility="visible";
				if(document.formRule.proto.selectedIndex != 0)
				{
					fDivPort.style.visibility="visible";
				}
				else
				{
					fDivPort.style.visibility="hidden";
					document.formRule.selnatapp.value="";
				}
			}
			else
			{
				fDivPort.style.visibility="hidden";
				document.formRule.selnatapp.value="";
				fDivaddr.style.visibility="hidden";
				document.formRule.selnatnet.value="";
			}
		}
		</script>
		<?php
		} else {
			if(!empty($ITEMID)){
				$SQL = "SELECT setmark FROM cc_firewall.rule_mangle_value ";
				$SQL .= "WHERE (CONCAT_WS('-', id_rul) = '$ITEMID')";
				$RSOPT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR129F"));
				$OBJ = mysql_fetch_array($RSOPT);
				$VALUE_SETMARK = $OBJ['setmark'];
			}
			?>
			<script language="javascript">
			function insertOpt()
			{
				for(i = 0; i < actId.length; i++)
				{
					f++;
					if (actSele == actId[i])
					{
						boo = true;
					}
					else
					{
						boo = false;
					}
					document.formRule.action[f] = new Option(actName[i], actId[i], boo);
				}
			}
			
			function visibliFieldInput()
			{
				document.getElementById('s_ifa').style.visibility="visible";
				document.getElementById('d_ifa').style.visibility="hidden";
				document.formRule.d_interface[0]=new Option("", "", true);
				document.getElementById('mac').style.visibility="visible";
			}
			function visibliFieldOutput()
			{
				document.getElementById('s_ifa').style.visibility="hidden";
				document.formRule.s_interface[0]=new Option("", "", true);
				document.getElementById('d_ifa').style.visibility="visible";
				document.getElementById('mac').style.visibility="hidden";
				document.formRule.mac.value="";
			}
			function visibliFieldFor()
			{
				document.getElementById('s_ifa').style.visibility="visible";
				document.getElementById('d_ifa').style.visibility="visible";
				document.getElementById('mac').style.visibility="visible";
			}
			function visibliFieldPre()
			{
				document.getElementById('d_ifa').style.visibility="hidden";
				document.getElementById('s_ifa').style.visibility="visible";
				document.getElementById('mac').style.visibility="visible";
			}
							
			function changeAction(){
				f = 0;
				do
				{
					document.formRule.action.options[document.formRule.action.length - 1] = null;
				}while(document.formRule.action.length > 0);
				if (actSele == "")
				{
					document.formRule.action[0]=new Option("", "", true);
				}else
				{
					document.formRule.action[0]=new Option("", "", false);
				}
				
				if ((document.formRule.direction.value == dirout) || (document.formRule.direction.value == dirpos))
				{
					visibliFieldOutput();;
					insertOpt();
				}
				else if ((document.formRule.direction.value == dirpre) || (document.formRule.direction.value == dirinp))
				{
					visibliFieldPre();
					insertOpt();
				}else
				{
					visibliFieldFor();
					insertOpt();
				}
			}
			
			function verifyAction(){
				fDivSetMark = document.getElementById('boxsetmark');
				if(document.formRule.action.value == actMark)
				{
					fDivSetMark.style.visibility="visible";
				}else{
					fDivSetMark.style.visibility="hidden";
					document.formRule.setmark.value="";
				}
			}
			</script>
			<?php
		}
		?>
	</div>

	<div class="r_box" id="s_ifa">
		<div class="r_box_text">
			<?php echo $T_INTERFACE_ENTRY;?><img src="../../@img/icons/ethernet-16x16.png" />:
		</div>
		<div>
		<select name="s_interface_condition">
			<?php
			if(($_SESSION['SIFACE_COND']==1)||($ARRAY['s_iface_condition']==1)){
				$COND_TEMP2 = 'selected="selected"';
				$COND_TEMP1 = 0;
			} else {
				$COND_TEMP1 = 'selected="selected"';
				$COND_TEMP2 = 0;
			}?>
			<option value="0" <?php echo $COND_TEMP1;?> >=</option>
			<option value="1" <?php echo $COND_TEMP2;?> >!=</option>
		</select>
		<select name="s_interface" class="select_details_cut" >
			<option></option>
			<?php 
			$SQL = "SELECT id, description FROM controlcenter.interface";
			$RSOPT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR079F"));
			$OBJ = mysql_fetch_array($RSOPT);
			
			do
			{
				if (($ARRAY['id_s_iface'] == $OBJ['id']) || ($OBJ['id'] == $_SESSION['SIFACE']))
				{
					$sel = 'selected="selected"';
				}
				else
				{
					$sel = "";
				}
				if ( $cor == 1 )
				{ ?>
					<option value="<?php echo $OBJ['id'];?>" <?php echo $sel;?> >
					<?php echo ($OBJ['description']); $cor=0;?></option>
					<?php 
				} else { ?>
					<option style="background:<?php echo $COLOR_LINE_SELECT;?>" value="<?php echo $OBJ['id'];?>" <?php echo $sel;?> >	
						<?php echo ($OBJ['description']); $cor=1;?></option>
					<?php
				}
			}while($OBJ = mysql_fetch_array($RSOPT));?>
			</select>
		</div>
	</div>

	<div class="r_box">
		<div class="r_box_text">
			<?php echo $T_SOURCE;?><img src="../../@img/icons/source-16x16.png" />:<br />
			<select name="source_condition">
				<?php
				if(($_SESSION['SOURCE_COND']==1)||($ARRAY['source_condition']==1)){
					$COND_TEMP2 = 'selected="selected"';
					$COND_TEMP1 = 0;
				} else {
					$COND_TEMP1 = 'selected="selected"';
					$COND_TEMP2 = 0;
				}?>
				<option value="0" <?php echo $COND_TEMP1;?> >=</option>
				<option value="1" <?php echo $COND_TEMP2;?> >!=</option>
			</select>
		</div>
		<div>
			<?php
			if(!empty($ITEMID)){				
				$SQL = "SELECT id,name FROM cc_firewall.network_address ";
				$SQL .= "WHERE id IN (SELECT id_net FROM cc_firewall.rul_net WHERE position = 's' AND ";
				$SQL .= "CONCAT_WS('-', id_rul) = '$ITEMID') ORDER BY name";
				$RSOPT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR114F"));
				$OBJ = mysql_fetch_array($RSOPT);
				$F = 0;
				do { 
					if(!empty($OBJ['name'])) {
						echo ('
							<script language="javascript">
								SNetSelectedN['.$F.'] = "'.$OBJ['name'].'";
								SNetSelectedI['.$F.'] = "'.$OBJ['id'].'";
							</script>');
					$F++;
					}
				}while($OBJ = mysql_fetch_array($RSOPT));
			}
			if(!empty($_SESSION['SOURCE'])){
				$ARRAY = $_SESSION['SOURCE'];
				for($F=0; $F < sizeof($ARRAY); $F++){
					$IDOBJ = $ARRAY[$F];
					$SQL = "SELECT id,name FROM cc_firewall.network_address WHERE id = '$IDOBJ' ORDER BY name";
					$RSOPT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR122F"));
					$OBJ = mysql_fetch_array($RSOPT);
					echo ('
						<script language="javascript">
							SNetSelectedN['.$F.'] = "'.$OBJ['name'].'";
							SNetSelectedI['.$F.'] = "'.$OBJ['id'].'";
						</script>');
				}
			}
			?>
			<select name="source" class="select_left_details" size="3">
			<option onclick="javascript:createObj(SNetSelectedN,SNetSelectedI,netName,netId,'source');" class="option_to_show_values"> </option>
			</select>
			<script language="javascript">
				createObjSelected(SNetSelectedN,SNetSelectedI,document.formRule.source,document.formRule.vsource);
			</script>
		</div>
	</div>

	<div class="r_box" id="box_sport">
		<div class="r_box_text">
			<?php echo $T_SOURCE_PORT;?><img src="../../@img/icons/protocol-16x16.png" />:<br />
			<select name="selsport_condition">
				<?php
				if(($_SESSION['SPORT_COND']==1)||($ARRAY['sport_condition']==1)){
					$COND_TEMP2 = 'selected="selected"';
					$COND_TEMP1 = 0;
				} else {
					$COND_TEMP1 = 'selected="selected"';
					$COND_TEMP2 = 0;
				}?>
				<option value="0" <?php echo $COND_TEMP1;?> >=</option>
				<option value="1" <?php echo $COND_TEMP2;?> >!=</option>
			</select>
		</div>
		<div>
		<?php
		if(!empty($ITEMID)){				
			$SQL = "SELECT id,name FROM cc_firewall.application ";
			$SQL .= "WHERE id IN (SELECT id_app FROM cc_firewall.rule_app WHERE position = 's' AND ";
			$SQL .= "CONCAT_WS('-', id_rul) = '$ITEMID') ORDER BY name";
			$RSOPT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR115F"));
			$OBJ = mysql_fetch_array($RSOPT);
			$F = 0;
			do { 
				if(!empty($OBJ['name'])) {
					echo ('
						<script language="javascript">
							SAppSelectedN['.$F.'] = "'.$OBJ['name'].'";
							SAppSelectedI['.$F.'] = "'.$OBJ['id'].'";
						</script>');
				$F++;
				}
			}while($OBJ = mysql_fetch_array($RSOPT));
		}
		if(!empty($_SESSION['SPORT'])){
			$ARRAY = $_SESSION['SPORT'];
			for($F=0; $F < sizeof($ARRAY); $F++){
				$IDOBJ = $ARRAY[$F];
				$SQL = "SELECT id,name FROM cc_firewall.application WHERE id = '$IDOBJ' ORDER BY name";
				$RSOPT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR122F"));
				$OBJ = mysql_fetch_array($RSOPT);
				echo ('
					<script language="javascript">
						SAppSelectedN['.$F.'] = "'.$OBJ['name'].'";
						SAppSelectedI['.$F.'] = "'.$OBJ['id'].'";
					</script>');
			}
		}
		?>
		<select name="selsport" id="selsport" class="obj_right_details" size="3">
		<option onclick="javascript:createObj(SAppSelectedN,SAppSelectedI,appName,appId,'selsport');" class="option_to_show_values">
		</option>
		</select>
			<script language="javascript">
				createObjSelected(SAppSelectedN,SAppSelectedI,document.formRule.selsport,document.formRule.vselsport);
			</script>
		</div>
	</div>

	<div class="r_box">
		<div class="r_box_text">
			<?php echo $T_ADD_COMMAND;?>:
		</div>
		<div>
		<select name="selcommandadd" class="obj_right_details">
		<option></option>
		<?php 
		$SQL = "SELECT * FROM cc_firewall.command";
		$RSOPT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR088F"));
		$OBJ = mysql_fetch_array($RSOPT);
		
		do
		{		
			if (($ARRAY['command'] == $OBJ['name']) || ($OBJ['name'] == $_SESSION['COMMANDADD']))
			{
				$sel = 'selected="selected"';
			}
			else
			{
				$sel = "";
			}?>
				<option value="<?php echo $OBJ['name'];?>" <?php echo $sel;?> >	
					<?php echo ($$OBJ['name']); $cor=1;?></option>
				<?php
		}while($OBJ = mysql_fetch_array($RSOPT));?>
		</select>
		</div>
	</div>
	</div><!-- Box left -->
	<div class="r_box_info_right"><!-- Box left-2 -->	
		<div class="r_box">
		<div class="r_box_text_right">
			<?php echo $T_PROTOCOL;?>:
		</div>
		<div>
		<select name="proto_condition" onchange="verifyProto(); verifyAction(); clearApp();">
				<?php
				if(($_SESSION['PROTO_COND']==1)||($ARRAY['proto_condition']==1)){
					$COND_TEMP2 = 'selected="selected"';
					$COND_TEMP1 = 0;
				} else {
					$COND_TEMP1 = 'selected="selected"';
					$COND_TEMP2 = 0;
				}?>
				<option value="0" <?php echo $COND_TEMP1;?> >=</option>
				<option value="1" <?php echo $COND_TEMP2;?> >!=</option>
		</select>
		<select name="proto" id="proto" class="select_details_cut" onchange="javascript:verifyProto(); verifyAction(); clearApp();">
		<option></option>
		<?php 
		$SQL = "SELECT id, name FROM cc_firewall.protocol WHERE id <> '0' ";
		$RSOPT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR085F"));
		$OBJ = mysql_fetch_array($RSOPT);
		do
		{		
			if (($ARRAY['id_pro'] == $OBJ['id'])||($OBJ['id'] == $_SESSION['PROTO']))
			{
				$sel = 'selected="selected"';
			}
			else
			{
				$sel = "";
			}
			if ( $cor == 1 )
			{ ?>
				<option value="<?php echo $OBJ['id'];?>" <?php echo $sel;?> >
					<?php echo (strtoupper($OBJ['name'])); $cor=0;?></option>
				<?php 
			} else { ?>
				<option style="background:<?php echo $COLOR_LINE_SELECT;?>" value="<?php echo $OBJ['id'];?>" <?php echo $sel;?> >	
					<?php echo (strtoupper($OBJ['name'])); $cor=1;?></option>
				<?php
			}
		}while($OBJ = mysql_fetch_array($RSOPT));?>
		</select>
		</div>
	</div>	
	
		<div class="r_box" id="d_ifa">
		<div class="r_box_text_right">
			<?php echo $T_INTERFACE_EXIT;?>:
		</div>
		<div>
		<select name="d_interface_condition">
			<?php
			if(($_SESSION['DIFACE_COND']==1)||($ARRAY['d_iface_condition']==1)){
				$COND_TEMP2 = 'selected="selected"';
				$COND_TEMP1 = 0;
			} else {
				$COND_TEMP1 = 'selected="selected"';
				$COND_TEMP2 = 0;
			}?>
			<option value="0" <?php echo $COND_TEMP1;?> >=</option>
			<option value="1" <?php echo $COND_TEMP2;?> >!=</option>
		</select>
		<select name="d_interface" class="select_details_cut">
		<option></option>
		<?php 
		$SQL = "SELECT id, description FROM controlcenter.interface";
		$RSOPT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR086F"));
		$OBJ = mysql_fetch_array($RSOPT);
		$IDNET = $ARRAY['id_d_net'];
		
		do
		{
		
			if (($ARRAY['id_d_iface'] == $OBJ['id']) || ($OBJ['id'] == $_SESSION['DIFACE']))
			{
				$sel = 'selected="selected"';
			}
			else
			{
				$sel = "";
			}
			if ( $cor == 1 )
			{ ?>
				<option value="<?php echo $OBJ['id'];?>" <?php echo $sel;?> >
					<?php echo ($OBJ['description']); $cor=0;?></option>
				<?php 
			} else { ?>
				<option style="background:<?php echo $COLOR_LINE_SELECT;?>" value="<?php echo $OBJ['id'];?>" <?php echo $sel;?> >	
					<?php echo ($OBJ['description']); $cor=1;?></option>
				<?php
			}
		}while($OBJ = mysql_fetch_array($RSOPT));?>
		</select>	
		</div>
	</div>
	
	<div class="r_box" >
		<div class="r_box_text_right">
			<?php echo $T_DESTINATION;?>:<br />
			<select name="destination_condition">
				<?php
				if(($_SESSION['DESTINATION_COND']==1)||($ARRAY['destination_condition']==1)){
					$COND_TEMP2 = 'selected="selected"';
					$COND_TEMP1 = 0;
				} else {
					$COND_TEMP1 = 'selected="selected"';
					$COND_TEMP2 = 0;
				}?>
				<option value="0" <?php echo $COND_TEMP1;?> >=</option>
				<option value="1" <?php echo $COND_TEMP2;?> >!=</option>
			</select>
		</div>
		<div>
			<?php
			if(!empty($ITEMID)){				
				$SQL = "SELECT id,name FROM cc_firewall.network_address ";
				$SQL .= "WHERE id IN (SELECT id_net FROM cc_firewall.rul_net WHERE position = 'd' AND ";
				$SQL .= "CONCAT_WS('-', id_rul) = '$ITEMID') ORDER BY name";
				$RSOPT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR114F"));
				$OBJ = mysql_fetch_array($RSOPT);
				$F = 0;
				do { 
					if(!empty($OBJ['name'])) {
						echo ('
							<script language="javascript">
								DNetSelectedN['.$F.'] = "'.$OBJ['name'].'";
								DNetSelectedI['.$F.'] = "'.$OBJ['id'].'";
							</script>');
					$F++;
					}
				}while($OBJ = mysql_fetch_array($RSOPT));
			}
			if(!empty($_SESSION['DESTINATION'])){
				$ARRAY = $_SESSION['DESTINATION'];
				for($F=0; $F < sizeof($ARRAY); $F++){
					$IDOBJ = $ARRAY[$F];
					$SQL = "SELECT id,name FROM cc_firewall.network_address WHERE id = '$IDOBJ' ORDER BY name";
					$RSOPT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR122F"));
					$OBJ = mysql_fetch_array($RSOPT);
					echo ('
						<script language="javascript">
							DNetSelectedN['.$F.'] = "'.$OBJ['name'].'";
							DNetSelectedI['.$F.'] = "'.$OBJ['id'].'";
						</script>');
				}
			}
			?>
			<select name="destination" class="obj_right_details" size="3">
			<option onclick="javascript:createObj(DNetSelectedN,DNetSelectedI,netName,netId,'destination');" class="option_to_show_values"> </option>
			</select>
			<script language="javascript">
				createObjSelected(DNetSelectedN,DNetSelectedI,document.formRule.destination,document.formRule.vdestination);
			</script>
		</div>
	</div>


	<div class="r_box" id="box_dport">
		<div class="r_box_text_right">
			<?php echo $T_DESTINATION_PORT;?>:<br />
			<select name="seldport_condition">
				<?php
				if(($_SESSION['DPORT_COND']==1)||($ARRAY['dport_condition']==1)){
					$COND_TEMP2 = 'selected="selected"';
					$COND_TEMP1 = 0;
				} else {
					$COND_TEMP1 = 'selected="selected"';
					$COND_TEMP2 = 0;
				}?>
				<option value="0" <?php echo $COND_TEMP1;?> >=</option>
				<option value="1" <?php echo $COND_TEMP2;?> >!=</option>
			</select>
		</div>
		<div>
		<?php
		if(!empty($ITEMID)){				
			$SQL = "SELECT id,name FROM cc_firewall.application ";
			$SQL .= "WHERE id IN (SELECT id_app FROM cc_firewall.rule_app WHERE position = 'd' AND ";
			$SQL .= "CONCAT_WS('-', id_rul) = '$ITEMID') ORDER BY name";
			$RSOPT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR116F"));
			$OBJ = mysql_fetch_array($RSOPT);
			$F = 0;
			do { 
				if(!empty($OBJ['name'])) {
					echo ('
						<script language="javascript">
							DAppSelectedN['.$F.'] = "'.$OBJ['name'].'";
							DAppSelectedI['.$F.'] = "'.$OBJ['id'].'";
						</script>');
				$F++;
				}
			}while($OBJ = mysql_fetch_array($RSOPT));
		}
		if(!empty($_SESSION['DPORT'])){
			$ARRAY = $_SESSION['DPORT'];
			for($F=0; $F < sizeof($ARRAY); $F++){
				$IDOBJ = $ARRAY[$F];
				$SQL = "SELECT id,name FROM cc_firewall.application WHERE id = '$IDOBJ' ORDER BY name";
				$RSOPT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR122F"));
				$OBJ = mysql_fetch_array($RSOPT);
				echo ('
					<script language="javascript">
						DAppSelectedN['.$F.'] = "'.$OBJ['name'].'";
						DAppSelectedI['.$F.'] = "'.$OBJ['id'].'";
					</script>');
			}
		}
		?>
		<select name="seldport" id="seldport" class="obj_right_details" size="3">
		<option onclick="javascript:createObj(DAppSelectedN,DAppSelectedI,appName,appId,'seldport');" class="option_to_show_values">
		</option>
		</select>
			<script language="javascript">
				createObjSelected(DAppSelectedN,DAppSelectedI,document.formRule.seldport,document.formRule.vseldport);
			</script>
		</div>
	</div>
	
	<div class="r_box">
		<div class="r_box_text_right">
			<?php echo $F_INTERVAL;?>
		</div>
		<div>
		<select name="hour_start">
		<option></option>
		<?php 
		$SQL = "SELECT id, name FROM cc_firewall.variable_time";
		$RSOPT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR081F"));
		$OBJ = mysql_fetch_array($RSOPT);
		
		do
		{
			$ID = $OBJ['id'];
			$SQL = "SELECT * FROM cc_firewall.rul_vartime WHERE id_rul = '$ITEMID' AND id_vartime IN ";
			$SQL .= "(SELECT id FROM cc_firewall.variable_time WHERE id = '$ID') AND status_order = 's'";
			$RSTIM = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR082F"));
			if ((mysql_affected_rows() != 0) || ($ID == $_SESSION['TIMESTART']))
			{
				$sel = 'selected="selected"';
			}
			else
			{
				$sel = "";
			}
			if ( $cor == 1 )
			{ ?>
				<option value="<?php echo $OBJ['id'];?>" <?php echo $sel;?> >
					<?php echo ($OBJ['name']); $cor=0;?></option>
				<?php 
			} else { ?>
				<option style="background:<?php echo $COLOR_LINE_SELECT;?>" value="<?php echo $OBJ['id'];?>" <?php echo $sel;?> >	
					<?php echo ($OBJ['name']); $cor=1;?></option>
				<?php
			}
		}while($OBJ = mysql_fetch_array($RSOPT));?>
		</select>
		-
		<select name="hour_end">
		<option></option>
		<?php 
		$SQL = "SELECT id, name FROM cc_firewall.variable_time";
		$RSOPT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR083F"));
		$OBJ = mysql_fetch_array($RSOPT);
		
		do
		{		
			$ID = $OBJ['id'];
			$SQL = "SELECT * FROM cc_firewall.rul_vartime WHERE id_rul = '$ITEMID' AND id_vartime IN ";
			$SQL .= "(SELECT id FROM cc_firewall.variable_time WHERE id = '$ID') AND status_order = 'e'";
			$RSTIM = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR084F"));
			if ((mysql_affected_rows() != 0) || ($ID == $_SESSION['TIMESTART']))
			{
				$sel = 'selected="selected"';
			}
			else
			{
				$sel = "";
			}
			if ( $cor == 1 )
			{ ?>
				<option value="<?php echo $OBJ['id'];?>" <?php echo $sel;?> >
					<?php echo ($OBJ['name']); $cor=0;?></option>
				<?php 
			} else { ?>
				<option style="background:<?php echo $COLOR_LINE_SELECT;?>" value="<?php echo $OBJ['id'];?>" <?php echo $sel;?> >	
					<?php echo ($OBJ['name']); $cor=1;?></option>
				<?php
			}
		}while($OBJ = mysql_fetch_array($RSOPT));?>
		</select>
		</div>
	</div>

	</div><!-- Box left-2-->

</div><!-- Information -->

	<div class="box_obj_list_rigth">
	<?php
	$SQL = "SELECT * FROM  controlcenter.firewall_list ORDER BY name";	
	$RSOPT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR136F"));
	$OBJ = mysql_fetch_array($RSOPT);
	$F = 0;
	do { 
		if(!empty($OBJ['name'])) {
			echo ('
				<script language="javascript">
					firewallListName['.$F.'] = "'.$OBJ['name'].'-'.$OBJ['ip'].'";
					firewallListId['.$F.'] = "'.$OBJ['id'].'";
				</script>');
		$F++; 
		}
	}while($OBJ = mysql_fetch_array($RSOPT));
	if(!empty($ITEMID)){				
		$SQL = "SELECT DISTINCT f.id,f.name,l.status FROM  controlcenter.firewall_list f, cc_firewall.rule_firewall_list l ";
		$SQL .= "WHERE f.id = l.id_fw AND CONCAT_WS('-', id_rul) = '$ITEMID' ORDER BY f.name";
		$RSOPT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR133F"));
		$OBJ = mysql_fetch_array($RSOPT);
		$F = 0;
		do { 
			if(!empty($OBJ['name'])) {
				if ($OBJ['status'] == '1')
				{
					$VARTEMP = $F_STATUS_EXPORT_OK;
				} else {
					$VARTEMP = $F_STATUS_EXPORT_FAIL;
				}
				echo ('
					<script language="javascript">
						FirewallExportedSelectedN['.$F.'] = "'.$OBJ['name'].'-'.$VARTEMP.'";
						FirewallExportedSelectedI['.$F.'] = "'.$OBJ['id'].'";
					</script>');
			$F++; 
			}
		}while($OBJ = mysql_fetch_array($RSOPT));
	}
	if(!empty($_SESSION['EXPORTFW'])){
		$ARRAY = $_SESSION['EXPORTFW'];
		for($F=0; $F < sizeof($ARRAY); $F++){
			$IDOBJ = $ARRAY[$F];
			$SQL = "SELECT * FROM controlcenter.firewall_list WHERE id = '$IDOBJ' ORDER BY name";
			$RSOPT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR134F"));
			$OBJ = mysql_fetch_array($RSOPT);
			echo ('
				<script language="javascript">
					FirewallExportedSelectedN['.$F.'] = "'.$OBJ['name'].'-'.$OBJ['ip'].'";
					FirewallExportedSelectedI['.$F.'] = "'.$OBJ['id'].'";
				</script>');
		}
	}
	?>
			<?php echo $T_EXPORT_RULE;?>:
			<select name="selexport" id="selexport" class="obj_right_export" size="9" >
				<option onclick="javascript:createObj(FirewallExportedSelectedN,FirewallExportedSelectedI,firewallListName,firewallListId,'export');" class="option_to_show_values" ></option>
			</select>
			<script language="javascript">
				createObjSelected(FirewallExportedSelectedN,FirewallExportedSelectedI,document.formRule.selexport,document.formRule.vselexport);
			</script>
	</div>

<?php
require_once('rule_modules_fw.php');
?>
	<div class="r_box_comment">
		<div class="r_box_mod_text">
			<?php echo $T_COMMENT;?>:
		</div>
		<div>
			<input size="35" maxlength="150" name="comment" value="<?php	if (!empty($ARRAY['commentfw'])){echo $ARRAY['commentfw'];}else{echo $_SESSION['COMMENT'];}?>" />
		</div>
	</div>
	<div class="r_box_right">
		<div class="r_box_mod_text" >
			<u>
			<?php echo $T_ACTION;?>
			</u>:
		</div>
		<div>
		<select name="action" onChange="javascript:verifyAction();">

		</select>
		</div>	
	</div>
<?php
if ($TABLE == "nat")
{?>
	<div class="r_box_redir">
		<div id="address">
			<div class="r_box_redir_text" >
				<u><?php echo $T_REDIRECT_TO;?></u>:
			</div>
			<div class="position_left" >
				<select name="selnatnet" id="selnatnet" class="obj_nat">
				</select>
			</div>
		</div>
		<div id="port">
			<div class="r_box_redir_text">
				<u><?php echo $T_PORT;?></u>:
			</div>
			<div class="position_left">
				<select name="selnatapp" id="selnatapp" class="obj_nat">
				</select>
			</div>
		</div>
	</div>
<?php
}elseif ($TABLE == "mangle")
{?>
	<div id="boxsetmark" style="visibility:hidden">
		<div class="r_box_redir_text" >
			<u><?php echo $T_SET_MARK;?></u>:
		</div>
		<div class="position_left" >
			<input id="setmark" name="setmark" type="text" size="19" maxlength="19" value="<?php echo $VALUE_SETMARK ; ?>" />
		</div>
	</div>
<?php
}?>

</div><!--Show detail-->
<input type="hidden" name="ind_search" id="ind_search" value="0" />
<div class="title_general_fw">
	<img class="contet_left_img" src="../../@img/icons/show-hidden-30x20.png" onclick="javascript:showDetails();" />
	<input type="submit" value="<?php if (empty($ITEMID)){ echo $B_ADD_NEW;} else { echo $B_UPDATE;}?>" onClick="javascript:ShowAllRules();" />
	<input type="button" value="<?php if(empty($_SESSION['SQL_SEARCH'])){echo $B_CLEAR;}else{ echo $B_SHOW_ALL;}?>" onClick="javascript:ShowAllRules();" />
	<input type="button" value="<?php echo $B_DELETE;?>" onClick="javascript:confirmDeleteSelected();" />
	<input type="button" value="<?php echo $B_SEARCH;?>" onClick="javascript:CheckSearh();" />

		<?php
		if (empty($_SESSION['SQL_SEARCH'])){
			$SQL = "SELECT id FROM cc_firewall.rulefw";
		} else {
			$SQL = $_SESSION['SQL_SEARCH'];
			$SQL .= "AND r.id_tab_dir_act IN (SELECT id FROM cc_firewall.tab_dir_act WHERE id_tab IN ";
			$SQL .= "(SELECT id FROM cc_firewall.tablefw WHERE name = '$TABLE') )";
		}
		$RS = mysql_query($SQL);// or (die("$ME_OCCURREDEERRORINTERNAL IFWSR107F"));
		$QTD = (mysql_affected_rows()/$QUANTITY_RULE_SHOW);
		if ($QTD > 1) {?>
			<input type="button" value="<<" onclick="javascript:selectPageSel(0);" />
			<input type="button" value="<" onclick="javascript:selectPageSel(<?php echo ($PAGE_SEQ_P-1);?>);" /><?php
			if (($QTD > 6)&&($PAGE_SEQ_P > 5)){ $p = $PAGE_SEQ_P;} else { $p = 1;}
			for($f=$p; $f < ($QTD+1); $f++)
			{
				if(($f == $p)&&($f != 1)){?>
					<input type="button" value="..." onclick="javascript:selectPageSel(<?php echo ($f-1);?>);" /><?php
				}
				if($f < ($p+6)){?>
					<input type="button" value="<?php echo $f;?>" onclick="javascript:selectPageSel(<?php echo ($f-1);?>);" />
				<?php 
				}elseif($f == ($p+6)) {?>
					<input type="button" value="..." onclick="javascript:selectPageSel(<?php echo ($f-1);?>);" /><?php
				}
			}
			?>
			<input type="button" value=">" onclick="javascript:selectPageSel(<?php echo ($PAGE_SEQ_P+1);?>);" />
			<input type="button" value=">>" onclick="javascript:selectPageSel(<?php echo ($f-2);?>);" />
		<?php }?>
</div>
</form>
<form action="<?php echo $PAGE_DELETE;?>" name="formSelect" method="post">
	<input type="hidden" name="rule" id="arule">
</form>
<form action="<?php echo $THISPAGE;?>" name="formShowAll" method="post">
	<input type="hidden" name="showall" id="showall" value="1">
</form>
<form action="<?php echo $THISPAGE;?>" name="formPageSeq" method="post">
	<input type="hidden" name="page_seq" id="page_seq" value="<?php echo $f;?>" />
</form>