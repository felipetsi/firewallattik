#!/bin/bash
#################################################################
# 			This script whill apply the rules 					#
#               Create by Felipe Pereira da Silva               #
#               Created in 29/11/2013                           #
#               Version: 1.0                                    #
#################################################################

# User'DB
USERDB="attikuser"
# Password of user'DB
PASSWDDB=$(cat /var/.incti/.access/.access_exec.php | sed 's/.*$INCTIPW = "//' | sed 's/".*//')
# Package Filter
FIREWALL="/sbin/iptables"
# IP of loopback
THISIP="127.0.0.1"
# HTTP port
HTTPPORT=$(cat /var/.incti/.access/httpd_port.php)

# File of rules
FILERULE="/var/.incti/.rules.sh"
FILERULEDEFECT="/var/.incti/.lastruledefect.log"

# Create the file
#sudo chattr -i $FILERULE
echo > $FILERULE;
chmod 775 $FILERULE
echo > $FILERULEDEFECT;
chmod 644 $FILERULEDEFECT;


# Clear all rules
echo "sudo $FIREWALL -F -t filter" > $FILERULE
echo "sudo $FIREWALL -F -t nat" >> $FILERULE
echo "sudo $FIREWALL -F -t mangle" >> $FILERULE
echo "sudo $FIREWALL -X -t filter" >> $FILERULE
echo "sudo $FIREWALL -X -t nat" >> $FILERULE
echo "sudo $FIREWALL -X -t mangle" >> $FILERULE

# Apply default police
mysql -u $USERDB -p$PASSWDDB -e "SELECT name FROM cc_firewall.direction WHERE have_policy = '1'" | sed '1d' | \
while read POLICYDIRECTION
do

	POLICYACTION=$(mysql -u $USERDB -p$PASSWDDB -e "SELECT name FROM cc_firewall.action \
	WHERE id IN (SELECT id_act FROM cc_firewall.policyfw WHERE id_dir IN (SELECT id FROM cc_firewall.direction \
	WHERE name = '$POLICYDIRECTION'))" | sed '1d')

	echo "sudo $FIREWALL -P $POLICYDIRECTION $POLICYACTION" >> $FILERULE

	if [ $? != "0" ]; then
		MOMENTNOW=$(date +%Y-%m-%d_%H:%M:%S|sed 's/_/ /')	# Date and hour now

		# Register in log the failure
		mysql -u $USERDB -p$PASSWDDB -e "INSERT INTO controlcenter.log_auditor \
		(code, moment, source, more_info) VALUES ('IFWDL003F', '$MOMENTNOW', '$THISIP', '$POLICYDIRECTION')"

	fi

done

# Remove all bad rule. Rule with defect, can't be will apply
mysql -u $USERDB -p$PASSWDDB -e "SELECT id FROM cc_firewall.rulefw WHERE id_tab_dir_act = '0'" | sed '1d' |
while read RULEDEFECT
do
	MOMENTNOW=$(date +%Y-%m-%d_%H:%M:%S|sed 's/_/ /')       # Date and hour now

	mysql -u $USERDB -p$PASSWDDB -e "DELETE FROM cc_firewall.rulefw WHERE id = '$RULEDEFECT'"

	if [ $? == "0" ]; then
		# Register in log the removing
		mysql -u $USERDB -p$PASSWDDB -e "INSERT INTO controlcenter.log_auditor \
		(code, moment, source, more_info) VALUES ('IFWDL002F', '$MOMENTNOW', '$THISIP', '0')"
	fi
done
# Create the direction created
mysql -u $USERDB -p$PASSWDDB -e "SELECT name FROM cc_firewall.direction WHERE name <> 'INPUT' AND name <> 'OUTPUT'\
AND name <> 'FORWARD' AND name <> 'PREROUTING' AND name <> 'POSTROUTING'" | sed '1d' | 
while read direction
do
	echo "sudo $FIREWALL -N $direction"  >> $FILERULE
done

# Select the all good rules
mysql -u $USERDB -p$PASSWDDB -e "SELECT id,name FROM cc_firewall.rulefwrun WHERE id NOT IN (SELECT id FROM \
 cc_firewall.rulefw WHERE command = 'S') ORDER BY id" | sed '1d' | 
while read data_rule 
do
	# Store the value in variables
	IDR=$(echo $data_rule | cut -f1 -d " ")
	rule=$(echo $data_rule | sed "s/$IDR//")
	
	# Create the rules according values of variables
	echo "sudo $FIREWALL $rule 2>&-" >> $FILERULE
	echo '[ "$?" != "0" ] && echo '$IDR' >> '$FILERULEDEFECT >> $FILERULE
done
# Update the applied flag in all rule.
	mysql -u $USERDB -p$PASSWDDB -e "UPDATE cc_firewall.rulefw SET applied = '1', status = '1'"

echo "sudo $FIREWALL -I INPUT -d 127.0.0.1 -j ACCEPT" >> $FILERULE
echo "sudo $FIREWALL -I OUTPUT -s 127.0.0.1 -j ACCEPT" >> $FILERULE

# Apply the permision for the adminsitrators can access the IncTI Control Center. This is the unique rule gereate automatic
# Everything tha have permision for create rules.
mysql -u $USERDB -p$PASSWDDB -e "SELECT id FROM controlcenter.user WHERE id_pro IN (SELECT id FROM controlcenter.profile \
WHERE id_profw IN (SELECT id FROM controlcenter.profilefw WHERE create_rule = '1'))" | sed '1d' | \
while read IDADMIN
do
	# Store the values for create the rule
	IPADMIN=$(mysql -u $USERDB -p$PASSWDDB -e "SELECT ip FROM controlcenter.user WHERE id = '$IDADMIN'" | sed '1d')

	RULETEMP="sudo $FIREWALL -I INPUT "
	if [ ! -z $IPADMIN ]; then RULETEMP="$RULETEMP -s $IPADMIN "; fi
	if [ ! -z $HTTPPORT ]; then RULETEMP="$RULETEMP -p tcp --dport $HTTPPORT "; fi
	RULETEMP="$RULETEMP -m state --state NEW,ESTABLISHED,RELATED "
	RULETEMP="$RULETEMP -j ACCEPT"
	echo $RULETEMP >> $FILERULE

	RULETEMP="sudo $FIREWALL -I OUTPUT "
	if [ ! -z $IPADMIN ]; then RULETEMP="$RULETEMP -d $IPADMIN "; fi
	if [ ! -z $HTTPPORT ]; then RULETEMP="$RULETEMP -p tcp --sport $HTTPPORT "; fi
	RULETEMP="$RULETEMP -m state --state ESTABLISHED,RELATED "
	RULETEMP="$RULETEMP -j ACCEPT"
	echo $RULETEMP >> $FILERULE
done
# Rule for LOG ereything trafic
#echo "sudo $FIREWALL -I INPUT -j LOG --log-level 4" >> $FILERULE
#echo "sudo $FIREWALL -I OUTPUT -j LOG --log-level 4" >> $FILERULE
#echo "sudo $FIREWALL -I FORWARD -j LOG --log-level 4" >> $FILERULE

if [ -e /etc/init.d/rc.firewall ]; then
	sudo chattr -i /etc/init.d/rc.firewall
	sudo chown attikuserweb /etc/init.d/rc.firewall
	chmod 644 /etc/init.d/rc.firewall
fi
# Verify and lock the file
#if [ -e "$FILERULE" ]; then
#	sudo chattr +i $FILERULE
#fi

# Verify state full mode
FW_STATE_TMP=$(cat /var/www/attik/configuration/variablegeneral.php| grep FW_STATE_FULL | grep 1)
if [ ! -z "$FW_STATE_TMP" ]; then
        echo "sudo $FIREWALL -I INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT" >> $FILERULE
        echo "sudo $FIREWALL -I OUTPUT -m state --state ESTABLISHED,RELATED -j ACCEPT" >> $FILERULE
        echo "sudo $FIREWALL -I FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT" >> $FILERULE
fi

# Execute the rule
$FILERULE

# Saving the rules
sudo $FIREWALL-save > /etc/init.d/rc.firewall
sudo chattr +i /etc/init.d/rc.firewall

for erroridrule in `cat $FILERULEDEFECT`
do
	MOMENTNOW=$(date +%Y-%m-%d_%H:%M:%S|sed 's/_/ /')	# Date and hour now
	# Update the status of rule for failure
	mysql -u $USERDB -p$PASSWDDB -e "UPDATE cc_firewall.rulefw SET status = '0', applied='0' WHERE id = '$erroridrule'"

	# Register in log the failure
	mysql -u $USERDB -p$PASSWDDB -e "INSERT INTO controlcenter.log_auditor 
	(code, moment, source, more_info) VALUES ('IFWIL001F', '$MOMENTNOW', '$THISIP', '0')"
done

# Remove the file of rule and ID's rule with defect
# rm $FILERULE
rm $FILERULEDEFECT

	# Take file's imutable value
	sudo chattr -i /etc/init.d/firewall
	sudo chown attikuserweb /etc/init.d/firewall
	chmod 750 /etc/init.d/firewall
	# Build auto start to rules
	sudo  echo '	#!/bin/bash
	#
	# /etc/init.d/firewall
 
	case "$1" in
		start)
			echo "Starting firewall rules..."
			# Enable FORWARDING 
			echo 1 | sudo tee -a /proc/sys/net/ipv4/ip_forward > /dev/null
			# Disable IP Spoofing
			echo 2 | sudo tee -a /proc/sys/net/ipv4/conf/all/rp_filter > /dev/null
			# Disable TIMESTAMPS
			echo 0 | sudo tee -a /proc/sys/net/ipv4/tcp_timestamps > /dev/null
			# Enable protection the Cookie TCP SYN
			echo 1 | sudo tee -a /proc/sys/net/ipv4/tcp_syncookies > /dev/null
			# Enable configuration ICMP
			# Enable protection to broadcast echo ICMP
			echo 1 | sudo tee -a /proc/sys/net/ipv4/icmp_echo_ignore_broadcasts > /dev/null
			# Enable protection the mensege of bad error
			echo 1 | sudo tee -a /proc/sys/net/ipv4/icmp_ignore_bogus_error_responses > /dev/null
			# Load the modules
			sudo /sbin/modprobe ip_tables
			sudo /sbin/modprobe iptable_filter
			sudo /sbin/modprobe iptable_nat
			sudo /sbin/modprobe ip_conntrack
			sudo /sbin/modprobe ip_conntrack_ftp
			sudo /sbin/modprobe ip_nat_ftp
			sudo /sbin/modprobe ipt_LOG
			sudo /sbin/modprobe ipt_REJECT
			sudo /sbin/modprobe ipt_state
			sudo /sbin/modprobe ipt_MASQUERADE
			sudo /sbin/modprobe ip_conntrack_pptp
			sudo /sbin/modprobe ip_nat_pptp
			sudo /sbin/iptables-restore /etc/init.d/rc.firewall
			if [ -e /var/.incti/.failover.conf ]; then
				/var/.incti/.failover.conf
			else
				echo > /var/.incti/.failover.conf
				chmod 755 /var/.incti/.failover.conf
			fi
			if [ -e /var/.incti/.route.sh ]; then
				/var/.incti/.route.sh
			fi
			if [ ! -e /etc/attikpersonalscript.sh ]; then
				sudo touch /etc/attikpersonalscript.sh
				sudo chown attikuserweb /etc/attikpersonalscript.sh
			else 
				sudo chown attikuserweb /etc/attikpersonalscript.sh
				chmod 770 /etc/attikpersonalscript.sh
				/etc/attikpersonalscript.sh
			fi
			;;
 
		stop)
			echo "Stoping firewall rules..."
			sudo /sbin/iptables -F -t filter
			sudo /sbin/iptables -F -t nat
			sudo /sbin/iptables -F -t mangle
			sudo /sbin/iptables -X -t filter
			sudo /sbin/iptables -X -t nat
			sudo /sbin/iptables -X -t mangle
			;;
 
		restart)
			echo "Restarting firewall rules..."
			# Enable FORWARDING 
			echo 1 | sudo tee -a /proc/sys/net/ipv4/ip_forward > /dev/null
			# Disable IP Spoofing
			echo 2 | sudo tee -a /proc/sys/net/ipv4/conf/all/rp_filter > /dev/null
			# Disable TIMESTAMPS
			echo 0 | sudo tee -a /proc/sys/net/ipv4/tcp_timestamps > /dev/null
			# Enable protection the Cookie TCP SYN
			echo 1 | sudo tee -a /proc/sys/net/ipv4/tcp_syncookies > /dev/null
			# Enable configuration ICMP
			# Enable protection to broadcast echo ICMP
			echo 1 | sudo tee -a /proc/sys/net/ipv4/icmp_echo_ignore_broadcasts > /dev/null
			# Enable protection the mensege of bad error
			echo 1 | sudo tee -a /proc/sys/net/ipv4/icmp_ignore_bogus_error_responses > /dev/null
			# Load the modules
			sudo /sbin/modprobe ip_tables
			sudo /sbin/modprobe iptable_filter
			sudo /sbin/modprobe iptable_nat
			sudo /sbin/modprobe ip_conntrack
			sudo /sbin/modprobe ip_conntrack_ftp
			sudo /sbin/modprobe ip_nat_ftp
			sudo /sbin/modprobe ipt_LOG
			sudo /sbin/modprobe ipt_REJECT
			sudo /sbin/modprobe ipt_state
			sudo /sbin/modprobe ipt_MASQUERADE
			sudo /sbin/modprobe ip_conntrack_pptp
			sudo /sbin/modprobe ip_nat_pptp
			sudo /sbin/iptables-restore /etc/init.d/rc.firewall
			if [ -e /var/.incti/.failover.conf ]; then
				/var/.incti/.failover.conf
			else
				echo > /var/.incti/.failover.conf
				chmod 755 /var/.incti/.failover.conf
			fi
			if [ -e /var/.incti/.route.sh ]; then
				/var/.incti/.route.sh
			fi
			if [ ! -e /etc/attikpersonalscript.sh ]; then
				sudo touch /etc/attikpersonalscript.sh
				sudo chown attikuserweb /etc/attikpersonalscript.sh
			else 
				sudo chown attikuserweb /etc/attikpersonalscript.sh
				chmod 770 /etc/attikpersonalscript.sh
				/etc/attikpersonalscript.sh
			fi
			;;
 
		*)
			echo "Invalid operation."
        		;;
	esac
	' > /etc/init.d/firewall

	sudo chattr +i /etc/init.d/firewall
	
	# Run the script
	/etc/init.d/firewall restart > /dev/null
	
	# Creating link to start in runlevel
	if [ ! -e /etc/rc1.d/S01firewall ]; then
		sudo ln -s /etc/init.d/firewall /etc/rc1.d/S01firewall
	fi
	if [ ! -e /etc/rc2.d/S01firewall ]; then
		sudo ln -s /etc/init.d/firewall /etc/rc2.d/S01firewall
	fi
	if [ ! -e /etc/rc3.d/S01firewall ]; then
		sudo ln -s /etc/init.d/firewall /etc/rc3.d/S01firewall
	fi
	if [ ! -e /etc/rc4.d/S01firewall ]; then
		sudo ln -s /etc/init.d/firewall /etc/rc4.d/S01firewall
	fi
	if [ ! -e /etc/rc5.d/S01firewall ]; then
		sudo ln -s /etc/init.d/firewall /etc/rc5.d/S01firewall
	fi
	if [ ! -e /etc/rc6.d/S01firewall ]; then
		sudo ln -s /etc/init.d/firewall /etc/rc6.d/S01firewall
	fi
