<?php 
require_once('../../includes/control_session.php');
$DESTINATION_PAGE = "general_personal_direction_fw.php";

$ID = trim(addslashes($_POST['id']));
$DIRECTION = substr(trim(addslashes($_POST['direction'])),0,10);
$CREATE_ACTION = substr(trim(addslashes($_POST['create_action'])),0,1);

if( eregi("[^a-z]", $DIRECTION, $regs) )
{
	$_SESSION['SHOW_MSG'] = 'ME_JUSTLETTER';
	$_SESSION['ITEMID'] = $ID;
	$_SESSION['EX_NAME'] = $DIRECTION;
	$_SESSION['EX_ACT'] = $CREATE_ACTION;
	header("Location:$DESTINATION_PAGE");
}
else
{
	if (empty($DIRECTION)) {
		$_SESSION['SHOW_MSG'] = 'ME_NEEDFILL';
		$_SESSION['ITEMID'] = $ID;
		$_SESSION['EX_NAME'] = $DIRECTION;
		$_SESSION['EX_ACT'] = $CREATE_ACTION;
		header("Location:$DESTINATION_PAGE");
	}
	else {
		if (empty($CREATE_ACTION))
		{
			$CREATE_ACTION = 0;
		}
		
		$SQL = "SELECT id FROM cc_firewall.direction WHERE name = '$DIRECTION' AND id != '$ID'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG011F"));
		$COUNT_DIR = mysql_affected_rows();
		
		$SQL = "SELECT id FROM cc_firewall.action WHERE name = '$DIRECTION' ";
		$SQL .= "AND name NOT IN (SELECT name FROM cc_firewall.direction WHERE id = '$ID')";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG012F"));
		$COUNT_ACT = mysql_affected_rows();
		
		if (($COUNT_DIR != 0)||($COUNT_ACT != 0))
		{
			if ($LOG_AUDITOR == 1)
			{
				auditor('IFWSG013F', $ADDRIP, $USER, '0');
			}
			$_SESSION['SHOW_MSG'] = 'ME_NAMEEXISTORDIRECTIONACTION';
			$_SESSION['ITEMID'] = $ID;
			$_SESSION['EX_NAME'] = $DIRECTION;
			$_SESSION['EX_ACT'] = $CREATE_ACTION;
			header("Location:$DESTINATION_PAGE");	
		}
		else
		{
			if (empty($ID))
			{
				// Create personal variable in file
				$COMMAND = "cp includes/variable_personal.php /tmp/.variable_personal.php";
				exec($COMMAND,$RETURN);
					if (!empty($RETURN) && ($LOG_AUDITOR == 1))
					{
						auditor('IFWCG014F', $ADDRIP, $USER, '0');
					}
				$COMMAND = "sed  '2i$$DIRECTION = \"'"."$DIRECTION"."'\";' /tmp/.variable_personal.php ";
				$COMMAND .= "> includes/variable_personal.php";
				exec($COMMAND,$RETURN);
					if (!empty($RETURN) && ($LOG_AUDITOR == 1))
					{
						auditor('IFWCG015F', $ADDRIP, $USER, '0');
					}
				
				$SQL = "INSERT INTO cc_firewall.direction (name, have_policy) VALUES ('$DIRECTION', '0')";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG016F"));
				$ID_DIR = mysql_insert_id();
				if ((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1)){
					auditor('IFWIG016S', $ADDRIP, $USER, '0');
				}elseif($LOG_AUDITOR == 1){
					auditor('IFWIG016F', $ADDRIP, $USER, '0');
				}
				
				if(empty($ID_DIR) && ($LOG_AUDITOR == 1)){
					auditor('IFWSG017F', $ADDRIP, $USER, '0');
				}
				
				//Select the table for create associate
				$SQL = "SELECT id FROM cc_firewall.tablefw WHERE name = 'filter'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG021F"));

				$ARRAY = mysql_fetch_array($RS);
				$ID_TAB = $ARRAY['id'];
				
				if ($CREATE_ACTION == 1)
				{
					$SQL = "INSERT INTO cc_firewall.action (name, in_policy) VALUES ('$DIRECTION', '0')";
					$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG018F"));
					$ID_ACT = mysql_insert_id();
					if ((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1)){
						auditor('IFWIG018S', $ADDRIP, $USER, '0');	
					}elseif($LOG_AUDITOR == 1){
						auditor('IFWIG018F', $ADDRIP, $USER, '0');
					}
					
					$SQL = "SELECT id FROM cc_firewall.direction WHERE (id IN ";
					$SQL .= "(SELECT id_dir FROM cc_firewall.tab_dir_act WHERE id_tab IN ";
					$SQL .= "(SELECT id FROM cc_firewall.tablefw WHERE name = 'filter')))";
					$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG019F"));

					$ARRAY = mysql_fetch_array($RS);
					do
					{
						$ID_LOOP = $ARRAY['id'];
						$SQL = "INSERT INTO cc_firewall.tab_dir_act (id_tab, id_dir, id_act) ";
						$SQL .= "VALUES ('$ID_TAB','$ID_LOOP','$ID_ACT')";
						$RS1 = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG020F"));
					
					}while($ARRAY = mysql_fetch_array($RS));
				}
				
				// Select the actions exists for create associate.
				$SQL = "SELECT id FROM cc_firewall.action WHERE (id IN ";
				$SQL .= "(SELECT id_act FROM cc_firewall.tab_dir_act WHERE id_tab IN ";
				$SQL .= "(SELECT id FROM cc_firewall.tablefw WHERE name = 'filter')))";

				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG022F"));
				$ARRAY = mysql_fetch_array($RS);
				do
				{
					$ID_LOOP = $ARRAY['id'];
					$SQL = "INSERT INTO cc_firewall.tab_dir_act (id_tab, id_dir, id_act) ";
					$SQL .= "VALUES ('$ID_TAB','$ID_DIR','$ID_LOOP')";
					$RS1 = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG023F"));
				}while($ARRAY = mysql_fetch_array($RS));
	
			}
			else
			{
				// Select the name just for change the variable in file
				$SQL = "SELECT name FROM cc_firewall.direction WHERE id = '$ID'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG024F"));

				$ARRAY = mysql_fetch_array($RS);
				$NAMEDIR = $ARRAY['name'];

				$COMMAND = "cp includes/variable_personal.php /tmp/.variable_personal.php";
				exec($COMMAND,$RETURN);
					if (!empty($RETURN) && ($LOG_AUDITOR == 1))
					{
						auditor('IFWSG025F', $ADDRIP, $USER, '0');
					}
				$COMMAND = "sed 's/$NAMEDIR = \"$NAMEDIR\"/$DIRECTION = \"'"."$DIRECTION"."'\"/' /tmp/.variable_personal.php ";
				$COMMAND .= "> includes/variable_personal.php";
				exec($COMMAND,$RETURN);
					if (!empty($RETURN) && ($LOG_AUDITOR == 1))
					{
						auditor('IFWSG026F', $ADDRIP, $USER, '0');
					}
				
				//Verify if arly have any action with this name
				$SQL = "SELECT id FROM cc_firewall.action WHERE name IN (SELECT name FROM cc_firewall.direction ";
				$SQL .= "WHERE id = '$ID' )";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG027F"));
				
				if (mysql_affected_rows() == 0)
				{
					$HAVE_ACTION = 0;
				}
				else
				{
					$ARRAY = mysql_fetch_array($RS);
					$ID_ACT = $ARRAY['id'];
					$HAVE_ACTION = 1;
				}
				if ($CREATE_ACTION == 1)
				{
					if ($HAVE_ACTION == 0)
					{
						$SQL = "INSERT INTO cc_firewall.action (name) VALUES ('$DIRECTION')";
						$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG028F"));
						if ((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1))
						{
							auditor('IFWIG028S', $ADDRIP, $USER, '0');
						}
					}
					else
					{
						$SQL = "UPDATE cc_firewall.action SET name = '$DIRECTION' WHERE id = '$ID_ACT'";
						$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUG029F"));
						if ((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1))
						{
							auditor('IFWUG029S', $ADDRIP, $USER, '0');
						}
					}
				}
				else
				{
					if ($HAVE_ACTION == 1)
					{
						$SQL = "DELETE FROM cc_firewall.action WHERE  id = '$ID_ACT'";
						$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG030F"));
					}
				}
				
				// Insert the direction
				$SQL = "UPDATE cc_firewall.direction SET name='$DIRECTION' WHERE id = '$ID'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUG031F"));
				if ((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1))
				{
					auditor('IFWUG031S', $ADDRIP, $USER, '0');
				}
			}		
			if (mysql_affected_rows() != 0) {
				$_SESSION['SHOW_MSG'] = 'F_SUCESS';
			} else {
				$_SESSION['SHOW_MSG'] = 'F_FAILURE';
			}
			header("Location:$DESTINATION_PAGE");
		}
	}
}
?>