<div id="menu_options_type"> <!--Main--> 
<form action="rule_fw.php" method="post" name="menu_rules_filtering">
<a href="javascript:document.menu_rules_filtering.submit();">
	<div class="button_rule_type" >
		<input type="hidden" name="type_rule" value="filtering" />
		<img src="/attik/@img/icons/filter-16x16.png" align="absmiddle"/>
		<?php echo $L_FILTER;?>
	</div>
</a>
</form>
<form action="rule_fw.php" method="post" name="menu_rules_nat">
<a href="javascript:document.menu_rules_nat.submit();">
	<div class="button_rule_type">
		<input type="hidden" name="type_rule" value="nat" />
		<img src="/attik/@img/icons/nat-16x16.png" align="absmiddle"/>	
		<?php echo $L_NAT;?>
	</div>
</a>
</form>
<form action="rule_fw.php" method="post" name="menu_rules_tos">
<a href="javascript:document.menu_rules_tos.submit();">
	<div class="button_rule_type">
		<input type="hidden" name="type_rule" value="tos" />
		<img src="/attik/@img/icons/tos-16x16.png" align="absmiddle"/>	
		<?php echo $L_MANGLE;?>
	</div>
</a>
</form>
<?php /*
<form action="rule_fw.php" method="post" name="menu_rules_loadbalance">
<a href="javascript:document.menu_rules_loadbalance.submit();">
	<div class="button_rule_type">
		<input type="hidden" name="type_rule" value="loadbalance" />
		<img src="/attik/@img/icons/loadbalance-24x24.png" align="absmiddle"/>	
		<?php echo $L_BALANCE;?>
	</div>
</a>
</form>*/?>
</div>
