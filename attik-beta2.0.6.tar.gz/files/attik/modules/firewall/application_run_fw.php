<?php 
require_once('../../includes/control_session.php');
require_once('includes/functions.php');

$DESTINATION_PAGE = "application_fw.php";

$ID = trim(addslashes($_POST['id']));
$NAME = substr(strtoupper(trim(addslashes($_POST['name']))),0,20);
$PORT = substr(trim(addslashes($_POST['port'])),0,11);
$DESCRIPTION = substr(trim(addslashes($_POST['description'])),0,50);
$ID_PRO = substr(trim(addslashes($_POST['protocol'])),0,3);
$REPORT = substr(trim(addslashes($_POST['graph'])),0,1);

if ((empty($NAME)) or ($PORT == "") or (empty($ID_PRO))) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDFILL';
	$_SESSION['ITEMID'] = $ID;
	$_SESSION['EX_NAME'] = $NAME;
	$_SESSION['EX_PORT'] = $PORT;
	$_SESSION['EX_DESC'] = $DESCRIPTION;
	$_SESSION['EX_PROTOCOL'] = $ID_PRO;
	$_SESSION['EX_GRAPH'] = $REPORT;
	header("Location:$DESTINATION_PAGE");
}elseif(((!empty($PORT))&&(verifyPort($PORT)!="ok"))||(eregi("[^0-9:]", $PORT, $regs))||(sizeof(explode(":",$PORT))>2)||($PORT[strlen($PORT)-1] == ':'))
	{
	$_SESSION['SHOW_MSG'] = 'ME_INVALIDPORT';
	$_SESSION['ITEMID'] = $ID;
	$_SESSION['EX_NAME'] = $NAME;
	$_SESSION['EX_PORT'] = $PORT;
	$_SESSION['EX_DESC'] = $DESCRIPTION;
	$_SESSION['EX_PROTOCOL'] = $ID_PRO;
	$_SESSION['EX_GRAPH'] = $REPORT;
	header("Location:$DESTINATION_PAGE");
}else {
	$SQL = "SELECT * FROM cc_firewall.application WHERE (name = '$NAME' OR port = '$PORT')";
	$SQL .= "AND id != '$ID' AND id_pro = '$ID_PRO'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSA006F"));
	if ( mysql_affected_rows() !=0 )
	{
		if($LOG_AUDITOR == 1){
			auditor('IFWSA006F', $ADDRIP, $USER, $NAME);
		}
		$_SESSION['SHOW_MSG'] = 'ME_NAMEORPORTEXIST';
		$_SESSION['ITEMID'] = $ID;
		$_SESSION['EX_NAME'] = $NAME;
		$_SESSION['EX_PORT'] = $PORT;
		$_SESSION['EX_DESC'] = $DESCRIPTION;
		$_SESSION['EX_PROTOCOL'] = $ID_PRO;
		$_SESSION['EX_GRAPH'] = $REPORT;
		header("Location:$DESTINATION_PAGE");
	}
	else {
		if ($REPORT != 1)
		{
			$REPORT = 0;
		}
	
		if (empty($ID)) {
				
				$SQL = "INSERT INTO cc_firewall.application (name, port, description, id_pro, report)"; 
				$SQL .= "VALUES ('$NAME', '$PORT', '$DESCRIPTION', '$ID_PRO', '$REPORT')";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIA007F"));
		}
		else {
			// Get the old value whould by change 
			$SQL = "SELECT port FROM cc_firewall.application WHERE id = '$ID'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSA012F"));
			$ARRAY = mysql_fetch_array($RS);
			$OLDVALUE = $ARRAY['port'];
			
			$SQL = "UPDATE cc_firewall.application SET name='$NAME', port='$PORT', description='$DESCRIPTION', ";
			$SQL .= "id_pro='$ID_PRO', report='$REPORT' WHERE id = '$ID'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUA008F"));
		}
		if (mysql_affected_rows() != 0) {
			if($LOG_AUDITOR == 1){
				auditor('IFWXA009S', $ADDRIP, $USER, '0');
			}
			$_SESSION['SHOW_MSG'] = 'F_SUCESS';
			if (!empty($ID)) {
				updateSyncRules("app",$ID,$OLDVALUE);
			}
		} else {
			if($LOG_AUDITOR == 1){
				auditor('IFWXA009F', $ADDRIP, $USER, '0');
			}
			$_SESSION['SHOW_MSG'] = 'F_FAILURE';
		}
		header("Location:$DESTINATION_PAGE");
	}
}
?>
