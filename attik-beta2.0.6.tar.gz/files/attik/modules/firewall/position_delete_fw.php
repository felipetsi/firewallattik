<?php 
require_once('../../includes/control_session.php');

$DESTINATION_PAGE = "position_fw.php";

$ID = trim(addslashes($_SESSION['ITEMDELETE']));

if (empty($ID)) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDSELECT';
	header("Location:$DESTINATION_PAGE");
}
else {
	$SQL = "UPDATE cc_firewall.network SET id_pfw = '0' WHERE id_pfw = '$ID'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUP009F"));
	
	$SQL = "DELETE FROM cc_firewall.positionfw WHERE id = '$ID'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDP010F"));
	if ( mysql_affected_rows() !=0 )
	{
		if($LOG_AUDITOR == 1){
			auditor('IFWDP010S', $ADDRIP, $USER, '0');
		}
		$_SESSION['SHOW_MSG'] = 'F_SUCESS';
	}else {
		if($LOG_AUDITOR == 1){
			auditor('IFWDP010F', $ADDRIP, $USER, '0');
		}
		$_SESSION['SHOW_MSG'] = 'F_FAILURE';
	}
		unset($_SESSION['ITEMDELETE']);
		header("Location:$DESTINATION_PAGE");
}
?>