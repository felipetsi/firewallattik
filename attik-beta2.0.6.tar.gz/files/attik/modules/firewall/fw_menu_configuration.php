<div id="left_menu"><!-- Sub-menu -->
<a href="general_conf_fw.php">
 <div class="button_conf_fw" >
	 <img src="../../@img/icons/suport-16x16.png" /><?php echo $L_GENERAL;?>
 </div>
</a>
<a href="application_fw.php">
 <div class="button_conf_fw" >
	 <img src="../../@img/icons/protocol-16x16.png" /><?php echo $L_PROTOCOL;?> 
 </div>
</a>
<a href="network_fw.php">
 <div class="button_conf_fw" >
	 <img src="../../@img/icons/network-connections-16x16.png" /><?php echo $L_ADDRESS;?>
 </div>
</a>
<a href="monitor_fw.php" target="_blank">
 <div class="button_conf_fw" >
	 <img src="../../@img/icons/log-16x16.png" /><?php echo $L_LOG;?>
 </div>
</a>
</div> <!-- Sub-menu -->