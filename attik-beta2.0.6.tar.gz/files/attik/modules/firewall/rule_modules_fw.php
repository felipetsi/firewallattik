<div class="r_text_atr"><?php echo $T_ATTRIBUTE;?></div>
<?php
$SQL = "SELECT * FROM cc_firewall.module ORDER BY id";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR090F"));
$MODULE = mysql_fetch_array($RS);
do{?>
<div class="r_box_right" id="<?php echo $MODULE['name']?>"><!-- Module -->
	<div class="r_box_mod_text">
		<?php echo ($$MODULE['name']);?>:
	</div>
	<?php
	if ($MODULE['definitive'] != 1)
	{
		$NAME = $MODULE['name'];
		if (!empty($ITEMID))
		{
			$ID = $MODULE['id'];
			$SQL = "SELECT name FROM cc_firewall.atribute_module WHERE id_mod = '$ID' AND ";
			$SQL .= "id IN (SELECT id_atr FROM cc_firewall.rul_atr WHERE id_rul = '$ITEMID')";
			$RSMOD = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR091F"));
			$MOD = mysql_fetch_array($RSMOD);
		}
		?>
			<div>
			<?php 
			if ($MODULE['name'] == "mac")
			{?>
				<select name="mac_condition">
					<?php
					if(($_SESSION['MAC_COND']==1)||($ARRAY['mac_condition']==1)){
						$COND_TEMP2 = 'selected="selected"';
						$COND_TEMP1 = 0;
					} else {
						$COND_TEMP1 = 'selected="selected"';
						$COND_TEMP2 = 0;
					}?>
					<option value="0" <?php echo $COND_TEMP1;?> >=</option>
					<option value="1" <?php echo $COND_TEMP2;?> >!=</option>
				</select>
				<input name="<?php echo $MODULE['name']?>" type="text" size="8" maxlength="17" 
				 value="<?php if (empty($MOD['name'])){echo $_SESSION["$NAME"];}else{echo $MOD['name'];} ?>" />
			<?php
			}
			elseif ($MODULE['name'] == "string")
			{?>
				<select name="string_condition">
					<?php
					if(($_SESSION['STRING_COND']==1)||($ARRAY['string_condition']==1)){
						$COND_TEMP2 = 'selected="selected"';
						$COND_TEMP1 = 0;
					} else {
						$COND_TEMP1 = 'selected="selected"';
						$COND_TEMP2 = 0;
					}?>
					<option value="0" <?php echo $COND_TEMP1;?> >=</option>
					<option value="1" <?php echo $COND_TEMP2;?> >!=</option>
				</select>
				<input name="<?php echo $MODULE['name']?>" type="text" size="10" maxlength="127" 
				 value="<?php if (empty($MOD['name'])){echo $_SESSION["$NAME"];}else{echo $MOD['name'];} ?>" onchange="javascript: verifyAction();" />
			<?php
			}
			else
			{
				if (!empty($MOD['name']))
				{
					$ARRAY_LIMIT = explode("/",$MOD['name']);
					$VALUE_LIMIT = $ARRAY_LIMIT[0];
					$UNIT_LIMIT = $ARRAY_LIMIT[1];
				}
				else
				{
					$ARRAY_LIMIT = explode("/",$_SESSION['limit']);
					$VALUE_LIMIT = $ARRAY_LIMIT[0];
					$UNIT_LIMIT = $ARRAY_LIMIT[1];
				}
			?>
				<input name="<?php echo $MODULE['name']?>" type="text" size="1" maxlength="4" value="<?php echo $VALUE_LIMIT; ?>" />
				<select name="type_time" style="width:85px;">
				<option></option>
				<?php 
				$IDACT = $ARRAY['id_tab_dir_act'];
				$SQL = "SELECT * FROM cc_firewall.unit_time";
				$RSMOD = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR092F"));
				$OBJ = mysql_fetch_array($RSMOD);
				do
				{
					if ($UNIT_LIMIT == $OBJ['name'])
					{
						$sel = 'selected="selected"';
					}
					else
					{
						$sel = "";
					}
				if ( $cor == 1 )
				{ ?>
					<option value="<?php echo $OBJ['name'];?>" <?php echo $sel;?> >
						<?php echo ($$OBJ['description']); $cor=0;?></option>
					<?php 
				} else { ?>
					<option style="background:<?php echo $COLOR_LINE_SELECT;?>" value="<?php echo $OBJ['name'];?>" <?php echo $sel;?> >	
						<?php echo ($$OBJ['description']); $cor=1;?></option>
						<?php
					}
				}while($OBJ = mysql_fetch_array($RSMOD));?>
				</select>
			<?php
			}?>
			</div><?php
	}
	else
	{?>
		<div>
		<select name="state_condition">
			<?php
			if(($_SESSION['STATE_COND']==1)||($ARRAY['state_condition']==1)){
				$COND_TEMP2 = 'selected="selected"';
				$COND_TEMP1 = 0;
			} else {
				$COND_TEMP1 = 'selected="selected"';
				$COND_TEMP2 = 0;
			}?>
			<option value="0" <?php echo $COND_TEMP1;?> >=</option>
			<option value="1" <?php echo $COND_TEMP2;?> >!=</option>
		</select>
		<select name="<?php echo $MODULE['name'];?>" style="width:140px;">
			<?php
			$SQL = "SELECT * FROM cc_firewall.rul_atr WHERE id_rul = '$ITEMID'";
			$RSSELECT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR093F"));
			$LENGSELECT = mysql_num_rows($RSSELECT);
			
			$sel = 'selected="selected"';
		
			?>
			<option <?php echo $sel;?> ></option>
			<?php
			$IDMOD = $MODULE['id'];
			$SQL = "SELECT * FROM cc_firewall.atribute_module WHERE id_mod = '$IDMOD'";
			$RSINSIDE = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR094F"));
			$ATTRIBUTE = mysql_fetch_array($RSINSIDE);
			$LENG = mysql_affected_rows();
			
			if ($LENG == $LENGSELECT)
			{
				$sel = 'selected="selected"';
			}
			else
			{
				$sel = "";
			}
			?>
			<option value="<?php
			do{
			$count++;
			if ($count < $LENG)
				{
					echo ($ATTRIBUTE['id']."@");
				}
			else
				{
					echo ($ATTRIBUTE['id']);
				}
			} while($ATTRIBUTE = mysql_fetch_array($RSINSIDE));?>" <?php echo $sel;?> ><?php echo $F_ALL; $cor=0;?></option>
			<?php
			$SQL = "SELECT * FROM cc_firewall.atribute_module WHERE id_mod = '$IDMOD'";
			$RSINSIDE = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR095F"));
			$ATTRIBUTE = mysql_fetch_array($RSINSIDE);
			$sel = "";
			do
			{
				if (!empty($ITEMID))
				{
					$SQL = "SELECT id_rul FROM cc_firewall.rul_atr WHERE id_rul = '$ITEMID' AND ";
					$SQL .= "id_atr IN (SELECT id FROM cc_firewall.atribute_module WHERE ";
					$SQL .= "id_mod IN (SELECT id FROM cc_firewall.module WHERE ";
					$SQL .= "definitive = '1'))";
					$RSSELECT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR096F"));
					$LENGALLRULE = mysql_affected_rows();
					
					$FID = $ATTRIBUTE['id'];
					$SQL = "SELECT id_rul FROM cc_firewall.rul_atr WHERE id_rul = '$ITEMID' ";
					$SQL .= "AND (id_atr = '$FID')";
					$RSSELECT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR097F"));
					$LENG = mysql_affected_rows();
				
					if (($LENG == $LENGALLRULE) && ($LENGALLRULE == 1))
						{
							$sel = 'selected="selected"';
						}
					else
						{
							$sel = "";
						}
				}
				if ( $cor == 1 )
				{ ?>
				<option value="<?php echo $ATTRIBUTE['id'];?>" <?php echo $sel;?> >
					<?php echo ($$ATTRIBUTE['name']); $cor=0;?></option>
				<?php 
				} else { ?>
				<option style="background:<?php echo $COLOR_LINE_SELECT;?>" value="<?php echo $ATTRIBUTE['id'];?>" <?php echo $sel;?> >	
					<?php echo ($$ATTRIBUTE['name']); $cor=1;?></option>
				<?php
				}
			}while($ATTRIBUTE = mysql_fetch_array($RSINSIDE));
			
			/*--------------------------*/

			$SQL = "SELECT * FROM cc_firewall.atribute_module WHERE id_mod = '$IDMOD'";
			$RSINSIDE = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR098F"));
			$ATTRIBUTE = mysql_fetch_array($RSINSIDE);

			$sel = "";
			do
			{
				$IDATTR = $ATTRIBUTE['id'];
				$SQL = "SELECT * FROM cc_firewall.atribute_module WHERE id_mod = '$IDMOD' ";
				$SQL .= "AND id <> '$IDATTR' ";
				for ($count = 0; $count < sizeof($EXCLUDEID); $count++)
					{
						$ID = $EXCLUDEID[$count];
						$SQL .= "AND id <> '$ID' ";
					}
				$RSATTR = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR099F"));
				$INSIDE = mysql_fetch_array($RSATTR);
				do{
					if (!empty($INSIDE['id']))
					{
						if (!empty($ITEMID))
						{
							$SQL = "SELECT id_rul FROM cc_firewall.rul_atr WHERE id_rul = '$ITEMID' AND ";
							$SQL .= "id_atr IN (SELECT id FROM cc_firewall.atribute_module WHERE ";
							$SQL .= "id_mod IN (SELECT id FROM cc_firewall.module WHERE ";
							$SQL .= "definitive = '1'))";
							$RSSELECT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR100F"));
							$LENGALLRULE = mysql_affected_rows();
						
							$SID = $INSIDE['id'];
							$SQL = "SELECT id_rul FROM cc_firewall.rul_atr WHERE id_rul = '$ITEMID' ";
							$SQL .= "AND (id_atr = '$IDATTR' OR id_atr = '$SID')";
							$RSSELECT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR101F"));
							$LENG = mysql_affected_rows();

							if (($LENG == $LENGALLRULE) && ($LENGALLRULE == 2))
								{
									$sel = 'selected="selected"';
								} 
							else 
								{
									$sel = "";
								}
						}
					if ( $cor == 1 )
					{ 
						?>
							<option value="<?php echo ($ATTRIBUTE['id']."@".$INSIDE['id']);?>" <?php echo $sel;?> >
								<?php echo ($$ATTRIBUTE['name'].", ".$$INSIDE['name']); $cor=0;?>
							</option>
						<?php 
						} else { ?>
							<option style="background:<?php echo $COLOR_LINE_SELECT;?>" 
								value="<?php echo ($ATTRIBUTE['id']."@".$INSIDE['id']);?>" <?php echo $sel;?> >	
								<?php echo ($$ATTRIBUTE['name'].", ".$$INSIDE['name']); $cor=1;?>
							</option>
					<?php
					}
					}
				}while($INSIDE = mysql_fetch_array($RSATTR));
				$EXCLUDEID[] = $ATTRIBUTE['id'];

			}while($ATTRIBUTE = mysql_fetch_array($RSINSIDE));

			/*--------------------------*/
			$SQL = "SELECT * FROM cc_firewall.atribute_module WHERE id_mod = '$IDMOD' LIMIT 0,2";
			$RSINSIDE = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR102F"));
			$ATTRIBUTE = mysql_fetch_array($RSINSIDE);

			do
			{
			$IDATTR = $ATTRIBUTE['id'];
			if (!empty($IDATTR))
			{
				$SQL = "SELECT * FROM cc_firewall.atribute_module WHERE id_mod = '$IDMOD' ";
				$SQL .= "AND id <> '$IDATTR' ";
				for ($count = 0; $count < sizeof($SEXCLUDEID); $count++)
					{
						$ID = $SEXCLUDEID[$count];
						$SQL .= "AND id <> '$ID' ";
					}
				$SQL .= "LIMIT 0,2";
				$RSATTR = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR103F"));
				$INSIDE = mysql_fetch_array($RSATTR);
				do{
					$IDINSIDE = $INSIDE['id'];
					$SQL = "SELECT * FROM cc_firewall.atribute_module WHERE id_mod = '$IDMOD' ";
					$SQL .= "AND id <> '$IDATTR' AND id <> '$IDINSIDE' AND id <> '$LASTLOOPID' AND id <> '$LASTID'";

					$RSATTR2 = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR104F"));
					$INSIDE2 = mysql_fetch_array($RSATTR2);
				
					do{
					
					if (!empty($INSIDE2['id']))
					{
						if (!empty($ITEMID))
						{
							$SQL = "SELECT id_rul FROM cc_firewall.rul_atr WHERE id_rul = '$ITEMID' AND ";
							$SQL .= "id_atr IN (SELECT id FROM cc_firewall.atribute_module WHERE ";
							$SQL .= "id_mod IN (SELECT id FROM cc_firewall.module WHERE ";
							$SQL .= "definitive = '1'))";
							$RSSELECT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR105F"));
							$LENGALLRULE = mysql_affected_rows();						
	
							$SID = $INSIDE2['id'];
							$SQL = "SELECT * FROM cc_firewall.rul_atr WHERE id_rul = '$ITEMID' ";
							$SQL .= "AND (id_atr = '$IDATTR' OR id_atr = '$IDINSIDE' OR ";
							$SQL .= "id_atr = '$SID')";
							$RSSELECT = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR106F"));
							$LENG = mysql_affected_rows();

							if (($LENG == $LENGALLRULE) && ($LENGALLRULE == 3))
								{
									$sel = 'selected="selected"';
								} 
							else 
								{
									$sel = "";
								}
						}
						if ( $cor == 1 )
						{ 
						?>
							<option value="<?php echo ($ATTRIBUTE['id']."@".$INSIDE['id']."@".$INSIDE2['id']);?>" <?php echo $sel;?> >
								<?php echo ($$ATTRIBUTE['name'].", ".$$INSIDE['name'].", ".$$INSIDE2['name']); $cor=0;?>
							</option>
						<?php 
						} else { ?>
							<option style="background:<?php echo $COLOR_LINE_SELECT;?>" 
								value="<?php echo ($ATTRIBUTE['id']."@".$INSIDE['id']."@".$INSIDE2['id']);?>" <?php echo $sel;?> >	
								<?php echo ($$ATTRIBUTE['name'].", ".$$INSIDE['name'].", ".$$INSIDE2['name']); $cor=1;?>
							</option>
					<?php
						}
					}
					}while($INSIDE2 = mysql_fetch_array($RSATTR2));
					$LASTLOOPID = $INSIDE['id'];
				}while($INSIDE = mysql_fetch_array($RSATTR));
				$SEXCLUDEID[] = $ATTRIBUTE['id'];
			$LASTID = $ATTRIBUTE['id'];
			}
			}while($ATTRIBUTE = mysql_fetch_array($RSINSIDE));

			/*--------------------------*/
			?>
		</select>

		</div><?php 
	}?>
</div> <!-- Module -->
<?php
}while($MODULE = mysql_fetch_array($RS)); ?>