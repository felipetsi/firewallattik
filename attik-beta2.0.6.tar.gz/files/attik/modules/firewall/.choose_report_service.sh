#!/bin/bash

# Home directory of attik pages
DIRHOMEPAGES="/var/www/attik"

export REPORTTYPE="graphservice"

$DIRHOMEPAGES/modules/firewall/.generate_history.sh
