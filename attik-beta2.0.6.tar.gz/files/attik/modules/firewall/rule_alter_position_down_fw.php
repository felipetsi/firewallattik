<?php 
require_once('../../includes/control_session.php');
require_once('includes/functions.php');
$DESTINATION_PAGE = $_SESSION['SOURCE_PAGE'];

// Load the profile of user autenticanted
$SQL = "SELECT create_rule, read_rule FROM controlcenter.profilefw WHERE id IN ";
$SQL .= "(SELECT id_profw FROM controlcenter.profile WHERE id IN (SELECT id_pro FROM ";
$SQL .= "controlcenter.user WHERE id = '$USER'))";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR001F"));
$DATA_USER = mysql_fetch_array($RS);

if ($DATA_USER['create_rule'] == 1)
{
	$ID = trim(addslashes($_POST['idrule']));
	$_SESSION['ITEMID'] = $ID;
	if ($ID != "")
	{
		$IDTARGET = $ID + 1;
		$SQL = "SELECT id FROM cc_firewall.rulefw WHERE '$IDTARGET'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR060F"));
		if (mysql_affected_rows() == 0)
		{
			$SQLF = "UPDATE cc_firewall.rulefw SET id = '$IDTARGET' WHERE id = '$ID'";

			// Change the attributes
			$SQL = "UPDATE cc_firewall.rul_atr SET id_rul = '$IDTARGET' WHERE id_rul = '$ID'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR061F"));
			
			// Change the rulefwrun
			$SQL = "UPDATE cc_firewall.rulefwrun SET id = '$IDTARGET' WHERE id = '$ID'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR111S"));

			// Change rule's application
			$SQL = "UPDATE cc_firewall.rule_app SET id_rul = '$IDTARGET' WHERE id_rul = '$ID'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR112S"));
			
			// Change rule's network attibutes NAT
			$SQL = "UPDATE cc_firewall.rule_nat_net SET id_rul = '$IDTARGET' WHERE id_rul = '$ID'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR113S"));
			
			// Change rule's application attibutes NAT
			$SQL = "UPDATE cc_firewall.rule_nat_app SET id_rul = '$IDTARGET' WHERE id_rul = '$ID'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR129S"));
			
			// Change rule's network
			$SQL = "UPDATE cc_firewall.rul_net SET id_rul = '$IDTARGET' WHERE id_rul = '$ID'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR114S"));
			
			/*
			$SQL = "UPDATE cc_firewall.rul_vartime SET id_rul = '$IDTARGET' WHERE id_rul = '$ID'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR061F"));*/
		}
		else
		{
			// Change the rule position
			$SQL = "UPDATE cc_firewall.rulefw SET id = '0.1' WHERE id = '$ID'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR062F"));
			// Change the rule position
			$SQL = "UPDATE cc_firewall.rulefw SET id = '$ID' WHERE id = '$IDTARGET'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR063F"));
			// Change the rule position
			$SQLF = "UPDATE cc_firewall.rulefw SET id = '$IDTARGET' WHERE CONCAT_WS('-',id) = '0.1'";
			
			// Change the attributes
			$SQL = "UPDATE cc_firewall.rul_atr SET id_rul = '0.1' WHERE id_rul = '$ID'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR064F"));
			// Change the attributes
			$SQL = "UPDATE cc_firewall.rul_atr SET id_rul = '$ID' WHERE id_rul= '$IDTARGET'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR065F"));
			// Change the attributes
			$SQL = "UPDATE cc_firewall.rul_atr SET id_rul = '$IDTARGET' WHERE CONCAT_WS('-',id_rul) = '0.1'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR066F"));
			

			// Change the rulefwrun
			$SQL = "UPDATE cc_firewall.rulefwrun SET id = '0.1' WHERE id = '$ID'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR115S"));
			// Change the rulefwrun
			$SQL = "UPDATE cc_firewall.rulefwrun SET id = '$ID' WHERE id = '$IDTARGET'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR116S"));
			// Change the rulefwrun
			$SQL = "UPDATE cc_firewall.rulefwrun SET id = '$IDTARGET' WHERE CONCAT_WS('-',id) = '0.1'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR117S"));

			// Change rule's application
			$SQL = "UPDATE cc_firewall.rule_app SET id_rul = '0.1' WHERE id_rul = '$ID'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR118S"));
			// Change rule's application
			$SQL = "UPDATE cc_firewall.rule_app SET id_rul = '$ID' WHERE id_rul= '$IDTARGET'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR119S"));
			// Change rule's application
			$SQL = "UPDATE cc_firewall.rule_app SET id_rul = '$IDTARGET' WHERE CONCAT_WS('-',id_rul) = '0.1'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR120S"));
			
			// Change rule's extends attibutes
			$SQL = "UPDATE cc_firewall.rule_nat_net SET id_rul = '0.1' WHERE id_rul = '$ID'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR121S"));
			// Change rule's extends attibutes
			$SQL = "UPDATE cc_firewall.rule_nat_net SET id_rul = '$ID' WHERE id_rul= '$IDTARGET'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR122S"));
			// Change rule's extends attibutes
			$SQL = "UPDATE cc_firewall.rule_nat_net SET id_rul = '$IDTARGET' WHERE CONCAT_WS('-',id_rul) = '0.1'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR123S"));
			
			// Change rule's extends attibutes
			$SQL = "UPDATE cc_firewall.rule_nat_app SET id_rul = '0.1' WHERE id_rul = '$ID'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR121S"));
			// Change rule's extends attibutes
			$SQL = "UPDATE cc_firewall.rule_nat_app SET id_rul = '$ID' WHERE id_rul= '$IDTARGET'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR122S"));
			// Change rule's extends attibutes
			$SQL = "UPDATE cc_firewall.rule_nat_app SET id_rul = '$IDTARGET' WHERE CONCAT_WS('-',id_rul) = '0.1'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR123S"));
			
			// Change rule's network
			$SQL = "UPDATE cc_firewall.rul_net SET id_rul = '0.1' WHERE id_rul = '$ID'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR124S"));
			// Change rule's network
			$SQL = "UPDATE cc_firewall.rul_net SET id_rul = '$ID' WHERE id_rul= '$IDTARGET'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR125S"));
			// Change rule's network
			$SQL = "UPDATE cc_firewall.rul_net SET id_rul = '$IDTARGET' WHERE CONCAT_WS('-',id_rul) = '0.1'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR126S"));
			
			/*
			$SQL = "UPDATE cc_firewall.rul_vartime SET id_rul = '$IDTARGET' WHERE id_rul = '$ID'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR061F"));*/
		}
	}
	$RS = mysql_query($SQLF) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR067F"));
	if (mysql_affected_rows() != 0)
	{
		if($LOG_AUDITOR == 1){
					auditor('IFWUR067S', $ADDRIP, $USER, '0');
		}
		$_SESSION['SHOW_MSG'] = 'F_SUCESS';
		needApply('1');
	} 
	else 
	{
		if($LOG_AUDITOR == 1){
					auditor('IFWUR067F', $ADDRIP, $USER, '0');
		}
		$_SESSION['SHOW_MSG'] = 'F_FAILURE';
	}
}
else
{
$_SESSION['SHOW_MSG'] = 'ME_DONTHAVEPERMITION';
}
unset($_SESSION['SOURCE_PAGE']);
header("Location:$DESTINATION_PAGE");
?>