<?php
require_once('../../includes/control_session.php');

$_SESSION['FILE_LANG'] = "firewall.php";
$DESTINATION_PAGE = "wizard_select_run_fw.php";
$THISPAGE = "wizard_select_fw.php";
$DESTINATION_END = "rule_fw.php";
$DESTINATION_BACK = "wizard_fw.php";

$SQL = "SELECT create_rule, read_rule FROM controlcenter.profilefw WHERE id IN ";
$SQL .= "(SELECT id_profw FROM controlcenter.profile WHERE id IN (SELECT id_pro FROM ";
$SQL .= "controlcenter.user WHERE id = '$USER'))";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB001F"));

$DATA_USER = mysql_fetch_array($RS);

$ADDRESS_SEL = $_POST['addressnet'];
if(sizeof($ADDRESS_SEL) > 1){
	if(!empty($ADDRESS_SEL)){
		$_SESSION['ADDRESS_SELECTED'] = $ADDRESS_SEL;
		$_SESSION['s_control'] = 0;
		$S_CONTROL = $_SESSION['s_control'];
		$S_ADDRESS = $ADDRESS_SEL[$S_CONTROL]
		$_SESSION['s_control']++;
	} else {
		$ADDRESS_SEL = $_SESSION['ADDRESS_SELECTED'];
		$S_CONTROL = $_SESSION['s_control'];
		$S_ADDRESS = $ADDRESS_SEL[$S_CONTROL]	
	}
	
		if(sizeof($ADDRESS_SEL) >= $S_CONTROL){
			$_SESSION['s_control']++;
			
			?>
			<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
			<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
			<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
			<title>..:: IncTI - Firewall ::..</title>
			<link href="../../includes/style_cc.css" rel="stylesheet" type="text/css" />
			</head>
			<body>
			<?php require_once('../../includes/top.php'); ?>
			<?php require_once('fw_menu.php'); ?>
			<div id="main"> <!--Main-->
			<form action="<?php echo $DESTINATION_PAGE?>" method="post" name="fobject">
					<div class="title_general_fw">
					<img src="../../@img/icons/network-connections-16x16.png" /><?php echo $NAME_O; ?>
					<img src="../../@img/icons/right-16x16.png" />
					<img src="../../@img/icons/network-connections-16x16.png" /><? echo $NAME_I; ?></div>
			<?php
				if ($DATA_USER['create_rule'] == 1){
					require_once('wizard_select_show_fw.php');
				}?>
				
				<div id="sentence_warningselect">
				<?php echo $S_SELECTPROTOCOL; ?>
				</div>
				<input type="submit" value="<?php echo $B_NEXT;?>" />
			</form>
			<div class="version_general">
			<?php
			echo $VERSIONCC;
			?>
			</div>
			
			</div>
			</body>
			</html>
			<?php 
		} else {
			header("Location:$DESTINATION_END");
		}
	} else {
		$_SESSION['SHOW_MSG'] = 'ME_INSUFFICIENT_HOSTSERVER';
		header("Location:$DESTINATION_BACK");
	} ?>