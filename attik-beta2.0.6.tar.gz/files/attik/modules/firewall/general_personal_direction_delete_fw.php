<?php 
require_once('../../includes/control_session.php');

$DESTINATION_PAGE = "general_personal_direction_fw.php";

$ID = trim(addslashes($_SESSION['ITEMDELETE']));
$STATUS = 1;
if (empty($ID)) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDSELECT';
	header("Location:$DESTINATION_PAGE");
}
else {
	// Select the name just for change the variable in file
	$SQL = "SELECT name FROM cc_firewall.direction WHERE id = '$ID'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG032F"));
	$ARRAY = mysql_fetch_array($RS);
	$NAMEDIR = $ARRAY['name'];

	$COMMAND = "cp includes/variable_personal.php /tmp/.variable_personal.php";
	system($COMMAND,$RETURN);
		if (!empty($RETURN) && ($LOG_AUDITOR == 1))
		{
			if($LOG_AUDITOR == 1){
				auditor('IFWSG033F', $ADDRIP, $USER, '0');
			}
		}
	$COMMAND = "cat /tmp/.variable_personal.php | grep -v '$NAMEDIR = \"$NAMEDIR\";' > ";
	$COMMAND .= "includes/variable_personal.php";
	system($COMMAND,$RETURN);
		if (!empty($RETURN) && ($LOG_AUDITOR == 1))
		{
			if($LOG_AUDITOR == 1){
				auditor('IFWSG034F', $ADDRIP, $USER, '0');
			}
		}
	
	// Remove the action case exist
	$SQL = "SELECT id FROM cc_firewall.action WHERE name = '$NAMEDIR'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG035F"));
	if (mysql_affected_rows() != 0)
	{
		$ARRAY = mysql_fetch_array($RS);
		$ID_ACT = $ARRAY['id'];
		$SQL = "DELETE FROM cc_firewall.action WHERE id = '$ID_ACT'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG036F"));
		if ( mysql_affected_rows() == 0 )
		{
			if($LOG_AUDITOR == 1){
				auditor('IFWDG036F', $ADDRIP, $USER, '0');
			}
			$STATUS = 0;
		}else{
			if($LOG_AUDITOR == 1){
				auditor('IFWDG036S', $ADDRIP, $USER, '0');
			}
		}
		
		$SQL = "DELETE FROM cc_firewall.tab_dir_act WHERE id_act = '$ID_ACT'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG037F"));
		if ( mysql_affected_rows() == 0 )
		{
			if($LOG_AUDITOR == 1){
				auditor('IFWDG037F', $ADDRIP, $USER, '0');
			}
			$STATUS = 0;
		}
		else{
			if($LOG_AUDITOR == 1){
				auditor('IFWDG037S', $ADDRIP, $USER, '0');
			}
		}
	}
	
	// Remove the direction
	$SQL = "DELETE FROM cc_firewall.direction WHERE id = '$ID'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG038F"));
	if ( mysql_affected_rows() == 0 )
	{
		if($LOG_AUDITOR == 1){
			auditor('IFWDG038F', $ADDRIP, $USER, '0');
		}
		$STATUS = 0;
	}
	else{
		if($LOG_AUDITOR == 1){
			auditor('IFWDG038S', $ADDRIP, $USER, '0');
		}
	}
	
	$SQL = "DELETE FROM cc_firewall.tab_dir_act WHERE id_dir = '$ID'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG039F"));
	if ( mysql_affected_rows() == 0 )
	{
		if($LOG_AUDITOR == 1){
			auditor('IFWDG039F', $ADDRIP, $USER, '0');
		}
		$STATUS = 0;
	}
	else{
		if($LOG_AUDITOR == 1){
			auditor('IFWDG039S', $ADDRIP, $USER, '0');
		}
	}
	
	
	if ( $STATUS != 0 )
	{
		$_SESSION['SHOW_MSG'] = 'F_SUCESS';
	}else {
		$_SESSION['SHOW_MSG'] = 'F_FAILURE';
	}
		unset($_SESSION['ITEMDELETE']);
		header("Location:$DESTINATION_PAGE");
}
?>