<div class="r_box">
	<div class="r_box_text_right">
		<?php echo ("DE");?>:
	</div>
	<div>
		<input type="text" name="fromAddress" size="15" maxlength="18" />
	</div>
	<div class="r_box_text_right">
		<?php echo ("AT�");?>:
	</div>
	<div>
		<input type="text" name="untilAddress" size="15" maxlength="18" />
	</div>
</div>