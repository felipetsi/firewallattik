<?php 
require_once('../../includes/control_session.php');
$DESTINATION_PAGE = "position_fw.php";

$ID = trim(addslashes($_POST['id']));
$NAME = substr(trim(addslashes($_POST['name'])),0,20);
$IMG = substr(trim(addslashes($_POST['img'])),0,100);

if ((empty($NAME))) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDFILL';
	$_SESSION['ITEMID'] = $ID;
	$_SESSION['EX_NAME'] = $NAME;
	$_SESSION['EX_IMG'] = $IMG;
	header("Location:$DESTINATION_PAGE");	
}
else {
	$SQL = "SELECT * FROM cc_firewall.positionfw WHERE name = '$NAME' AND id != '$ID' ";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSP005F"));
	if ( mysql_affected_rows() !=0 )
	{
		if($LOG_AUDITOR == 1){
			auditor('IFWSP005F', $ADDRIP, $USER, $NAME);
		}
		$_SESSION['SHOW_MSG'] = 'ME_NAMEORPORTEXIST';
		$_SESSION['ITEMID'] = $ID;
		$_SESSION['EX_NAME'] = $NAME;
		$_SESSION['EX_IMG'] = $IMG;
		header("Location:$DESTINATION_PAGE");
	}
	else {
	
		if (empty($ID)) {
				
				$SQL = "INSERT INTO cc_firewall.positionfw (name, img)"; 
				$SQL .= "VALUES ('$NAME', '$IMG')";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIP006F"));
		}
		else {
				$SQL = "UPDATE cc_firewall.positionfw SET name='$NAME', img='$IMG' WHERE id = '$ID'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUP007F"));
				}
		if (mysql_affected_rows() != 0) {
			if($LOG_AUDITOR == 1){
					auditor('IFWXP008S', $ADDRIP, $USER, '0');
			}
			$_SESSION['SHOW_MSG'] = 'F_SUCESS';
		} else {
			if($LOG_AUDITOR == 1){
					auditor('IFWXP008F', $ADDRIP, $USER, '0');
			}
			$_SESSION['SHOW_MSG'] = 'F_FAILURE';
		}
		header("Location:$DESTINATION_PAGE");
	}
}
?>