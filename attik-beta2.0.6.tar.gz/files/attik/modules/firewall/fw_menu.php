<div id="menu_options"> <!--Main--> 
<a href="general_conf_fw.php">
	<div class="button_mod">
		<img src="/attik/@img/icons/build-16x16.gif" align="absmiddle"/>
		<?php echo $L_CONFIGURATION;?>
	</div>
</a>
<?php /*
<a href="wizard_fw.php">
	<div class="button_mod">
		<img src="/attik/@img/icons/wizard-16x16.png" align="absmiddle"/>	
		<?php echo $L_WIZARD;?>
	</div>
</a>*/?>
<a href="rule_fw.php">
	<div class="button_mod">
		<img src="/attik/@img/icons/rule-16x16.gif" align="absmiddle"/>	
		<?php echo $L_RULES;?>
	</div>
</a>
<a href="report_fw.php">
	<div class="button_mod">
		<img src="/attik/@img/icons/graph-16x16.png" align="absmiddle"/>
		<?php echo $L_REPORT;?>
	</div>
</a> 
<a href="apply_modified_run_fw.php">
	<?php 
	$SQL = "SELECT name FROM cc_firewall.needapply";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSU001F"));
	$ARRAY = mysql_fetch_array($RS);
	if($ARRAY['name'] == 0){?>
	<div class="button_mod">
		<img src="/attik/@img/icons/Ok-16x16.png" align="absmiddle"/>
		<?php echo $L_APPLY_RULES;?>
	</div>
	<?php } else {?>
	<div class="button_mod" style="color:#FFA64C">
		<img src="/attik/@img/icons/apply-16x16.png" align="absmiddle"/>
		<?php echo $L_APPLY_RULES;?>
	</div>
	<?php } ?>
</a>
</div>
