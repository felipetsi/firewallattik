<?php 
require_once('../../includes/control_session.php');

$DESTINATION_PAGE = "monitor_fw.php";
$THISPAGE = "monitor_fw.php";
$_SESSION['FILE_LANG'] = "firewall.php";


require_once('../../includes/top_monitor.php');

// Load the profile of user autenticanted
$USER = $_SESSION['USER'];
$SQL = "SELECT create_net, read_net FROM controlcenter.profilefw WHERE id IN ";
$SQL .= "(SELECT id_profw FROM controlcenter.profile WHERE id IN (SELECT id_pro FROM ";
$SQL .= "controlcenter.user WHERE id = '$USER'))";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSN001F"));
$DATA_USER = mysql_fetch_array($RS);

$_SESSION['MAXNUMLINE'] = trim(addslashes($_POST['maxnumberline']));
$_SESSION['FIELD1'] = trim(addslashes($_POST['field1']));
$_SESSION['FIELD2'] = trim(addslashes($_POST['field2']));
$_SESSION['FIELD3'] = trim(addslashes($_POST['field3']));
$_SESSION['FIELD4'] = trim(addslashes($_POST['field4']));
$_SESSION['FIELD5'] = trim(addslashes($_POST['field5']));
$TIMEREFRESH = trim(addslashes($_POST['timeupdatepage']));

if (empty($_SESSION['MAXNUMLINE'])) {
	$_SESSION['MAXNUMLINE'] = 100;
}

if ((empty($_POST['timeupdatepage']))&&(empty($_SESSION['TIMEUPDATE']))){
	$_SESSION['TIMEUPDATE'] = 5;
} elseif (!empty($_POST['timeupdatepage'])){
	$_SESSION['TIMEUPDATE'] = $_POST['timeupdatepage'];
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo $TITLE_FW; ?></title>
<script language="JavaScript" type="text/javascript">
var thispage = "monitor_fw.php";
</script>
<link href="../../includes/style_cc.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="main_full_monitor"> <!--Main-->
<?php
if ($DATA_USER['create_net'] == 1) {

// Load the user selected
$SQL = "SELECT * FROM cc_firewall.network_address WHERE id = '$ITEMID'";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSN002F"));
if((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1)){
		auditor('IFWSN002S', $ADDRIP, $USER, '0');
}
$ARRAY = mysql_fetch_array($RS);
?>
<!--Start add-->
<form class="insert_border" action="<?php echo $DESTINATION_PAGE;?>" method="post">
<div class="title_general_fw" > <?php echo $T_MONITOR; ?></div>
<div id="contet_rigth_data">
<div align="right" class="left_name"><u><?php echo $F_FIELD;?>1:</u></div>
	<div> <input type="text" size="20" maxlength="20" name="field1"  value="<?php if(!empty($_SESSION['FIELD1'])) { echo $_SESSION['FIELD1'];} ?>" /></div>
<div align="right" class="left_name"><u><?php echo $F_FIELD;?>2:</u></div>
	<div> <input type="text" size="20" maxlength="20" name="field2"  value="<?php if(!empty($_SESSION['FIELD2'])) { echo $_SESSION['FIELD2'];} ?>" /></div>
<div align="right" class="left_name"><u><?php echo $F_FIELD;?>3:</u></div>
	<div> <input type="text" size="20" maxlength="20" name="field3"  value="<?php if(!empty($_SESSION['FIELD3'])) { echo $_SESSION['FIELD3'];} ?>" /></div>
<div align="right" class="left_name"><u><?php echo $F_FIELD;?>4:</u></div>
	<div> <input type="text" size="20" maxlength="20" name="field4"  value="<?php if(!empty($_SESSION['FIELD4'])) { echo $_SESSION['FIELD4'];} ?>" /></div>
<div align="right" class="left_name"><u><?php echo $F_FIELD;?>5:</u></div>
	<div> <input type="text" size="20" maxlength="20" name="field5"  value="<?php if(!empty($_SESSION['FIELD5'])) { echo $_SESSION['FIELD5'];} ?>" /></div>
<div align="right" class="left_name"><u><?php echo $F_MAX_LINE;?></u></div>
	<div> <input type="text" size="5" maxlength="5" name="maxnumberline"  value="<?php if(!empty($_SESSION['MAXNUMLINE'])) { echo $_SESSION['MAXNUMLINE'];}else{echo '100';} ?>" /></div>
<div align="right" class="left_name"><u><?php echo $F_TIME_REFRESH;?></u></div>
	<div> <input type="text" size="5" maxlength="4" name="timeupdatepage"  value="<?php if(!empty($_SESSION['TIMEUPDATE'])) { echo $_SESSION['TIMEUPDATE'];}else {echo '5';} ?>" /> s</div>

	</div>
	<div id="contet_rigth_img">
	<img src="../../@img/icons/log-128x128.png" />
	</div>
<div class="title_general_fw">		
	<input type="submit" value="<?php echo $B_FILTER;?>" />
	<input type="button" value="<?php echo $B_CLEAR;?>" onclick="javascript:window.location=thispage" />
</div>
</form>
<!--End add-->

<!-- Start list-->

<div class="title_general_fw"><?php echo $T_MONITOR_TRAFIC;?></div>
<iframe src ="monitor_show_log_fw.php" width="795" height="250" scrolling="no">
</iframe>
<?php 
}?>
<div class="version_general">
<?php
echo $VERSIONCC;
?>

</div>
</body>
</html>