<?php 
require_once('../../includes/control_session.php');

$DESTINATION_PAGE = "network_run_fw.php";
$THISPAGE = "network_fw.php";
$_SESSION['FILE_LANG'] = "firewall.php";

// Load the profile of user autenticanted
$USER = $_SESSION['USER'];
$SQL = "SELECT create_net, read_net FROM controlcenter.profilefw WHERE id IN ";
$SQL .= "(SELECT id_profw FROM controlcenter.profile WHERE id IN (SELECT id_pro FROM ";
$SQL .= "controlcenter.user WHERE id = '$USER'))";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSN001F"));
$DATA_USER = mysql_fetch_array($RS);

// Load the item selected
if (!empty($_POST['list']))
{
	$_SESSION['ITEMID'] = $_POST['list'];
	$ITEMID = $_SESSION['ITEMID'];
} else {
	$ITEMID = $_SESSION['ITEMID'];
}
$_SESSION['ITEMDELETE'] = $ITEMID;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $TITLE_FW; ?></title>
<script language="javascript">
var thispage = "network_fw.php";
var deletepage = "network_delete_fw.php";
</script>
<link href="../../includes/style_cc.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php 
require_once('../../includes/top.php');
require_once('fw_menu.php');
?>
<script language="javascript">
function confirmDeleteSelected()
{
	document.getElementById('background_transparent').style.display="inline";
	document.getElementById('box_delete').style.display="table";	
}
function yesdeleteSelected()
{
	window.location=deletepage;
}
function nodeleteSelected()
{
	document.getElementById('box_delete').style.display="none";
	document.getElementById('background_transparent').style.display="none";
}
function clickBackgroudTrabsparent()
{
	nodeleteSelected();
}
</script>
<div id="background_transparent" onclick="javascript:clickBackgroudTrabsparent();"></div>
<div id="box_delete"><?php echo("$S_WANT_DELETE?");?> 
	<div class="space_confirm_box">
		<input type="button" value="<?php echo $B_YES;?>" onclick="javascript:yesdeleteSelected();" />
		<input type="button" value="<?php echo $B_NO;?>" onclick="javascript:nodeleteSelected();" />
	</div>	
</div>
<div id="main"> <!--Main-->
<?php require_once('fw_menu_configuration.php');?>

	<div id="contet_rigth">
<?php
if ($DATA_USER['create_net'] == 1) {

// Load the user selected
$SQL = "SELECT * FROM cc_firewall.network_address WHERE id = '$ITEMID'";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSN002F"));
if((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1)){
		auditor('IFWSN002S', $ADDRIP, $USER, '0');
}
$ARRAY = mysql_fetch_array($RS);

$SQL = "SELECT * from controlcenter.interface WHERE id in (SELECT id FROM  cc_firewall.network_address WHERE id = '$ITEMID')";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSN003F"));
$OTHER = mysql_fetch_array($RS);
?>
<!--Start add-->
<form class="insert_border" action="<?php echo $DESTINATION_PAGE;?>" method="post">
<input type="hidden" name="id" value="<?php echo $ARRAY['id'];?>" />
<input type="hidden" name="id_face" value="<?php echo $OTHER['id'];?>" />
<div class="title_general_fw" > <?php echo $T_NETWORK; ?> </div>
<div id="contet_rigth_data">
<div align="right" class="left_name"><u><?php echo $F_NAME;?></u></div>
	<div> <input type="text" size="20" maxlength="20" name="name"  value="<?php if(!empty($_SESSION['EX_NAME'])) { echo $_SESSION['EX_NAME'];} else { echo $ARRAY['name'];}?>" autocomplete="off"/></div>
	
<div align="right" class="left_name"><?php echo $F_DESCRIPTION;?></div>
	<div> <input type="text" size="20" maxlength="100" name="description"  value="<?php if(!empty($_SESSION['EX_DESCRIPTION'])) { echo $_SESSION['EX_DESCRIPTION'];} else { echo $ARRAY['description'];}?>" autocomplete="off"/></div>

<div align="right" class="left_name"><u><?php echo $F_CLASS;?></u></div>
	<div> <input type="text" size="20" maxlength="18" name="class" value="<?php if(!empty($_SESSION['EX_CLASS'])) { echo $_SESSION['EX_CLASS'];} else { echo $ARRAY['ip'];}?>" autocomplete="off"/></div>
<div align="right" class="left_name"><?php echo $F_MASK;?></div>
	<div> <input type="text" size="20" maxlength="18" name="mask" value="<?php if(!empty($_SESSION['EX_MASK'])) { echo $_SESSION['EX_MASK'];} else { echo $ARRAY['mask'];}?>" autocomplete="off"/></div>
<div align="right" class="left_name"><?php echo $F_TYPE;?></div>
	<div> 
	<select name="localglobal">
	<?php
		$selglobal = "";
		$sellocal = "";

		if (($ARRAY['global'] == '1') || ($_SESSION['GLOBAL'] == '1')){
			$selglobal = 'selected="selected"'; 
		} else {
			$sellocal = 'selected="selected"';
		}?>
		<option> </option>
		<option <?php echo $sellocal;?> value="0" style="background:<?php echo $COLOR_LINE_SELECT;?>"><?php echo $F_LOCAL;?></option>
		<option <?php echo $selglobal;?> value="1"><?php echo $F_GLOBAL;?></option>
	</select>
	</div>
	</div>
	<div id="contet_rigth_img">
	<img src="../../@img/icons/globe-Vista-128x128.png" />
	</div>
<div class="title_general_fw">		
	<input type="submit" value="<?php if (empty($ARRAY['id'])){ echo $B_ADD_NEW;} else { echo $B_UPDATE;}?>" />
	<input type="button" value="<?php echo $B_CLEAR;?>" onclick="javascript:window.location=thispage" />
	<?php
	if (($DATA_USER['create_net'] == 1)&&($DATA_USER['read_net'] == 1)){?>
	<input type="button" value="<?php echo $B_DELETE;?>" onClick="javascript:confirmDeleteSelected();" />
	<?php 
	}?>
</div>
</form>
<!--End add-->
<?php }
if ($DATA_USER['read_net'] == 1) {
?>
<!-- Start list-->

<div class="title_general_fw"><?php echo $T_NETWORK_LIST;?></div>
<form class="insert_border" action="<?php echo $THISPAGE;?>" method="post" name="objselect">
<select class="select_list" name="list" size="20" ondblclick="javascript:document.objselect.submit()">
<?php
$SQL = "SELECT id, name, ip, mask FROM cc_firewall.network_address ORDER BY name";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSN007F"));
$ARRAY = mysql_fetch_array($RS);
$cor = 1;	
do{
	if ($ITEMID == $ARRAY['id']) {
		$sel = 'selected="selected"';
	} else {
			$sel = "";
	}
	
	if ($ARRAY['mask'] == "") {
		$NET_ADDRESS = $ARRAY['ip'];
	} else {
		$NET_ADDRESS = $ARRAY['ip']."/".$ARRAY['mask'];
	}
	?>
	<option value="<?php echo $ARRAY['id'];?>" <?php echo $sel; if ( $cor == 1 ){$cor=0;} else {$cor=1; echo "style=\"background: $COLOR_LINE_SELECT;\"";}?> ><?php echo $ARRAY['name']." - ".$NET_ADDRESS; ?></option>
	<?php
}while ($ARRAY =  mysql_fetch_array($RS));
?>
</select>
</form>
	</div>
<?php 
}?>
<div class="version_general">
<?php
echo $VERSIONCC;
?>
</div>

</div>
</body>
</html>
<?php
unset($_SESSION['ITEMID']);
unset($_SESSION['EX_NAME']);
unset($_SESSION['EX_CLASS']);
unset($_SESSION['EX_MASK']);
unset($_SESSION['EX_POSITIONFW']);
unset($_SESSION['EX_DESCRIPTION']);
unset($_SESSION['GLOBAL']);
?>