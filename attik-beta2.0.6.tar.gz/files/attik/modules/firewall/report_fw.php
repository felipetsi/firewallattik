<?php 
require_once('../../includes/control_session.php');
$_SESSION['FILE_LANG'] = "firewall.php";
// Load the profile of user autenticanted
$SQL = "SELECT read_report FROM controlcenter.profilefw WHERE id IN ";
$SQL .= "(SELECT id_profw FROM controlcenter.profile WHERE id IN (SELECT id_pro FROM ";
$SQL .= "controlcenter.user WHERE id = '$USER'))";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSE001F"));
$DATA_USER = mysql_fetch_array($RS);

//Function to set date
function setDate()
{
	// Set the current day 
	$DAY = (date("d")-1);
	$DATESEL = ($DAY."-".date("m-Y"));
	$_SESSION['DATESEL'] = $DATESEL;
}

//Select the type of report
$REPORT = $_POST['type_report'];
if (empty($REPORT))
{
	if (empty($_SESSION['REPORT']))
	{
		$REPORT = "service";
		$_SESSION['REPORT'] = $REPORT;		
	}
	else
	{
		$REPORT = $_SESSION['REPORT'];
	}

}
else
{
	$_SESSION['REPORT'] = $REPORT;
	setDate();
}

$DATESEL = $_POST['date_report'];
if ((empty($DATESEL)) && (empty($_SESSION['DATESEL'])))
{
	setDate();
}
else
{
	if (empty($DATESEL))
	{
		if (empty($_SESSION['DATESEL']))
		{
			$_SESSION['DATESEL'] = $DATESEL;
		}
		else
		{
			$DATESEL = $_SESSION['DATESEL'];
		}
	}
	else
	{
		$_SESSION['DATESEL'] = $DATESEL;
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $TITLE_FW; ?></title>
<link href="../../includes/style_cc.css" rel="stylesheet" type="text/css" />
<link href="style_firewall_rule.css" rel="stylesheet" type="text/css" />
<link href="style_firewall_report.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php require_once('../../includes/top.php');
require_once('../../lang/'.$LANG.'/firewall_report.php');
require_once('fw_menu.php'); 
if ($DATA_USER['read_report'] == 1)
{
	require_once('fw_menu_report.php'); 
}?>

<div id="main"> <!--Main-->
<?php
if ($DATA_USER['read_report'] == 1)
{?>
	<div class="title_general">
		<?php
		switch ($REPORT){
			case "service": {
				echo $T_GRAPH_OF_SERVICE; 
				$TYPE_REPORT = "graphservice_$DATESEL.php";
				break;}
			case "protocol": {
				echo $T_GRAPH_OF_PROTOCOL; 
				$TYPE_REPORT = "graphprotocol_$DATESEL.php";
				break;}
		}?>
	</div>
<div class="title_report">
<?php
$COMMAND = "ls $ROOT_DIR/modules/firewall/graph/$TYPE_REPORT";
exec($COMMAND,$RESULT);
if (!empty($RETURN) && ($LOG_AUDITOR == 1))
{
	auditor('IFWCE002S', $ADDRIP, $USER, '0');
}
if (sizeof($RESULT) != 0)
{
	$CONTROL = 1;
	echo $REPORT_DAILY;?>
	<br />
	<?php
	echo $REPORT_SERVICE;
}?>
</div>
	<?php require_once('fw_menu_report_day.php');
if ($CONTROL == 1)
{?>

	<div id="contet_rigth_report">
	<?php
	echo ("$REFERENCEGRAPH: $DATESEL");
	?><br /><?php
	require_once('graph/.lib/.graph_object.php');
	open_flash_chart_object( 500, 250, 'http://'. $_SERVER['SERVER_NAME'] ."/attik/modules/firewall/graph/$TYPE_REPORT", false );?>

	</div><?php
}
?>

	
	<div class="version_general">
	<?php
	echo $VERSIONCC;
	?>
	</div>
</div>
</body>
</html>
<?php
unset($CONTROL);
}
?>