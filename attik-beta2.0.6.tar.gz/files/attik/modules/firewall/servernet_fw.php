<?php 
require_once('../../includes/control_session.php');

$DESTINATION_PAGE = "servernet_run_fw.php";
$THISPAGE = "servernet_fw.php";
$_SESSION['FILE_LANG'] = "firewall.php";

// Load the profile of user autenticanted
$SQL = "SELECT create_net, read_net FROM controlcenter.profilefw WHERE id IN ";
$SQL .= "(SELECT id_profw FROM controlcenter.profile WHERE id IN (SELECT id_pro FROM ";
$SQL .= "controlcenter.user WHERE id = '$USER'))";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSS001F"));
$DATA_USER = mysql_fetch_array($RS);

// Load the item selected
if (!empty($_POST['list']))
{
	$_SESSION['ITEMID'] = $_POST['list'];
	$ITEMID = $_SESSION['ITEMID'];
} else {
	$ITEMID = $_SESSION['ITEMID'];
}
$_SESSION['ITEMDELETE'] = $ITEMID;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $TITLE_FW; ?></title>
<script language="javascript">
var thispage = "servernet_fw.php";
var deletepage = "servernet_delete_fw.php";
</script>
<link href="../../includes/style_cc.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php 
require_once('../../includes/top.php');
require_once('fw_menu.php');
?>
<script language="javascript">
function confirmDeleteSelected()
{
	document.getElementById('box_delete').style.display="table";
}
function yesdeleteSelected()
{
	window.location=deletepage;
}
function nodeleteSelected()
{
	document.getElementById('box_delete').style.display="none";
}
</script>
<div id="box_delete"><?php echo("$S_WANT_DELETE?");?> 
	<div class="space_confirm_box">
		<input type="button" value="<?php echo $B_YES;?>" onclick="javascript:yesdeleteSelected();" />
		<input type="button" value="<?php echo $B_NO;?>" onclick="javascript:nodeleteSelected();" />
	</div>	
</div>

<div id="main"> <!--Main-->
<?php require_once('fw_menu_configuration.php');?>

	<div id="contet_rigth">
<?php
if ($DATA_USER['create_net'] == 1) {

// Load the user selected
$SQL = "SELECT * FROM cc_firewall.hostserver WHERE id = '$ITEMID'";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSS002F"));
if((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1)){
		auditor('IFWSS002S', $ADDRIP, $USER, '0');
}
$ARRAY = mysql_fetch_array($RS);
?>
<!--Start add-->
<form class="insert_border" action="<?php echo $DESTINATION_PAGE;?>" method="post" name="data" enctype="multipart/form-data">
<input type="hidden" name="id" value="<?php echo $ARRAY['id'];?>" />
<div class="title_general_fw" > <?php echo $T_SERVER; ?> </div>
<div id="contet_rigth_data">
<div align="right" class="left_name"><u><?php echo $F_NAME;?></u></div>
	<div> <input type="text" size="20" maxlength="100" name="name" value="<?php if(!empty($_SESSION['EX_NAME'])) { echo $_SESSION['EX_NAME'];} else { echo $ARRAY['name']; }?>" autocomplete="off"/></div>

<div align="right" class="left_name"><u><?php echo $F_NETWORK;?></u></div>
	<div>
	<select name="network">
	<option> </option>
<?php
$SQL = "SELECT id, name FROM cc_firewall.positionfw ORDER BY name";
$RS1 = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSS003F"));
$POSITIONFW = mysql_fetch_array($RS1);
do{
	$ID_POSITIONFW = $POSITIONFW['id'];
	$SQL = "SELECT id, name, class FROM cc_firewall.network WHERE id_pfw = '$ID_POSITIONFW' ORDER BY name";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSS004F"));
	$DATA = mysql_fetch_array($RS);
	if (!empty($DATA['id'])){?>
		<optgroup label="<?php echo $POSITIONFW['name'];?>"><?php
		$cor = 1;	
		do{
			if (($ARRAY['id_net'] == $DATA['id']) or ($_SESSION['EX_NET'] == $DATA['id'])) {
				$sel = 'selected="selected"';
			} else {
				$sel = "";
			}
		
			if ( $cor == 1 )
			{
				?>
				<option value="<?php echo $DATA['id'];?>" <?php echo $sel;?> ><?php echo ($DATA['name'].":".$DATA['class']); $cor=0?></option>
				<?php 
			} else { ?>
				<option style="background:<?php echo $COLOR_LINE_SELECT;?>" value="<?php echo $DATA['id'];?>" <?php echo $sel;?> ><?php echo ($DATA['name'].":".$DATA['class']); $cor=1;?></option>
				<?php
			} 
		}while ($DATA = mysql_fetch_array($RS));?>
		</optgroup><?php
	}
} while($POSITIONFW = mysql_fetch_array($RS1));?>
	</select></div>
<?php 
$ID_NET = $_SESSION['EX_NET'];
$SQL = "SELECT class FROM cc_firewall.network WHERE id = '$ID_NET'";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSS005F"));
$DATA = mysql_fetch_array($RS);
$CLASS_IP = $DATA['class'];
?>

<div align="right" class="left_name"><u><?php echo $F_IP;?></u></div>
	<div> <input type="text" size="20" maxlength="15" name="ip" value="<?php if (!empty($ITEMID)){echo $ARRAY['ip'];}elseif(!empty($_SESSION['EX_IP'])) { echo $_SESSION['EX_IP'];} else { echo $CLASS_IP;}?>" autocomplete="off"/></div>
	
<div align="right" class="left_name"><?php echo $F_MAC;?></div>
	<div> 
	  <input type="text"  size="20" maxlength="17" name="mac" value="<?php if (!empty($_SESSION['EX_MAC'])) { echo $_SESSION['EX_MAC'];} else { echo $ARRAY['mac'];}?>" autocomplete="off"/>
	  </div>

	</div><!--content data -->
	<div id="contet_rigth_img">

		<img src="<?php if (empty($ARRAY['img'])){ echo "@img/server/server.png";} else {echo $ARRAY['img'];}?>" />

	</div>
<div class="title_general_fw">
	<input type="submit" value="<?php if (empty($ARRAY['id'])){ echo $B_ADD_NEW; } else { echo $B_UPDATE;}?>" />
	<input type="button" value="<?php echo $B_CLEAR;?>" onclick="javascript:window.location=thispage" />
	<?php
	if (($DATA_USER['create_net'] == 1)&&($DATA_USER['read_net'] == 1)){?>
	<input type="button" value="<?php echo $B_DELETE;?>" onClick="javascript:confirmDeleteSelected();" />
	<?php
	}?>
</div>
</form>
<!--End add-->
<?php }
if ($DATA_USER['read_net'] == 1) {
?>
<!-- Start list-->
<div class="title_general_fw"><?php echo $T_SERVER_LIST;?></div>
<form class="insert_border" action="<?php echo $THISPAGE;?>" method="post" name="objselect">
<select class="select_list" name="list" size="20" onclick="javascript:document.objselect.submit()">
<?php
$SQL = "SELECT n.id, n.name, p.name as positionfw FROM cc_firewall.network n, cc_firewall.positionfw p ";
$SQL .= "WHERE p.id = n.id_pfw AND n.id in (SELECT id_net FROM cc_firewall.hostserver)";
$SQL .= "ORDER BY p.name, n.name ";
$RS1 = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSS006F"));
$OTHER = mysql_fetch_array($RS1);
do{
	if(!empty($OTHER['id'])) 
	{?>
		<optgroup label="<?php echo ($F_NETWORK.$OTHER['name']." - ".$OTHER['positionfw']);?>"><?php
			$ID_NET = $OTHER['id'];
			$SQL = "SELECT id, name FROM cc_firewall.hostserver WHERE id_net = '$ID_NET' ORDER BY name";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSS007F"));
			$ARRAY = mysql_fetch_array($RS);
			$cor = 1;	
			do{
			if ($ITEMID == $ARRAY['id']) {
				$sel = 'selected="selected"';
			} else {
					$sel = "";
			}
			
			if ( $cor == 1 )
				{
				?>
				<option value="<?php echo $ARRAY['id'];?>" <?php echo $sel;?> ><?php echo $ARRAY['name']; $cor=0?></option>
				<?php 
				} else { ?>
				<option style="background:<?php echo $COLOR_LINE_SELECT;?>" value="<?php echo $ARRAY['id'];?>" <?php echo $sel;?> ><?php echo $ARRAY['name']; $cor=1;?></option>
				<?php
				} 
			}while ($ARRAY =  mysql_fetch_array($RS));?>
		</optgroup><?php
	}
}while ($OTHER = mysql_fetch_array($RS1));?>
<?php
$SQL = "SELECT id, name FROM cc_firewall.hostserver WHERE id_net NOT IN(SELECT id FROM  cc_firewall.network)  ORDER BY name";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSS008F"));
$ARRAY = mysql_fetch_array($RS);
if (mysql_affected_rows() != 0)
{?>
<optgroup label="<?php echo $F_OUT_NETWORK;?>"><?php

	$cor = 1;
	do{
	if ($ITEMID == $ARRAY['id']) {
		$sel = 'selected="selected"';
	} else {
			$sel = "";
	}
	
	if ( $cor == 1 )
		{
		?>
		<option value="<?php echo $ARRAY['id'];?>" <?php echo $sel;?> ><?php echo $ARRAY['name']; $cor=0?></option>
		<?php 
		} else { ?>
		<option style="background:<?php echo $COLOR_LINE_SELECT;?>" value="<?php echo $ARRAY['id'];?>" <?php echo $sel;?> ><?php echo $ARRAY['name']; $cor=1;?></option><?php
		}
	}while ($ARRAY =  mysql_fetch_array($RS));
?>
</optgroup>
<?php
}?>
</select>
</form>
	</div>
<?php 
}?>
<div class="version_general">
<?php
echo $VERSIONCC;
?>
</div>

</div>
</body>
</html>
<?php
unset($_SESSION['ITEMID']);
unset($_SESSION['EX_NAME']);
unset($_SESSION['EX_IP']);
unset($_SESSION['EX_MAC']);
unset($_SESSION['EX_NET']);
?>