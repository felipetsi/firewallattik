<?php 
require_once('../../includes/control_session.php');
require_once('includes/variable_personal.php');
//Variable need becase various moment is use, including the top for change language
$THISPAGE = "general_personal_direction_fw.php";
$DESTINATION_PAGE = "general_personal_direction_run_fw.php";
$_SESSION['FILE_LANG'] = "firewall.php";

// Load the profile of user autenticanted
$SQL = "SELECT create_rule, read_rule FROM controlcenter.profilefw WHERE id IN ";
$SQL .= "(SELECT id_profw FROM controlcenter.profile WHERE id IN (SELECT id_pro FROM ";
$SQL .= "controlcenter.user WHERE id = '$USER'))";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG007F"));
$DATA_USER = mysql_fetch_array($RS);

// Load the item selected
if (!empty($_POST['list']))
{
	$_SESSION['ITEMID'] = $_POST['list'];
	$ITEMID = $_SESSION['ITEMID'];
} else {
	$ITEMID = $_SESSION['ITEMID'];
}
$_SESSION['ITEMDELETE'] = $ITEMID;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<script language="javascript">
var thispage = "general_personal_direction_fw.php";
var deletepage = "general_personal_direction_delete_fw.php";
</script>
<title><?php echo $TITLE_FW; ?></title>

<link href="../../includes/style_cc.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php 
require_once('../../includes/top.php');
require_once('fw_menu.php');
?>
<script language="javascript">
function confirmDeleteSelected()
{
	document.getElementById('background_transparent').style.display="inline";
	document.getElementById('box_delete').style.display="table";	
}
function yesdeleteSelected()
{
	window.location=deletepage;
}
function nodeleteSelected()
{
	document.getElementById('box_delete').style.display="none";
	document.getElementById('background_transparent').style.display="none";
}
function clickBackgroudTrabsparent()
{
	nodeleteSelected();
}
</script>
<div id="background_transparent" onclick="javascript:clickBackgroudTrabsparent();"></div>
<div id="box_delete"><?php echo("$S_WANT_DELETE?");?> 
	<div class="space_confirm_box">
		<input type="button" value="<?php echo $B_YES;?>" onclick="javascript:yesdeleteSelected();" />
		<input type="button" value="<?php echo $B_NO;?>" onclick="javascript:nodeleteSelected();" />
	</div>	
</div>
<div id="main"> <!--Main-->
<?php require_once('fw_menu_configuration.php');
require_once('fw_menu_conf_general.php'); ?>

<div id="contet_rigth"> <!-- Rigth -->
<?php
if (($DATA_USER['create_rule'] == 1)&&($DATA_USER['read_rule'] == 1)) {

// Load the user selected
$SQL = "SELECT id, name FROM cc_firewall.direction WHERE (id IN ";
$SQL .= "(SELECT id_dir FROM cc_firewall.tab_dir_act WHERE id_tab IN ";
$SQL .= "(SELECT id FROM cc_firewall.tablefw WHERE name = 'filter'))) AND " ;
$SQL .= "(name != 'INPUT' AND name != 'OUTPUT' AND name != 'FORWARD') AND ";
$SQL .= "id = '$ITEMID' ";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG008F"));
	//Auditor
	if ((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1))
	{
		auditor('IFWSG008S', $ADDRIP, $USER, '0');
	}
$ARRAY = mysql_fetch_array($RS);
?>
<!--Start add-->
<form class="insert_border" action="<?php echo $DESTINATION_PAGE;?>" method="post">
<input type="hidden" name="id" value="<?php echo $ARRAY['id'];?>" />
<div class="title_general_fw" > <?php echo $T_DIRECTION; ?> </div>
<div id="contet_rigth_data"><!-- content rigth -->

<div align="right" class="left_name"><u><?php echo $F_DIRECTION;?></u></div>
	<div> <input type="text" size="20" maxlength="10" name="direction" value="<?php if(!empty($_SESSION['EX_NAME'])) { echo $_SESSION['EX_NAME'];} else { echo $ARRAY['name']; }?>" autocomplete="off"/></div>

<div class="separate_line">
	<div align="right" class="left_name"><?php echo $F_CREATE_ALSO_ACTION;?></div>
	<div>
		<?php
		$SQL = "SELECT id FROM cc_firewall.action WHERE name IN (SELECT name FROM cc_firewall.direction ";
		$SQL .= "WHERE id = '$ITEMID' )";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG009F"));
		if ((mysql_affected_rows() != 0) || ($_SESSION['EX_ACT'] == 1))
		{
			$sel='checked="checked"';
		}
		else
		{
			$sel='';
		}
		?>
		<input type="checkbox"  name="create_action" value="1" <?php echo $sel;?> />
	</div>
</div>
</div><!-- content rigth -->
	<div id="contet_rigth_img">

		<img src="../../@img/icons/configuration-128x128.png" />	

	</div>

<div class="title_general_fw">
	<input type="submit" value="<?php if (empty($ARRAY['id'])){ echo $B_ADD_NEW;} else { echo $B_UPDATE;}?>" />
	<input type="button" value="<?php echo $B_CLEAR;?>" onclick="javascript:window.location=thispage" />
	<?php
	if (($DATA_USER['create_rule'] == 1)&&($DATA_USER['read_rule'] == 1)){?>
	<input type="button" value="<?php echo $B_DELETE;?>" onclick="javascript:confirmDeleteSelected();" />
	<?php 
	} ?>
</div>
</form>
<!--End add-->

<!-- Start list-->
<div class="title_general_fw"><?php echo $T_PERSONAL_DIRECTION_LIST;?></div>
<form class="insert_border" action="<?php echo $THISPAGE;?>" method="post" name="objselect">
<select class="select_list_1" name="list" size="20" onclick="javascript:document.objselect.submit()">
<?php
	$SQL = "SELECT id, name FROM cc_firewall.direction WHERE (id IN ";
	$SQL .= "(SELECT id_dir FROM cc_firewall.tab_dir_act WHERE id_tab IN ";
	$SQL .= "(SELECT id FROM cc_firewall.tablefw WHERE name = 'filter'))) AND " ;
	$SQL .= "(name != 'INPUT' AND name != 'OUTPUT' AND name != 'FORWARD') ";
	$SQL .= "ORDER BY name";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG010F"));
	$ARRAY = mysql_fetch_array($RS);
	$cor = 1;	
	do{
	if ($ITEMID == $ARRAY['id']) {
		$sel = 'selected="selected"';
	} else {
			$sel = "";
	}
	
	if ( $cor == 1 )
		{
		?>
		<option value="<?php echo $ARRAY['id'];?>" <?php echo $sel;?> ><?php echo $$ARRAY['name']; $cor=0?></option>
		<?php 
		} else { ?>
		<option style="background:<?php echo $COLOR_LINE_SELECT;?>" value="<?php echo $ARRAY['id'];?>" <?php echo $sel;?> ><?php echo $$ARRAY['name']; $cor=1;?></option>
		<?php
		} 
	}while ($ARRAY =  mysql_fetch_array($RS));?>
</select>
</form>
</div> <!-- Rigth -->
<?php 
} ?>
<div class="version_general">
<?php
echo $VERSIONCC;
?>
</div>

</div> <!--Main-->
</body>
</html>
<?php
unset($_SESSION['EX_NAME']);
unset($_SESSION['EX_ACT']);
unset($_SESSION['ITEMID']);
?>