<div id="menu_conf_sub">
<a href="general_conf_fw.php">
	<div class="button_gen">
		<img src="/controlcenter/@img/icons/direction-16x16.png" align="absmiddle"/>
		<?php echo $L_DEFAULT_POLICY;?>
	</div>
</a>
<a href="general_personal_direction_fw.php">
	<div class="button_gen">
		<img src="/controlcenter/@img/icons/rule-16x16.gif" align="absmiddle"/>	
		<?php echo $L_PERSONAL_CHAINS;?>
	</div>
</a>
<a href="general_attack_protection_fw.php">
	<div class="button_gen">
		<img src="/controlcenter/@img/icons/rule-16x16.gif" align="absmiddle"/>
		<?php echo $L_ATTACK_PROTECTION;?>
	</div>
</a>
</div>