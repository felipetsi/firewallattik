#!/bin/bash

# Home directory of attik pages
DIRHOMEPAGES="/var/www/attik"

export REPORTTYPE="graphprotocol"

$DIRHOMEPAGES/modules/firewall/.generate_history.sh
