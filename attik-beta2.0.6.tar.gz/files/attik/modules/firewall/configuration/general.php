<?php
//Quantity rule to show in list
$QUANTITY_RULE_SHOW = 50;
//Prefix to insert in LOG
$KEY_LOG = "\"Attik: \"";

?>