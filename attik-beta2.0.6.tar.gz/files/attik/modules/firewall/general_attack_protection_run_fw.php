<?php 
require_once('../../includes/control_session.php');
require_once('includes/functions.php');

$DESTINATION_PAGE = "general_attack_protection_fw.php";

$ID = trim(addslashes($_POST['id']));
$STATUS = $_POST['apply'];

$_SESSION['ITEMID'] = $ID;

if (empty($ID))  {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDFILL';
	$_SESSION['EX_STATUS'] = $STATUS;
	header("Location:$DESTINATION_PAGE");	
}
else {
	if (empty($STATUS))
	{
		$STATUS = 0;
	}
	else
	{
		$STATUS = 1;
	}
		// Update the BD
		$SQL = "UPDATE cc_firewall.attack SET status='$STATUS' WHERE id = '$ID'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUG043F"));

		// Select the name
		$SQL = "SELECT name FROM cc_firewall.attack WHERE id = '$ID'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG044F"));
		$ARRAY = mysql_fetch_array($RS);
		$ATTACK = $ARRAY['name'];
		
		if ($STATUS == 1)
		{
			// Create the rule of protection of attack
			createRule($ATTACK);
		}
		else
		{
			// Remove the rule created with this protection to attack
			removeRule($ATTACK);
		}
			
		if (mysql_affected_rows() != 0) {
			//Auditor
			if ((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1))
			{
				auditor('IFWSG045S', $ADDRIP, $USER, '0');
			}
			$_SESSION['SHOW_MSG'] = 'F_SUCESS';
		} else {
			//Auditor
			if ((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1))
			{
				auditor('IFWSG045F', $ADDRIP, $USER, '0');
			}
			$_SESSION['SHOW_MSG'] = 'F_FAILURE';
		}
		header("Location:$DESTINATION_PAGE");
}
?>