<?php 
require_once('../../includes/control_session.php');

//Variable need becase various moment is use, including the top for change language
$THISPAGE = "general_attack_protection_fw.php";
$DESTINATION_PAGE = "general_attack_protection_run_fw.php";
$_SESSION['FILE_LANG'] = "firewall.php";

// Load the profile of user autenticanted
$SQL = "SELECT create_rule, read_rule FROM controlcenter.profilefw WHERE id IN ";
$SQL .= "(SELECT id_profw FROM controlcenter.profile WHERE id IN (SELECT id_pro FROM ";
$SQL .= "controlcenter.user WHERE id = '$USER'))";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG040F"));
$DATA_USER = mysql_fetch_array($RS);

// Load the item selected
if (!empty($_POST['list']))
{
	$_SESSION['ITEMID'] = $_POST['list'];
	$ITEMID = $_SESSION['ITEMID'];
} else {
	$ITEMID = $_SESSION['ITEMID'];
}
$_SESSION['ITEMDELETE'] = $ITEMID;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<?php
echo '
<script language="javascript">
	var thispage = "'.$THISPAGE.'";
</script>' ?>
<title><?php echo $TITLE_FW; ?></title>

<link href="../../includes/style_cc.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php 
require_once('../../includes/top.php');
require_once('../../lang/'.$LANG.'/firewall_attack.php');
require_once('fw_menu.php');
?>
<div id="main"> <!--Main-->
<?php require_once('fw_menu_configuration.php');
require_once('fw_menu_conf_general.php'); ?>


<div id="contet_rigth"> <!-- Rigth -->
<?php
if (($DATA_USER['create_rule'] == 1) && ($DATA_USER['read_rule'] == 1)) {

// Load the user selected
$SQL = "SELECT * FROM cc_firewall.attack WHERE id = '$ITEMID'";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG041F"));
	//Auditor
	if ((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1))
	{
		auditor('IFWSG041S', $ADDRIP, $USER, '0');
	}
$ARRAY = mysql_fetch_array($RS);
?>
<!--Start add-->
<form class="insert_border" action="<?php echo $DESTINATION_PAGE;?>" method="post">
<input type="hidden" name="id" value="<?php echo $ARRAY['id'];?>" />
<div class="title_general_fw" > <?php echo $T_ATTACK_PROTECTION; ?> </div>
<div id="contet_rigth_data">

	<div class="separate_line">
		<div align="right" class="left_name"><u><?php echo $F_ATTACK;?></u></div>
		<div class="title_option"><?php echo $$ARRAY['name']; ?></div>
	</div>
	
	<div class="separate_line">
		<div align="right" class="left_name"><?php echo $F_APPLY;?></div>
		<div> 
		<?php
			if (($ARRAY['status'] == '1') || ($_SESSION['EX_STATUS'] == '1')) {
				$sel = 'checked="checked"';
			} else {
					$sel = "";
			}?>
			<input type="checkbox" name="apply" <?php echo $sel;?> value="1" />
		</div>
	</div>

	<div class="separate_line">
		<div align="right" class="left_name"><u><?php echo $F_DESCRIPTION;?></u></div>
		<div> 
			<textarea name="description" cols="20" rows="3"><?php echo $$ARRAY['description'];?></textarea>
		</div>
	</div>

</div>
	<div id="contet_rigth_img">

		<img src="../../@img/icons/configuration-128x128.png" />	

	</div>	

<div class="title_general_fw">		
	<input type="submit" value="<?php if (empty($ARRAY['id'])){ echo $B_ADD_NEW;} else { echo $B_UPDATE;}?>" />
	<input type="button" value="<?php echo $B_CLEAR;?>" onclick="javascript:window.location=thispage" />
</div>
</form>
<!--End add-->

<!-- Start list-->
<div class="title_general_fw"><?php echo $T_DIRECTION_LIST;?></div>
<form class="insert_border" action="<?php echo $THISPAGE;?>" method="post" name="objselect">
<select class="select_list_1" name="list" size="20" onclick="javascript:document.objselect.submit()">
<?php
	$SQL = "SELECT id, name FROM cc_firewall.attack ORDER BY name";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG042F"));
	$ARRAY = mysql_fetch_array($RS);
	$cor = 1;	
	do{
	if ($ITEMID == $ARRAY['id']) {
		$sel = 'selected="selected"';
	} else {
			$sel = "";
	}
	
	if ( $cor == 1 )
		{
		?>
		<option value="<?php echo $ARRAY['id'];?>" <?php echo $sel;?> ><?php echo $$ARRAY['name']; $cor=0?></option>
		<?php 
		} else { ?>
		<option style="background:<?php echo $COLOR_LINE_SELECT;?>" value="<?php echo $ARRAY['id'];?>" <?php echo $sel;?> ><?php echo $$ARRAY['name']; $cor=1;?></option>
		<?php
		} 
	}while ($ARRAY =  mysql_fetch_array($RS));?>
</select>
</form>
</div> <!-- Rigth -->
<?php 
}?>
<div class="version_general">
<?php
echo $VERSIONCC;
?>
</div>

</div> <!--Main-->

</body>
</html>
<?php
unset($_SESSION['EX_STATUS']);
unset($_SESSION['ITEMID']);
?>