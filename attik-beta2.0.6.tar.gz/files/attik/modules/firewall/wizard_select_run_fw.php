<?php
require_once('../../includes/control_session.php');
require_once('includes/functions.php');

$THISPAGE = "wizard_select_run_fw.php";
$DESTINATION_PAGE = "wizard_select_fw.php";
$IPTABLES = "/sbin/iptables";
$_SESSION['FILE_LANG'] = "firewall.php";
$USER = $_SESSION['USER'];

// Esta vari�vel ir� conter a tabela do iptables, se ela estiver v�zia � porque n�o veio de uma p�gina que configura redirecionamento, nat ou mangle, ent�o a tabela filter � assumida por padr�o.
$FWTABLE = $_POST['fwtable'];
if (empty($FWTABLE)){
	$FWTABLE = "filter";
}

$PROTOCOL = $_POST['protocol'];

$ID_SNET = $_SESSION['ID_O'];
$ID_DNET = $_SESSION['ID_I'];
$S_MULTIPORT_PORT = '1024:65535';
$DATE_NOW = date('Y-m-d H:i:s');
$ACTION = "ACCEPT";

//Verify if is net between server or net between net. If variable session equals 1, is net between server.
$SQL = "SELECT id, ip, mask FROM cc_firewall.network_address WHERE id = '$ID_SNET'";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB005F"));
$ARRAY = mysql_fetch_array($RS);
if (!empty($ARRAY['mask'])){
	$SNET = $ARRAY['ip']."/".$ARRAY['mask'];
} else {
	$SNET = $ARRAY['ip'];
}	
$SQL = "SELECT id, ip, mask FROM cc_firewall.network_address WHERE id = '$ID_DNET'";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB006F"));
$ARRAY = mysql_fetch_array($RS);
if (!empty($ARRAY['mask'])){
	$DNET = $ARRAY['ip']."/".$ARRAY['mask'];
} else {
	$DNET = $ARRAY['ip'];
}	

//Select the attributes of module state for insert in rules in flow the go
$SQL = "SELECT id FROM cc_firewall.atribute_module WHERE (name = 'NEW' OR name = 'ESTABLISHED' ";
$SQL .= "OR name = 'RELATED') AND id_mod IN (SELECT id FROM cc_firewall.module WHERE definitive='1')";
$RSS_GO = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB015F"));
$STATE_GO = mysql_fetch_array($RSS_GO);

//Select the attributes of module state for insert in rules in flow the back
$SQL = "SELECT id FROM cc_firewall.atribute_module WHERE (name = 'ESTABLISHED' ";
$SQL .= "OR name = 'RELATED') AND id_mod IN (SELECT id FROM cc_firewall.module WHERE definitive='1')";
$RSS_BACK = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB016F"));
$STATE_BACK = mysql_fetch_array($RSS_BACK);

//Select the Action, Direction and Table
if (empty($_SESSION['WIZARD_TO_FW'])){
	$DIRECTION = "FORWARD";
	$SQL = "SELECT id FROM cc_firewall.tab_dir_act WHERE ";
	$SQL .= "id_tab IN (SELECT id FROM cc_firewall.tablefw WHERE name = 'filter') ";
	$SQL .= "AND id_dir IN (SELECT id FROM cc_firewall.direction WHERE name = '$DIRECTION') ";
	$SQL .= "AND id_act IN (SELECT id FROM cc_firewall.action WHERE name = '$ACTION')";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB017F"));
	$ARRAY = mysql_fetch_array($RS);
	$ID_TAB_DIR_ACT1 = $ARRAY['id'];
}else{
	$SQL = "SELECT id FROM cc_firewall.tab_dir_act WHERE ";
	$SQL .= "id_tab IN (SELECT id FROM cc_firewall.tablefw WHERE name = 'filter') ";
	$SQL .= "AND id_dir IN (SELECT id FROM cc_firewall.direction WHERE name = 'INPUT') ";
	$SQL .= "AND id_act IN (SELECT id FROM cc_firewall.action WHERE name = '$ACTION')";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB018F"));
	$ARRAY = mysql_fetch_array($RS);
	//Store with direction to input
	$ID_TAB_DIR_ACT1 = $ARRAY['id'];
	
	$SQL = "SELECT id FROM cc_firewall.tab_dir_act WHERE ";
	$SQL .= "id_tab IN (SELECT id FROM cc_firewall.tablefw WHERE name = 'filter') ";
	$SQL .= "AND id_dir IN (SELECT id FROM cc_firewall.direction WHERE name = 'OUTPUT') ";
	$SQL .= "AND id_act IN (SELECT id FROM cc_firewall.action WHERE name = '$ACTION')";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB019F"));
	$ARRAY = mysql_fetch_array($RS);
	//Store with direction to output
	$ID_TAB_DIR_ACT2 = $ARRAY['id'];
}
$MSTATE = "";

for ($F = 0; $F < (sizeof($PROTOCOL)); $F++)
	{
		$ARRAY = explode("@",$PROTOCOL[$F]);
		$ID_D_PORT = trim(addslashes($ARRAY[0]));
		$PROTO = trim(addslashes($ARRAY[1]));
		
		// Flow in
		$SQL = "INSERT INTO cc_firewall.rulefw (";
		$SQL .= "id_pro, command, id_tab_dir_act, id_user, date_created, last_update, ";
		$SQL .= "use_assistant, status, applied) VALUES (";
		$SQL .="'$PROTO', 'A', '$ID_TAB_DIR_ACT1', '$USER', '$DATE_NOW', '$DATE_NOW', '1', '1', '0' )";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIB020F"));
		//Insert the module state to rule
		$ID_RULE = mysql_insert_id();
		
		$SQL = "INSERT INTO cc_firewall.rul_net (id_rul, id_net, position) VALUES ";
		$SQL .= "('$ID_RULE', '$SNET', 's')";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIB007F"));
		
		$SQL = "INSERT INTO cc_firewall.rul_net (id_rul, id_net, position) VALUES ";
		$SQL .= "('$ID_RULE', '$DNET', 'd')";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB008F"));
		
		$SQL = "INSERT INTO cc_firewall.rule_app (id_rul, id_app, position) VALUES ";
		$SQL .= "('$ID_RULE', '$ID_D_PORT', 'd')";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIB007F"));
		
		// Flow back
		$SQL = "INSERT INTO cc_firewall.rulefw (";
		$SQL .= "id_pro, command, id_tab_dir_act, id_user, date_created, last_update, ";
		$SQL .= "use_assistant, status, applied) VALUES (";
		$SQL .="'$PROTO', 'A', '$ID_TAB_DIR_ACT1', '$USER', '$DATE_NOW', '$DATE_NOW', '1', '1', '0' )";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIB020F"));
		//Insert the module state to rule
		$ID_RULE = mysql_insert_id();
		
		$SQL = "INSERT INTO cc_firewall.rul_net (id_rul, id_net, position) VALUES ";
		$SQL .= "('$ID_RULE', '$SNET', 'd')";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIB007F"));
		
		$SQL = "INSERT INTO cc_firewall.rul_net (id_rul, id_net, position) VALUES ";
		$SQL .= "('$ID_RULE', '$DNET', 's')";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB008F"));
		
		$SQL = "INSERT INTO cc_firewall.rule_app (id_rul, id_app, position) VALUES ";
		$SQL .= "('$ID_RULE', '$ID_D_PORT', 's')";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIB007F"));
		
		do
		{
				$ID_ATR = $STATE_GO['id'];
				$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
				$SQL .= "('$ID_RULE', '$ID_ATR')";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIB021F"));
				
				$SQL = "SELECT name FROM cc_firewall.atribute_module WHERE id = '$ID_ATR'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIB021F"));
				$ARRAY = mysql_fetch_array($RS);
		}while($STATE_GO = mysql_fetch_array($RSS_GO));
			

		$SQL = "SELECT name FROM cc_firewall.protocol WHERE id = '$PROTO'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR057F"));
		$ARRAY = mysql_fetch_array($RS);
		$PROTODESCRIPTION = $ARRAY['name'];
		$SQL = "SELECT port FROM cc_firewall.application WHERE id = '$ID_D_PORT'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR057F"));
		$ARRAY = mysql_fetch_array($RS);
		$D_PORT = $ARRAY['port'];
		// Flow in
		// Mount the rule in one line
		$RULE = "-t $FWTABLE -A $DIRECTION ";
		if (!empty($SNET)){ $RULE .= "-s $SNET ";}
		if (!empty($DNET)){ $RULE .= "-d $DNET ";}
		if (!empty($PROTODESCRIPTION)){ $RULE .= "-p $PROTODESCRIPTION --dport $D_PORT ";}
		$RULE .= "-m state --state NEW,ESTABLISHED,RELATED ";
		if (!empty($ACTION)){ $RULE .= "-j $ACTION ";}
		// Insert the rule in table to execute
		$SQL = "INSERT INTO cc_firewall.rulefwrun (id, name) VALUES ('$ID_RULE', '$RULE')";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR055F"));
		
		// Flow back
		// Mount the rule in one line
		$RULE = "-t $FWTABLE -A $DIRECTION ";
		if (!empty($SNET)){ $RULE .= "-d $SNET ";}
		if (!empty($DNET)){ $RULE .= "-s $DNET ";}
		if (!empty($PROTODESCRIPTION)){ $RULE .= "-p $PROTODESCRIPTION --sport $D_PORT ";}
		$RULE .= "-m state --state ESTABLISHED,RELATED ";
		if (!empty($ACTION)){ $RULE .= "-j $ACTION ";}
		// Insert the rule in table to execute
		$SQL = "INSERT INTO cc_firewall.rulefwrun (id, name) VALUES ('$ID_RULE', '$RULE')";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR055F"));
		needApply('1');
	}
	

header("Location: $DESTINATION_PAGE");
?>