<?php 
require_once('../../includes/control_session.php');

//Variable need becase various moment is use, including the top for change language
$THISPAGE = "general_conf_fw.php";
$DESTINATION_PAGE = "general_conf_run_fw.php";
$_SESSION['FILE_LANG'] = "firewall.php";

// Load the profile of user autenticanted
$SQL = "SELECT create_rule, read_rule FROM controlcenter.profilefw WHERE id IN ";
$SQL .= "(SELECT id_profw FROM controlcenter.profile WHERE id IN (SELECT id_pro FROM ";
$SQL .= "controlcenter.user WHERE id = '$USER'))";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG001F"));
$DATA_USER = mysql_fetch_array($RS);

// Load the item selected
if (!empty($_POST['list']))
{
	$_SESSION['ITEMID'] = $_POST['list'];
	$ITEMID = $_SESSION['ITEMID'];
} else {
	$ITEMID = $_SESSION['ITEMID'];
}
$_SESSION['ITEMDELETE'] = $ITEMID;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<script language="javascript">
var thispage = "general_conf_fw.php";
</script>
<title><?php echo $TITLE_FW; ?></title>

<link href="../../includes/style_cc.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php 
require_once('../../includes/top.php');
require_once('fw_menu.php');
?>
<div id="main"> <!--Main-->
<?php require_once('fw_menu_configuration.php');
require_once('fw_menu_conf_general.php'); ?>


<div id="contet_rigth"> <!-- Rigth -->
<?php
if (($DATA_USER['create_rule'] == 1)&&($DATA_USER['read_rule'] == 1)) {

// Load the user selected
$SQL = "SELECT p.id, p.id_act, d.name as direction, ac.name as action FROM cc_firewall.action ac, cc_firewall.direction d, ";
$SQL .= "cc_firewall.policyfw p WHERE d.id = '$ITEMID' AND p.id_dir = d.id AND ac.id = p.id_act";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG002F"));
	//Auditor
	if ((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1))
	{
		auditor('IFWSG002S', $ADDRIP, $USER, '0');
	}
$ARRAY = mysql_fetch_array($RS);
?>
<!--Start add-->
<form class="insert_border" action="<?php echo $DESTINATION_PAGE;?>" method="post">
<input type="hidden" name="id" value="<?php echo $ARRAY['id'];?>" />
<div class="title_general_fw" > <?php echo $T_POLICY_DIRECTION; ?> </div>
<div id="contet_rigth_data">

<div align="right" class="left_name"><u><?php echo $F_DIRECTION;?></u></div>
	<div class="title_option"><?php echo $$ARRAY['direction']; ?></div>

<div class="separate_line">
<div align="right" class="left_name"><u><?php echo $F_ACTION;?></u></div>
	<div> <select name="action">
	<?php
		if (!empty($ITEMID)){
			$SQL = "SELECT id, name FROM cc_firewall.action WHERE in_policy = '1' ORDER BY name";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG003F"));
			$DATA = mysql_fetch_array($RS);
			$cor = 1;	
			do{
			if (($ARRAY['id_act'] == $DATA['id']) or ($_SESSION['EX_ACTION'] == $DATA['id'])) {
				$sel = 'selected="selected"';
			} else {
					$sel = "";
			}
		
			if ( $cor == 1 )
			{
				?>
				<option value="<?php echo $DATA['id'];?>" <?php echo $sel;?> ><?php echo ($$DATA['name']); $cor=0?></option>
				<?php 
			} else { ?>
				<option style="background:<?php echo $COLOR_LINE_SELECT;?>" value="<?php echo $DATA['id'];?>" <?php echo $sel;?> ><?php echo ($$DATA['name']); $cor=1;?></option>
				<?php
			} 
		}while ($DATA =  mysql_fetch_array($RS));
	}?>
	</select></div>
	</div>
</div>
	<div id="contet_rigth_img">

		<img src="../../@img/icons/configuration-128x128.png" />	

	</div>	

<div class="title_general_fw">		
	<input type="submit" value="<?php echo $B_UPDATE;?>" />
	<input type="button" value="<?php echo $B_CLEAR;?>" onclick="javascript:window.location=thispage" />
</div>
</form>
<!--End add-->

<!-- Start list-->
<div class="title_general_fw"><?php echo $T_DIRECTION_LIST;?></div>
<form class="insert_border" action="<?php echo $THISPAGE;?>" method="post" name="objselect">
<select class="select_list_1" name="list" size="20" onclick="javascript:document.objselect.submit()">
<?php
	$SQL = "SELECT id, name FROM cc_firewall.direction WHERE ";
	$SQL .= "have_policy = '1' ORDER BY name";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG004F"));
	$ARRAY = mysql_fetch_array($RS);
	$cor = 1;	
	do{
	if ($ITEMID == $ARRAY['id']) {
		$sel = 'selected="selected"';
	} else {
			$sel = "";
	}?>
	
	<option value="<?php echo $ARRAY['id'];?>" <?php echo $sel; if ( $cor == 1 ){$cor=0;} else {$cor=1; echo "style=\"background: $COLOR_LINE_SELECT;\"";}?> ><?php echo $$ARRAY['name']; ?></option>
		<?php 
	}while ($ARRAY =  mysql_fetch_array($RS));?>
</select>
</form>
</div><!-- Rigth -->
<?php 
}?>

<div class="version_general">
<?php
echo $VERSIONCC;
?>
</div>

</div> <!--Main-->

</body>
</html>
<?php
unset($_SESSION['EX_ACTION']);
unset($_SESSION['ITEMID']);
?>