<?php 
require_once('../../includes/control_session.php');

//require_once('../../includes/functions.php');

$DESTINATION_PAGE = "servernet_fw.php";

$ID = trim(addslashes($_POST['id']));
$NAME = substr(trim(addslashes($_POST['name'])),0,100);
$IP = substr(trim(addslashes($_POST['ip'])),0,15);
$MAC = replaceMAC(substr(strtoupper(trim(addslashes($_POST['mac']))),0,17));
$ID_NET = substr(trim(addslashes($_POST['network'])),0,2);

if ((empty($NAME)) || (empty($IP)) || (empty($ID_NET))) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDFILL';
	$_SESSION['ITEMID'] = $ID;
	$_SESSION['EX_NAME'] = $NAME;
	$_SESSION['EX_IP'] = $IP;
	$_SESSION['EX_MAC'] = $MAC;
	$_SESSION['EX_NET'] = $ID_NET;
	header("Location:$DESTINATION_PAGE");	
}
elseif((verifyIp($IP) != "ok")||(eregi("[^0-9./]", $IP, $regs))){
	$_SESSION['SHOW_MSG'] = 'ME_INVALIDIP';
	$_SESSION['ITEMID'] = $ID;
	$_SESSION['EX_NAME'] = $NAME;
	$_SESSION['EX_IP'] = $IP;
	$_SESSION['EX_MAC'] = $MAC;
	$_SESSION['EX_NET'] = $ID_NET;
	header("Location:$DESTINATION_PAGE");
}
elseif(($MAC != "") && (verifyMAC($MAC) != "ok")){
	$_SESSION['SHOW_MSG'] = 'ME_INVALIDMAC';
	$_SESSION['ITEMID'] = $ID;
	$_SESSION['EX_NAME'] = $NAME;
	$_SESSION['EX_IP'] = $IP;
	$_SESSION['EX_MAC'] = $MAC;
	$_SESSION['EX_NET'] = $ID_NET;
	header("Location:$DESTINATION_PAGE");
}
else {
	$SQL = "SELECT * FROM cc_firewall.hostserver WHERE (name = '$NAME' OR ip = '$IP')";
	$SQL .= "AND id != '$ID'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSS009F"));
	if ( mysql_affected_rows() !=0 )
	{
		if($LOG_AUDITOR == 1){
			auditor('IFWSS009F', $ADDRIP, $USER, $NAME);
		}
		$_SESSION['SHOW_MSG'] = 'ME_NAMEORIPEXIST';
		$_SESSION['ITEMID'] = $ID;
		$_SESSION['EX_NAME'] = $NAME;
		$_SESSION['EX_IP'] = $IP;
		$_SESSION['EX_MAC'] = $MAC;
		$_SESSION['EX_NET'] = $ID_NET;
		header("Location:$DESTINATION_PAGE");
	}
	else {
	
		if (empty($ID)) {
				
				$SQL = "INSERT INTO cc_firewall.hostserver (name, ip, mac, id_net)"; 
				$SQL .= "VALUES ('$NAME', '$IP', '$MAC', '$ID_NET')";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIS010F"));
		}
		else {
				$SQL = "UPDATE cc_firewall.hostserver SET name='$NAME', ip='$IP', mac='$MAC', ";
				$SQL .= "id_net='$ID_NET' WHERE id = '$ID'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUS011F"));
		}
		if (mysql_affected_rows() != 0) {
			if($LOG_AUDITOR == 1){
				auditor('IFWXS012S', $ADDRIP, $USER, '0');
			}
			$_SESSION['SHOW_MSG'] = 'F_SUCESS';
		} else {
			if($LOG_AUDITOR == 1){
				auditor('IFWXS012F', $ADDRIP, $USER, '0');
			}
			$_SESSION['SHOW_MSG'] = 'F_FAILURE';
		}		
		header("Location:$DESTINATION_PAGE");
	}
}

?>