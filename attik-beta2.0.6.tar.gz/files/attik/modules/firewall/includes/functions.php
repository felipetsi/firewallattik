<?php
require_once('../../includes/control_session.php');
	
// Create protection
function createRule($attack)
{
	//Load the user autenticated
	$USER = $_SESSION['USER'];
	//Date and Hour current
	$DATE_NOW = date('Y-m-d H:i:s');
	//Select the associated beteween Table, Direction and Action
	$SQL = "SELECT id FROM cc_firewall.tab_dir_act WHERE ";
	$SQL .= "id_tab IN (SELECT id FROM cc_firewall.tablefw WHERE name = 'filter') AND ";
	$SQL .= "id_dir IN (SELECT id FROM cc_firewall.direction WHERE name = 'FORWARD') AND ";
	$SQL .= "id_act IN (SELECT id FROM cc_firewall.action WHERE name = 'DROP')";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG046F"));
	$ARRAY = mysql_fetch_array($RS);
	$ID_TAB_DIR_ACT = $ARRAY['id'];
	
	// Load the protocol tcp	
	$SQL = "SELECT id FROM cc_firewall.protocol WHERE name = 'tcp'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG047F"));
	$ARRAY = mysql_fetch_array($RS);
	$PROTOTCP = $ARRAY['id'];
	// Load the protocol udp
	$SQL = "SELECT id FROM cc_firewall.protocol WHERE name = 'udp'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG048F"));
	$ARRAY = mysql_fetch_array($RS);
	$PROTOUDP = $ARRAY['id'];
	
	//Load the defult variables
	$TABLE = "filter";
	$COMMANDADD = "A";
	$DIRECTION = "FORWARD";
	$ACTION = "DROP";
	
	switch ($attack) {
		case "Multicast":
			$SQL = "INSERT INTO cc_firewall.rulefw (s_address, id_tab_dir_act, id_user, ";
			$SQL .= "date_created, last_update, commentfw, use_assistant, command, status)";
			$SQL .= "VALUES ('224.0.0.0/8', '$ID_TAB_DIR_ACT', '$USER', '$DATE_NOW', '$DATE_NOW', ";
			$SQL .= "'Multicast', '1', 'A', '1')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG049F"));
			$ID_RULE = mysql_insert_id();
			$RULE[0] = "$ID_RULE@-t $TABLE -$COMMANDADD $DIRECTION -s 224.0.0.0/8 -j $ACTION";
			
			$SQL = "INSERT INTO cc_firewall.rulefw (d_address, id_tab_dir_act, id_user, ";
			$SQL .= "date_created, last_update, commentfw, use_assistant, command, status)";
			$SQL .= "VALUES ('224.0.0.0/8', '$ID_TAB_DIR_ACT', '$USER', '$DATE_NOW', '$DATE_NOW', ";
			$SQL .= "'Multicast', '1', 'A', '1')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG050F"));
			$ID_RULE = mysql_insert_id();
			$RULE[1] = "$ID_RULE@-t $TABLE -$COMMANDADD $DIRECTION -d 224.0.0.0/8 -j $ACTION";
			break;
		case "BackOrifice":
			$SQL = "INSERT INTO cc_firewall.rulefw (id_pro, d_port, id_tab_dir_act, id_user, ";
			$SQL .= "date_created, last_update, commentfw, use_assistant, command, status) ";
			$SQL .= "VALUES ('$PROTOTCP', '31337', '$ID_TAB_DIR_ACT', '$USER', '$DATE_NOW', '$DATE_NOW', ";
			$SQL .= "'Back Orifice', '1', 'A', '1')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG051F"));
			$ID_RULE = mysql_insert_id();
			$RULE[0] = "$ID_RULE@-t $TABLE -$COMMANDADD $DIRECTION -p tcp --dport 31337 -j $ACTION";
						
			$SQL = "INSERT INTO cc_firewall.rulefw (id_pro, d_port, id_tab_dir_act, id_user, ";
			$SQL .= "date_created, last_update, commentfw, use_assistant, command, status) ";
			$SQL .= "VALUES ('$PROTOUDP', '31337', '$ID_TAB_DIR_ACT', '$USER', '$DATE_NOW', '$DATE_NOW', ";
			$SQL .= "'Back Orifice', '1', 'A', '1')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG052F"));
			$ID_RULE = mysql_insert_id();
			$RULE[1] = "$ID_RULE@-t $TABLE -$COMMANDADD $DIRECTION -p udp --dport 31337 -j $ACTION";
			break;
		case "Netbus":
			$SQL = "INSERT INTO cc_firewall.rulefw (id_pro, id_tab_dir_act, id_user, ";
			$SQL .= "date_created, last_update, commentfw, use_assistant, command, status) ";
			$SQL .= "VALUES ('$PROTOTCP', '$ID_TAB_DIR_ACT', '$USER', '$DATE_NOW', '$DATE_NOW', ";
			$SQL .= "'NetBus', '1', 'A', '1')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG053F"));
			$ID_RULE = mysql_insert_id();
			//Insert the module smultipor
			$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'dmultiport'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG054F"));
			$ARRAY = mysql_fetch_array($RS);
			$ID_MOD = $ARRAY['id'];
			$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
			$SQL .= "('$ID_MOD' ,'12345:12346')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG055F"));
			$ID_ATR = mysql_insert_id();
			$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ('$ID_RULE', '$ID_ATR')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG056F"));
			$RULE[0] = "$ID_RULE@-t $TABLE -$COMMANDADD $DIRECTION -p tcp -m multiport --dport 12345:12346 -j $ACTION";
					
			$SQL = "INSERT INTO cc_firewall.rulefw (id_pro, id_tab_dir_act, id_user, ";
			$SQL .= "date_created, last_update, commentfw, use_assistant, command, status) ";
			$SQL .= "VALUES ('$PROTOUDP', '$ID_TAB_DIR_ACT', '$USER', '$DATE_NOW', '$DATE_NOW', ";
			$SQL .= "'NetBus', '1', 'A', '1')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG057F"));
			$ID_RULE = mysql_insert_id();
			//Insert the module smultipor
			$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'dmultiport'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG058F"));
			$ARRAY = mysql_fetch_array($RS);
			$ID_MOD = $ARRAY['id'];
			$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
			$SQL .= "('$ID_MOD' ,'12345:12346')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG059F"));
			$ID_ATR = mysql_insert_id();
			$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ('$ID_RULE', '$ID_ATR')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG060F"));
			$RULE[1] = "$ID_RULE@-t $TABLE -$COMMANDADD $DIRECTION -p udp -m multiport --dport 12345:12346 -j $ACTION";
			break;
		case "Trin00":
			$SQL = "INSERT INTO cc_firewall.rulefw (id_pro, id_tab_dir_act, id_user, ";
			$SQL .= "date_created, last_update, commentfw, use_assistant, command, status) ";
			$SQL .= "VALUES ('$PROTOTCP', '$ID_TAB_DIR_ACT', '$USER', '$DATE_NOW', '$DATE_NOW', ";
			$SQL .= "'NetBus', '1', 'A', '1')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG061F"));
			$ID_RULE = mysql_insert_id();
			//Insert the module smultipor
			$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'dmultiport'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG062F"));
			$ARRAY = mysql_fetch_array($RS);
			$ID_MOD = $ARRAY['id'];
			$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
			$SQL .= "('$ID_MOD', '1524,27665')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG063F"));
			$ID_ATR = mysql_insert_id();
			$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ('$ID_RULE', '$ID_ATR')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG064F"));
			$RULE[0] = "$ID_RULE@-t $TABLE -$COMMANDADD $DIRECTION -p tcp -m multiport --dport 1524,27665 -j $ACTION";
					
			$SQL = "INSERT INTO cc_firewall.rulefw (id_pro, id_tab_dir_act, id_user, ";
			$SQL .= "date_created, last_update, commentfw, use_assistant, command, status) ";
			$SQL .= "VALUES ('$PROTOUDP', '$ID_TAB_DIR_ACT', '$USER', '$DATE_NOW', '$DATE_NOW', ";
			$SQL .= "'NetBus', '1', 'A', '1')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG065F"));
			$ID_RULE = mysql_insert_id();
			//Insert the module smultipor
			$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'dmultiport'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG066F"));
			$ARRAY = mysql_fetch_array($RS);
			$ID_MOD = $ARRAY['id'];
			$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
			$SQL .= "('$ID_MOD', '1524,27665')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG067F"));
			$ID_ATR = mysql_insert_id();
			$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ('$ID_RULE', '$ID_ATR')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG068F"));
			$RULE[1] = "$ID_RULE@-t $TABLE -$COMMANDADD $DIRECTION -p udp -m multiport --dport 1524,27665 -j $ACTION";
			break;
		case "TraceRoute":
			$SQL = "INSERT INTO cc_firewall.rulefw (id_pro, id_tab_dir_act, id_user, ";
			$SQL .= "date_created, last_update, commentfw, use_assistant, command, status) ";
			$SQL .= "VALUES ('$PROTOUDP', '$ID_TAB_DIR_ACT', '$USER', '$DATE_NOW', '$DATE_NOW', ";
			$SQL .= "'Trace Route', '1', 'A', '1')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG069F"));
			$ID_RULE = mysql_insert_id();
			//Insert the module smultipor
			$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'dmultiport'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG070F"));
			$ARRAY = mysql_fetch_array($RS);
			$ID_MOD = $ARRAY['id'];
			$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
			$SQL .= "('$ID_MOD' ,'33435:33525')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG071F"));
			$ID_ATR = mysql_insert_id();
			$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ('$ID_RULE', '$ID_ATR')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG072F"));
			$RULE[0] = "$ID_RULE@-t $TABLE -$COMMANDADD $DIRECTION -p udp -m multiport --dport 33435:33525 -j $ACTION";
			break;
		case "cmd":		
			$SQL = "INSERT INTO cc_firewall.rulefw (id_pro, id_tab_dir_act, id_user, ";
			$SQL .= "date_created, last_update, commentfw, use_assistant, command, status) ";
			$SQL .= "VALUES ('$PROTOTCP', '$ID_TAB_DIR_ACT', '$USER', '$DATE_NOW', '$DATE_NOW', ";
			$SQL .= "'CMD.EXE', '1', 'A', '1')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG073F"));
			$ID_RULE = mysql_insert_id();
			//Insert the module string
			$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'string'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG074F"));
			$ARRAY = mysql_fetch_array($RS);
			$ID_MOD = $ARRAY['id'];
			$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
			$SQL .= "('$ID_MOD' ,'cmd.exe')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG075F"));
			$ID_ATR = mysql_insert_id();
			$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ('$ID_RULE', '$ID_ATR')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG076F"));
			$RULE[0] = "$ID_RULE@-t $TABLE -$COMMANDADD $DIRECTION -p tcp -m string --algo bm --string ".'"cmd.exe"'." -j $ACTION";
			
			$SQL = "INSERT INTO cc_firewall.rulefw (id_pro, id_tab_dir_act, id_user, ";
			$SQL .= "date_created, last_update, commentfw, use_assistant, command, status) ";
			$SQL .= "VALUES ('$PROTOUDP', '$ID_TAB_DIR_ACT', '$USER', '$DATE_NOW', '$DATE_NOW', ";
			$SQL .= "'CMD.EXE', '1', 'A', '1')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG077F"));
			$ID_RULE = mysql_insert_id();
			//Insert the module smultipor
			$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'string'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG078F"));
			$ARRAY = mysql_fetch_array($RS);
			$ID_MOD = $ARRAY['id'];
			$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
			$SQL .= "('$ID_MOD' ,'cmd.exe')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG079F"));
			$ID_ATR = mysql_insert_id();
			$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ('$ID_RULE', '$ID_ATR')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG080F"));
			$RULE[1] = "$ID_RULE@-t $TABLE -$COMMANDADD $DIRECTION -p udp -m string --algo bm --string ".'"cmd.exe"'." -j $ACTION";
			break;
	}
	for($f=0; $f < sizeof($RULE); $f++) {
		$RULERUN = $RULE[$f];
		$RULEARRAY = explode("@",$RULERUN);
		$RULEID = $RULEARRAY[0];
		$RULEDATA = $RULEARRAY[1];
		// Insert the rule in table to execute
		$SQL = "INSERT INTO cc_firewall.rulefwrun (id, name) VALUES ('$RULEID', '$RULEDATA')";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG118F"));
	}
}
// Remove protection
function removeRule($attack)
{
	//Load the user autenticated
	$USER = $_SESSION['USER'];
	//Date and Hour current
	$DATE_NOW = date('Y-m-d H:i:s');
	//Select the associated beteween Table, Direction and Action
	$SQL = "SELECT id FROM cc_firewall.tab_dir_act WHERE ";
	$SQL .= "id_tab IN (SELECT id FROM cc_firewall.tablefw WHERE name = 'filter') AND ";
	$SQL .= "id_dir IN (SELECT id FROM cc_firewall.direction WHERE name = 'FORWARD') AND ";
	$SQL .= "id_act IN (SELECT id FROM cc_firewall.action WHERE name = 'DROP')";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIG081F"));
	$ARRAY = mysql_fetch_array($RS);
	$ID_TAB_DIR_ACT = $ARRAY['id'];
	
	// Load the protocol tcp	
	$SQL = "SELECT id FROM cc_firewall.protocol WHERE name = 'tcp'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG082F"));
	$ARRAY = mysql_fetch_array($RS);
	$PROTOTCP = $ARRAY['id'];
	// Load the protocol udp
	$SQL = "SELECT id FROM cc_firewall.protocol WHERE name = 'udp'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG083F"));
	$ARRAY = mysql_fetch_array($RS);
	$PROTOUDP = $ARRAY['id'];
	
	switch ($attack) {
		case "Multicast":
			$SQL = "DELETE FROM cc_firewall.rulefw WHERE s_address='224.0.0.0/8' AND id_tab_dir_act='$ID_TAB_DIR_ACT'AND ";
			$SQL .= "use_assistant='1'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG084F"));
			
			$SQL = "DELETE FROM cc_firewall.rulefw WHERE d_address='224.0.0.0/8' AND id_tab_dir_act='$ID_TAB_DIR_ACT' AND ";
			$SQL .= "use_assistant='1'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG085F"));
			break;
		case "BackOrifice":
			
			$SQL = "DELETE FROM cc_firewall.rulefw WHERE id_pro='$PROTOTCP' AND d_port='31337' AND ";
			$SQL .= "id_tab_dir_act='$ID_TAB_DIR_ACT' AND use_assistant='1'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG086F"));

			$SQL = "DELETE FROM cc_firewall.rulefw WHERE id_pro='$PROTOUDP' AND d_port='31337' AND ";
			$SQL .= "id_tab_dir_act='$ID_TAB_DIR_ACT' AND use_assistant='1'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG087F"));
			break;
		case "Netbus":	
			$SQL = "SELECT id FROM cc_firewall.rulefw WHERE id_pro='$PROTOTCP' AND id_tab_dir_act='$ID_TAB_DIR_ACT' AND ";
			$SQL .= "use_assistant=1 AND id IN (SELECT id_rul FROM cc_firewall.rul_atr WHERE id_atr IN ";
			$SQL .= "(SELECT id FROM cc_firewall.atribute_module WHERE name='12345:12346'))";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG088F"));
			$ARRAY = mysql_fetch_array($RS);
			$ID_RULE = $ARRAY['id'];
			//Delete the module smultipor
			if (mysql_affected_rows() != 0)
			{					
				$SQL = "DELETE FROM cc_firewall.atribute_module WHERE ";
				$SQL .= "id IN (SELECT id_atr FROM cc_firewall.rul_atr WHERE id_rul='$ID_RULE')";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG089F"));

				$SQL = "DELETE FROM cc_firewall.rul_atr WHERE id_rul='$ID_RULE'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG090F"));
				
				$SQL = "DELETE FROM cc_firewall.rulefw WHERE id='$ID_RULE'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG091F"));
			}

			$SQL = "SELECT id FROM cc_firewall.rulefw WHERE id_pro='$PROTOUDP' AND id_tab_dir_act='$ID_TAB_DIR_ACT' AND ";
			$SQL .= "use_assistant=1 AND id IN (SELECT id_rul FROM cc_firewall.rul_atr WHERE id_atr IN ";
			$SQL .= "(SELECT id FROM cc_firewall.atribute_module WHERE name='12345:12346'))";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG092F"));
			$ARRAY = mysql_fetch_array($RS);
			$ID_RULE = $ARRAY['id'];
			//Delete the module smultipor
			if (mysql_affected_rows() != 0)
			{
								
				$SQL = "DELETE FROM cc_firewall.atribute_module WHERE ";
				$SQL .= "id IN (SELECT id_atr FROM cc_firewall.rul_atr WHERE id_rul='$ID_RULE')";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG093F"));

				$SQL = "DELETE FROM cc_firewall.rul_atr WHERE id_rul='$ID_RULE'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG094F"));
				
				$SQL = "DELETE FROM cc_firewall.rulefw WHERE id='$ID_RULE'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG095F"));
			}
			break;
		case "Trin00":
			$SQL = "SELECT id FROM cc_firewall.rulefw WHERE id_pro='$PROTOTCP' AND id_tab_dir_act='$ID_TAB_DIR_ACT' AND ";
			$SQL .= "use_assistant=1 AND id IN (SELECT id_rul FROM cc_firewall.rul_atr WHERE id_atr IN ";
			$SQL .= "(SELECT id FROM cc_firewall.atribute_module WHERE name='1524,27665'))";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG096F"));
			$ARRAY = mysql_fetch_array($RS);
			$ID_RULE = $ARRAY['id'];
			//Delete the module smultipor
			if (mysql_affected_rows() != 0)
			{					
				$SQL = "DELETE FROM cc_firewall.atribute_module WHERE ";
				$SQL .= "id IN (SELECT id_atr FROM cc_firewall.rul_atr WHERE id_rul='$ID_RULE')";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG097F"));

				$SQL = "DELETE FROM cc_firewall.rul_atr WHERE id_rul='$ID_RULE'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG098F"));
				
				$SQL = "DELETE FROM cc_firewall.rulefw WHERE id='$ID_RULE'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG099F"));
			}
			

			$SQL = "SELECT id FROM cc_firewall.rulefw WHERE id_pro='$PROTOUDP' AND id_tab_dir_act='$ID_TAB_DIR_ACT' AND ";
			$SQL .= "use_assistant=1 AND id IN (SELECT id_rul FROM cc_firewall.rul_atr WHERE id_atr IN ";
			$SQL .= "(SELECT id FROM cc_firewall.atribute_module WHERE name='1524,27665'))";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG100F"));
			$ARRAY = mysql_fetch_array($RS);
			$ID_RULE = $ARRAY['id'];
			//Delete the module smultipor
			if (mysql_affected_rows() != 0)
			{					
				$SQL = "DELETE FROM cc_firewall.atribute_module WHERE ";
				$SQL .= "id IN (SELECT id_atr FROM cc_firewall.rul_atr WHERE id_rul='$ID_RULE')";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG101F"));

				$SQL = "DELETE FROM cc_firewall.rul_atr WHERE id_rul='$ID_RULE'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG102F"));
				
				$SQL = "DELETE FROM cc_firewall.rulefw WHERE id='$ID_RULE'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG103F"));
			}
			break;
		case "TraceRoute":
			$SQL = "SELECT id FROM cc_firewall.rulefw WHERE id_pro='$PROTOUDP' AND id_tab_dir_act='$ID_TAB_DIR_ACT' AND ";
			$SQL .= "use_assistant=1 AND id IN (SELECT id_rul FROM cc_firewall.rul_atr WHERE id_atr IN ";
			$SQL .= "(SELECT id FROM cc_firewall.atribute_module WHERE name='33435:33525'))";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG104F"));
			$ARRAY = mysql_fetch_array($RS);
			$ID_RULE = $ARRAY['id'];
			//Delete the module smultipor
			if (mysql_affected_rows() != 0)
			{					
				$SQL = "DELETE FROM cc_firewall.atribute_module WHERE ";
				$SQL .= "id IN (SELECT id_atr FROM cc_firewall.rul_atr WHERE id_rul='$ID_RULE')";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG105F"));

				$SQL = "DELETE FROM cc_firewall.rul_atr WHERE id_rul='$ID_RULE'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG106F"));
				
				$SQL = "DELETE FROM cc_firewall.rulefw WHERE id='$ID_RULE'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG107F"));
			}
			break;
		case "cmd":
			$SQL = "SELECT id FROM cc_firewall.rulefw WHERE id_pro='$PROTOTCP' AND id_tab_dir_act='$ID_TAB_DIR_ACT' AND ";
			$SQL .= "use_assistant=1 AND id IN (SELECT id_rul FROM cc_firewall.rul_atr WHERE id_atr IN ";
			$SQL .= "(SELECT id FROM cc_firewall.atribute_module WHERE name='cmd.exe'))";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG108F"));
			$ARRAY = mysql_fetch_array($RS);
			$ID_RULE = $ARRAY['id'];
			//Delete the module smultipor
			if (mysql_affected_rows() != 0)
			{					
				$SQL = "DELETE FROM cc_firewall.atribute_module WHERE ";
				$SQL .= "id IN (SELECT id_atr FROM cc_firewall.rul_atr WHERE id_rul='$ID_RULE')";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG109F"));

				$SQL = "DELETE FROM cc_firewall.rul_atr WHERE id_rul='$ID_RULE'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG110F"));
				
				$SQL = "DELETE FROM cc_firewall.rulefw WHERE id='$ID_RULE'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG111F"));
			}
			
			$SQL = "SELECT id FROM cc_firewall.rulefw WHERE id_pro='$PROTOUDP' AND id_tab_dir_act='$ID_TAB_DIR_ACT' AND ";
			$SQL .= "use_assistant=1 AND id IN (SELECT id_rul FROM cc_firewall.rul_atr WHERE id_atr IN ";
			$SQL .= "(SELECT id FROM cc_firewall.atribute_module WHERE name='cmd.exe'))";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG112F"));
			$ARRAY = mysql_fetch_array($RS);
			$ID_RULE = $ARRAY['id'];
			//Delete the module smultipor
			if (mysql_affected_rows() != 0)
			{					
				$SQL = "DELETE FROM cc_firewall.atribute_module WHERE ";
				$SQL .= "id IN (SELECT id_atr FROM cc_firewall.rul_atr WHERE id_rul='$ID_RULE')";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG113F"));

				$SQL = "DELETE FROM cc_firewall.rul_atr WHERE id_rul='$ID_RULE'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG114F"));
				
				$SQL = "DELETE FROM cc_firewall.rulefw WHERE id='$ID_RULE'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG115F"));
			}
			break;
	}
	$SQL = "DELETE FROM cc_firewall.rulefwrun WHERE id NOT IN (SELECT id FROM cc_firewall.rulefw)";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG119F"));
}
function alterDefaultPolicy($act,$dir)
{
	if($act == "DROP")
	{
		if($dir != "FORWARD")
		{
			$COMMAND = "sudo iptables -L $dir -n | grep 127.0.0.1";
			exec($COMMAND,$RETURN);
			if(empty($RETURN)) {
				$COMMAND = "sudo iptables -A $dir ";
				if ($dir == "INPUT") {$COMMAND .= "-d 127.0.0.1 -j ACCEPT";}
				elseif ($dir == "OUTPUT") {$COMMAND .= "-s 127.0.0.1 -j ACCEPT";}
				exec($COMMAND,$RETURN);
			}
			$HTTPPORT="2880";
			$COMMAND = "sudo iptables -L $dir -n | grep pt:$HTTPPORT";
			exec($COMMAND,$RETURN);
			if(empty($RETURN)) {
				$COMMAND = "sudo iptables -A $dir ";
				if ($dir == "INPUT") {$COMMAND .= "-p tcp --dport $HTTPPORT -j ACCEPT";}
				elseif ($dir == "OUTPUT") {$COMMAND .= "-p tcp --sport $HTTPPORT -j ACCEPT";}
				exec($COMMAND,$RETURN);
			}
		}
	}
	$COMMAND = "sudo iptables -P $dir $act";
	exec($COMMAND,$RETURN);
/*	if (!empty($RETURN))
"ok";	{
		return "invalid";
	} else{
		return 
	}*/
}
function needApply($namevalue){
	$SQL = "UPDATE cc_firewall.needapply SET name = '$namevalue'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDG120F"));
}
function SyncronizeRules(){
	require_once('configuration/general.php');
	needApply('1');
	// Count the number of rules in table before
	$SQL = "SELECT id FROM cc_firewall.rulefwrun";
	$RS = mysql_query($SQL);
	$COUNT_RULE_BEFORE = mysql_affected_rows();
	// Clear the table of run rules
	$SQL = "TRUNCATE TABLE cc_firewall.rulefwrun";
	$RS = mysql_query($SQL);
	// Max port in one rule
	$MAXPORTNUMBER = 15;
	$SQL = "SELECT DISTINCT r.id,r.command,r.s_iface_condition,r.d_iface_condition,r.source_condition,r.destination_condition, ";
	$SQL .= "r.sport_condition,r.dport_condition,r.proto_condition,r.mac_condition,r.string_condition,r.state_condition, ";
	$SQL .= "r.status,r.id_s_iface,r.id_d_iface,r.id_pro,t.name as tablefw,d.name as direction, a.name as action_fw ";
	$SQL .= "FROM cc_firewall.rulefw r, controlcenter.interface i, cc_firewall.protocol p, cc_firewall.tablefw t, ";
	$SQL .= "cc_firewall.direction d, cc_firewall.action a WHERE ";
	$SQL .= "t.id IN (SELECT id_tab FROM cc_firewall.tab_dir_act WHERE r.id_tab_dir_act = id) AND ";
	$SQL .= "d.id IN (SELECT id_dir FROM cc_firewall.tab_dir_act WHERE r.id_tab_dir_act = id) AND ";
	$SQL .= "a.id IN (SELECT id_act FROM cc_firewall.tab_dir_act WHERE r.id_tab_dir_act = id) AND r.command != 'S' ";
	$RSRULE = mysql_query($SQL);
	$RULEFW = mysql_fetch_array($RSRULE);
	do {
		$IDRULELOOP = $RULEFW['id'];
		// Outher query
		$SQL = "SELECT port FROM cc_firewall.application WHERE ";
		$SQL .= "id IN (SELECT id_app FROM cc_firewall.rule_app WHERE id_rul = '$IDRULELOOP' ";
		$SQL .= "AND position = 's')";
		$RS = mysql_query($SQL);
		$ARRAY = mysql_fetch_array($RS);
		unset($SPORT);
		$f = 0;
		do {
			$SPORT[$f] = $ARRAY['port'];
			$f++;
		}while($ARRAY = mysql_fetch_array($RS));
		// Max port in one rule
		$MAXPORTNUMBER = 15;
		$APP_RANGE_S = 0;
		$APP_RANGE_D = 0;
		$LENGARRAY = sizeof($SPORT);
		//Clear the arrays
		unset($SPORTNUMBERARRAY);
		unset($DPORTNUMBERARRAY);
		$k = 0;
		// Number of port of application multiple 15
		$APP_RANGE_S = ceil($LENGARRAY/$MAXPORTNUMBER);
		for($p = 1; $p <= $APP_RANGE_S; $p++){
			for($f = 0; (($k < $LENGARRAY)&&($f < $MAXPORTNUMBER)); $f++){
				$LEGNPORTAPP = sizeof(explode(":",$SPORT[$k]));
				if($LEGNPORTAPP > 1){
					$APP_RANGE_S++;
					$f = $MAXPORTNUMBER;
					$SPORTNUMBERARRAY[sizeof($SPORTNUMBERARRAY)] = $SPORT[$k];
				} else {
					if(($LENGARRAY > 1)&&($f > 0)) {
						$SPORTNUMBERARRAY[$p-1] = $SPORT[$k].",".$SPORTNUMBERARRAY[$p-1];
					} else {
						$SPORTNUMBERARRAY[sizeof($SPORTNUMBERARRAY)] = $SPORT[$k];
					}
				}
				$k++;
			}
		}
		//
		$SQL = "SELECT port FROM cc_firewall.application WHERE ";
		$SQL .= "id IN (SELECT id_app FROM cc_firewall.rule_app WHERE id_rul = '$IDRULELOOP' ";
		$SQL .= "AND position = 'd')";
		$RS = mysql_query($SQL);
		$ARRAY = mysql_fetch_array($RS);
		unset($DPORT);
		$f = 0;
		do {
			$DPORT[$f] = $ARRAY['port'];
			$f++;
		}while($ARRAY = mysql_fetch_array($RS));
		// Max port in one rule
		$MAXPORTNUMBER = 15;
		$APP_RANGE_S = 0;
		$APP_RANGE_D = 0;
		$LENGARRAY = sizeof($DPORT);
		$k = 0;
		// Number of port of application multiple 15
		$APP_RANGE_S = ceil($LENGARRAY/$MAXPORTNUMBER);
		for($p = 1; $p <= $APP_RANGE_S; $p++){
			for($f = 0; (($k < $LENGARRAY)&&($f < $MAXPORTNUMBER)); $f++){
				$LEGNPORTAPP = sizeof(explode(":",$DPORT[$k]));
				if($LEGNPORTAPP > 1){
					$APP_RANGE_S++;
					$f = $MAXPORTNUMBER;
					$DPORTNUMBERARRAY[sizeof($DPORTNUMBERARRAY)] = $DPORT[$k];
				} else {
					if(($LENGARRAY > 1)&&($f > 0)) {
						$DPORTNUMBERARRAY[$p-1] = $DPORT[$k].",".$DPORTNUMBERARRAY[$p-1];
					} else {
						$DPORTNUMBERARRAY[sizeof($DPORTNUMBERARRAY)] = $DPORT[$k];
					}
				}
				$k++;
			}
		}
		//
		$SQL = "SELECT id_net FROM cc_firewall.rul_net WHERE id_rul = '$IDRULELOOP' ";
		$SQL .= "AND position = 's'";
		$RS = mysql_query($SQL);
		$ARRAY = mysql_fetch_array($RS);
		unset($SOURCE);
		$f = 0;
		do {
			$SOURCE[$f] = $ARRAY['id_net'];
			$f++;
		}while($ARRAY = mysql_fetch_array($RS));
		//
		$SQL = "SELECT id_net FROM cc_firewall.rul_net WHERE id_rul = '$IDRULELOOP' ";
		$SQL .= "AND position = 'd'";
		$RS = mysql_query($SQL);
		$ARRAY = mysql_fetch_array($RS);
		unset($DESTINATION);
		$f = 0;
		do {
			$DESTINATION[$f] = $ARRAY['id_net'];
			$f++;
		}while($ARRAY = mysql_fetch_array($RS));
		//
		$SQL = "SELECT name FROM controlcenter.interface WHERE ";
		$SQL .= "id IN (SELECT id_s_iface FROM cc_firewall.rulefw WHERE id = '$IDRULELOOP' )";
		$RS = mysql_query($SQL);
		$ARRAY = mysql_fetch_array($RS);
		$SIFACENAME = $ARRAY['name'];
		//
		$SQL = "SELECT name FROM controlcenter.interface WHERE ";
		$SQL .= "id IN (SELECT id_d_iface FROM cc_firewall.rulefw WHERE id = '$IDRULELOOP' )";
		$RS = mysql_query($SQL);
		$ARRAY = mysql_fetch_array($RS);
		$DIFACENAME = $ARRAY['name'];
		//
		$SQL = "SELECT id_atr FROM cc_firewall.rul_atr WHERE id_rul = '$IDRULELOOP' AND id_atr IN ";
		$SQL .= "(SELECT id FROM cc_firewall.atribute_module WHERE id_mod IN ";
		$SQL .= "(SELECT id FROM cc_firewall.module WHERE definitive = 0))";
		$RS = mysql_query($SQL);
		$ARRAY = mysql_fetch_array($RS);	
		do {
			$IDATTR = $ARRAY['id_atr'];
			$SQL = "SELECT a.name as value, m.name as module FROM cc_firewall.atribute_module a,cc_firewall.module m WHERE ";
			$SQL .= "a.id = '$IDATTR' AND a.id_mod = m.id";
			$RSMOD = mysql_query($SQL);
			$ATTRMODULE = mysql_fetch_array($RSMOD);
			unset($MLIMIT);
			unset($MMAC);
			unset($MSTRING);
			switch ($ATTRMODULE['module']){
				case 'limit':
					$MLIMIT = $ATTRMODULE['value'];
					break;
				case 'mac':
					$MMAC = $ATTRMODULE['value'];
					break;
				case 'string':
					$MSTRING = $ATTRMODULE['value'];
					break;
			}
		}while($ARRAY = mysql_fetch_array($RS));
		//
		if(!empty($RULEFW['id_pro'])){
			$SQL = "SELECT name FROM cc_firewall.protocol WHERE id = ".$RULEFW['id_pro'];
			$RS = mysql_query($SQL);
			$ARRAY = mysql_fetch_array($RS);
			$PROTOLO = $ARRAY['name'];
		}
		else {
			unset($PROTOLO);
		}
		//
		$SQL = "SELECT a.name as value, m.name as module FROM cc_firewall.atribute_module a, cc_firewall.module m ";
		$SQL .= "WHERE a.id IN (SELECT id_atr FROM cc_firewall.rul_atr WHERE id_rul = '$IDRULELOOP') ";
		$SQL .= "AND m.id = a.id_mod AND m.definitive = '1'";
		$RS = mysql_query($SQL);
		$ARRAY = mysql_fetch_array($RS);
		$LENGATTRMODULE=mysql_affected_rows();
		unset($TEMPVALUE);
		unset($MSTATE);
		$F = 1;
		do {
			if ($LENGATTRMODULE > ($F)){
				 $TEMPVALUE = $TEMPVALUE.$ARRAY['value'].",";
			} else {
				 $TEMPVALUE = $TEMPVALUE.$ARRAY['value'];
			}
			$F++; 
		} while($ARRAY = mysql_fetch_array($RS));
		$MSTATE = $MSTATE.$TEMPVALUE;

		// Do insert
		$k = 0;
		do
		{
			$SPORTNUMBER = $SPORTNUMBERARRAY[$k];
			$m = 0;
			do
			{
				$DPORTNUMBER = $DPORTNUMBERARRAY[$m];
				$f = 0;
				do
				{
					$SQL = "SELECT ip,mask FROM cc_firewall.network_address WHERE id = '".$SOURCE[$f]."'";
					$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR120F"));
					$ARRAY = mysql_fetch_array($RS);
					if(!empty($ARRAY['mask'])){
						$SOURCEIP = $ARRAY['ip']."/".$ARRAY['mask'];
					} else {
						$SOURCEIP = $ARRAY['ip'];
					}
					$p = 0;
					do
					{
						$SQL = "SELECT ip,mask FROM cc_firewall.network_address WHERE id = '".$DESTINATION[$p]."'";
						$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR121F"));
						$ARRAY = mysql_fetch_array($RS);
						if(!empty($ARRAY['mask'])){
							$DESTINATIONIP = $ARRAY['ip']."/".$ARRAY['mask'];
						} else {
							$DESTINATIONIP = $ARRAY['ip'];
						}
						// Mount the rule in one line
						
						if(!empty($IDRULELOOP)){$RULE = "-t ".$RULEFW['tablefw']." -".$RULEFW['command']." ".$RULEFW['direction']." ";}
						if (!empty($SOURCEIP)){if($RULEFW['source_condition']==0){$RULE .= "-s $SOURCEIP ";}
												else{$RULE .= "! -s $SOURCEIP ";}}
						if (!empty($DESTINATIONIP)){if($RULEFW['destination_condition']=="0"){$RULE .= "-d $DESTINATIONIP ";}
												else{$RULE .= "! -d $DESTINATIONIP ";}}
						if (!empty($SIFACENAME)){if($RULEFW['s_iface_condition']==0){$RULE .= "-i $SIFACENAME ";}
												else{$RULE .= "! -i $SIFACENAME ";}}
						if (!empty($DIFACENAME)){if($RULEFW['d_iface_condition']==0){$RULE .= "-o $DIFACENAME ";}
												else{$RULE .= "! -o $DIFACENAME ";}}
						if (!empty($PROTOLO)){if($RULEFW['proto_condition']==0){$RULE .= "-p ".$PROTOLO." ";} 
												else{$RULE .= "! -p ".$PROTOLO." ";}}
						if (!empty($SPORTNUMBER)){if((($PROTOLO=='tcp')||($PROTOLO=='udp'))&&($RULEFW['proto_condition']==0)){
							if($RULEFW['sport_condition']==0){$RULE .= "-m multiport --sport $SPORTNUMBER ";}
												else{$RULE .= "-m multiport ! --sport $SPORTNUMBER ";}}}
						if (!empty($DPORTNUMBER)){if((($PROTOLO=='tcp')||($PROTOLO=='udp'))&&($RULEFW['proto_condition']==0)){
							if($RULEFW['dport_condition']==0){$RULE .= "-m multiport --dport $DPORTNUMBER ";}
												else{$RULE .= "-m multiport ! --dport $DPORTNUMBER ";}}}
						if (!empty($MLIMIT)){ $RULE .= "-m limit --limit $MLIMIT ";}
						if (!empty($MMAC)){if($RULEFW['mac_condition']==0){$RULE .= "-m mac --mac-source $MMAC ";}
												else{$RULE .= "-m mac ! --mac-source $MMAC ";}}
						if (!empty($MSTRING)){if($RULEFW['string_condition']==0){$RULE .= "-m string --algo bm --string \"".$MSTRING."\" ";}
												else{$RULE .= "-m string --algo bm ! --string \"".$MSTRING."\" ";}}
						if (!empty($MSTATE)){if($RULEFW['state_condition']==0){$RULE .= "-m state --state $MSTATE ";}
												else{$RULE .= "-m state ! --state $MSTATE ";}}
						if (($RULEFW['tablefw'] == "nat") || ($RULEFW['tablefw'] == "filter")) {
							if (!empty($RULEFW['action_fw'])){ $RULE .= "-j ".$RULEFW['action_fw']." ";}
							if ($RULEFW['tablefw'] == "nat") {
								$SQL = "SELECT port FROM cc_firewall.application WHERE id IN (SELECT id_app FROM ";
								$SQL .= "cc_firewall.rule_nat_app WHERE id_rul = '$IDRULELOOP') ";
								$RS = mysql_query($SQL);
								$ARRAY = mysql_fetch_array($RS);
								$TOPORT = $ARRAY['port'];
								$SQL = "SELECT ip FROM cc_firewall.network_address WHERE id IN (SELECT id_net FROM ";
								$SQL .= "cc_firewall.rule_nat_net WHERE id_rul = '$IDRULELOOP') ";
								$RS = mysql_query($SQL);
								$ARRAY = mysql_fetch_array($RS);
								$TOADDRESS = $ARRAY['ip'];
								if ((!empty($TOADDRESS))&&(!empty($TOPORT))){ 
									if($RULEFW['action_fw'] == "SNAT"){
										$RULE .= "--to-source $TOADDRESS:$TOPORT";
										}
									elseif($RULEFW['action_fw'] == "DNAT"){
										$RULE .= "--to-destination $TOADDRESS:$TOPORT";
										}
									elseif($RULEFW['action_fw'] == "REDIRECT") {
										$RULE .= "--to $TOADDRESS:$TOPORT";
									}
								}
								elseif ((!empty($TOADDRESS))&&(empty($TOPORT))){
									if($RULEFW['action_fw'] == "SNAT"){
										$RULE .= "--to-source $TOADDRESS";
										}
									elseif($RULEFW['action_fw'] == "DNAT"){
										$RULE .= "--to-destination $TOADDRESS";
										}
									elseif($RULEFW['action_fw'] == "REDIRECT") {
										$RULE .= "--to $TOADDRESS";
									}
								}
								elseif((empty($TOADDRESS))&&(!empty($TOPORT))) {
									$RULE .= "--to-port $TOPORT";
								}
							}
						}
						else{
							if (!empty($RULEFW['action_fw'])){
								$RULE .= "-j ".substr($RULEFW['action_fw'],0,3);
								if(substr($RULEFW['action_fw'],0,3) == "TOS"){$RULE .= " --set-tos ".substr($RULEFW['action_fw'],3,4);}
								else{$RULE .= substr($RULEFW['action_fw'],3,4);}
								}
							}
						if($RULEFW['action_fw'] == "LOG"){$RULE .= " --log-leve 4 --log-prefix $KEY_LOG ";}
						// Insert the rule in table to execute
						if(!empty($IDRULELOOP)){
							$SQL = "INSERT INTO cc_firewall.rulefwrun (id, name) VALUES ('$IDRULELOOP', '$RULE')";
							$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR055F"));
						}
						$p++;
					}while($p < sizeof($DESTINATION));
					$f++;
				}while($f < sizeof($SOURCE));
				$m++;
			}while($m < sizeof($DPORTNUMBERARRAY));
			$k++;
		}while($k < sizeof($SPORTNUMBERARRAY));
	}while($RULEFW = mysql_fetch_array($RSRULE));

	// Count the number of rules in table after
	$SQL = "SELECT id FROM cc_firewall.rulefwrun";
	$RS = mysql_query($SQL);
	$COUNT_RULE_AFTER = mysql_affected_rows();
	if ($COUNT_RULE_AFTER == $COUNT_RULE_BEFORE) {
		return "ok";
	} else {
		return "fail";
	}
}

function updateSyncRules($type,$id,$old_value){
	require_once('configuration/general.php');
	needApply('1');
	
	if($type == "net"){
		$table_middle = "cc_firewall.rul_net";
		$id_table = "id_net";
		$table = "cc_firewall.network_address";
		$field = "ip";
		$field_add_sql = ",mask";
		$field_add = "mask";
	} elseif ($type == "app"){
		$table_middle = "cc_firewall.rule_app";
		$id_table = "id_app";
		$table = "cc_firewall.application";
		$field = "port";
		$field_add_sql = "";
		$field_add = "";
	}

	$SQL = "SELECT r.id FROM cc_firewall.rulefw r WHERE ";
	$SQL .= "r.id IN (SELECT id_rul FROM $table_middle WHERE $id_table = '$id')";
	$RSRULE = mysql_query($SQL);
	$RULEFW = mysql_fetch_array($RSRULE);
	do {
		$ID_RULE = $RULEFW['id'];
		// Get the new value whould by change 
		$SQL = "SELECT $field$field_add_sql FROM $table WHERE id = '$id'";
		$RS = mysql_query($SQL) or mysql_error();
		$ARRAY = mysql_fetch_array($RS);
		$newvalue = $ARRAY["$field"];
		if($ARRAY["$field_add"]){
			$newvalue = $newvalue."/".$ARRAY["$field_add"];
		}
		if ($type == "net") {
			$SQL = "SELECT refer,name FROM cc_firewall.rulefwrun WHERE (id = '$ID_RULE' AND name LIKE '% $old_value %')";
		}elseif ($type == "app") {
			$SQL = "SELECT refer,name FROM cc_firewall.rulefwrun WHERE id = '$ID_RULE' AND ";
			$SQL .= "(name LIKE '%port $old_value%' OR name LIKE '%,$old_value%' OR name LIKE '%$old_value%,')";
		}
		$RS = mysql_query($SQL);
		unset($ARRAY);
		$ARRAY = mysql_fetch_array($RS);
		do{
			if($type == "net") {
				$RULE = $ARRAY['name'];
				$REFER = $ARRAY['refer'];
				$RULE_REPLACED = str_ireplace($old_value,$newvalue,$RULE);
				$SQL = "UPDATE cc_firewall.rulefwrun SET name='$RULE_REPLACED' WHERE refer = '$REFER' ";
				$RSCHANGE = mysql_query($SQL);
				$SQL = "UPDATE cc_firewall.rulefw SET applied='0' WHERE id = '$ID_RULE' ";
				$RSCHANGE = mysql_query($SQL);
			}
			else{
				$SQL = "UPDATE cc_firewall.rulefw SET applied='2' WHERE id = '$ID_RULE' ";
				$RSCHANGE = mysql_query($SQL);
			}
		} while($ARRAY = mysql_fetch_array($RS));

	}while($RULEFW = mysql_fetch_array($RSRULE));
}
function connect_in_other_fw($IPOTHERFW)
{
	require('/var/.incti/.access/.access_exec.php');
	$hostname = $IPOTHERFW;
	$username = "attikuser";
	$connection_temp = mysql_connect($hostname,$username,$INCTIPW);
	return($connection_temp);
}
function test_connect_in_other_fw($IPOTHERFW,$TIME_OUT_CONN_DB)
{
	require('/var/.incti/.access/.access_exec.php');
	$hostname = $IPOTHERFW;
	$port = "3306";
	$connection_temp = @fsockopen($hostname,$port,$errno,$errstr,$TIME_OUT_CONN_DB);
	if (empty($connection_temp))
	{
		return(0);
	} else
	{
		return(1);
	}
	
	//mysql_close($connection_temp);
}
function insertAppInOtherFw ($IPOTHERFW,$PORTNUMBER,$NAME_PROTO)
{
	//connect_in_other_fw('127.0.0.1');
	$SQL = "SELECT * FROM cc_firewall.application WHERE port = '$PORTNUMBER'";
	$RSOBJEXPORT = mysql_query($SQL,connect_in_other_fw('127.0.0.1'));
	$ARRAY_LOCAL_DATA = mysql_fetch_array($RSOBJEXPORT);
	$SQL = "SELECT id FROM cc_firewall.protocol WHERE name = '$NAME_PROTO'";
	$RSOBJEXPORT2 = mysql_query($SQL,connect_in_other_fw('127.0.0.1'));
	$ARRAY_LOCAL_DATA_TEMP = mysql_fetch_array($RSOBJEXPORT);
	$ID_PRO = $ARRAY_LOCAL_DATA_TEMP['id'];
	
	//connect_in_other_fw($IPOTHERFW);
	$NAME = $ARRAY_LOCAL_DATA ['name'];
	$PORT = $ARRAY_LOCAL_DATA ['port'];
	$DESCRIPTION = $ARRAY_LOCAL_DATA ['description'];
	$REPORT = $ARRAY_LOCAL_DATA ['report'];
	$SQL = "INSERT INTO cc_firewall.application (name, port, description, id_pro, report)"; 
	$SQL .= "VALUES ('$NAME', '$PORT', '$DESCRIPTION', '$ID_PRO', '$REPORT')";
	$RS = mysql_query($SQL,connect_in_other_fw($IPOTHERFW));
	$_SESSION['ID_OBJ'] = mysql_insert_id(connect_in_other_fw($IPOTHERFW));
	// Just go to back connection to localhost database.
	$SQL = "SELECT id FROM controlcenter.language WHERE id = 1";
	$RS = mysql_query($SQL,connect_in_other_fw('127.0.0.1'));
}
function insertNetInOtherFw ($IPOTHERFW,$NAME,$IP,$MASK,$MAC,$DESCRIPTION,$IMG,$GLOBAL)
{
	//connect_in_other_fw($IPOTHERFW);
	$SQL = "INSERT INTO cc_firewall.network_address (name, ip, mask, mac, description, img, global)"; 
	$SQL .= "VALUES ('$NAME', '$IP', '$MASK', '$MAC', '$DESCRIPTION', '$IMG', '$GLOBAL')";
	$RS = mysql_query($SQL,connect_in_other_fw($IPOTHERFW));
	$_SESSION['ID_OBJ'] = mysql_insert_id(connect_in_other_fw($IPOTHERFW));
	// Just go to back connection to localhost database.
	$SQL = "SELECT id FROM controlcenter.language WHERE id = 1";
	$RS = mysql_query($SQL,connect_in_other_fw('127.0.0.1'));
}
function exportRuleFw($id_s_iface,$id_d_iface,$id_pro,$command,$TABLEFW_NAME,$DIRECTION_NAME,$ACTION_NAME,$id_user,$commentfw,$DATE_NOW,$DATE_NOW,$s_iface_condition,$d_iface_condition,$source_condition,$destination_condition,$sport_condition,$dport_condition,$proto_condition,$mac_condition,$string_condition,$state_condition,$SPORTNUMBERARRAY,$DPORTNUMBERARRAY,$SOURCEID,$DESTINATIONID,$MLIMIT,$MMAC,$MSTRING,$STATES,$TOADDRESS,$TOPORT,$SETMARK,$ID_RULE_EXPORTED,$TIME_START,$TIME_STOP,$IPFWEXPORT)
{
	if (!empty($ID_RULE_EXPORTED))
	{
	$CONN_FW_EXPORT = connect_in_other_fw($IPFWEXPORT);
	
	$SQL = "SELECT description FROM controlcenter.interface WHERE id = '$id_s_iface'";
	$RSOBJEXPORT = mysql_query($SQL,connect_in_other_fw('127.0.0.1'));
	$ARRAY = mysql_fetch_array($RSOBJEXPORT);
	$NAME_SIFACE = $ARRAY['description'];
	
	$SQL = "SELECT description FROM controlcenter.interface WHERE id = '$id_d_iface'";
	$RSOBJEXPORT = mysql_query($SQL,connect_in_other_fw('127.0.0.1'));
	$ARRAY = mysql_fetch_array($RSOBJEXPORT);
	$NAME_DIFACE = $ARRAY['description'];
	
	$SQL = "SELECT name FROM cc_firewall.protocol WHERE id = '$id_pro'";
	$RSOBJEXPORT = mysql_query($SQL,connect_in_other_fw('127.0.0.1'));
	$ARRAY = mysql_fetch_array($RSOBJEXPORT);
	$NAME_PROTO = $ARRAY['name'];
	
	$SQL = "SELECT login FROM controlcenter.user WHERE id = '$id_user'";
	$RSOBJEXPORT = mysql_query($SQL,connect_in_other_fw('127.0.0.1'));
	$ARRAY = mysql_fetch_array($RSOBJEXPORT);
	$USER_LOGIN = $ARRAY['login'];
	
	$SQL = "SELECT name FROM cc_firewall.variable_time WHERE id='$TIME_START'";
	$RSOBJEXPORT = mysql_query($SQL,connect_in_other_fw('127.0.0.1'));
	$ARRAY = mysql_fetch_array($RSOBJEXPORT);
	$TIME_START = $ARRAY['name'];
	
	$SQL = "SELECT name FROM cc_firewall.variable_time WHERE id='$TIME_STOP'";
	$RSOBJEXPORT = mysql_query($SQL,connect_in_other_fw('127.0.0.1'));
	$ARRAY = mysql_fetch_array($RSOBJEXPORT);
	$TIME_STOP = $ARRAY['name'];
	
	// Tarefas no outro firewall
		//connect_in_other_fw($IPFWEXPORT);
		
		$SQL = "SELECT id FROM controlcenter.user WHERE login = '$USER_LOGIN'";
		$RSOBJEXPORT = mysql_query($SQL,$CONN_FW_EXPORT);
		$ARRAY = mysql_fetch_array($RSOBJEXPORT);
		$ID_USER_EX = $ARRAY['id'];
		if (empty($ID_USER_EX)) {
			$ID_USER_EX = 1;
		}
		
		// Get data to mount the rule
		$SQL = "SELECT id,name FROM controlcenter.interface WHERE description = '$NAME_SIFACE'";
		$RSOBJEXPORT = mysql_query($SQL,$CONN_FW_EXPORT);
		$ARRAY = mysql_fetch_array($RSOBJEXPORT);
		$ID_SIFACE_EX = $ARRAY['id'];
		if (empty($ID_SIFACE_EX)){
			$s_iface_condition = 0;
		}
		$_SESSION['SIFACE_NAME_EXPORTED'] = $ARRAY['name'];
	
		$SQL = "SELECT id,name FROM controlcenter.interface WHERE description = '$NAME_DIFACE'";
		$RSOBJEXPORT = mysql_query($SQL,$CONN_FW_EXPORT);
		$ARRAY = mysql_fetch_array($RSOBJEXPORT);
		$ID_DIFACE_EX = $ARRAY['id'];
		if (empty($ID_DIFACE_EX)){
			$d_iface_condition = 0;
		}
		$_SESSION['DIFACE_NAME_EXPORTED'] = $ARRAY['name'];
		
		$SQL = "SELECT id FROM cc_firewall.protocol WHERE name = '$NAME_PROTO'";
		$RSOBJEXPORT = mysql_query($SQL,$CONN_FW_EXPORT);
		$ARRAY = mysql_fetch_array($RSOBJEXPORT);
		$ID_PROTO_EX = $ARRAY['id'];
		$SQL = "SELECT id FROM cc_firewall.tablefw WHERE name = '$TABLEFW_NAME'";
		$RSOBJEXPORT = mysql_query($SQL,$CONN_FW_EXPORT);
		$ARRAY = mysql_fetch_array($RSOBJEXPORT);
		$ID_TABLEFW_EX = $ARRAY['id'];
		$SQL = "SELECT id FROM cc_firewall.direction WHERE name = '$DIRECTION_NAME'";
		$RSOBJEXPORT = mysql_query($SQL,$CONN_FW_EXPORT);
		$ARRAY = mysql_fetch_array($RSOBJEXPORT);
		$ID_DIRECTION_EX = $ARRAY['id'];
		$SQL = "SELECT id FROM cc_firewall.action WHERE name = '$ACTION_NAME'";
		$RSOBJEXPORT = mysql_query($SQL,$CONN_FW_EXPORT);
		$ARRAY = mysql_fetch_array($RSOBJEXPORT);
		$ID_ACTION_EX = $ARRAY['id'];
		$SQL = "SELECT id FROM cc_firewall.tab_dir_act WHERE id_tab = '$ID_TABLEFW_EX' AND id_dir = '$ID_DIRECTION_EX' ";
		$SQL .= "AND id_act = '$ID_ACTION_EX'";
		$RSOBJEXPORT = mysql_query($SQL,$CONN_FW_EXPORT);
		$ARRAY = mysql_fetch_array($RSOBJEXPORT);
		$ID_TAB_DIR_ACT_EX = $ARRAY['id'];
		
		$SQL = "SELECT id FROM cc_firewall.variable_time WHERE name='$TIME_START'";
		$RSOBJEXPORT = mysql_query($SQL,$CONN_FW_EXPORT);
		$ARRAY = mysql_fetch_array($RSOBJEXPORT);
		$TIME_START = $ARRAY['id'];
		
		$SQL = "SELECT id FROM cc_firewall.variable_time WHERE name='$TIME_STOP'";
		$RSOBJEXPORT = mysql_query($SQL,$CONN_FW_EXPORT);
		$ARRAY = mysql_fetch_array($RSOBJEXPORT);
		$TIME_STOP = $ARRAY['id'];
	
		if($ID_RULE_EXPORTED == "I")
		{
			// Insert the Rule
			$SQL = "INSERT INTO cc_firewall.rulefw (id_s_iface, id_d_iface, id_pro, ";
			$SQL .= "command, id_tab_dir_act, id_user, commentfw, date_created, last_update, ";
			$SQL .= "status, applied, s_iface_condition, d_iface_condition, source_condition, ";
			$SQL .= "destination_condition, sport_condition, dport_condition, proto_condition, ";
			$SQL .= "mac_condition, string_condition, state_condition, exported) VALUE ('$ID_SIFACE_EX', '$ID_DIFACE_EX', ";
			$SQL .= "'$ID_PROTO_EX', '$command', '$ID_TAB_DIR_ACT_EX', '$ID_USER_EX', '$commentfw', '$DATE_NOW', ";
			$SQL .= "'$DATE_NOW','1','0','$s_iface_condition','$d_iface_condition','$source_condition','$destination_condition', ";
			$SQL .= "'$sport_condition','$dport_condition','$proto_condition','$mac_condition','$string_condition', ";
			$SQL .= "'$state_condition','1')";
			$RSOBJEXPORT = mysql_query($SQL,$CONN_FW_EXPORT);
			$ID_RULE = mysql_insert_id($CONN_FW_EXPORT);
			$_SESSION['ID_RULE_EXPORTED'] = $ID_RULE;
			$ID_RULE_EXPORTED = $_SESSION['ID_RULE_EXPORTED'];
		}else
		{
			$_SESSION['ID_RULE_EXPORTED'] = $ID_RULE_EXPORTED;
			
			$SQL = "UPDATE cc_firewall.rulefw SET id_s_iface='$ID_SIFACE_EX', id_d_iface='$ID_DIFACE_EX', ";
			$SQL .= "id_pro='$ID_PROTO_EX', ";
			$SQL .= "command='$command', id_tab_dir_act='$ID_TAB_DIR_ACT_EX', ";
			$SQL .= "id_user='$ID_USER_EX', commentfw='$commentfw', last_update='$DATE_NOW', applied = '0', ";
			$SQL .= "source_condition='$source_condition', destination_condition='$destination_condition', ";
			$SQL .= "s_iface_condition='$s_iface_condition', d_iface_condition='$d_iface_condition', ";
			$SQL .= "proto_condition='$proto_condition', mac_condition='$mac_condition', string_condition='$string_condition', ";
			$SQL .= "state_condition='$state_condition', sport_condition='$sport_condition', dport_condition='$dport_condition' ";
			$SQL .= "WHERE id = '$ID_RULE_EXPORTED'";
			$RS = mysql_query($SQL,$CONN_FW_EXPORT);
		}
								
		if(mysql_affected_rows($CONN_FW_EXPORT) != 0)
		{
			$_SESSION['STATUS_RULE_EXPORT'] = '1';
	
			// Type table
			if ($TABLEFW_NAME == "nat")
			{
				if ((!empty($ID_RULE)) && (!empty($TOADDRESS)))
				{
					//connect_in_other_fw('127.0.0.1');
					
					$SQL = "SELECT * FROM cc_firewall.network_address WHERE id = '$TOADDRESS'";
					$RSOBJEXPORT = mysql_query($SQL,connect_in_other_fw('127.0.0.1'));
					$ARRAY_PRE_TEMP = mysql_fetch_array($RSOBJEXPORT);
					$TOADDRESS = $ARRAY_PRE_TEMP['ip'];
					
					//connect_in_other_fw($IPFWEXPORT);
					
					$SQL = "SELECT * FROM cc_firewall.network_address WHERE ip = '$TOADDRESS'";
					$RSOBJEXPORT = mysql_query($SQL,$CONN_FW_EXPORT);
					$ARRAY = mysql_fetch_array($RSOBJEXPORT);
					if (mysql_affected_rows($CONN_FW_EXPORT) != 0) 
					{
						$TOADDRESS = $ARRAY['id'];
						$SQL = "INSERT INTO cc_firewall.rule_nat_net (id_rul, id_net) VALUES ";
						$SQL .= "('$ID_RULE_EXPORTED', '$TOADDRESS')";
						$RS = mysql_query($SQL,$CONN_FW_EXPORT);
					}
					else {	
						if ($ARRAY_PRE_TEMP['global'] == 1) 
						{				
							insertNetInOtherFw($IPFWEXPORT,$ARRAY_PRE_TEMP['name'],$ARRAY_PRE_TEMP['ip'],$ARRAY_PRE_TEMP['mask'],$ARRAY_PRE_TEMP['mac'],$ARRAY_PRE_TEMP['descripttion'],$ARRAY_PRE_TEMP['img'],$ARRAY_PRE_TEMP['global']);
							$ID_OBJ = $_SESSION['ID_OBJ'];
							unset($_SESSION['ID_OBJ']);
						} else {				
							$NAMEADDRESS = $ARRAY['name'];
							$SQL = "SELECT * FROM cc_firewall.network_address WHERE name = '$NAMEADDRESS'";
							$RSOBJEXPORT = mysql_query($SQL,$CONN_FW_EXPORT);
							$ARRAY_PRE_TEMP = mysql_fetch_array($RSOBJEXPORT);
												
							if (mysql_affected_rows($CONN_FW_EXPORT) == 0) {
								insertNetInOtherFw ($IPFWEXPORT,$ARRAY_PRE_TEMP['name'],$ARRAY_PRE_TEMP['ip'],$ARRAY_PRE_TEMP['mask'],$ARRAY_PRE_TEMP['mac'],$ARRAY_PRE_TEMP['descripttion'],$ARRAY_PRE_TEMP['img'],$ARRAY_PRE_TEMP['global']);
								$ID_OBJ = $_SESSION['ID_OBJ'];
								unset($_SESSION['ID_OBJ']);
							} else {
								$ARRAY = mysql_fetch_array($RSOBJEXPORT);
								$ID_OBJ = $ARRAY['id'];
							}
						
						}
						$SQL = "INSERT INTO cc_firewall.rule_nat_net (id_rul, id_net) VALUES ";
						$SQL .= "('$ID_RULE_EXPORTED', '$ID_OBJ')";
						$RS = mysql_query($SQL,$CONN_FW_EXPORT);
					}
				}
				if ((!empty($ID_RULE)) && (!empty($TOPORT)))
				{
					//connect_in_other_fw('127.0.0.1');
					
					$SQL = "SELECT port FROM cc_firewall.application WHERE id = '$TOPORT'";
					$RSOBJEXPORT = mysql_query($SQL,connect_in_other_fw('127.0.0.1'));
					$ARRAY_PRE_TEMP = mysql_fetch_array($RSOBJEXPORT);
					$TOPORT = $ARRAY_PRE_TEMP['port'];
					
					//connect_in_other_fw($IPFWEXPORT);
					
					$SQL = "SELECT id FROM cc_firewall.application WHERE port = '$TOPORT'";
					$RSOBJEXPORT = mysql_query($SQL,$CONN_FW_EXPORT);
					if (mysql_affected_rows($CONN_FW_EXPORT) != 0) {
						$ARRAY = mysql_fetch_array($RSOBJEXPORT);
						$TOPORT = $ARRAY['id'];
						$SQL = "INSERT INTO cc_firewall.rule_nat_app (id_rul, id_app) VALUES ";
						$SQL .= "('$ID_RULE_EXPORTED', '$TOPORT')";
						$RS = mysql_query($SQL,$CONN_FW_EXPORT);
					} else {
						if (mysql_affected_rows($CONN_FW_EXPORT) == 0) {
							insertAppInOtherFw ($IPFWEXPORT,$TOPORT,$NAME_PROTO);
							$ID_OBJ = $_SESSION['ID_OBJ'];
							unset($_SESSION['ID_OBJ']);
						} else {
							$ARRAY = mysql_fetch_array($RSOBJEXPORT);
							$ID_OBJ = $ARRAY['id'];
						}
					}
					$SQL = "INSERT INTO cc_firewall.rule_nat_app (id_rul, id_app) VALUES ";
					$SQL .= "('$ID_RULE_EXPORTED', '$ID_OBJ')";
					$RS = mysql_query($SQL,$CONN_FW_EXPORT);
				}
			}
			elseif ($TABLEFW_NAME == "mangle")
			{
				if ((!empty($ID_RULE)) && ($ACTION == "MARK") && (!empty($SETMARK)))
				{
					$SQL = "INSERT INTO cc_firewall.rule_mangle_value (id_rul, setmark) VALUES ";
					$SQL .= "('$ID_RULE_EXPORTED', '$SETMARK')";
					$RS = mysql_query($SQL,$CONN_FW_EXPORT);
				}
			}
			//Insert the time
			if (!empty($TIME_START))
			{
				//Insert the start time
				$SQL = "INSERT INTO cc_firewall.rul_vartime (id_rul, id_vartime, status_order) ";
				$SQL .= "VALUES ('$ID_RULE_EXPORTED', '$TIME_START','s')";
				$RSOBJEXPORT = mysql_query($SQL,$CONN_FW_EXPORT);
				// Insert the end time
				$SQL = "INSERT INTO cc_firewall.rul_vartime (id_rul, id_vartime, status_order) ";
				$SQL .= "VALUES ('$ID_RULE_EXPORTED', '$TIME_STOP','e')";
				$RSOBJEXPORT = mysql_query($SQL,$CONN_FW_EXPORT);
			}
			// Application
			for ($F = 0; $F < sizeof($SPORTNUMBERARRAY); $F++) 
			{
				$ARRAYPORT = explode(",",$SPORTNUMBERARRAY[$F]);
				for ($I = 0; $I < sizeof($ARRAYPORT); $I++)
				{
					$PORTNUMBER = $ARRAYPORT[$I];
					$SQL = "SELECT id FROM cc_firewall.application WHERE port = '$PORTNUMBER' ";
					$RSOBJEXPORT = mysql_query($SQL,$CONN_FW_EXPORT);
					if (mysql_affected_rows($CONN_FW_EXPORT) == 0) {
						insertAppInOtherFw ($IPFWEXPORT,$PORTNUMBER,$NAME_PROTO);
						$ID_OBJ = $_SESSION['ID_OBJ'];
						unset($_SESSION['ID_OBJ']);
					} else {
						$ARRAY = mysql_fetch_array($RSOBJEXPORT);
						$ID_OBJ = $ARRAY['id'];
					}
					
					$SQL = "INSERT INTO cc_firewall.rule_app VALUES('$ID_RULE_EXPORTED','$ID_OBJ','s')";
					$RSOBJEXPORT = mysql_query($SQL,$CONN_FW_EXPORT);
				}
			}
			for ($F = 0; $F < sizeof($DPORTNUMBERARRAY); $F++) 
			{
				$ARRAYPORT = explode(",",$DPORTNUMBERARRAY[$F]);
				for ($I = 0; $I < sizeof($ARRAYPORT); $I++)
				{
					$PORTNUMBER = $ARRAYPORT[$I];
					$SQL = "SELECT id FROM cc_firewall.application WHERE port = '$PORTNUMBER' ";
					$RSOBJEXPORT = mysql_query($SQL,$CONN_FW_EXPORT);
					if (mysql_affected_rows($CONN_FW_EXPORT) == 0) {
						insertAppInOtherFw ($IPFWEXPORT,$PORTNUMBER,$NAME_PROTO);
						$ID_OBJ = $_SESSION['ID_OBJ'];
						unset($_SESSION['ID_OBJ']);
					} else {
						$ARRAY = mysql_fetch_array($RSOBJEXPORT);
						$ID_OBJ = $ARRAY['id'];
					}
					
					$SQL = "INSERT INTO cc_firewall.rule_app VALUES('$ID_RULE_EXPORTED','$ID_OBJ','d')";
					$RSOBJEXPORT = mysql_query($SQL,$CONN_FW_EXPORT);
				}
			}
			// Address network
			for ($F = 0; $F < sizeof($SOURCEID); $F++) 
			{
				//connect_in_other_fw('127.0.0.1');
				$ID = $SOURCEID[$F];
				$SQL = "SELECT * FROM cc_firewall.network_address WHERE id = '$ID'";
				$RSOBJEXPORT = mysql_query($SQL,connect_in_other_fw('127.0.0.1'));
				$ARRAY_PRE_TEMP = mysql_fetch_array($RSOBJEXPORT);
				
				//connect_in_other_fw($IPFWEXPORT);
				
				if ($ARRAY_PRE_TEMP['global'] == 1) 
				{
					$IPADDRESS = $ARRAY_PRE_TEMP['ip'];
					$MASKADDRESS = $ARRAY_PRE_TEMP['mask'];
					$SQL = "SELECT id FROM cc_firewall.network_address WHERE ip = '$IPADDRESS' AND mask = '$MASKADDRESS' ";
					$RSOBJEXPORT = mysql_query($SQL,$CONN_FW_EXPORT);
					if (mysql_affected_rows($CONN_FW_EXPORT) == 0) {
						insertNetInOtherFw($IPFWEXPORT,$ARRAY_PRE_TEMP['name'],$ARRAY_PRE_TEMP['ip'],$ARRAY_PRE_TEMP['mask'],$ARRAY_PRE_TEMP['mac'],$ARRAY_PRE_TEMP['descripttion'],$ARRAY_PRE_TEMP['img'],$ARRAY_PRE_TEMP['global']);
						$ID_OBJ = $_SESSION['ID_OBJ'];
						unset($_SESSION['ID_OBJ']);
					} else {
						$ARRAY = mysql_fetch_array($RSOBJEXPORT);
						$ID_OBJ = $ARRAY['id'];
					}
				} else {
					$NAMEADDRESS = $ARRAY_PRE_TEMP['name'];
					$SQL = "SELECT id FROM cc_firewall.network_address WHERE name = '$NAMEADDRESS' ";
					$RSOBJEXPORT = mysql_query($SQL,$CONN_FW_EXPORT);
					if (mysql_affected_rows($CONN_FW_EXPORT) == 0) {
						insertNetInOtherFw ($IPFWEXPORT,$ARRAY_PRE_TEMP['name'],$ARRAY_PRE_TEMP['ip'],$ARRAY_PRE_TEMP['mask'],$ARRAY_PRE_TEMP['mac'],$ARRAY_PRE_TEMP['descripttion'],$ARRAY_PRE_TEMP['img'],$ARRAY_PRE_TEMP['global']);
						$ID_OBJ = $_SESSION['ID_OBJ'];
						unset($_SESSION['ID_OBJ']);
					} else {
						$ARRAY = mysql_fetch_array($RSOBJEXPORT);
						$ID_OBJ = $ARRAY['id'];
					}
				
				}
				
				$SQL = "INSERT INTO cc_firewall.rul_net VALUES('$ID_RULE_EXPORTED','$ID_OBJ','s')";
				$RSOBJEXPORT = mysql_query($SQL,$CONN_FW_EXPORT);
			}
			for ($F = 0; $F < sizeof($DESTINATIONID); $F++) 
			{
				//connect_in_other_fw('127.0.0.1');
				$ID = $DESTINATIONID[$F];
				$SQL = "SELECT * FROM cc_firewall.network_address WHERE id = '$ID'";
				$RSOBJEXPORT = mysql_query($SQL,connect_in_other_fw('127.0.0.1'));
				$ARRAY_PRE_TEMP = mysql_fetch_array($RSOBJEXPORT);
				
				//connect_in_other_fw($IPFWEXPORT);
				if ($ARRAY_PRE_TEMP['global'] == 1) 
				{
					$IPADDRESS = $ARRAY_PRE_TEMP['ip'];
					$MASKADDRESS = $ARRAY_PRE_TEMP['mask'];
					$SQL = "SELECT id FROM cc_firewall.network_address WHERE ip = '$IPADDRESS' AND mask = '$MASKADDRESS' ";
					$RSOBJEXPORT = mysql_query($SQL,$CONN_FW_EXPORT);
					if (mysql_affected_rows($CONN_FW_EXPORT) == 0) {
						insertNetInOtherFw ($IPFWEXPORT,$ARRAY_PRE_TEMP['name'],$ARRAY_PRE_TEMP['ip'],$ARRAY_PRE_TEMP['mask'],$ARRAY_PRE_TEMP['mac'],$ARRAY_PRE_TEMP['descripttion'],$ARRAY_PRE_TEMP['img'],$ARRAY_PRE_TEMP['global']);
						$ID_OBJ = $_SESSION['ID_OBJ'];
						unset($_SESSION['ID_OBJ']);
					} else {
						$ARRAY = mysql_fetch_array($RSOBJEXPORT);
						$ID_OBJ = $ARRAY['id'];
					}
				} else {
					$NAMEADDRESS = $ARRAY_PRE_TEMP['name'];
					$SQL = "SELECT id FROM cc_firewall.network_address WHERE name = '$NAMEADDRESS' ";
					$RSOBJEXPORT = mysql_query($SQL,$CONN_FW_EXPORT);
					if (mysql_affected_rows($CONN_FW_EXPORT) == 0) {
						insertNetInOtherFw ($IPFWEXPORT,$ARRAY_PRE_TEMP['name'],$ARRAY_PRE_TEMP['ip'],$ARRAY_PRE_TEMP['mask'],$ARRAY_PRE_TEMP['mac'],$ARRAY_PRE_TEMP['descripttion'],$ARRAY_PRE_TEMP['img'],$ARRAY_PRE_TEMP['global']);
						$ID_OBJ = $_SESSION['ID_OBJ'];
						unset($_SESSION['ID_OBJ']);
					} else {
						$ARRAY = mysql_fetch_array($RSOBJEXPORT);
						$ID_OBJ = $ARRAY['id'];
					}
				
				}
				
				$SQL = "INSERT INTO cc_firewall.rul_net VALUES('$ID_RULE_EXPORTED','$ID_OBJ','d')";
				$RSOBJEXPORT = mysql_query($SQL,$CONN_FW_EXPORT);
			}
			// Modules
			if (!empty($MLIMIT))
			{
				$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'limit'";
				$RS = mysql_query($SQL,$CONN_FW_EXPORT);
				if (mysql_affected_rows($CONN_FW_EXPORT) != 0) 
				{
					$ARRAY = mysql_fetch_array($RS);
					$ID = $ARRAY['id'];
					$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
					$SQL .= "('$ID', '$MLIMIT')";
					$RS = mysql_query($SQL,$CONN_FW_EXPORT);
					if (mysql_affected_rows($CONN_FW_EXPORT) != 0)
					{
						$ID = mysql_insert_id($CONN_FW_EXPORT);
						$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
						$SQL .= "('$ID_RULE_EXPORTED', '$ID')";
						$RS = mysql_query($SQL,$CONN_FW_EXPORT);
					}
				}
			}
			if (!empty($MMAC))
			{
				$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'mac'";
				$RS = mysql_query($SQL,$CONN_FW_EXPORT);
				if (mysql_affected_rows($CONN_FW_EXPORT) != 0) 
				{
					$ARRAY = mysql_fetch_array($RS);
					$ID = $ARRAY['id'];
					$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
					$SQL .= "('$ID', '$MMAC')";
					$RS = mysql_query($SQL,$CONN_FW_EXPORT);
					if (mysql_affected_rows($CONN_FW_EXPORT) != 0)
					{
						$ID = mysql_insert_id($CONN_FW_EXPORT);
						$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
						$SQL .= "('$ID_RULE_EXPORTED', '$ID')";
						$RS = mysql_query($SQL,$CONN_FW_EXPORT);
					}								
				}
			}
			if (!empty($MSTRING))
			{
				$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'string'";
				$RS = mysql_query($SQL,$CONN_FW_EXPORT);
				if (mysql_affected_rows($CONN_FW_EXPORT) != 0) 
				{
					$ARRAY = mysql_fetch_array($RS);
					$ID = $ARRAY['id'];
					$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
					$SQL .= "('$ID', '$MSTRING')";
					$RS = mysql_query($SQL,$CONN_FW_EXPORT);
					if (mysql_affected_rows($CONN_FW_EXPORT) != 0)
					{
						$ID = mysql_insert_id($CONN_FW_EXPORT);
						$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
						$SQL .= "('$ID_RULE_EXPORTED', '$ID')";
						$RS = mysql_query($SQL,$CONN_FW_EXPORT);
					}
				}
			}
			if (!empty($STATES[0]))
			{
				for ($count = 0; $count < sizeof($STATES); $count++)
					{		
						$ID_ATR = $STATES[$count];
						$SQL = "SELECT name FROM cc_firewall.atribute_module WHERE id = '$ID_ATR'";
						$RS = mysql_query($SQL,connect_in_other_fw('127.0.0.1'));
						$ARRAY = mysql_fetch_array($RS);
						$TEMP_NAME = $ARRAY['name'];
						$SQL = "SELECT id FROM cc_firewall.atribute_module WHERE name = '$TEMP_NAME'";
						$RS = mysql_query($SQL,$CONN_FW_EXPORT);
						$ARRAY = mysql_fetch_array($RS);
						$ID_ATR = $ARRAY['id'];
						$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
						$SQL .= "('$ID_RULE_EXPORTED', '$ID_ATR')";
						$RS = mysql_query($SQL,$CONN_FW_EXPORT);
					}
			}
			$SQL = "UPDATE cc_firewall.needapply SET name = '1'";
			$RS = mysql_query($SQL,$CONN_FW_EXPORT);
		} else
		{
			$_SESSION['STATUS_RULE_EXPORT'] = '0';
		}
		// Just go to back connection to localhost database.
		$SQL = "SELECT id FROM controlcenter.language WHERE id = 1";
		$RS = mysql_query($SQL,connect_in_other_fw('127.0.0.1'));
	}else{
		$_SESSION['STATUS_RULE_EXPORT'] = '0';
	}
}
function deleteExportedRuleFw($ID_RULE, $ID_RULE_EXPORTED,$TABLE,$IPFWEXPORT)
{
	// Established the conection
	$CONN_FW_EXPORT = connect_in_other_fw($IPFWEXPORT);

	// Delete association to NAT and Mangle tables
		// Delete the field network_address in rule
		$SQL = "DELETE FROM cc_firewall.rule_nat_net WHERE id_rul = '$ID_RULE_EXPORTED'";
		$RS = mysql_query($SQL,$CONN_FW_EXPORT);
		// Delete the field application in rule
		$SQL = "DELETE FROM cc_firewall.rule_nat_app WHERE id_rul = '$ID_RULE_EXPORTED'";
		$RS = mysql_query($SQL,$CONN_FW_EXPORT);
	
		// Delete the field value of mark pakage
		$SQL = "DELETE FROM cc_firewall.rule_mangle_value WHERE id_rul = '$ID_RULE_EXPORTED'";
		$RS = mysql_query($SQL,$CONN_FW_EXPORT);
	
	// Delete the variable time refereced in rule
	$SQL = "DELETE FROM cc_firewall.rul_vartime WHERE id_rul = '$ID_RULE_EXPORTED'";
	$RS = mysql_query($SQL,$CONN_FW_EXPORT);
	
	// Delete the attributes of State module
	$SQL = "DELETE FROM cc_firewall.atribute_module WHERE id IN (SELECT id_atr FROM ";
	$SQL .= "cc_firewall.rul_atr WHERE id_rul = '$ID_RULE_EXPORTED') AND id_mod IN (SELECT id FROM ";
	$SQL .= "cc_firewall.module WHERE definitive <> '1')";
	$RS = mysql_query($SQL,$CONN_FW_EXPORT);
	
	// Delete the associated (rul_atr)
	$SQL = "DELETE FROM cc_firewall.rul_atr WHERE id_rul = '$ID_RULE_EXPORTED'";
	$RS = mysql_query($SQL,$CONN_FW_EXPORT);

	// Delete the address, ports and firewalls exported
	$SQL = "DELETE FROM cc_firewall.rul_net WHERE id_rul = '$ID_RULE_EXPORTED'";
	$RS = mysql_query($SQL,$CONN_FW_EXPORT);
	
	$SQL = "DELETE FROM cc_firewall.rule_app WHERE id_rul = '$ID_RULE_EXPORTED'";
	$RS = mysql_query($SQL,$CONN_FW_EXPORT);
	
	// Delete the rule in table to execute for before will insert
	$SQL = "DELETE FROM cc_firewall.rulefwrun WHERE id = '$ID_RULE_EXPORTED'";
	$RS = mysql_query($SQL,$CONN_FW_EXPORT);
	
	// Just go to back connection to localhost database.
	$SQL = "SELECT id FROM controlcenter.language WHERE id = 1";
	$RS = mysql_query($SQL,connect_in_other_fw('127.0.0.1'));
}
?>