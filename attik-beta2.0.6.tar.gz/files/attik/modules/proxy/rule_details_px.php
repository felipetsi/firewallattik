<script language="javascript">

function showDetailSelected()
{
	document.getElementById('r_show_rule_detail').style.display="table";
	document.getElementById('r_show_rule').style.height="90px";
}
function showDetails()
{
	if(document.getElementById('r_show_rule_detail').style.display=="none"){
		document.getElementById('r_show_rule_detail').style.display="table";
		document.getElementById('r_show_rule').style.height="90px";
	} else {
		document.getElementById('r_show_rule_detail').style.display="none";
		document.getElementById('r_show_rule').style.height="320px";
	}
}

function confirmDeleteSelected()
{
	document.getElementById('box_delete').style.display="table";
}
function yesdeleteSelected()
{
	setValuesCheck();
}
function nodeleteSelected()
{
	document.getElementById('box_delete').style.display="none";
}
function selectPageSel($pageSeq)
{
	document.getElementById('page_seq').value=$pageSeq;
	document.formPageSeq.submit();
}
</script>
	<div id="box_delete"><?php echo("$S_WANT_DELETE $S_SELECTED?");?> 
		<div class="space_confirm_box">
			<input type="button" value="<?php echo $B_YES;?>" onclick="javascript:yesdeleteSelected();" />
			<input type="button" value="<?php echo $B_NO;?>" onclick="javascript:nodeleteSelected();" />
		</div>	
	</div>
<form action="<?php echo $DESTINATION_PAGE;?>" method="post" name="formRule">
<?php
if (empty($ITEMID)){
	$SHOWDETAILS = 'style="display:none"';
} else {
	$SHOWDETAILS = "";
}
?>
<div id="r_show_rule_detail" ><!--Show detail-->
<?php
		$SQL = "SELECT DISTINCT r.id, r.s_address as source, r.d_address as destination, ";
		$SQL .= "r.id_tab_dir_act, r.id_s_iface, r.id_d_iface, r.s_port, r.d_port, r.commentfw, ";
		$SQL .= "r.id_pro, r.command, ac.name as action, ac.id as id_action, t.id as id_table FROM ";
		$SQL .= "cc_firewall.rulefw r, cc_firewall.action ac, cc_firewall.tablefw t WHERE ";
		$SQL .= "t.id IN (SELECT id FROM cc_firewall.tablefw WHERE name = '$TABLE') "; 
		$SQL .= "AND ac.name IN (SELECT name FROM cc_firewall.action WHERE id IN ";
		$SQL .= "(SELECT tda.id_act FROM cc_firewall.tab_dir_act tda WHERE r.id_tab_dir_act = tda.id))";
		$SQL .= "AND CONCAT_WS('-', r.id) = '$ITEMID'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR073F"));
		$ARRAY = mysql_fetch_array($RS);
		
		if (!empty($ARRAY['s_port'])){
			echo ('
				<script language="javascript">
					sportSele = '.$ARRAY['s_port'].';
				</script>');
		}
		if (!empty($ARRAY['d_port'])){
			echo ('
				<script language="javascript">
					dportSele = '.$ARRAY['d_port'].';
				</script>');
		}
?>
<div class="r_info"><!-- Information -->
	<input type="hidden" value="<?php echo $ITEMID;?>" name="id" />
	<div class="r_box_info_left"><!-- Box left -->
		<div class="r_box_text">
			<u>
			<?php echo $T_USER;?></u><img src="../../@img/icons/direction-16x16.png" />:			
		</div>
		<div>
			<select name="user" class="select_left_details" size="2"/>
				<option></option>
			</select>
		</div>
	
	</div><!-- Box left -->
	<div class="r_box_info_right"><!-- Box midle-->	
		<div class="r_box_text">
			<?php echo $T_GROUP;?>:
		</div>
		<div>
		<select name="group" class="obj_right_details" size="2">
		<option></option>
		</select>
		</div>
	</div><!-- Box midle-->
	<div class="r_box_info_right"><!-- Box rigth-->	
		<div class="r_box_text">
			<?php echo $F_IP;?>
		</div>
		<div>
		<select name="group" class="obj_right_details" size="2">
		<option></option>
		</select>
		</div>
	</div><!-- Box rigth-->
</div><!-- Information -->

	<div class="r_box_comment">
		<div class="r_box_mod_text">
			<?php echo $T_COMMENT;?>:
		</div>
		<div>
			<input size="35" maxlength="50" name="comment" value="<?php	if (!empty($ARRAY['commentfw'])){echo $ARRAY['commentfw'];}else{echo $_SESSION['COMMENT'];}?>" />
		</div>
	</div>
	<div class="r_box_right">
		<div class="r_box_mod_text" >
			<u>
			<?php echo $T_ACTION;?>
			</u>:
		</div>
		<div>
		<select name="action" onChange="javascript:verifyAction();">

		</select>
		</div>	
	</div>

</div><!--Show detail-->
<input type="hidden" name="ind_search" id="ind_search" value="0" />
<div class="title_general">
	<img class="contet_left_img" src="../../@img/icons/show-hidden-24x24.png" onclick="javascript:showDetails();" />
	<input type="submit" value="<?php if (empty($ITEMID)){ echo $B_ADD_NEW;} else { echo $B_UPDATE;}?>" onClick="javascript:ShowAllRules();" />
	<input type="button" value="<?php if(empty($_SESSION['SQL_SEARCH'])){echo $B_CLEAR;}else{ echo $B_SHOW_ALL;}?>" onClick="javascript:ShowAllRules();" />
	<input type="button" value="<?php echo $B_DELETE;?>" onClick="javascript:confirmDeleteSelected();" />
	<input type="button" value="<?php echo $B_SEARCH;?>" onClick="javascript:CheckSearh();" />
		<?php
		if (empty($_SESSION['SQL_SEARCH'])){
			$SQL = "SELECT id FROM cc_firewall.rulefw";
		} else {
			$SQL = $_SESSION['SQL_SEARCH'];
			$SQL .= "AND id_tab IN (SELECT id FROM cc_firewall.tablefw WHERE name = '$TABLE') ) ";
		}
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR107F"));
		$QTD = (mysql_affected_rows()/$QUANTITY_RULE_SHOW);
		if ($QTD > 1) {?>
			<input type="button" value="<<" onclick="javascript:selectPageSel(0);" />
			<input type="button" value="<" onclick="javascript:selectPageSel(<?php echo ($PAGE_SEQ_P-1);?>);" /><?php
			if (($QTD > 6)&&($PAGE_SEQ_P > 5)){ $p = $PAGE_SEQ_P;} else { $p = 1;}
			for($f=$p; $f < ($QTD+1); $f++)
			{
				if(($f == $p)&&($f != 1)){?>
					<input type="button" value="..." onclick="javascript:selectPageSel(<?php echo ($f-1);?>);" /><?php
				}
				if($f < ($p+6)){?>
					<input type="button" value="<?php echo $f;?>" onclick="javascript:selectPageSel(<?php echo ($f-1);?>);" />
				<?php 
				}elseif($f == ($p+6)) {?>
					<input type="button" value="..." onclick="javascript:selectPageSel(<?php echo ($f-1);?>);" /><?php
				}
			}
			?>
			<input type="button" value=">" onclick="javascript:selectPageSel(<?php echo ($PAGE_SEQ_P+1);?>);" />
			<input type="button" value=">>" onclick="javascript:selectPageSel(<?php echo ($f-2);?>);" />
		<?php }?>
</div>
</form>
<form action="<?php echo $PAGE_DELETE;?>" name="formSelect" method="post">
	<input type="hidden" name="rule" id="arule">
</form>
<form action="<?php echo $THISPAGE;?>" name="formShowAll" method="post">
	<input type="hidden" name="showall" id="showall" value="1">
</form>
<form action="<?php echo $THISPAGE;?>" name="formPageSeq" method="post">
	<input type="hidden" name="page_seq" id="page_seq" value="<?php echo $f;?>" />
</form>