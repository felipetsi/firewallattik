<?php 
require_once('../../includes/control_session.php');
$DESTINATION_PAGE = "rule_fw.php";

// Load the profile of user autenticanted
$SQL = "SELECT create_rule FROM controlcenter.profilefw WHERE id IN ";
$SQL .= "(SELECT id_profw FROM controlcenter.profile WHERE id IN (SELECT id_pro FROM ";
$SQL .= "controlcenter.user WHERE id = '$USER'))";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR001F"));
$DATA_USER = mysql_fetch_array($RS);
if ($DATA_USER['create_rule'] == 1){
	$COMMAND = "./.apply_modified.sh";
	exec($COMMAND,$RETURN);
	if (!empty($RETURN)) {
		$_SESSION['SHOW_MSG'] = 'F_FAILURE';
		if ($LOG_AUDITOR == 1) {
			auditor('IFWCY001F', $ADDRIP, $USER, '0');
		}
	}
	else {
		$_SESSION['SHOW_MSG'] = 'F_SUCESS';
	}

} else {
	$_SESSION['SHOW_MSG'] = 'ME_DONTHAVEPERMITION';
}	
header("Location:$DESTINATION_PAGE");
?>