<?php 
require_once('../../includes/control_session.php');

$DESTINATION_PAGE = "position_run_fw.php";
$THISPAGE = "position_fw.php";
$_SESSION['FILE_LANG'] = "firewall.php";

// Load the profile of user autenticanted
$SQL = "SELECT create_net, read_net FROM controlcenter.profilefw WHERE id IN ";
$SQL .= "(SELECT id_profw FROM controlcenter.profile WHERE id IN (SELECT id_pro FROM ";
$SQL .= "controlcenter.user WHERE id = '$USER'))";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSP001F"));
$DATA_USER = mysql_fetch_array($RS);

// Load the item selected
if (!empty($_POST['list']))
{
	$_SESSION['ITEMID'] = $_POST['list'];
	$ITEMID = $_SESSION['ITEMID'];
} else {
	$ITEMID = $_SESSION['ITEMID'];
}
$_SESSION['ITEMDELETE'] = $ITEMID;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $TITLE_FW; ?></title>
<script language="javascript">
var thispage = "position_fw.php";
var deletepage = "position_delete_fw.php";
</script>
<link href="../../includes/style_cc.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php 
require_once('../../includes/top.php');
require_once('fw_menu.php');
?>
<script language="javascript">
function confirmDeleteSelected()
{
	document.getElementById('box_delete').style.display="table";
}
function yesdeleteSelected()
{
	window.location=deletepage;
}
function nodeleteSelected()
{
	document.getElementById('box_delete').style.display="none";
}
</script>
<div id="box_delete"><?php echo("$S_WANT_DELETE?");?> 
	<div class="space_confirm_box">
		<input type="button" value="<?php echo $B_YES;?>" onclick="javascript:yesdeleteSelected();" />
		<input type="button" value="<?php echo $B_NO;?>" onclick="javascript:nodeleteSelected();" />
	</div>	
</div>
<div id="main"> <!--Main-->
<?php require_once('px_menu_configuration.php');?>

	<div id="contet_rigth">
<?php
if ($DATA_USER['create_net'] == 1) {

// Load the user selected
$SQL = "SELECT * FROM cc_firewall.positionfw WHERE id = '$ITEMID'";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSP002F"));
if((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1)){
		auditor('IFWSP002S', $ADDRIP, $USER, '0');
}
$ARRAY = mysql_fetch_array($RS);
?>

<!--Start add-->
<form class="insert_border" action="<?php echo $DESTINATION_PAGE;?>" method="post">
<input type="hidden" name="id" value="<?php echo $ARRAY['id'];?>" />
<div class="title_general_fw" > <?php echo $T_TOPOLOGY; ?> </div>
<div id="contet_rigth_data">
<div align="right" class="left_name"><u><?php echo $F_NAME;?></u></div>
	<div> <input type="text" size="20" maxlength="20" name="name" value="<?php if(!empty($_SESSION['EX_NAME'])) { echo $_SESSION['EX_NAME'];} else { echo $ARRAY['name']; }?>" autocomplete="off"/></div>

<?php /*
<div align="right" class="left_name"><?php echo $F_IMG;?></div>
	<div> <input type="text" size="20" maxlength="100" name="img" value="<?php if (!empty($_SESSION['EX_IMG'])) { echo $_SESSION['EX_IMG'];} else { echo $ARRAY['img'];}?>" autocomplete="off"/></div>
*/?>
	</div>
	<div id="contet_rigth_img">

		<img src="../../@img/icons/topology-128x128.png" />	

	</div>	

<div class="title_general_fw">		
	<input type="submit" value="<?php if (empty($ARRAY['id'])){ echo $B_ADD_NEW;} else { echo $B_UPDATE;}?>" />
	<input type="button" value="<?php echo $B_CLEAR;?>" onclick="javascript:window.location=thispage" />
	<?php
	if (($DATA_USER['create_net'] == 1) && ($DATA_USER['read_net'] == 1)){?>
	<input type="button" value="<?php echo $B_DELETE;?>" onClick="javascript:confirmDeleteSelected();" />
		<font class="alert_small"><?php 
		$SQL = $SQL = "SELECT id FROM cc_firewall.network WHERE id_pfw = '$ITEMID' AND id_pfw != '0'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSP004F"));
		if (mysql_affected_rows() != 0 )
		{
			echo $F_ALERT_REMOVE; 
		}
	} ?></font> 
</div>
</form>
<!--End add-->
<?php }
if ($DATA_USER['read_net'] == 1) {
?>
<!-- Start list-->
<div class="title_general_fw"><?php echo $T_TOPOLOGY_LIST;?></div>
<form class="insert_border" action="<?php echo $THISPAGE;?>" method="post" name="objselect">
<select class="select_list" name="list" size="20" onclick="javascript:document.objselect.submit()">
<?php
	$SQL = "SELECT id, name FROM cc_firewall.positionfw ORDER BY name";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSP003F"));
	$ARRAY = mysql_fetch_array($RS);
	$cor = 1;	
	do{
	if ($ITEMID == $ARRAY['id']) {
		$sel = 'selected="selected"';
	} else {
			$sel = "";
	}
	
	if ( $cor == 1 )
		{
		?>
		<option value="<?php echo $ARRAY['id'];?>" <?php echo $sel;?> ><?php echo $ARRAY['name']; $cor=0?></option>
		<?php 
		} else { ?>
		<option style="background:<?php echo $COLOR_LINE_SELECT;?>" value="<?php echo $ARRAY['id'];?>" <?php echo $sel;?> ><?php echo $ARRAY['name']; $cor=1;?></option>
		<?php
		} 
	}while ($ARRAY =  mysql_fetch_array($RS));?>
</select>
</form>
	</div>
<?php 
}?>
<div class="version_general">
<?php
echo $VERSIONCC;
?>
</div>
</div>
</body>
</html>
<?php
unset($_SESSION['ITEMID']);
unset($_SESSION['EX_NAME']);
unset($_SESSION['EX_IMG']);
?>