<?php 
require_once('../../includes/control_session.php');

$DATE_NOW = date('Y-m-d H:i:s');

//Select the table of page
$TABLE = trim(addslashes($_SESSION['TABLE']));
$DESTINATION_PAGE = "rule_fw.php";

$_SESSION['TRYINSERTRULE'] = 1;
$DIRECTION = substr(trim(addslashes($_POST['direction'])),0,3);
$IDSELECTED = trim(addslashes($_POST['id']));
$_SESSION['ITEMID']	= $IDSELECTED;
$SIFACE = substr(trim(addslashes($_POST['s_interface'])),0,6);
$SOURCE = substr(trim(addslashes($_POST['source'])),0,31);
$DIFACE = substr(trim(addslashes($_POST['d_interface'])),0,6);
$DESTINATION = substr(trim(addslashes($_POST['destination'])),0,31);
$PROTO = substr(trim(addslashes($_POST['proto'])),0,2);
$SPORT = substr(trim(addslashes($_POST['selsport'])),0,5);
if (empty($SPORT))
{
	$SPORT = substr(trim(addslashes($_POST['insport'])),0,5);
}
$DPORT = substr(trim(addslashes($_POST['seldport'])),0,5);
if (empty($DPORT))
{
	$DPORT = substr(trim(addslashes($_POST['indport'])),0,5);
}
$COMMANDADD = substr(trim(addslashes($_POST['selcommandadd'])),0,1);
$TIME_START = substr(trim(addslashes($_POST['hour_start'])),0,2);
$TIME_END = substr(trim(addslashes($_POST['hour_end'])),0,2);
$ACTION = substr(trim(addslashes($_POST['action'])),0,3);
$COMMENT = substr(trim(addslashes($_POST['comment'])),0,50);
$MMAC = replaceMAC(substr(trim(addslashes($_POST['mac'])),0,17));
$MSTRING = substr(trim(addslashes($_POST['string'])),0,127);
$MSMULTIPORT = substr(trim(addslashes($_POST['smultiport'])),0,104);
if (!empty($MSMULTIPORT))
{
	$SPORT = "";
}
$MDMULTIPORT = substr(trim(addslashes($_POST['dmultiport'])),0,104);
if (!empty($MDMULTIPORT))
{
	$DPORT = "";
}
$COUNTS = 16 - sizeof(explode(":",$MSMULTIPORT));
$COUNTD = 16 - sizeof(explode(":",$MDMULTIPORT));

$MSTATE = substr(trim(addslashes($_POST['state'])),0,10);
$MLIMIT = substr(trim(addslashes($_POST['limit'])),0,4);
$UNIT_TIME = substr(trim(addslashes($_POST['type_time'])),0,1);
if (!empty($MLIMIT))
{
	if (empty($UNIT_TIME))
	{
		$UNIT_TIME = "s";
	}
	$MLIMITTEMP = $MLIMIT;
	$MLIMIT = ($MLIMITTEMP."/".$UNIT_TIME);
}
if (empty($COMMANDADD))
{
	$COMMANDADD = "A";
}
$TOADDRESS = substr(trim(addslashes($_POST['toaddress'])),0,15);	
$TOPORT = substr(trim(addslashes($_POST['toport'])),0,5);
$IDTO = substr(trim(addslashes($_POST['idto'])),0,9);
if (($TABLE == "nat")&&(($_SESSION['S_DNAT'] == $ACTION)||($_SESSION['S_SNAT'] == $ACTION)))
{
	if(eregi("[^0-9./]", $TOADDRISVALID, $regs)){
		$TOADDRISVALID = "invalid";
	} else {
		$TOADDRISVALID = verifyIp($TOADDRESS);
	}
} else {
	$TOADDRISVALID = "ok";
}
if(eregi("[^0-9,:]", $TOPORT, $regs)) {
	$TOPORTINVALID = "invalid";
} else {
	$TOPORTINVALID = verifyPort($TOPORT);
}
/*unset($_SESSION['S_DNAT']);
unset($_SESSION['S_SNAT']);*/

// Verify if option selected was to search or add/update
$SEARCH = substr(trim(addslashes($_POST['ind_search'])),0,1);
if ($SEARCH == 1)
{
	unset($_SESSION['SQL_SEARCH']);
	$_SESSION['SQL_SEARCH'] .= "SELECT DISTINCT r.id, r.s_address as source, r.d_address as destination, ";
	$_SESSION['SQL_SEARCH'] .= "r.id_s_iface, r.id_d_iface, r.s_port, r.d_port, ";
	$_SESSION['SQL_SEARCH'] .= "ac.name as action, r.status, r.applied FROM ";
	$_SESSION['SQL_SEARCH'] .= "cc_firewall.rulefw r, cc_firewall.action ac, cc_firewall.direction d WHERE r.id_tab_dir_act IN ";
	$_SESSION['SQL_SEARCH'] .= "(SELECT id FROM cc_firewall.tab_dir_act WHERE id_act = ac.id ";
	if(!empty($DIRECTION)){$_SESSION['SQL_SEARCH'] .= "AND id_dir = '$DIRECTION' ";}
	if(!empty($ACTION)){$_SESSION['SQL_SEARCH'] .= "AND id_act = '$ACTION' ";}

	if(!empty($SIFACE)){$_SESSION['SQL_SEARCH'] .= "AND r.id_s_iface = '$SIFACE' ";}
	if(!empty($DIFACE)){$_SESSION['SQL_SEARCH'] .= "AND r.id_d_iface = '$DIFACE' ";}
	if(!empty($SOURCE)){$_SESSION['SQL_SEARCH'] .= "AND r.s_address = '$SOURCE' ";}
	if(!empty($DESTINATION)){$_SESSION['SQL_SEARCH'] .= "AND r.d_address = '$DESTINATION' ";}
	if(!empty($PROTO)){$_SESSION['SQL_SEARCH'] .= "AND r.id_pro = '$PROTO' ";}
	if(!empty($SPORT)){$_SESSION['SQL_SEARCH'] .= "AND r.s_port = '$SPORT' ";}
	if(!empty($DPORT)){$_SESSION['SQL_SEARCH'] .= "AND r.d_port = '$DPORT' ";}
	if(!empty($COMMANDADD)){$_SESSION['SQL_SEARCH'] .= "AND r.command = '$COMMANDADD' ";}
	if(!empty($COMMENT)){$_SESSION['SQL_SEARCH'] .= "AND r.commentfw = '$COMMENT' ";}
	if(!empty($TIME_START)){$_SESSION['SQL_SEARCH'] .= "AND r.id IN (SELECT id_rul FROM cc_firewall.rul_vartime WHERE status_order = 's' AND id_vartime = '$TIME_START') ";}
	if(!empty($TIME_END)){$_SESSION['SQL_SEARCH'] .= "AND r.id IN (SELECT id_rul FROM cc_firewall.rul_vartime WHERE status_order = 'e' AND id_vartime = '$TIME_END') ";}
	if(!empty($MLIMIT)){$_SESSION['SQL_SEARCH'] .= "AND r.id IN (SELECT id_rul FROM cc_firewall.rul_atr WHERE id_atr IN (SELECT id FROM cc_firewall.atribute_module WHERE name = '$MLIMIT' AND id_mod IN (SELECT id FROM cc_firewall.module WHERE name = 'limit'))) ";}
	if(!empty($MSMULTIPORT)){$_SESSION['SQL_SEARCH'] .= "AND r.id IN (SELECT id_rul FROM cc_firewall.rul_atr WHERE id_atr IN (SELECT id FROM cc_firewall.atribute_module WHERE name = '$MSMULTIPORT' AND id_mod IN (SELECT id FROM cc_firewall.module WHERE name = 'smultiport'))) ";}
	if(!empty($MDMULTIPORT)){$_SESSION['SQL_SEARCH'] .= "AND r.id IN (SELECT id_rul FROM cc_firewall.rul_atr WHERE id_atr IN (SELECT id FROM cc_firewall.atribute_module WHERE name = '$MDMULTIPORT' AND id_mod IN (SELECT id FROM cc_firewall.module WHERE name = 'dmultiport'))) ";}
	if(!empty($MSTRING)){$_SESSION['SQL_SEARCH'] .= "AND r.id IN (SELECT id_rul FROM cc_firewall.rul_atr WHERE id_atr IN (SELECT id FROM cc_firewall.atribute_module WHERE name = '$MSTRING' AND id_mod IN (SELECT id FROM cc_firewall.module WHERE name = 'string'))) ";}
	if(!empty($MMAC)){$_SESSION['SQL_SEARCH'] .= "AND r.id IN (SELECT id_rul FROM cc_firewall.rul_atr WHERE id_atr IN (SELECT id FROM cc_firewall.atribute_module WHERE name = '$MMAC' AND id_mod IN (SELECT id FROM cc_firewall.module WHERE name = 'mac'))) ";}
	$STATES = explode("@",$MSTATE);
	for($f=0; $f < sizeof($STATES); $f++)
	{
		$STATE = $STATES[$f];
		if(!empty($STATE)){$_SESSION['SQL_SEARCH'] .= "AND r.id IN (SELECT id_rul FROM cc_firewall.rul_atr WHERE id_atr IN (SELECT id FROM cc_firewall.atribute_module WHERE id = '$STATE' AND id_mod IN (SELECT id FROM cc_firewall.module WHERE name = 'state'))) ";}
	}
	if(!empty($TOADDRESS)){$_SESSION['SQL_SEARCH'] .= "AND r.id IN (SELECT id_rul FROM cc_firewall.rule_extend WHERE extend1 = '$TOADDRESS') ";}
	if(!empty($TOPORT)){$_SESSION['SQL_SEARCH'] .= "AND r.id IN (SELECT id_rul FROM cc_firewall.rule_extend WHERE extend2 = '$TOPORT') ";}
	header("Location:$DESTINATION_PAGE");
}
else 
{
	if (empty($DIRECTION) || empty($ACTION))
		{
			$_SESSION['SHOW_MSG'] = 'ME_NEEDFILL';
			$_SESSION['DIRECTION'] = $DIRECTION;
			$_SESSION['SIFACE'] = $SIFACE;
			$_SESSION['SOURCE'] = $SOURCE;
			$_SESSION['DIFACE'] = $DIFACE;
			$_SESSION['DESTINATION'] = $DESTINATION;
			$_SESSION['DPORT'] = $DPORT;
			$_SESSION['SPORT'] = $SPORT;
			$_SESSION['PROTO'] = $PROTO;
			$_SESSION['COMMANDADD'] = $COMMANDADD;
			$_SESSION['TIMESTART'] = $TIME_START;
			$_SESSION['TIMEEND'] = $TIME_END;
			$_SESSION['COMMENT'] = $COMMENT;
			$_SESSION['limit'] = $MLIMIT;
			$_SESSION['state'] = $MSTATE;
			$_SESSION['mac'] = $MMAC;
			$_SESSION['string'] = $MSTRING;
			$_SESSION['smultiport'] = $MSMULTIPORT;
			$_SESSION['dmultiport'] = $MDMULTIPORT;
			$_SESSION['EXTEND1'] = $TOADDRESS;
			$_SESSION['EXTEND2'] = $TOPORT;
			$_SESSION['ACTION'] = $ACTION;
			header("Location:$DESTINATION_PAGE");
		}
	elseif(eregi("[^0-9]", $MLIMITTEMP, $regs))
		{
			$_SESSION['SHOW_MSG'] = 'ME_INVALIDLIMITDIGITED';
			$_SESSION['DIRECTION'] = $DIRECTION;
			$_SESSION['SIFACE'] = $SIFACE;
			$_SESSION['SOURCE'] = $SOURCE;
			$_SESSION['DIFACE'] = $DIFACE;
			$_SESSION['DESTINATION'] = $DESTINATION;
			$_SESSION['DPORT'] = $DPORT;
			$_SESSION['SPORT'] = $SPORT;
			$_SESSION['PROTO'] = $PROTO;
			$_SESSION['COMMANDADD'] = $COMMANDADD;
			$_SESSION['TIMESTART'] = $TIME_START;
			$_SESSION['TIMEEND'] = $TIME_END;
			$_SESSION['COMMENT'] = $COMMENT;
			$_SESSION['limit'] = $MLIMIT;
			$_SESSION['state'] = $MSTATE;
			$_SESSION['mac'] = $MMAC;
			$_SESSION['string'] = $MSTRING;
			$_SESSION['smultiport'] = $MSMULTIPORT;
			$_SESSION['dmultiport'] = $MDMULTIPORT;
			$_SESSION['EXTEND1'] = $TOADDRESS;
			$_SESSION['EXTEND2'] = $TOPORT;
			$_SESSION['ACTION'] = $ACTION;
			header("Location:$DESTINATION_PAGE");
		}
	elseif((eregi("[^0-9,:]", $MSMULTIPORT, $regs))||(eregi("[^0-9,:]", $MDMULTIPORT, $regs) )||(eregi("[^0-9,:]", $DPORT, $regs) )||(eregi("[^0-9,:]", $SPORT, $regs) ))
		{
			$_SESSION['SHOW_MSG'] = 'ME_INVALIDPORTDIGITED';
			$_SESSION['DIRECTION'] = $DIRECTION;
			$_SESSION['SIFACE'] = $SIFACE;
			$_SESSION['SOURCE'] = $SOURCE;
			$_SESSION['DIFACE'] = $DIFACE;
			$_SESSION['DESTINATION'] = $DESTINATION;
			$_SESSION['DPORT'] = $DPORT;
			$_SESSION['SPORT'] = $SPORT;
			$_SESSION['PROTO'] = $PROTO;
			$_SESSION['COMMANDADD'] = $COMMANDADD;
			$_SESSION['TIMESTART'] = $TIME_START;
			$_SESSION['TIMEEND'] = $TIME_END;
			$_SESSION['COMMENT'] = $COMMENT;
			$_SESSION['limit'] = $MLIMIT;
			$_SESSION['state'] = $MSTATE;
			$_SESSION['mac'] = $MMAC;
			$_SESSION['string'] = $MSTRING;
			$_SESSION['smultiport'] = $MSMULTIPORT;
			$_SESSION['dmultiport'] = $MDMULTIPORT;
			$_SESSION['EXTEND1'] = $TOADDRESS;
			$_SESSION['EXTEND2'] = $TOPORT;
			$_SESSION['ACTION'] = $ACTION;
			header("Location:$DESTINATION_PAGE");
		}
	elseif ((!empty($TIME_START) && (empty($TIME_END))) || (empty($TIME_START) && (!empty($TIME_END))))
		{
			$_SESSION['SHOW_MSG'] = 'ME_NEEDSELECTSTARTANDENDTIME';
			$_SESSION['DIRECTION'] = $DIRECTION;
			$_SESSION['SIFACE'] = $SIFACE;
			$_SESSION['SOURCE'] = $SOURCE;
			$_SESSION['DIFACE'] = $DIFACE;
			$_SESSION['DESTINATION'] = $DESTINATION;
			$_SESSION['DPORT'] = $DPORT;
			$_SESSION['SPORT'] = $SPORT;
			$_SESSION['PROTO'] = $PROTO;
			$_SESSION['COMMANDADD'] = $COMMANDADD;
			$_SESSION['TIMESTART'] = $TIME_START;
			$_SESSION['TIMEEND'] = $TIME_END;
			$_SESSION['COMMENT'] = $COMMENT;
			$_SESSION['limit'] = $MLIMIT;
			$_SESSION['state'] = $MSTATE;
			$_SESSION['mac'] = $MMAC;
			$_SESSION['string'] = $MSTRING;
			$_SESSION['smultiport'] = $MSMULTIPORT;
			$_SESSION['dmultiport'] = $MDMULTIPORT;
			$_SESSION['EXTEND1'] = $TOADDRESS;
			$_SESSION['EXTEND2'] = $TOPORT;
			$_SESSION['ACTION'] = $ACTION;
			header("Location:$DESTINATION_PAGE");
		}
	elseif(((!empty($SOURCE)) && ($SOURCE != "0.0.0.0") && (verifyIp($SOURCE) != "ok")) || 
		((!empty($DESTINATION)) && ($DESTINATION != "0.0.0.0") && (verifyIp($DESTINATION) != "ok")) || 
		($TOADDRISVALID != "ok" ) || (eregi("[^0-9./]", $SOURCE, $regs)) || (eregi("[^0-9./]", $DESTINATION, $regs)) )
		{
			$_SESSION['SHOW_MSG'] = 'ME_INVALIDIP';
			$_SESSION['DIRECTION'] = $DIRECTION;
			$_SESSION['SIFACE'] = $SIFACE;
			$_SESSION['SOURCE'] = $SOURCE;
			$_SESSION['DIFACE'] = $DIFACE;
			$_SESSION['DESTINATION'] = $DESTINATION;
			$_SESSION['DPORT'] = $DPORT;
			$_SESSION['SPORT'] = $SPORT;
			$_SESSION['PROTO'] = $PROTO;
			$_SESSION['COMMANDADD'] = $COMMANDADD;
			$_SESSION['TIMESTART'] = $TIME_START;
			$_SESSION['TIMEEND'] = $TIME_END;
			$_SESSION['COMMENT'] = $COMMENT;
			$_SESSION['limit'] = $MLIMIT;
			$_SESSION['state'] = $MSTATE;
			$_SESSION['mac'] = $MMAC;
			$_SESSION['string'] = $MSTRING;
			$_SESSION['smultiport'] = $MSMULTIPORT;
			$_SESSION['dmultiport'] = $MDMULTIPORT;
			$_SESSION['EXTEND1'] = $TOADDRESS;
			$_SESSION['EXTEND2'] = $TOPORT;
			$_SESSION['ACTION'] = $ACTION;
			header("Location:$DESTINATION_PAGE");
		}
	elseif(($MMAC != "") && (verifyMAC($MMAC) != "ok"))
		{
			$_SESSION['SHOW_MSG'] = 'ME_INVALIDMAC';
			$_SESSION['DIRECTION'] = $DIRECTION;
			$_SESSION['SIFACE'] = $SIFACE;
			$_SESSION['SOURCE'] = $SOURCE;
			$_SESSION['DIFACE'] = $DIFACE;
			$_SESSION['DESTINATION'] = $DESTINATION;
			$_SESSION['DPORT'] = $DPORT;
			$_SESSION['SPORT'] = $SPORT;
			$_SESSION['PROTO'] = $PROTO;
			$_SESSION['COMMANDADD'] = $COMMANDADD;
			$_SESSION['TIMESTART'] = $TIME_START;
			$_SESSION['TIMEEND'] = $TIME_END;
			$_SESSION['COMMENT'] = $COMMENT;
			$_SESSION['limit'] = $MLIMIT;
			$_SESSION['state'] = $MSTATE;
			$_SESSION['mac'] = $MMAC;
			$_SESSION['string'] = $MSTRING;
			$_SESSION['smultiport'] = $MSMULTIPORT;
			$_SESSION['dmultiport'] = $MDMULTIPORT;
			$_SESSION['EXTEND1'] = $TOADDRESS;
			$_SESSION['EXTEND2'] = $TOPORT;
			$_SESSION['ACTION'] = $ACTION;
			header("Location:$DESTINATION_PAGE");
		}
	elseif(((!empty($DPORT)) && (verifyPort($DPORT) != "ok")) || ((!empty($SPORT)) && (verifyPort($SPORT) != "ok")) ||
		((!empty($MSMULTIPORT)) && (verifyPort($MSMULTIPORT) != "ok")) || ((!empty($MDMULTIPORT)) && 
		(verifyPort($MDMULTIPORT) != "ok")) || $TOPORTINVALID != "ok")
		{
			$_SESSION['SHOW_MSG'] = 'ME_INVALIDSOMEPORT';
			$_SESSION['DIRECTION'] = $DIRECTION;
			$_SESSION['SIFACE'] = $SIFACE;
			$_SESSION['SOURCE'] = $SOURCE;
			$_SESSION['DIFACE'] = $DIFACE;
			$_SESSION['DESTINATION'] = $DESTINATION;
			$_SESSION['DPORT'] = $DPORT;
			$_SESSION['SPORT'] = $SPORT;
			$_SESSION['PROTO'] = $PROTO;
			$_SESSION['COMMANDADD'] = $COMMANDADD;
			$_SESSION['TIMESTART'] = $TIME_START;
			$_SESSION['TIMEEND'] = $TIME_END;
			$_SESSION['COMMENT'] = $COMMENT;
			$_SESSION['limit'] = $MLIMIT;
			$_SESSION['state'] = $MSTATE;
			$_SESSION['mac'] = $MMAC;
			$_SESSION['string'] = $MSTRING;
			$_SESSION['smultiport'] = $MSMULTIPORT;
			$_SESSION['dmultiport'] = $MDMULTIPORT;
			$_SESSION['EXTEND1'] = $TOADDRESS;
			$_SESSION['EXTEND2'] = $TOPORT;
			$_SESSION['ACTION'] = $ACTION;
			header("Location:$DESTINATION_PAGE");
		}
	elseif((sizeof(explode(",",$MSMULTIPORT)) > $COUNTS)||(sizeof(explode(",",$MDMULTIPORT)) > $COUNTS))
		{
			$_SESSION['SHOW_MSG'] = 'ME_OVER_FLOW_PORT';
			$_SESSION['DIRECTION'] = $DIRECTION;
			$_SESSION['SIFACE'] = $SIFACE;
			$_SESSION['SOURCE'] = $SOURCE;
			$_SESSION['DIFACE'] = $DIFACE;
			$_SESSION['DESTINATION'] = $DESTINATION;
			$_SESSION['DPORT'] = $DPORT;
			$_SESSION['SPORT'] = $SPORT;
			$_SESSION['PROTO'] = $PROTO;
			$_SESSION['COMMANDADD'] = $COMMANDADD;
			$_SESSION['TIMESTART'] = $TIME_START;
			$_SESSION['TIMEEND'] = $TIME_END;
			$_SESSION['COMMENT'] = $COMMENT;
			$_SESSION['limit'] = $MLIMIT;
			$_SESSION['state'] = $MSTATE;
			$_SESSION['mac'] = $MMAC;
			$_SESSION['string'] = $MSTRING;
			$_SESSION['smultiport'] = $MSMULTIPORT;
			$_SESSION['dmultiport'] = $MDMULTIPORT;
			$_SESSION['EXTEND1'] = $TOADDRESS;
			$_SESSION['EXTEND2'] = $TOPORT;
			$_SESSION['ACTION'] = $ACTION;
			header("Location:$DESTINATION_PAGE");
		}
	else
		{
			$SQL = "SELECT id FROM cc_firewall.action WHERE (name = 'DNAT' OR name = 'SNAT') AND id = '$ACTION'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR052F"));
			if ( (mysql_affected_rows() != 0) && (empty($TOADDRESS) && (empty($TOPORT)) ) )
			{
				$_SESSION['SHOW_MSG'] = 'ME_NEEDFILLADDRORPORT';
				$_SESSION['DIRECTION'] = $DIRECTION;
				$_SESSION['SIFACE'] = $SIFACE;
				$_SESSION['SOURCE'] = $SOURCE;
				$_SESSION['DIFACE'] = $DIFACE;
				$_SESSION['DESTINATION'] = $DESTINATION;
				$_SESSION['DPORT'] = $DPORT;
				$_SESSION['SPORT'] = $SPORT;
				$_SESSION['PROTO'] = $PROTO;
				$_SESSION['COMMANDADD'] = $COMMANDADD;
				$_SESSION['TIMESTART'] = $TIME_START;
				$_SESSION['TIMEEND'] = $TIME_END;
				$_SESSION['COMMENT'] = $COMMENT;
				$_SESSION['limit'] = $MLIMIT;
				$_SESSION['state'] = $MSTATE;
				$_SESSION['mac'] = $MMAC;
				$_SESSION['string'] = $MSTRING;
				$_SESSION['smultiport'] = $MSMULTIPORT;
				$_SESSION['dmultiport'] = $MDMULTIPORT; 
				$_SESSION['EXTEND1'] = $TOADDRESS;
				$_SESSION['EXTEND2'] = $TOPORT;
				$_SESSION['ACTION'] = $ACTION;
				header("Location:$DESTINATION_PAGE");
			}
			else
			{
				// Test and if need apply the default command
				if (empty($COMMANDADD))
				{
					$COMMANDADD = "A";
				}
				
				//Select the associated beteween Table, Direction and Action
				$SQL = "SELECT tda.id, d.name as direction, a.name as action FROM ";
				$SQL .= "cc_firewall.tab_dir_act tda, cc_firewall.direction d, cc_firewall.action a ";
				$SQL .= "WHERE d.id = tda.id_dir AND a.id = tda.id_act AND d.id = '$DIRECTION' AND a.id = '$ACTION' AND ";
				$SQL .= "id_tab IN (SELECT id FROM cc_firewall.tablefw WHERE name = '$TABLE')";
				
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR002F"));
				$ARRAY = mysql_fetch_array($RS);
				$ID_TAB_DIR_ACT = $ARRAY['id'];
				$DIRECTION = $ARRAY['direction'];
				$ACTION = $ARRAY['action'];
				
				$STATES = explode("@",$MSTATE);

				$SQL = "SELECT name FROM controlcenter.interface WHERE id = '$SIFACE'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR056F"));
				$ARRAY = mysql_fetch_array($RS);
				$SIFACENAME = $ARRAY['name'];
				$SQL = "SELECT name FROM controlcenter.interface WHERE id = '$DIFACE'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR057F"));
				$ARRAY = mysql_fetch_array($RS);
				$DIFACENAME = $ARRAY['name'];
				$SQL = "SELECT name FROM cc_firewall.protocol WHERE id = '$PROTO'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR058F"));
				$ARRAY = mysql_fetch_array($RS);
				$PROTOCOL = $ARRAY['name'];
				// Mount the rule in one line
				$RULE = "-t $TABLE -$COMMANDADD $DIRECTION ";
				if (!empty($SOURCE)){ $RULE .= "-s $SOURCE ";}
				if (!empty($DESTINATION)){ $RULE .= "-d $DESTINATION ";}
				if (!empty($SIFACENAME)){ $RULE .= "-i $SIFACENAME ";}
				if (!empty($DIFACENAME)){ $RULE .= "-o $DIFACENAME ";}
				if (!empty($PROTOCOL)){ $RULE .= "-p $PROTOCOL ";}
				if (!empty($MSMULTIPORT)){ $RULE .= "-m multiport --sport $MSMULTIPORT ";}
					elseif (!empty($SPORT)){ $RULE .= "-m multiport --sport $SPORT ";}
				if (!empty($MDMULTIPORT)){ $RULE .= "-m multiport --dport $MDMULTIPORT ";}
					elseif (!empty($DPORT)){ $RULE .= "-m multiport --dport $DPORT ";}
				if (!empty($MLIMIT)){ $RULE .= "-m limit --limit $MLIMIT ";}
				if (!empty($MMAC)){ $RULE .= "-m mac --mac-source $MMAC ";}
				if (!empty($MSTRING)){ $RULE .= '-m string --algo bm --string "'.$MSTRING.'" ';}
				if (!empty($MSTATE)){ 
					$MSTATE = "";
					for ($f = 0; $f < sizeof($STATES); $f++)
					{
						$ID = $STATES[$f];
						$SQL = "SELECT name FROM cc_firewall.atribute_module WHERE id = '$ID'";
						$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR054F"));
						$ARRAY = mysql_fetch_array($RS);
						if ($f != (sizeof($STATES)-1)) {
							$MSTATE .= $ARRAY['name'].",";
						} else {
							$MSTATE .= $ARRAY['name'];
						}
					}
					$RULE .= "-m state --state $MSTATE ";
				}
				if (($TABLE == "nat") || ($TABLE == "filter")) {
					if (!empty($ACTION)){ $RULE .= "-j $ACTION ";}
					if ($TABLE == "nat") {
						if ((!empty($TOADDRESS))&&(!empty($TOPORT))){ 
							if($ACTION == "SNAT"){
								$RULE .= "--to-source $TOADDRESS:$TOPORT";
								}
							elseif($ACTION == "DNAT"){
								$RULE .= "--to-destination $TOADDRESS:$TOPORT";
								}
							elseif($ACTION == "REDIRECT") {
								$RULE .= "--to $TOADDRESS:$TOPORT";
							}
						}
						elseif ((!empty($TOADDRESS))&&(empty($TOPORT))){
							if($ACTION == "SNAT"){
								$RULE .= "--to-source $TOADDRESS";
								}
							elseif($ACTION == "DNAT"){
								$RULE .= "--to-destination $TOADDRESS";
								}
							elseif($ACTION == "REDIRECT") {
								$RULE .= "--to $TOADDRESS";
							}
						}
						elseif((empty($TOADDRESS))&&(!empty($TOPORT))) {
							$RULE .= "--to-port $TOPORT";
						}
					}
				}
				else{
					if (!empty($ACTION)){
						$RULE .= "-j ".substr($ACTION,0,3)." --set-tos ".substr($ACTION,3,4);
					}
				}
					//Insert the rule
					if (empty($IDSELECTED))
						{
							$SQL = "INSERT INTO cc_firewall.rulefw (id_s_iface, id_d_iface, s_address, d_address, id_pro, ";
							$SQL .= "s_port, d_port, command, id_tab_dir_act, id_user, commentfw, date_created, last_update, ";
							$SQL .= "status, applied) ";
							$SQL .= "VALUE ('$SIFACE', '$DIFACE','$SOURCE', '$DESTINATION', '$PROTO', ";
							$SQL .= "'$SPORT', '$DPORT', '$COMMANDADD', '$ID_TAB_DIR_ACT', '$USER', '$COMMENT', '$DATE_NOW', ";
							$SQL .= "'$DATE_NOW','1','0')";
							$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR004F"));
							
							$ID_RULE = mysql_insert_id();
							if ($TABLE == "nat")
							{
								if ((!empty($ID_RULE)) && (!empty($TOADDRESS)) && (!empty($TOPORT)))
								{
									$SQL = "INSERT INTO cc_firewall.rule_extend (id_rul, extend1, extend2) VALUES ";
									$SQL .= "('$ID_RULE', '$TOADDRESS', '$TOPORT')";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR005F"));
								}
								elseif ((!empty($ID_RULE)) && (!empty($TOADDRESS)) && (empty($TOPORT)))
								{
									$SQL = "INSERT INTO cc_firewall.rule_extend (id_rul, extend1) VALUES ";
									$SQL .= "('$ID_RULE', '$TOADDRESS')";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR006F"));
								}
								elseif ((!empty($ID_RULE)) && (empty($TOADDRESS)) && (!empty($TOPORT)))
								{
									$SQL = "INSERT INTO cc_firewall.rule_extend (id_rul, extend2) VALUES ";
									$SQL .= "('$ID_RULE', '$TOPORT')";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR007F"));
								}
							}
							if (!empty($TIME_START))
								{
									//Insert the start time
									$SQL = "INSERT INTO cc_firewall.rul_vartime (id_rul, id_vartime, status_order) ";
									$SQL .= "VALUES ('$ID_RULE', '$TIME_START','s')";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR008F"));
									// Insert the end time
									$SQL = "INSERT INTO cc_firewall.rul_vartime (id_rul, id_vartime, status_order) ";
									$SQL .= "VALUES ('$ID_RULE', '$TIME_END','e')";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR009F"));
								}
		/*						for ($count = 0; $count < sizeof($STATES); $count++)
								{
								
								}*/
							for ($count = 0; $count < sizeof($STATES); $count++)
								{
									$ID_ATR = $STATES[$count];
									$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
									$SQL .= "('$ID_RULE', '$ID_ATR')";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR010F"));
								}
							if (!empty($MLIMIT))
							{
								$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'limit'";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR011F"));
								if (mysql_affected_rows() != 0)
								{
									$ARRAY = mysql_fetch_array($RS);
									$ID = $ARRAY['id'];
									$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
									$SQL .= "('$ID', '$MLIMIT')";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR012F"));
									if (mysql_affected_rows() != 0)
									{
										$ID = mysql_insert_id();
										$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
										$SQL .= "('$ID_RULE', '$ID')";
										$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR013F"));
									}
								}
							}
							if (!empty($MMAC))
							{
								$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'mac'";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR014F"));
								if (mysql_affected_rows() != 0) 
								{
									$ARRAY = mysql_fetch_array($RS);
									$ID = $ARRAY['id'];
									$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
									$SQL .= "('$ID', '$MMAC')";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR015F"));
									if (mysql_affected_rows() != 0)
									{
										$ID = mysql_insert_id();
										$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
										$SQL .= "('$ID_RULE', '$ID')";
										$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR016F"));
									}								
								}
							}
							if (!empty($MSTRING))
							{
								$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'string'";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR017F"));
								if (mysql_affected_rows() != 0) 
								{
									$ARRAY = mysql_fetch_array($RS);
									$ID = $ARRAY['id'];
									$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
									$SQL .= "('$ID', '$MSTRING')";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR018F"));
									if (mysql_affected_rows() != 0)
									{
										$ID = mysql_insert_id();
										$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
										$SQL .= "('$ID_RULE', '$ID')";
										$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR019F"));
									}
								}
							}
							if (!empty($MSMULTIPORT))
							{
								$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'smultiport'";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR020F"));
								if (mysql_affected_rows() != 0) 
								{
									$ARRAY = mysql_fetch_array($RS);
									$ID = $ARRAY['id'];
									$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
									$SQL .= "('$ID', '$MSMULTIPORT')";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR021F"));
									if (mysql_affected_rows() != 0)
									{
										$ID = mysql_insert_id();
										$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
										$SQL .= "('$ID_RULE', '$ID')";
										$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR022F"));
									}
								}
							}
							if (!empty($MDMULTIPORT))
							{
								$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'dmultiport'";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR023F"));
								if (mysql_affected_rows() != 0) 
								{
									$ARRAY = mysql_fetch_array($RS);
									$ID = $ARRAY['id'];
									$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
									$SQL .= "('$ID', '$MDMULTIPORT')";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR024F"));
									if (mysql_affected_rows() != 0)
									{
										$ID = mysql_insert_id();
										$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
										$SQL .= "('$ID_RULE', '$ID')";
										$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR025F"));
									}
								}
							}
						

								// Insert the rule in table to execute
								$SQL = "INSERT INTO cc_firewall.rulefwrun (id, name) VALUES ('$ID_RULE', '$RULE')";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR055F"));
						}
						else
							{
							$SQL = "UPDATE cc_firewall.rulefw SET id_s_iface='$SIFACE', id_d_iface='$DIFACE', ";
							$SQL .= "s_address='$SOURCE', d_address='$DESTINATION', id_pro='$PROTO', ";
							$SQL .= "s_port='$SPORT', d_port='$DPORT', command='$COMMANDADD', id_tab_dir_act='$ID_TAB_DIR_ACT', ";
							$SQL .= "id_user='$USER', commentfw='$COMMENT', last_update='$DATE_NOW', applied = '0' ";
							$SQL .= "WHERE id = '$IDSELECTED'";
							$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR026F"));
							
							//Store the value of variable tha will be used after
							$ID_RULE = $IDSELECTED;
							
							// If table nat insert the extends digited
							if ($TABLE == "nat")
							{
		//						if ((!empty($TOADDRESS)) && (!empty($TOPORT)))
		//						{
									$SQL = "UPDATE cc_firewall.rule_extend SET id_rul='$IDSELECTED', ";
									$SQL .= "extend1='$TOADDRESS', extend2='$TOPORT' WHERE id = '$IDTO'";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR027F"));
		//						}
		//						elseif ((!empty($ID_RULE)) && (!empty($TOADDRESS)) && (empty($TOPORT)))
		//						{
		//							$SQL = "UPDATE cc_firewall.rule_extend SET id_rul='$IDSELECTED', ";
		//							$SQL .= "extend1='$TOADDRESS' WHERE id = '$IDTO'";
		//							$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR028F"));
		//						}
		//						elseif ((!empty($ID_RULE)) && (empty($TOADDRESS)) && (!empty($TOPORT)))
		//						{
		//							$SQL = "UPDATE cc_firewall.rule_extend SET id_rul='$IDSELECTED', ";
		//							$SQL .= "extend2='$TOPORT' WHERE id = '$IDTO'";
		//							$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR029F"));
		//						}
							}
							
							// Delete the variable time refereced in rule
							$SQL = "DELETE FROM cc_firewall.rul_vartime WHERE id_rul = '$ID_RULE'";
							$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR030F"));
							
							//Insert the start time
							$SQL = "INSERT INTO cc_firewall.rul_vartime (id_rul, id_vartime, status_order) ";
							$SQL .= "VALUES ('$IDSELECTED', '$TIME_START','s')";
							$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR031F"));
							// Insert the end time
							$SQL = "INSERT INTO cc_firewall.rul_vartime (id_rul, id_vartime, status_order) ";
							$SQL .= "VALUES ('$IDSELECTED', '$TIME_END','e')";
							$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR032F"));
							
							// Delete the attributes
							$SQL = "DELETE FROM cc_firewall.atribute_module WHERE id IN (SELECT id_atr FROM ";
							$SQL .= "cc_firewall.rul_atr WHERE id_rul = '$IDSELECTED') AND id_mod IN (SELECT id FROM ";
							$SQL .= "cc_firewall.module WHERE definitive <> '1')";
							$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR033F"));
							
							// Delete the associated (rul_atr)
							$SQL = "DELETE FROM cc_firewall.rul_atr WHERE id_rul = '$IDSELECTED'";
							$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR034F"));
							
							$ID_RULE = $IDSELECTED;
							for ($count = 0; $count < sizeof($STATES); $count++)
								{
									$ID_ATR = $STATES[$count];
									$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
									$SQL .= "('$ID_RULE', '$ID_ATR')";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR035F"));
								}
							if (!empty($MLIMIT))
							{
								$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'limit'";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR036F"));
								if (mysql_affected_rows() != 0) 
								{
									$ARRAY = mysql_fetch_array($RS);
									$ID = $ARRAY['id'];
									$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
									$SQL .= "('$ID', '$MLIMIT')";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR037F"));
									if (mysql_affected_rows() != 0)
									{
										$ID = mysql_insert_id();
										$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
										$SQL .= "('$ID_RULE', '$ID')";
										$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR038F"));
									}
								}
							}
							if (!empty($MMAC))
							{
								$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'mac'";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR039F"));
								if (mysql_affected_rows() != 0) 
								{
									$ARRAY = mysql_fetch_array($RS);
									$ID = $ARRAY['id'];
									$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
									$SQL .= "('$ID', '$MMAC')";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR040F"));
									if (mysql_affected_rows() != 0)
									{
										$ID = mysql_insert_id();
										$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
										$SQL .= "('$ID_RULE', '$ID')";
										$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR041F"));
									}								
								}
							}
							if (!empty($MSTRING))
							{
								$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'string'";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR042F"));
								if (mysql_affected_rows() != 0) 
								{
									$ARRAY = mysql_fetch_array($RS);
									$ID = $ARRAY['id'];
									$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
									$SQL .= "('$ID', '$MSTRING')";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR043F"));
									if (mysql_affected_rows() != 0)
									{
										$ID = mysql_insert_id();
										$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
										$SQL .= "('$ID_RULE', '$ID')";
										$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR044F"));
									}
								}
							}
							if (!empty($MSMULTIPORT))
							{
								$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'smultiport'";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR045F"));
								if (mysql_affected_rows() != 0) 
								{
									$ARRAY = mysql_fetch_array($RS);
									$ID = $ARRAY['id'];
									$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
									$SQL .= "('$ID', '$MSMULTIPORT')";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR046F"));
									if (mysql_affected_rows() != 0)
									{
										$ID = mysql_insert_id();
										$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
										$SQL .= "('$ID_RULE', '$ID')";
										$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR047F"));
									}
								}
							}
							if (!empty($MDMULTIPORT))
							{
								$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'dmultiport'";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR048F"));
								if (mysql_affected_rows() != 0) 
								{
									$ARRAY = mysql_fetch_array($RS);
									$ID = $ARRAY['id'];
									$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
									$SQL .= "('$ID', '$MDMULTIPORT')";
									$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR049F"));
									if (mysql_affected_rows() != 0)
									{
										$ID = mysql_insert_id();
										$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
										$SQL .= "('$ID_RULE', '$ID')";
										$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR050F"));
									}
								}
							}
						
								// Update the rule in table to execute
								$SQL = "UPDATE cc_firewall.rulefwrun SET name='$RULE' WHERE id = '$IDSELECTED'";
								$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR055F"));
						}
						if (mysql_affected_rows() != 0) 
							{
								if($LOG_AUDITOR == 1){
										auditor('IFWXR051S', $ADDRIP, $USER, '0');
								}
								$_SESSION['SHOW_MSG'] = 'F_SUCESS';
								unset($_SESSION['DIRECTION']);
							} 
						else 
							{
								if($LOG_AUDITOR == 1){
										auditor('IFWXR051F', $ADDRIP, $USER, '0');
								}
								$_SESSION['SHOW_MSG'] = 'F_FAILURE';
							}
				header("Location:$DESTINATION_PAGE");
		}
	}
}
?>