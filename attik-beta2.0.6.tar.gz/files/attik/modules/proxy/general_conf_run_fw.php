<?php 
require_once('../../includes/control_session.php');
require_once('includes/functions.php');
$DESTINATION_PAGE = "general_conf_fw.php";

$ID = trim(addslashes($_POST['id']));
$ACTION = trim(addslashes($_POST['action']));

if ((empty($ID)) or (empty($ACTION))) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDSELECT';
	$_SESSION['ITEMID'] = $ID;
	$_SESSION['EX_ACTION'] = $ACTION;
	header("Location:$DESTINATION_PAGE");	
}
else {
	if (empty($ACTION))
	{
		$SQL = "SELECT id FROM cc_firewall.action WHERE name = 'DROP'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG005F"));
		$ARRAY = mysql_fetch_array($RS);
		$ACTION = $ARRAY['id'];
	}
		$SQL = "UPDATE cc_firewall.policyfw SET id_act='$ACTION' WHERE id = '$ID'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUG006F"));
		
		if (mysql_affected_rows() != 0) {
			if($LOG_AUDITOR == 1){
					auditor('IFWUG006S', $ADDRIP, $USER, '0');
			}
			$SQL = "SELECT a.name as action, d.name as direction FROM cc_firewall.action a, cc_firewall.direction d  WHERE ";
			$SQL .= "a.id IN (SELECT id_act FROM cc_firewall.policyfw WHERE id = '$ID') AND d.id IN ";
			$SQL .= "(SELECT id_dir FROM cc_firewall.policyfw WHERE id = '$ID')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG116F"));
			$ARRAY = mysql_fetch_array($RS);
			alterDefaultPolicy($ARRAY['action'],$ARRAY['direction']);
//			if(alterDefaultPolicy($ARRAY['action'],$ARRAY['direction']) == "ok") {
				$_SESSION['SHOW_MSG'] = 'F_SUCESS';
/*			} else {
				if($LOG_AUDITOR == 1){
						auditor('IFWSG117F', $ADDRIP, $USER, '0');
				}
				$_SESSION['SHOW_MSG'] = 'F_FAILURE';
			}*/
		} else {
			if($LOG_AUDITOR == 1){
				auditor('IFWUG006F', $ADDRIP, $USER, '0');
			}
			$_SESSION['SHOW_MSG'] = 'F_FAILURE';
		}
		header("Location:$DESTINATION_PAGE");
}
?>