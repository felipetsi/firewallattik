<?php
require_once('../../includes/control_session.php');

$THISPAGE = "select_services_run_fw.php";
$IPTABLES = "iptables";
$DESTINATION_PAGE = "select_services_fw.php";
$_SESSION['FILE_LANG'] = "firewall.php";
$USER = $_SESSION['USER'];

// Esta vari�vel ir� conter a tabela do iptables, se ela estiver v�zia � porque n�o veio de uma p�gina que configura redirecionamento, nat ou mangle, ent�o a tabela filter � assumida por padr�o.
$FWTABLE = $_POST['fwtable'];
if (empty($FWTABLE)){
	$FWTABLE = "filter";
}

$PROTOCOL = $_POST['protocol'];

$ID_SNET = $_SESSION['IDNET'];
$ID_DNET = $_SESSION['IDNETASSOCIATED'];
$S_MULTIPORT_PORT = '1023:65535';
$DATE_NOW = date('Y-m-d H:i:s');
$ACTION = "ACCEPT";

//Verify if is net between server or net between net. If variable session equals 1, is net between server.
if (empty($_SESSION['PG_SERVER_NET'])) {
	$SQL = "SELECT class, mask, id_ifa FROM cc_firewall.network WHERE id = '$ID_SNET'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB009F"));
	$ARRAY = mysql_fetch_array($RS);
	if (!empty($ARRAY['mask'])){
		$SNET = $ARRAY['class']."/".$ARRAY['mask'];
	} else {
		$SNET = $ARRAY['class'];
	}	
	$ID_S_IFA = $ARRAY['id_ifa'];
	$SQL = "SELECT class, mask, id_ifa FROM cc_firewall.network WHERE id = '$ID_DNET'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB010F"));
	$ARRAY = mysql_fetch_array($RS);
	if (!empty($ARRAY['mask'])){
		$DNET = $ARRAY['class']."/".$ARRAY['mask'];
	} else {
		$DNET = $ARRAY['class'];
	}
	$ID_D_IFA = $ARRAY['id_ifa'];
	
}else{
	if (empty($_SESSION['FLOW']))
	{
		$ID_SOURCE = $_SESSION['ID_NET'];
		$ID_DESTINATION = $_SESSION['ID_HOST'];
		
		$SQL = "SELECT class, id_ifa FROM cc_firewall.network WHERE id = '$ID_SOURCE'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB011F"));
		$ARRAY = mysql_fetch_array($RS);
		if (!empty($ARRAY['mask'])){
			$SNET = $ARRAY['class']."/".$ARRAY['mask'];
		} else {
			$SNET = $ARRAY['class'];
		}
		$ID_S_IFA = $ARRAY['id_ifa'];
		
		$SQL = "SELECT h.ip, n.id_ifa FROM cc_firewall.hostserver h, cc_firewall.network n WHERE ";
		$SQL .= "h.id = '$ID_DESTINATION' AND h.id_net = n.id";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB012F"));
		$ARRAY = mysql_fetch_array($RS);
		$DNET = $ARRAY['ip'];
		$ID_D_IFA = $ARRAY['id_ifa'];
	
	}
	elseif($_SESSION['FLOW'] == 1)
	{
		$ID_SOURCE = $_SESSION['ID_HOST'];
		$ID_DESTINATION = $_SESSION['ID_NET'];
		
		$SQL = "SELECT class, id_ifa FROM cc_firewall.network WHERE id = '$ID_DESTINATION'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB013F"));
		$ARRAY = mysql_fetch_array($RS);
		if (!empty($ARRAY['mask'])){
			$DNET = $ARRAY['class']."/".$ARRAY['mask'];
		} else {
			$DNET = $ARRAY['class'];
		}
		$ID_D_IFA = $ARRAY['id_ifa'];
		
		$SQL = "SELECT h.ip, n.id_ifa FROM cc_firewall.hostserver h, cc_firewall.network n WHERE ";
		$SQL .= "h.id = '$ID_SOURCE' AND h.id_net=n.id";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB014F"));
		$ARRAY = mysql_fetch_array($RS);
		$SNET = $ARRAY['ip'];
		$ID_S_IFA = $ARRAY['id_ifa'];
	}
}

//Select the attributes of module state for insert in rules in flow the go
$SQL = "SELECT id FROM cc_firewall.atribute_module WHERE (name = 'NEW' OR name = 'ESTABLISHED' ";
$SQL .= "OR name = 'RELATED') AND id_mod IN (SELECT id FROM cc_firewall.module WHERE definitive='1')";
$RSS_GO = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB015F"));
$STATE_GO = mysql_fetch_array($RSS_GO);

//Select the attributes of module state for insert in rules in flow the back
$SQL = "SELECT id FROM cc_firewall.atribute_module WHERE (name = 'ESTABLISHED' ";
$SQL .= "OR name = 'RELATED') AND id_mod IN (SELECT id FROM cc_firewall.module WHERE definitive='1')";
$RSS_BACK = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB016F"));
$STATE_BACK = mysql_fetch_array($RSS_BACK);

//Select the Action, Direction and Table
if (empty($_SESSION['WIZARD_TO_FW'])){
	$DIRECTION = "FORWARD";
	$SQL = "SELECT id FROM cc_firewall.tab_dir_act WHERE ";
	$SQL .= "id_tab IN (SELECT id FROM cc_firewall.tablefw WHERE name = 'filter') ";
	$SQL .= "AND id_dir IN (SELECT id FROM cc_firewall.direction WHERE name = '$DIRECTION') ";
	$SQL .= "AND id_act IN (SELECT id FROM cc_firewall.action WHERE name = '$ACTION')";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB017F"));
	$ARRAY = mysql_fetch_array($RS);
	$ID_TAB_DIR_ACT1 = $ARRAY['id'];
}else{
	$SQL = "SELECT id FROM cc_firewall.tab_dir_act WHERE ";
	$SQL .= "id_tab IN (SELECT id FROM cc_firewall.tablefw WHERE name = 'filter') ";
	$SQL .= "AND id_dir IN (SELECT id FROM cc_firewall.direction WHERE name = 'INPUT') ";
	$SQL .= "AND id_act IN (SELECT id FROM cc_firewall.action WHERE name = '$ACTION')";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB018F"));
	$ARRAY = mysql_fetch_array($RS);
	//Store with direction to input
	$ID_TAB_DIR_ACT1 = $ARRAY['id'];
	
	$SQL = "SELECT id FROM cc_firewall.tab_dir_act WHERE ";
	$SQL .= "id_tab IN (SELECT id FROM cc_firewall.tablefw WHERE name = 'filter') ";
	$SQL .= "AND id_dir IN (SELECT id FROM cc_firewall.direction WHERE name = 'OUTPUT') ";
	$SQL .= "AND id_act IN (SELECT id FROM cc_firewall.action WHERE name = '$ACTION')";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB019F"));
	$ARRAY = mysql_fetch_array($RS);
	//Store with direction to output
	$ID_TAB_DIR_ACT2 = $ARRAY['id'];
}
$MSTATE = "";

for ($F = 0; $F < (sizeof($PROTOCOL)); $F++)
	{
	// Flow the go
		$ARRAY = explode("@",$PROTOCOL[$F]);
		$D_PORT = $ARRAY[0];
		$PROTO = $ARRAY[1];
		
		$SQL = "INSERT INTO  cc_firewall.rulefw (id_s_iface, id_d_iface, ";
		$SQL .= "s_address, d_address, id_pro, d_port, command, id_tab_dir_act, id_user, date_created, last_update, ";
		$SQL .= "use_assistant, status, applied) VALUES ('$ID_S_IFA', '$ID_D_IFA', '$SNET', ";
		$SQL .="'$DNET', '$PROTO', '$D_PORT', 'A', '$ID_TAB_DIR_ACT1', '$USER', '$DATE_NOW', '$DATE_NOW', '1', '1', '0' )";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIB020F"));
		
		//Insert the module state to rule
		$ID_RULE = mysql_insert_id();
		do
		{
				$ID_ATR = $STATE_GO['id'];
				$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
				$SQL .= "('$ID_RULE', '$ID_ATR')";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIB021F"));
				
				$SQL = "SELECT name FROM cc_firewall.atribute_module WHERE id = '$ID_ATR'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIB021F"));
				$ARRAY = mysql_fetch_array($RS);
		}while($STATE_GO = mysql_fetch_array($RSS_GO));
		
		//Insert the module smultipor
		$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'smultiport'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB022F"));
		$ARRAY = mysql_fetch_array($RS);
		$ID_MOD = $ARRAY['id'];
		
		$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
		$SQL .= "('$ID_MOD' ,'$S_MULTIPORT_PORT')";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIB023F"));
		
		$ID_ATR = mysql_insert_id();
		$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ('$ID_RULE', '$ID_ATR')";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIB024F"));
		
						$SQL = "SELECT name FROM controlcenter.interface WHERE id = '$ID_SNET'";
						$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR056F"));
						$ARRAY = mysql_fetch_array($RS);
						$SIFACE = $ARRAY['name'];
						$SQL = "SELECT name FROM controlcenter.interface WHERE id = '$ID_DNET'";
						$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR057F"));
						$ARRAY = mysql_fetch_array($RS);
						$DIFACE = $ARRAY['name'];
						$SQL = "SELECT name FROM cc_firewall.protocol WHERE id = '$PROTO'";
						$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR057F"));
						$ARRAY = mysql_fetch_array($RS);
						$PROTODESCRIPTION = $ARRAY['name'];
						// Mount the rule in one line
						$RULE = "-t $FWTABLE -A $DIRECTION ";
						if (!empty($SNET)){ $RULE .= "-s $SNET ";}
						if (!empty($DNET)){ $RULE .= "-d $DNET ";}
						if (!empty($SIFACE)){ $RULE .= "-i $SIFACE ";}
						if (!empty($DIFACE)){ $RULE .= "-o $DIFACE ";}
						if (!empty($PROTODESCRIPTION)){ $RULE .= "-p $PROTODESCRIPTION --dport $D_PORT ";}
						$RULE .= "-m state --state NEW,ESTABLISHED,RELATED ";
						if (!empty($ACTION)){ $RULE .= "-j $ACTION ";}
						// Insert the rule in table to execute
						$SQL = "INSERT INTO cc_firewall.rulefwrun (id, name) VALUES ('$ID_RULE', '$RULE')";
						$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR055F"));
		
		if ($APPLY_RULE_REAL_TIME != 0)
		{
			/*$COMMAND = "sudo $IPTABLES -t $FWTABLE -A FORWARD -s $SNET -d $DNET -p $PROT --dport $DPORT ";
			$COMMAND .= "-m multiport --sport $S_MULTIPORT_PORT -j $ACTION";
			system($COMMAND, $result);
			if ($result != "0"){
			print_r($COMMAND);
			}*/
			// FAZER UM COMANDO DE LOG.
		}
	
	// Flow the back
		//Verify if is to firewall or is forward
		if (empty($ID_TAB_DIR_ACT2))
		{
			$SQL = "INSERT INTO  cc_firewall.rulefw (id_s_iface, id_d_iface, ";
			$SQL .= "s_address, d_address, id_pro, s_port, command, id_tab_dir_act, id_user, date_created, ";
			$SQL .= "last_update, use_assistant, status, applied) ";
			$SQL .= "VALUES ('$ID_D_IFA', '$ID_S_IFA', '$DNET', ";
			$SQL .="'$SNET', '$PROTO', '$D_PORT', 'A', '$ID_TAB_DIR_ACT1','$USER', '$DATE_NOW', '$DATE_NOW', '1', '1', '0' )";
		}else {
			$SQL = "INSERT INTO  cc_firewall.rulefw (id_s_iface, id_d_iface, ";
			$SQL .= "s_address, d_address, id_pro, s_port, command, id_tab_dir_act, id_user, date_created, ";
			$SQL .= "last_update, use_assistant, status, applied) ";
			$SQL .= "VALUES ('$ID_DNET', '$ID_SNET', '$DNET', ";
			$SQL .="'$SNET', '$PROTO', '$D_PORT', 'A', '$ID_TAB_DIR_ACT2','$USER', '$DATE_NOW', '$DATE_NOW', '1', '1', '0' )";
		}			
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIB025F"));
		
		//Insert the module state to rule
		$ID_RULE = mysql_insert_id();
		do
		{
				$ID_ATR = $STATE_BACK['id'];
				$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ";
				$SQL .= "('$ID_RULE', '$ID_ATR')";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIB026F"));
				
				$SQL = "SELECT name FROM cc_firewall.atribute_module WHERE id = '$ID_ATR'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIB021F"));
				$ARRAY = mysql_fetch_array($RS);
				$MSTATE .= $ARRAY ['name'];
		}while($STATE_BACK = mysql_fetch_array($RSS_BACK));
		
		//Insert the module dmultipor
		$SQL = "SELECT id FROM cc_firewall.module WHERE name = 'dmultiport'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB027F"));
		$ARRAY = mysql_fetch_array($RS);
		$ID_MOD = $ARRAY['id'];
		
		$SQL = "INSERT INTO cc_firewall.atribute_module (id_mod, name) VALUES ";
		$SQL .= "('$ID_MOD' ,'$S_MULTIPORT_PORT')";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIB028F"));
		
		$ID_ATR = mysql_insert_id();
		$SQL = "INSERT INTO cc_firewall.rul_atr (id_rul, id_atr) VALUES ('$ID_RULE', '$ID_ATR')";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIB029F"));

						$SQL = "SELECT name FROM controlcenter.interface WHERE id = '$ID_SNET'";
						$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR056F"));
						$ARRAY = mysql_fetch_array($RS);
						$SIFACE = $ARRAY['name'];
						$SQL = "SELECT name FROM controlcenter.interface WHERE id = '$ID_DNET'";
						$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR057F"));
						$ARRAY = mysql_fetch_array($RS);
						$DIFACE = $ARRAY['name'];
						$SQL = "SELECT name FROM cc_firewall.protocol WHERE id = '$PROTO'";
						$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR057F"));
						$ARRAY = mysql_fetch_array($RS);
						$PROTODESCRIPTION = $ARRAY['name'];
						// Mount the rule in one line
						$RULE = "-t $FWTABLE -A $DIRECTION ";
						if (!empty($SNET)){ $RULE .= "-d $SNET ";}
						if (!empty($DNET)){ $RULE .= "-s $DNET ";}
						if (!empty($SIFACE)){ $RULE .= "-i $SIFACE ";}
						if (!empty($DIFACE)){ $RULE .= "-o $DIFACE ";}
						if (!empty($PROTODESCRIPTION)){ $RULE .= "-p $PROTODESCRIPTION ";}
						if (!empty($D_PORT)){ $RULE .= "--sport $D_PORT ";}
						$RULE .= "-m state --state ESTABLISHED,RELATED ";
						if (!empty($ACTION)){ $RULE .= "-j $ACTION ";}
						// Insert the rule in table to execute
						$SQL = "INSERT INTO cc_firewall.rulefwrun (id, name) VALUES ('$ID_RULE', '$RULE')";
						$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR055F"));
						
		if ($APPLY_RULE_REAL_TIME != 0)
		{
			/*$COMMAND = "sudo $IPTABLES -t $FWTABLE -A FORWARD -d $SNET -s $DNET -p $PROT --sport $DPORT ";
			$COMMAND .= "-m multiport --dport $S_MULTIPORT_PORT -j $ACTION";
			system($COMMAND, $result);
			if ($result != "0"){
			print_r($COMMAND);
			}*/
			// FAZER UM COMANDO DE LOG.
		}
	}
header("Location: $DESTINATION_PAGE");
?>