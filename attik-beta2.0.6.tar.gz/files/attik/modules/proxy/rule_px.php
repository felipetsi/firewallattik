<?php 
require_once('../../includes/control_session.php');
require_once('configuration/general.php');

$DESTINATION_PAGE = "rule_run_px.php";
$THISPAGE = "rule_px.php";
$PAGE_DELETE="rule_delete_fw.php";
$ALTERPOSITIONUP = "rule_alter_position_up_px.php";
$ALTERPOSITIONDOWN = "rule_alter_position_down_px.php";
$_SESSION['FILE_LANG'] = "proxy.php";
$PAGE_SEQ_P = substr(trim(addslashes($_POST['page_seq'])),0,2);
$PAGE_SEQ = ($PAGE_SEQ_P*50);

// Load the profile of user autenticanted
$SQL = "SELECT create_rule, read_rule FROM controlcenter.profilepx WHERE id IN ";
$SQL .= "(SELECT id_propx FROM controlcenter.profile WHERE id IN (SELECT id_pro FROM ";
$SQL .= "controlcenter.user WHERE id = '$USER'))";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IPXSR001F"));
$DATA_USER = mysql_fetch_array($RS);

//Storage in session for know tha page was send alter position of rule.
$_SESSION['SOURCE_PAGE'] = $THISPAGE;

// Select the object selected
$ID = $_POST['rule'];
if (!is_array($ID)){
	$ID = split(",",$ID);
}
$QTD_ITEM = sizeof($ID);
$ITEMID = trim(addslashes($ID[0]));
if (empty($ITEMID))
{
	$ITEMID = $_SESSION['ITEMID'];
}
else
{
	$_SESSION['ITEMID'] = $ITEMID;
}
$_SESSION['ITEMDELETE'] = $ID;
if(!empty($_POST['showall'])){
	unset($_SESSION['SQL_SEARCH']);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $TITLE_FW; ?></title>
<link href="../../includes/style_cc.css" rel="stylesheet" type="text/css" />
<link href="style_proxy_rule.css" rel="stylesheet" type="text/css" />
<?php
echo ('
<script language="javascript">
var thispage = "'.$THISPAGE.'";
var deletepage = "'.$PAGE_DELETE.'";
</script>');
?>
</head>
<?php if((!empty($ITEMID))||(!empty($_SESSION['TRYINSERTRULE']))){
echo '<body onload="javascript:changeAction(); verifyAction(); SelectCheckedAfter(); verifyProto(); showDetailSelected();" >';} else {
echo '<body onload="javascript:changeAction(); verifyAction(); SelectCheckedAfter(); verifyProto(); ">';
}

require_once('../../includes/top.php');
require_once('px_menu.php');
?>
<div id="main"> <!--Main-->

<?php 
if ($DATA_USER['create_rule'] == 1)//If of permition
{
	require_once('rule_details_px.php');
} //If of permition

if ($DATA_USER['read_rule'] == 1) //If of permition
{
	//include('px_menu_rule.php');
	require_once('rule_show_all_px.php');
} //If of permition ?>

<div class="version_general">
<?php
echo $VERSIONCC;
?>
</div>

</div><!--Main-->
</body>
</html>