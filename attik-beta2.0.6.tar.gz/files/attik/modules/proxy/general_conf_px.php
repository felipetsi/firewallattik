<?php 
require_once('../../includes/control_session.php');

//Variable need becase various moment is use, including the top for change language
$THISPAGE = "general_conf_px.php";
$DESTINATION_PAGE = "general_conf_run_px.php";
$_SESSION['FILE_LANG'] = "proxy.php";

// Load the profile of user autenticanted
$SQL = "SELECT create_rule, read_rule FROM controlcenter.profilepx WHERE id IN ";
$SQL .= "(SELECT id_propx FROM controlcenter.profile WHERE id IN (SELECT id_pro FROM ";
$SQL .= "controlcenter.user WHERE id = '$USER'))";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG001F"));
$DATA_USER = mysql_fetch_array($RS);

// Load the item selected
if (!empty($_POST['list']))
{
	$_SESSION['ITEMID'] = $_POST['list'];
	$ITEMID = $_SESSION['ITEMID'];
} else {
	$ITEMID = $_SESSION['ITEMID'];
}
$_SESSION['ITEMDELETE'] = $ITEMID;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<script language="javascript">
var thispage = "general_conf_fw.php";
</script>
<title><?php echo $TITLE_FW; ?></title>
<link href="../../includes/style_cc.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php 
require_once('../../includes/top.php');
require_once('px_menu.php');
?>
<div id="main"> <!--Main-->
<?php require_once('px_menu_configuration.php'); ?>


<div id="contet_rigth"> <!-- Rigth -->
<?php
if (($DATA_USER['create_rule'] == 1)&&($DATA_USER['read_rule'] == 1)) {

// Load the user selected
$SQL = "SELECT p.id, p.id_act, d.name as direction, ac.name as action FROM cc_firewall.action ac, cc_firewall.direction d, ";
$SQL .= "cc_firewall.policyfw p WHERE d.id = '$ITEMID' AND p.id_dir = d.id AND ac.id = p.id_act";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG002F"));
	//Auditor
	if ((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1))
	{
		auditor('IFWSG002S', $ADDRIP, $USER, '0');
	}
$ARRAY = mysql_fetch_array($RS);
?>
<form class="insert_border" action="<?php echo $DESTINATION_PAGE;?>" method="post" name="frmgeneral">
<div class="title_general_px" > <?php echo $T_GENERAL_CONFIG;?> </div>
<div id="contet_rigth_data">
<div class="sub_title"><?php echo $T_INCTI_SUPORTT;?></div>
<div align="right" class="left_name"><?php echo $F_ENABLE;?></div>
	<div>
	<input type="radio" name="suport" value="1" <?php if ($INCTI_SUPORT_REMOTE == 1){echo 'checked="checked"';}?> />
	</div>
<div align="right" class="left_name"><?php echo $F_DISABLE;?></div>
	<div>
	<input type="radio" name="suport" value="0" <?php if ($INCTI_SUPORT_REMOTE == 0){echo 'checked="checked"';}?> />
	</div>
<div class="sub_title"><?php echo $T_AUDITORY;?></div>
<div align="right" class="left_name"><?php echo $F_ENABLE;?></div>
	<div>
	<input type="radio" name="audit" value="1" <?php if ($LOG_AUDITOR == 1){echo 'checked="checked"';}?> />
	</div>
<div align="right" class="left_name"><?php echo $F_DISABLE;?></div>
	<div>
	<input type="radio" name="audit" value="0" <?php if ($LOG_AUDITOR == 0){echo 'checked="checked"';}?> />
	</div>
<div class="sub_title"><?php echo $T_PASSWORD_USER_DATABASE;?></div>
	<div align="right" class="left_name">*<?php echo $F_PASSWORD;?></div>
		<div> <input type="password" size="20" maxlength="40" name="password" /></div>
	
	<div align="right" class="left_name">*<?php echo $F_REPASSWORD;?></div>
		<div> <input type="password" size="20" maxlength="40" name="repassword" /></div>
<div class="sub_title"><?php echo $T_DEFAULT_LANG;?></div>
<div align="right" class="left_name"><?php echo $F_LANGUAGE;?></div>
	<div>
	<select name="language">
	<?php
		$SQL = "SELECT * FROM  controlcenter.language ORDER BY name";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSG001F"));
		$DATA = mysql_fetch_array($RS);
		$cor = 1;	
		do{
		if($DATA['file'] == $DEFAULT_LANGUAGE) {
			$sel = 'selected="selected"';
		} else {
				$sel = "";
		}
	
		if ( $cor == 1 )
		{
			?>
			<option value="<?php echo $DATA['file'];?>" <?php echo $sel;?> ><?php echo ($DATA['name']); $cor=0?></option>
			<?php 
		} else { ?>
			<option style="background:<?php echo $COLOR_LINE_SELECT;?>" value="<?php echo $DATA['file'];?>" <?php echo $sel;?> ><?php echo ($DATA['name']); $cor=1;?></option>
			<?php
		} 
	}while ($DATA =  mysql_fetch_array($RS));?>
	</select>
	</div>
</div>
	<div id="contet_rigth_img">

		<img src="@img/icons/suport-128x128.png" />	

	</div>	

<div class="title_general_px">		
	<input type="submit" value="<?php echo $B_UPDATE;?>" /><font id="small_alert">* <?php echo $S_FILL_JUST_CHANGE;?></font>
</div>
</form>
</div><!-- Rigth -->
<?php 
}?>

<div class="version_general">
<?php
echo $VERSIONCC;
?>
</div>

</div> <!--Main-->

</body>
</html>
<?php
unset($_SESSION['EX_ACTION']);
unset($_SESSION['ITEMID']);
?>