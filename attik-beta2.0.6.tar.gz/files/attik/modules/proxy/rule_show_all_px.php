<div class="rule_show_line_title">
	<div class="r_sppaccing_title"></div>
	<div class="r_sppaccing_check">
		<input type="checkbox" id="allCheckRule" onchange="javascript:checkAll();"/>
	</div>
	<div class="title_interface_filter"><?php echo $T_INTERFACE_ENTRY;?></div>
	<div class="title_address_filter"><?php echo $T_SOURCE;?></div>
	<div class="title_interface_filter"><?php echo $T_INTERFACE_EXIT;?></div>			
	<div class="title_address_filter"><?php echo $T_DESTINATION;?></div>
	<div class="title_service_filter"><?php echo $T_SOURCE_PORT;?></div>
	<div class="title_service_filter"><?php echo $T_DESTINATION_PORT;?></div>
	<div class="title_action_filter"><?php echo $T_ACTION;?></div>
</div>
<script language="javascript">
var arrayCheck = new Array();
var p = 0;
function selectCheck(elementValue, elementName)
{
	if (elementName == true)
	{
		arrayCheck.push(elementValue);
	}
	else
	{
		for (p=0; p < arrayCheck.length; p++)
		{
			if (arrayCheck[p] == elementValue)
			{
				arrayCheck.splice(p, 1);
			}
		}
	}
}
function setValuesCheck()
{
	document.getElementById('arule').value = arrayCheck;
	document.formSelect.submit();
}
var allObj = new Array();
function SelectCheckedAfter()
{
	for(f=0; f < allObj.length; f++)
	{
		if (document.getElementById(allObj[f]).checked == true)
		{
			arrayCheck.push(allObj[f]);
		}
	}
}
function checkAll()
{
	if(document.getElementById('allCheckRule').checked == true)
	{
		for(f=0; f < allObj.length; f++)
		{
			document.getElementById(allObj[f]).checked = true;
			arrayCheck.push(allObj[f]);
		}
	} else {
		for(f=0; f < allObj.length; f++)
		{
			document.getElementById(allObj[f]).checked = false;
			arrayCheck[f] = "";
		}
	}
}
function CheckSearh()
{
	document.getElementById('ind_search').value = "1";
	document.formRule.submit();
}
function UnCheckSearh()
{
	document.getElementById('ind_search').value = "0";
}
function ShowAllRules()
{
	document.formShowAll.submit();
}
</script>
<div id="r_show_rule"><!--Rules list-->
		<?php 
		if ($PAGE_SEQ < 0) { $PAGE_SEQ = 0;}elseif(($PAGE_SEQ_P > ($QTD-1))&&($QTD > 2)) { $PAGE_SEQ = (round($QTD)-1)*$QUANTITY_RULE_SHOW;}
		if (empty($_SESSION['SQL_SEARCH']))
		{
			$SQL = "SELECT DISTINCT r.id, r.s_address as source, r.d_address as destination, ";
			$SQL .= "r.id_s_iface, r.id_d_iface, r.s_port, r.d_port, r.status, r.applied, ";
			$SQL .= "ac.name as action, r.id_pro FROM cc_firewall.rulefw r, cc_firewall.action ac WHERE ";
			$SQL .= "r.id_tab_dir_act IN (SELECT id FROM cc_firewall.tab_dir_act WHERE id_act = ac.id AND ";
			$SQL .= "id_tab IN (SELECT id FROM cc_firewall.tablefw WHERE name = '$TABLE')) ";
			$SQL .= "ORDER BY r.id ASC LIMIT $PAGE_SEQ,$QUANTITY_RULE_SHOW";
		}
		else
		{
			$SQL = $_SESSION['SQL_SEARCH'];
			$SQL .= "AND id_tab IN (SELECT id FROM cc_firewall.tablefw WHERE name = '$TABLE') ) ";
			$SQL .= "ORDER BY r.id ASC ";
			$SQL .= " LIMIT $PAGE_SEQ,$QUANTITY_RULE_SHOW";
		}
		$COUNT=$PAGE_SEQ;
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR107F"));
		$ARRAY = mysql_fetch_array($RS);
		$QTD = mysql_affected_rows();
		if ($QTD != 0)
		{
			do{
				$IDSIFA = $ARRAY['id_s_iface'];
				$IDDIFA = $ARRAY['id_d_iface'];

				$SQL = "SELECT description FROM controlcenter.interface ";
				$SQL .= "WHERE id = '$IDSIFA'";
				$RSI = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR108F"));
				$ARRAYSIFA = mysql_fetch_array($RSI);

				$SQL = "SELECT description FROM controlcenter.interface ";
				$SQL .= "WHERE id ='$IDDIFA'";
				$RSI = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR109F"));
				$ARRAYDIFA = mysql_fetch_array($RSI);
				
				$IDSELCHECK = $_SESSION['ITEMDELETE'];
				if(sizeof($IDSELCHECK) > 1 ){
					$SELECTCHECK = in_array($ARRAY['id'], $IDSELCHECK);
				}elseif($QTD_ITEM == 1){
					if($IDSELCHECK[0] == $ARRAY['id']){
						$SELECTCHECK = 1;
					}else{
						$SELECTCHECK="";
					}
				}
				else{
					$SELECTCHECK="";
				}
				$IDOBJ = $ARRAY['id'];
				// Load the array with the IDs for allow selectall function
				echo ('
					<script language="javascript">
						allObj.push('.$IDOBJ.');
					</script>');
				$COUNT++;?>
				<div class="<?php if ($ARRAY['status'] == 0){ echo 'select_line_color_fail';}
					elseif ($ARRAY['applied'] == 0){ echo 'select_line_color_dapplied';}
					elseif ($cor == 1) {echo 'select_line_color'; $cor=0;}
					else {echo 'select_line'; $cor=1;}?>">
					<div class="r_sppaccing_id">
							<div class="r_info">
								<label for="<?php echo $ARRAY['id'];?>">
									<?php echo $COUNT;?>
								</label>
							</div>
							<div class="position_right">
								<?php
								if ($COUNT == 1)
								{?>
										<form action="<?php echo $ALTERPOSITIONDOWN;?>" name="<?php echo ("rules".$COUNT."down");?>" method="post">
										<a href="<?php echo ('javascript:document.rules'.$COUNT.'down.submit();');?>">
										<input type="hidden" value="<?php echo $ARRAY['id'];?>" name="idrule" />
										<img src="../../@img/icons/down-16x16.png" alt="<?php echo $F_RULE_UP;?>"/>
										</a>
										</form>
								<?php
								}elseif ($QTD == $COUNT)
								{?>
										<form action="<?php echo $ALTERPOSITIONUP;?>" name="<?php echo ("rules".$COUNT."up");?>" method="post">
										<a href="<?php echo ('javascript:document.rules'.$COUNT.'up.submit();');?>">
										<input type="hidden" value="<?php echo $ARRAY['id'];?>" name="idrule" />
										<img src="../../@img/icons/up-16x16.png" alt="<?php echo $F_RULE_UP;?>"/>
										</a>
										</form>
								<?php
								}else
								{?>
									<div class="position_left">
										<form action="<?php echo $ALTERPOSITIONDOWN;?>" name="<?php echo ("rules".$COUNT."down");?>" method="post">
										<a href="<?php echo ('javascript:document.rules'.$COUNT.'down.submit();');?>">
										<input type="hidden" value="<?php echo $ARRAY['id'];?>" name="idrule" />
										<img src="../../@img/icons/down-16x16.png" alt="<?php echo $F_RULE_UP;?>"/>
										</a>
										</form>
									</div>
									<div>
										<form action="<?php echo $ALTERPOSITIONUP;?>" name="<?php echo ("rules".$COUNT."up");?>" method="post">
										<a href="<?php echo ('javascript:document.rules'.$COUNT.'up.submit();');?>">
										<input type="hidden" value="<?php echo $ARRAY['id'];?>" name="idrule" />
										<img src="../../@img/icons/up-16x16.png" alt="<?php echo $F_RULE_UP;?>"/>
										</a>
										</form>
									</div>
								<?php
								}?>
							</div>
					</div>
				<form action="<?php echo $THISPAGE;?>" name="<?php echo ("rules".$COUNT);?>" method="post">					
					<div class="r_sppaccing">
						<input type="checkbox" value="<?php echo $ARRAY['id'];?>" name="rule" <?php echo 'onclick="javascript:selectCheck(this.value,this.checked);"';?> id="<?php echo $ARRAY['id'];?>" <?php if($SELECTCHECK != ""){ echo 'checked="checked"';} ?> />
						</div>
					<div class="interface_filter">
						<label for="<?php echo $ARRAY['id'];?>">
							<a href="<?php echo ("javascript:document.rules$COUNT.submit();");?>">
								<?php echo verifyEmpty($ARRAYSIFA['description'],$S_ANY);?>
							</a>
						</label>
					</div>
					<div class="address_filter">
						<label for="<?php echo $ARRAY['id'];?>">
							<a href="<?php echo ("javascript:document.rules$COUNT.submit();");?>">
								<?php echo verifyEmpty($ARRAY['source'],$S_ANY);?>
							</a>
						</label>
					</div>
					<div class="interface_filter">
						<label for="<?php echo $ARRAY['id'];?>">
							<a href="<?php echo ("javascript:document.rules$COUNT.submit();");?>">
								<?php echo verifyEmpty($ARRAYDIFA['description'],$S_ANY);?>
							</a>
						</label>
					</div>
					<div class="address_filter">
						<label for="<?php echo $ARRAY['id'];?>">
							<a href="<?php echo ("javascript:document.rules$COUNT.submit();");?>">
								<?php echo verifyEmpty($ARRAY['destination'],$S_ANY);?>
							</a>
						</label>
					</div>
					<div class="service_filter">
						<label for="<?php echo $ARRAY['id'];?>">
							<a href="<?php echo ("javascript:document.rules$COUNT.submit();");?>">
								<?php echo verifyEmpty($ARRAY['s_port'],$S_ANY);?>
							</a>
						</label>
					</div>
					<div class="service_filter">
						<label for="<?php echo $ARRAY['id'];?>">
							<a href="<?php echo ("javascript:document.rules$COUNT.submit();");?>">
								<?php echo verifyEmpty($ARRAY['d_port'],$S_ANY);?>
							</a>
						</label>
					</div>
					<div class="action_filter">
						<label for="<?php echo $ARRAY['id'];?>">
							<a href="<?php echo ("javascript:document.rules$COUNT.submit();");?>">
								<img src="../../@img/icons/<?php echo verifyActionForImg($ARRAY['action']);?>" /> 
								<?php
								echo ($$ARRAY['action']);?>
							</a>
						</label>
					</div>
				</form>
				</div>
				<?php 
			} while ($ARRAY = mysql_fetch_array($RS));
		}?>
</div><!--Rules list-->