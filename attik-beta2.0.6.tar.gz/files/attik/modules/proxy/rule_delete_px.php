<?php 
require_once('../../includes/control_session.php');

$DESTINATION_PAGE = $_SESSION['SOURCE_PAGE'];

//$IDARRAY = $_SESSION['ITEMDELETE'];
$ID = $_POST['rule'];
if (!is_array($ID)){
	$IDARRAY = split(",",$ID);
}

if ((sizeof($IDARRAY) == 0) || (empty($IDARRAY[0]))) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDSELECT';
	header("Location:$DESTINATION_PAGE");
}
else {
	for ($F = 0; $F < sizeof($IDARRAY); $F++)
	{
		$ID = $IDARRAY[$F];
		
		// Delete the attributes
		$SQL = "DELETE FROM cc_firewall.atribute_module WHERE id IN (SELECT id_atr FROM ";
		$SQL .= "cc_firewall.rul_atr WHERE id_rul = '$ID') AND id_mod IN (SELECT id FROM ";
		$SQL .= "cc_firewall.module WHERE definitive <> '1')";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR068F"));
	
		// Delete the associated (rul_atr)
		$SQL = "DELETE FROM cc_firewall.rul_atr WHERE id_rul = '$ID'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR069F"));
		
		// Delete the associated extend (rule_extend)
		$SQL = "DELETE FROM cc_firewall.rule_extend WHERE id_rul = '$ID'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR070F"));
		
		// Delete the associated varriable time
		$SQL = "DELETE FROM cc_firewall.rul_vartime WHERE id_rul = '$ID'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR071F"));
		
		// Delete the rule
		$SQL = "DELETE FROM cc_firewall.rulefw WHERE id = '$ID'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR072F"));
		
		// Delete the rule mounted
		$SQL = "DELETE FROM cc_firewall.rulefwrun WHERE id = '$ID'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDR110S"));
	}	
	if ( mysql_affected_rows() !=0 )
	{
		if($LOG_AUDITOR == 1){
				auditor('IFWDR072S', $ADDRIP, $USER, '0');
		}
		$_SESSION['SHOW_MSG'] = 'F_SUCESS';
	}else {
		if($LOG_AUDITOR == 1){
				auditor('IFWDR072F', $ADDRIP, $USER, '0');
		}
		$_SESSION['SHOW_MSG'] = 'F_FAILURE';
	}
		unset($_SESSION['ITEMDELETE']);
		unset($_SESSION['SOURCE_PAGE']);
		header("Location:$DESTINATION_PAGE");
}
?>