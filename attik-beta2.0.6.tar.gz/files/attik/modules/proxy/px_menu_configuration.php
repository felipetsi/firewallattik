<div id="left_menu"><!-- Sub-menu -->
<a href="general_conf_px.php">
 <div class="button_conf_px" >
	 <img src="../../@img/icons/suport-16x16.png" /><?php echo $L_GENERAL;?>
 </div>
</a>
</div> <!-- Sub-menu -->