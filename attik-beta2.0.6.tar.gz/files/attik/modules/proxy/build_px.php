<?php 
require_once('../../includes/control_session.php');

$DESTINATION_PAGE = "select_services_fw.php";

$_SESSION['FILE_LANG'] = "firewall.php";
//Clear the session variable with indicated tha is for start
$_SESSION['PG_SERVER_NET'] = 0;

// Load the profile of user autenticanted
$SQL = "SELECT create_rule, read_rule FROM controlcenter.profilefw WHERE id IN ";
$SQL .= "(SELECT id_profw FROM controlcenter.profile WHERE id IN (SELECT id_pro FROM ";
$SQL .= "controlcenter.user WHERE id = '$USER'))";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB001F"));
$DATA_USER = mysql_fetch_array($RS);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $TITLE_FW; ?></title>
<link href="../../includes/style_cc.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php require_once('../../includes/top.php'); ?>
<?php require_once('fw_menu.php'); ?>
<div id="main"> <!--Main-->
<div class="title_general_fw"><?php echo $T_TOPOLOGY_SELECT;?></div>
	<?php 
if ($DATA_USER['create_rule'] == 1) {	
	mysql_select_db("cc_firewall");
	$SQL = "SELECT * FROM cc_firewall.positionfw";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB002F"));
	$ARRAY = mysql_fetch_array($RS);
	if (mysql_affected_rows() != 0)
	{ ?>
	<form action="<?php echo $DESTINATION_PAGE;?>" method="post">
	<?php
		do{
			$ID =  $ARRAY['id'];?>
			<div <?php if($place == "1") {echo 'id="rigth_option"';$place=0;} else {echo 'id="left_option"';$place=1;}?> >
				<p id="title_option"><input id="<?php echo $ID;?>" type="radio" name="position" value="<?php echo $ID;?>" >
				<label class="title_option" for="<?php echo $ID;?>"><?php echo $ARRAY['name']; ?>
				</label></p>
				
				<?php
				$SQL = "SELECT id, name, class FROM cc_firewall.network WHERE id_pfw = '$ID'";
				$RSO = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB032F"));
				$OBJ = mysql_fetch_array($RSO);
				do {
						if(!empty($OBJ['name'])){?><b style="font-size:small"><label class="title_option_sub" for="<?php echo $ID;?>"><?php
							echo $OBJ['name']." - ".$OBJ['class'];?></label></b><br /><ol><?php
						$IDOBJ = $OBJ['id'];
						$SQL = "SELECT name, ip FROM cc_firewall.hostserver WHERE id_net = '$IDOBJ' ";
						$RSOINSIDE = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB033F"));
						$OBJINSIDE = mysql_fetch_array($RSOINSIDE);
						do {
							if(!empty($OBJINSIDE['name'])){?><li><label class="title_option_sub" for="<?php echo $ID;?>"><?php
								echo $OBJINSIDE['name']." - ".$OBJINSIDE['ip'];?></label></li><br /><?php
							}
						} while($OBJINSIDE = mysql_fetch_array($RSOINSIDE));?></ol><?php
					}
				} while($OBJ = mysql_fetch_array($RSO));?>
			</div>
			<?php 
		} while ($ARRAY = mysql_fetch_array($RS));
	}?>
	<div align="center" id="button_submit"> <!--butons-->
	<input type="submit" name="btn_post" value="<?php echo $B_NEXT;?>">
	</div>
	</form>
	
<div class="version_general">
<?php
echo $VERSIONCC;
?>
</div>

</div>
<?php
}?>
</div>
</body>
</html>
<?php
// Variable use for control in next page, don't let that the user click in back.
$_SESSION['CONTROLBACK'] = 1;
unset($_SESSION['QTD_NET_POSITION']);
unset($_SESSION['INVALIDTOPOLOGY']);
?>