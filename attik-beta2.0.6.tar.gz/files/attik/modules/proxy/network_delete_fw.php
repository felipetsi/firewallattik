<?php 
require_once('../../includes/control_session.php');

$DESTINATION_PAGE = "network_fw.php";

$ID = trim(addslashes($_SESSION['ITEMDELETE']));

if (empty($ID)) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDSELECT';
	header("Location:$DESTINATION_PAGE");
}
else {
	$SQL = "DELETE FROM cc_firewall.network_address WHERE id = '$ID'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDN012F"));
	if ( mysql_affected_rows() !=0 )
	{
		if($LOG_AUDITOR == 1){
			auditor('IFWDN012S', $ADDRIP, $USER, '0');
		}
		$_SESSION['SHOW_MSG'] = 'F_SUCESS';
	}else {
		if($LOG_AUDITOR == 1){
			auditor('IFWDN012F', $ADDRIP, $USER, '0');
		}
		$_SESSION['SHOW_MSG'] = 'F_FAILURE';
	}
		unset($_SESSION['ITEMDELETE']);
		header("Location:$DESTINATION_PAGE");
}
?>