<script language="javascript">
	var allObj = new Array();
</script>
<div id="select_services_list"> <!--Protocol list-->
	<div class="select_line_title">
		<div class="select_item1"><input type="checkbox" id="allCheckRule" onchange="javascript:checkAll();"/></div>
		<div class="select_item2"><?php echo $T_SERVICE;?></div>
		<div class="select_item3"><?php echo $T_PORT;?></div>
		<div class="select_item4"><?php echo $T_PROTOCOL;?></div>
		<div class="select_item5"><?php echo $T_DESCRIPTION;?></div>
	</div>
	
<?php
$SQL = "SELECT a.id, a.name, a.port, a.description, p.name as proto, p.id as id_pro FROM ";
$SQL .= "cc_firewall.application a, cc_firewall.protocol p WHERE a.id_pro = p.id";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB030F"));
$ARRAY = mysql_fetch_array($RS);
if (mysql_affected_rows() != 0)
{
	do{ 
		$IDOBJ = $ARRAY['id'];
		// Load the array with the IDs for allow selectall function
		echo ('
			<script language="javascript">
				allObj.push('.$IDOBJ.');
			</script>');
		if ($cor == 1)
		{
		?>
		<div class="select_line_color">
			<div class="select_item1">
				<input type="checkbox" value="<?php echo (($ARRAY['port']).'@'.($ARRAY['id_pro']));?>" name="protocol[]" id="<?php echo $ARRAY['id'];?>"/>
			</div>
			<div class="select_item2"><label for="<?php echo $ARRAY['id'];?>"><?php echo ($ARRAY['name']);?></label></div>
			<div class="select_item3"><label for="<?php echo $ARRAY['id'];?>"><?php echo ($ARRAY['port']);?></label></div>
			<div class="select_item4"><label for="<?php echo $ARRAY['id'];?>"><?php echo ($ARRAY['proto']);?></label></div>
			<div class="select_item5"><label for="<?php echo $ARRAY['id'];?>"><?php echo ($ARRAY['description']);?></label>
			</div>
		</div>
		<?php 
		$cor = 0;
		} else {
		$cor = 1;
		?>
		<div class="select_line">
			<div class="select_item1">
				<input type="checkbox" value="<?php echo (($ARRAY['port']).'@'.($ARRAY['id_pro']));?>" name="protocol[]" id="<?php echo $ARRAY['id'];?>"/>
			</div>
			<div class="select_item2"><label for="<?php echo $ARRAY['id'];?>"><?php echo ($ARRAY['name']);?></label></div>
			<div class="select_item3"><label for="<?php echo $ARRAY['id'];?>"><?php echo ($ARRAY['port']);?></label></div>
			<div class="select_item4"><label for="<?php echo $ARRAY['id'];?>"><?php echo ($ARRAY['proto']);?></label></div>
			<div class="select_item5"><label for="<?php echo $ARRAY['id'];?>"><?php echo ($ARRAY['description']);?></label>
			</div>
		</div>
		<?php 
		}
	} while ($ARRAY = mysql_fetch_array($RS));
}
?>
</div><!--Protocol list-->
<script language="javascript">
function checkAll()
{
	if(document.getElementById('allCheckRule').checked == true)
	{
		for(f=0; f < allObj.length; f++)
		{
			document.getElementById(allObj[f]).checked = true;
		}
	} else {
		for(f=0; f < allObj.length; f++)
		{
			document.getElementById(allObj[f]).checked = false;
		}
	}
}
</script>