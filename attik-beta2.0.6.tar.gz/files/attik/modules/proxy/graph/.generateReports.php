#!/bin/sh
############################################################
# This script whill be for generete the report/graph dialy #
#		Create by Felipe Pereira da Silva	   #
#		Created in 29/05/2008			   #
#		Version: 1.0				   #
############################################################

# Log file
LOGFILE="/var/log/firewall.log"

# Store the date current
DATETODAY=$(date +%d-%m-%Y)

# Report data file
GRAPHDATASERVICE="/var/www/controlcenter/modules/firewall/graph/graphservice_$DATETODAY.php"
GRAPHDATAPROTOCOL="/var/www/controlcenter/modules/firewall/graph/graphprotocol_$DATETODAY.php"

SERVICEFILE="/tmp/service.values"
# Verify and if exist the temp file remove this
if [ -e "$SERVICEFILE" ]
then
	rm -f $SERVICEFILE
fi

TCPFILE="/tmp/tcp.values"
if [ -e "$TCPFILE" ]
then
	rm -f $TCPFILE
fi

UDPFILE="/tmp/udp.values"
if [ -e "$UDPFILE" ]
then
	rm -f $UDPFILE
fi

TMPLENGTH="/tmp/length.values"
if [ -e "$TMPLENGTH" ]
then
	rm -f $TMPLENGTH
fi

# Start these variable 
FCOUNTTCP=1
FCOUNTUDP=1

# Define the day is today
FTODAYMAY=$(date +%c | cut -f3 -d " ")
FTODAYDAY=$(date +%c | cut -f2 -d " ")
FTODAY=$(echo "$FTODAYMAY $FTODAYDAY")

# Set the variables of protocols

# export FSERVICELENGTH=1
# export FLENGTH=1

mysql -p123 -u inctiuser cc_firewall -e \
"SELECT a.name, a.port, p.name as proto FROM cc_firewall.application a, cc_firewall.protocol p WHERE \
a.report=1 AND a.id_pro=p.id"| \
sed '1d' | \
while read SERVICE
do
	unset FSERVICELENGTH
	FPROTO=$(echo $SERVICE | cut -f3 -d " ")
	FAPPLICATION=$(echo $SERVICE | cut -f1 -d " ")
	FPORT=$(echo $SERVICE | cut -f2 -d " ")

	# Put in spaces empty one symbol of @ for shell don't interpretate one on space with outher line
#RULES=$(cat $LOGFILE | grep -i ": IN="|sed 's/ /\@/g' | grep -i $FPROTO@ | awk -F@ '$19 ~/DPT='"$FPORT"'/ {print $19}')
	RULES=$(cat $LOGFILE | grep -i ": IN="|sed 's/ /\@/g' | grep -i $FPROTO@ | grep -i =$FPORT@)

	if [ "$RULES" != "" ]
	then

	 for F in $RULES
	 do
		# Get the type of param
		#FMONTH=$(echo $F | cut -f1 -d "@")
		#FDAY=$(echo $F | cut -f2 -d "@")
		#FHOUR=$(echo $F | cut -f3 -d "@" | cut -f1 -d ":")
		#FMINUTE=$(echo $F | cut -f3 -d "@" | cut -f2 -d ":")
		#FSECOND=$(echo $F | cut -f3 -d "@" | cut -f3 -d ":")
		#FIFACEIN=$(echo $F | cut -f6 -d "@" | cut -f2 -d "=")
		#FIFACEOUT=$(echo $F | cut -f7 -d "@" | cut -f2 -d "=")
		#FMAC=$(echo $F | cut -f8 -d "@" | cut -f2 -d "=")
		#FSOURCE=$(echo $F | cut -f9 -d "@" | cut -f2 -d "=")
		#FDEST=$(echo $F | cut -f10 -d "@" | cut -f2 -d "=")
		#FLENGTH=$(echo $F | cut -f11 -d "@" | cut -f2 -d "=")
		FLENGTH=$(echo $F | sed 's/.*@LEN=//' | sed 's/@.*//')
		#FTOS=$(echo $F | cut -f12 -d "@" | cut -f2 -d "=")
		#FPROTO=$(echo $F | cut -f17 -d "@" | cut -f2 -d "=")

		# Get the param of port
		# If the param will be the indicated the SPORT pass the value to variable
		#FSPORT=$(echo $F | awk -F@ '$10 ~/SPT=/ {print $10}'| cut -f2 -d "=")
		FSPORT=$(echo $F | sed 's/.*@SPT=//' | sed 's/@.*//')
		# If the param will be the indicated the DPORT pass the value to variable
		#FDPORT=$(echo $F | awk -F@ '$19 ~/DPT=/ {print $19}'| cut -f2 -d "=")
		FDPORT=$(echo $F | sed 's/.*@DPT=//' | sed 's/@.*//')
		
		FSERVICELENGTH=$(expr $FSERVICELENGTH + $FLENGTH)
		echo $FLENGTH >> $TMPLENGTH
	 done
		echo "$FAPPLICATION:$FPORT:$FPROTO:$FSERVICELENGTH" >> $SERVICEFILE
	fi
done

TCPRULES=$(cat $SERVICEFILE | grep -i :tcp: | awk -F: '{print $4}')
for F in $TCPRULES
do
	FCOUNTTCP=$(expr $FCOUNTTCP + $F)
done

UDPRULES=$(cat $SERVICEFILE | grep -i :udp: | awk -F: '{print $4}')
for F in $UDPRULES
do
	FCOUNTUDP=$(expr $FCOUNTUDP + $F)
done

# Generate the pizza's graph with the protocols of layer 7

TEMP=$(cat $SERVICEFILE | cut -f1 -d ":")
SERVICE=$(echo $TEMP | sed "s/ /\','/g" | sed "s/^/'/" | sed "s/$/'/")

#TEMP=$(cat $SERVICEFILE | cut -f2 -d ":")
#FPORT=$(echo $TEMP | sed "s/ /\','/g" | sed "s/^/'/" | sed "s/$/'/")

TEMP=$(cat $SERVICEFILE | cut -f4 -d ":")
#FLENGTH=$(echo $TEMP | sed "s/ /\','/g" | sed "s/^/'/" | sed "s/$/'/")
echo "
	<?php
	"'$data'" = array();
	" > $GRAPHDATASERVICE

P=0

for F in $TEMP
do
echo "	"'$data['"$P"']'" = $F;" >> $GRAPHDATASERVICE
P=$(expr $P + 1)
done


for F in $TEMP
do
	COUNTLENGTH=$(expr $COUNTLENGTH + $F)
done
	FDATECURRENT=$(date +%Y/%m/%d)
	

	#Generate the graph to protocol TCP
	echo "
	
	include_once('../.lib_graph@/.graph.php');
	"'$g'" = new graph();

	"'$g'"->bg = '#E4F0DB';
	"'$g'"->pie(60,'#E4F0DB','{display:none;}',false,1);

	"'$g'"->pie_values( "'$data'", array("$SERVICE") );

	"'$g'"->pie_slice_colours( array('#d01f3c','#356aa0','#C79810','#FFDAB9','#00EE00','#4682B4','#66CDAA','#00FF7F','#6B8E23','#FFD700','#B22222') );
	"'$g'"->set_tool_tip( '#x_label#<br>#val# bytes' );

	"'$g'"->title( '', '{font-size:18px; color: #d01f3c}' );

	echo "'$g'"->render();
	?>
	" >> $GRAPHDATASERVICE


# Generate the pizza's graph with the protocols TCP and UDP

echo "
	<?php
	"'$data'" = array();
	" > $GRAPHDATAPROTOCOL

P=0

echo "	"'$data['0']'" = $FCOUNTTCP;" >> $GRAPHDATAPROTOCOL
echo "	"'$data['1']'" = $FCOUNTUDP;" >> $GRAPHDATAPROTOCOL


	#Generate the graph to protocol TCP and UDP
	echo "
	
	include_once('../.lib_graph@/.graph.php');
	"'$g'" = new graph();

	"'$g'"->bg = '#E4F0DB';
	"'$g'"->pie(60,'#E4F0DB','{display:none;}',false,1);

	"'$g'"->pie_values( "'$data'", array('"'TCP'"','"'UDP'"') );

	"'$g'"->pie_slice_colours( array('#d01f3c','#356aa0','#C79810','#FFDAB9','#00EE00','#4682B4','#66CDAA','#00FF7F','#6B8E23','#FFD700','#B22222') );
	"'$g'"->set_tool_tip( 'Label: #x_label#<br>Value: #val# bytes' );

	"'$g'"->title( '', '{font-size:18px; color: #d01f3c}' );

	echo "'$g'"->render();
	?>
	" >> $GRAPHDATAPROTOCOL


