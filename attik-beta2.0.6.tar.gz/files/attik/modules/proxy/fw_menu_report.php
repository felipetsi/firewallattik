<div id="menu_options_type"> <!--Main--> 
<form action="report_px.php" method="post" name="menu_report_service">
<a href="javascript:document.menu_report_service.submit();">
	<div class="button_report_type" >
		<input type="hidden" name="type_report" value="service" />
		<img src="/controlcenter/@img/icons/protocol-24x24.gif" align="absmiddle"/>
		<?php echo $T_SERVICE;?>
	</div>
</a>
</form>
<form action="report_px.php" method="post" name="menu_report_protocol">
<a href="javascript:document.menu_report_protocol.submit();">
	<div class="button_report_type">
		<input type="hidden" name="type_report" value="protocol" />
		<img src="/controlcenter/@img/icons/protocol-transport-24x24.gif" align="absmiddle"/>	
		<?php echo $T_PROTOCOL;?>
	</div>
</a>
</form>
</div>