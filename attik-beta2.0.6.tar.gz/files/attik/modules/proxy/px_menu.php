<div id="menu_options"> <!--Main--> 
<a href="general_conf_px.php">
	<div class="button_mod_px">
		<img src="/controlcenter/@img/icons/build-24x24.gif" align="absmiddle"/>
		<?php echo $L_CONFIGURATION;?>
	</div>
</a>
<?php /*<a href="build_px.php">
	<div class="button_mod_px">
		<img src="/controlcenter/@img/icons/wizard-24x24.gif" align="absmiddle"/>	
		<?php echo $L_WIZARD;?>
	</div>
</a>*/ ?>
<a href="rule_px.php">
	<div class="button_mod_px">
		<img src="/controlcenter/@img/icons/rule-24x24.gif" align="absmiddle"/>	
		<?php echo $L_RULES;?>
	</div>
</a>
<a href="report_px.php">
	<div class="button_mod_px">
		<img src="/controlcenter/@img/icons/graph-24x24.gif" align="absmiddle"/>
		<?php echo $L_REPORT;?>
	</div>
</a> 
<a href="apply_modified_run_px.php">
	<div class="button_mod_px">
		<img src="/controlcenter/@img/icons/apply-24x24.gif" align="absmiddle"/>
		<?php echo $L_APPLY_RULES;?>
	</div>
</a>
</div>