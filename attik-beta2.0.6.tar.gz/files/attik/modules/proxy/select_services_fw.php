<?php
require_once('../../includes/control_session.php');

$_SESSION['FILE_LANG'] = "firewall.php";
$DESTINATION_PAGE = "select_services_run_fw.php";
$THISPAGE = "select_services_fw.php";
$DESTINATION_END = "rule_fw.php";
$DESTINATION_BACK = "build_fw.php";
$POSITION = substr(trim(addslashes($_POST['position'])),0,4);

if(!empty($POSITION)){
	$SQL = "SELECT id FROM cc_firewall.network WHERE id NOT IN (SELECT id_net FROM cc_firewall.hostserver) AND id_pfw = '$POSITION' ";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB034F"));
	if(mysql_affected_rows() > 0){
		$_SESSION['INVALIDTOPOLOGY']=1;
	}
}
if (empty($POSITION) && ($_SESSION['CONTROLBACK'] == 1))
{
	$_SESSION['SHOW_MSG'] = 'ME_NEEDSELECT';
	header("Location:$DESTINATION_BACK");
}
elseif (empty($_SESSION['CONTROLBACK']))
{
	header("Location:$DESTINATION_BACK");
}
else
{
	if($_SESSION['PG_SERVER_NET'] != 1)
	{
		if(!empty($POSITION)) {
			$SQL = "SELECT * FROM cc_firewall.network WHERE id_pfw='$POSITION'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB003F"));
			$_SESSION['QTD_NET_POSITION'] = mysql_num_rows($RS);
			
			if($LOG_AUDITOR == 1){
				auditor('IFWAB004F', $ADDRIP, $USER, '0');
			}
			
			$_SESSION['COUNTNET'] = mysql_num_rows($RS);
		
			$ARRAY = mysql_fetch_array($RS);
			$_SESSION['NET'] = $ARRAY['name'];
			$_SESSION['IDNET'] = $ARRAY['id'];
			$_SESSION['POSITION'] = $POSITION;
			//Store the fisth combination
			$_SESSION['SEQ1'] = 0;
			
			//Store the second combination	
			$_SESSION['SEQ2'] = 0;
			
			//Store the count positions have in array
			$_SESSION['COUNTNETASSOCIATED'] = ($_SESSION['COUNTNET'] - 1);
			
			//Store the value two for control back
			$_SESSION['CONTROLBACK'] = 2;
			
			//Store the value 0 to control if is net to net or net to host
			$_SESSION['PG_SERVER_NET'] = 0;
		}
		
		$_SESSION['PG_SERVER_NET'] = 0;
			//Load thes session of variable on simple variable
			$POSITION = $_SESSION['POSITION'];
			$IDNET = $_SESSION['IDNET'];
		
			$SEQ = $_SESSION['SEQ2'];
			if ($SEQ < $_SESSION['COUNTNETASSOCIATED'])
			{
				$SQL = "SELECT * FROM cc_firewall.network WHERE id_pfw='$POSITION' AND id <> '$IDNET'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB005F"));
				$ARRAY = mysql_fetch_array($RS);
				for ($control = 0; $control < $SEQ; $control++)
				{
					$ARRAY = mysql_fetch_array($RS);
				}
				$_SESSION['IDNETASSOCIATED'] = $ARRAY['id'];
				$_SESSION['NETASSOCIATED'] = $ARRAY['name'];
				$SEQ = $_SESSION['SEQ2'];
				$SEQ++;
				$_SESSION['SEQ2'] = $SEQ;
			}
			else {
		
				$SEQ = $_SESSION['SEQ1'];
				$SEQ++;
				$_SESSION['SEQ1'] = $SEQ;
				$SQL = "SELECT * FROM cc_firewall.network WHERE id_pfw='$POSITION'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB006F"));
				
				$ARRAY = mysql_fetch_array($RS);
				for ($control = 0; $control < $SEQ; $control++)
				{
					$ARRAY = mysql_fetch_array($RS);
				}
				$_SESSION['IDNET'] = $ARRAY['id'];
				$_SESSION['NET'] = $ARRAY['name'];
				$_SESSION['SEQ2'] = 0;
				
				if ($SEQ >= $_SESSION['COUNTNET']){
					$_SESSION['CONTROLSTART'] = 1;
					$_SESSION['PG_SERVER_NET'] = 1;
				}
				header("Location:$THISPAGE");
			}
		}
		else 
		{
			$_SESSION['PG_SERVER_NET'] = 1;
			$POSITION = $_SESSION['POSITION'];
			if (empty($_SESSION['flow']))
			{
				//Control the flow of trafic. Ex. Server to one network
				$_SESSION['flow'] = 1;
			}
			if (!empty($_SESSION['CONTROLSTART']))
			{
				unset($_SESSION['CONTROLSTART']);
				unset($_SESSION['COUNTNET']);
				unset($_SESSION['COUNTHOST']);
				unset($_SESSION['ID_NET']);
				unset($_SESSION['NET']);
				unset($_SESSION['ID_HOST']);
				unset($_SESSION['HOST']);
				$_SESSION['CONTROLHOST'] = 1;
				$_SESSION['CONTROLNET'] = 1;	
			}
				
			//Network
			$SQL = "SELECT * FROM cc_firewall.network WHERE id_pfw='$POSITION'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB007F"));
			if ( $_SESSION['CHANGE_SERVER'] == 1 )
			{
				if (($_SESSION['COUNTNET'] == $_SESSION['CONTROLNET']) && ($_SESSION['FLOW'] == 1))
				{
					unset($_SESSION['FLOW']);
					unset($_SESSION['CONTROLSTART']);
					unset($_SESSION['COUNTNET']);
					unset($_SESSION['COUNTHOST']);
					unset($_SESSION['ID_NET']);
					unset($_SESSION['NET']);
					unset($_SESSION['ID_HOST']);
					unset($_SESSION['HOST']);
					unset($_SESSION['CONTROLNET']);
					unset($_SESSION['CONTROLHOST']);
					unset($_SESSION['PG_SERVER_NET']);
					$_SESSION['TABLE'] = 'filter';
					header("Location:$DESTINATION_END");
				}
				elseif (($_SESSION['COUNTNET'] == $_SESSION['CONTROLNET']) && (empty($_SESSION['FLOW'])))
				{
					$_SESSION['CONTROLSTART'] = 1;
					// This variable is for controler the flow (fluxo). Ex: Net to Server,  Server to Net.				
					$_SESSION['FLOW'] = 1;
					header("Location:$THISPAGE");
				}
				$_SESSION['CONTROLNET'] = ($_SESSION['CONTROLNET'] + 1);
				$_SESSION['CONTROLHOST'] = 1;
				$_SESSION['CHANGE_SERVER'] = 0;
			}
			$CONTROLNET = $_SESSION['CONTROLNET'];
			for ($control = 0; $control < $CONTROLNET; $control++)
			{
				$NETWORK = mysql_fetch_array($RS);
			}
			$_SESSION['COUNTNET'] = mysql_num_rows($RS);
				
			$_SESSION['ID_NET'] = $NETWORK['id'];
			$_SESSION['NET'] = $NETWORK['name'];
			
			// Need for will use in the next select
			$ID_NET = $_SESSION['ID_NET'];
	
			//Host Server
			$SQL = "SELECT id, name FROM cc_firewall.hostserver WHERE id_net in (SELECT id FROM cc_firewall.network ";
			$SQL .= "WHERE id_pfw ='$POSITION' AND id <> '$ID_NET')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB008F"));

			$_SESSION['COUNTHOST'] = mysql_num_rows($RS);

			$CONTROLHOST = $_SESSION['CONTROLHOST'];
			for ($control = 0; $control < $CONTROLHOST; $control++)
			{
				$HOST = mysql_fetch_array($RS);
			}
			$_SESSION['ID_HOST'] = $HOST['id'];
			$_SESSION['HOST'] = $HOST['name'];

			// Verify the end of list of servers.
			$COUNTHOST = $_SESSION['COUNTHOST'];
			if ("$COUNTHOST" == "$CONTROLHOST")
			{
				$_SESSION['CHANGE_SERVER'] = 1;
			}
			$_SESSION['CONTROLHOST'] = $CONTROLHOST + 1;
		}
?>
<?php if(($_SESSION['QTD_NET_POSITION'] > 1)&&($_SESSION['INVALIDTOPOLOGY'] != 1)){?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>..:: IncTI - Firewall ::..</title>
<link href="../../includes/style_cc.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php require_once('../../includes/top.php'); ?>
<?php require_once('fw_menu.php'); ?>
<div id="main"> <!--Main-->
<form action="<?php echo $DESTINATION_PAGE?>" method="post" name="fobject">
<?php
	if($_SESSION['PG_SERVER_NET'] != 1)
	{?>
		<div class="title_general_fw"><?php echo ("$S_NET ")?>
		<img src="../../@img/icons/network-connections-16x16.png" /><?php echo $_SESSION['NET']?>
		<? echo ("$S_TO ")?>
		<img src="../../@img/icons/network-connections-16x16.png" /><? echo $_SESSION['NETASSOCIATED'];?></div>
<?php
	}
	else
	{
		if (empty($_SESSION['FLOW']))
		{?>
			<div class="title_general_fw"><?php echo ("$S_NET ")?>
			<img src="../../@img/icons/network-connections-16x16.png" /><?php echo $_SESSION['NET']?>
			<? echo ("$S_TO ")?>
			<img src="../../@img/icons/server-16x16.png" /><? echo $_SESSION['HOST'];?></div>
		<?php 
		} else
		{ ?>
			<div class="title_general_fw"><?php echo ("$S_HOST ")?>
			<img src="../../@img/icons/server-16x16.png" /><?php echo $_SESSION['HOST']?>
			<? echo ("$S_TO ")?>
			<img src="../../@img/icons/network-connections-16x16.png" /><? echo $_SESSION['NET'];?></div>
		<?php
		} 
	}
	$SQLUSER = "SELECT create_rule FROM controlcenter.profilefw WHERE id IN ";
	$SQLUSER .= "(SELECT id_profw FROM controlcenter.profile WHERE id IN (SELECT id_pro FROM ";
	$SQLUSER .= "controlcenter.user WHERE id = '$USER'))";
	$RSUSER = mysql_query($SQLUSER) or (die("$ME_OCCURREDEERRORINTERNAL IFWSB031F"));
	$DATA_USER = mysql_fetch_array($RSUSER);
	if ($DATA_USER['create_rule'] == 1){
		require_once('select_services_show_fw.php');
	}?>
	
	<div id="sentence_warningselect">
	<?php echo $S_SELECTPROTOCOL; ?>
	</div>
	<input type="submit" value="<?php echo $B_NEXT;?>" />
</form>
<div class="version_general">
<?php
echo $VERSIONCC;
?>
</div>

</div>
</body>
</html>
<?php } else {
	if ($_SESSION['INVALIDTOPOLOGY'] == 1){
		$_SESSION['SHOW_MSG'] = 'ME_INSUFFICIENT_HOSTSERVER';
	} else {
		$_SESSION['SHOW_MSG'] = 'ME_TOPOLOGY_NET_INSUFFICIENT';
	}
	header("Location:$DESTINATION_BACK");
}
} ?>