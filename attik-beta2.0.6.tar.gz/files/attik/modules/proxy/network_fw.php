<?php 
require_once('../../includes/control_session.php');

$DESTINATION_PAGE = "network_run_fw.php";
$THISPAGE = "network_fw.php";
$_SESSION['FILE_LANG'] = "firewall.php";

// Load the profile of user autenticanted
$USER = $_SESSION['USER'];
$SQL = "SELECT create_net, read_net FROM controlcenter.profilefw WHERE id IN ";
$SQL .= "(SELECT id_profw FROM controlcenter.profile WHERE id IN (SELECT id_pro FROM ";
$SQL .= "controlcenter.user WHERE id = '$USER'))";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSN001F"));
$DATA_USER = mysql_fetch_array($RS);

// Load the item selected
if (!empty($_POST['list']))
{
	$_SESSION['ITEMID'] = $_POST['list'];
	$ITEMID = $_SESSION['ITEMID'];
} else {
	$ITEMID = $_SESSION['ITEMID'];
}
$_SESSION['ITEMDELETE'] = $ITEMID;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $TITLE_FW; ?></title>
<script language="javascript">
var thispage = "network_fw.php";
var deletepage = "network_delete_fw.php";
</script>
<link href="../../includes/style_cc.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php 
require_once('../../includes/top.php');
require_once('fw_menu.php');
?>
<script language="javascript">
function confirmDeleteSelected()
{
	document.getElementById('box_delete').style.display="table";
}
function yesdeleteSelected()
{
	window.location=deletepage;
}
function nodeleteSelected()
{
	document.getElementById('box_delete').style.display="none";
}
</script>
<div id="box_delete"><?php echo("$S_WANT_DELETE?");?> 
	<div class="space_confirm_box">
		<input type="button" value="<?php echo $B_YES;?>" onclick="javascript:yesdeleteSelected();" />
		<input type="button" value="<?php echo $B_NO;?>" onclick="javascript:nodeleteSelected();" />
	</div>	
</div>

<div id="main"> <!--Main-->
<?php require_once('px_menu_configuration.php');?>

	<div id="contet_rigth">
<?php
if ($DATA_USER['create_net'] == 1) {

// Load the user selected
$SQL = "SELECT * FROM cc_firewall.network WHERE id = '$ITEMID'";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSN002F"));
if((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1)){
		auditor('IFWSN002S', $ADDRIP, $USER, '0');
}
$ARRAY = mysql_fetch_array($RS);

$SQL = "SELECT * from controlcenter.interface WHERE id in (SELECT id FROM  cc_firewall.network WHERE id = '$ITEMID')";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSN003F"));
$OTHER = mysql_fetch_array($RS);
?>
<!--Start add-->
<form class="insert_border" action="<?php echo $DESTINATION_PAGE;?>" method="post">
<input type="hidden" name="id" value="<?php echo $ARRAY['id'];?>" />
<input type="hidden" name="id_face" value="<?php echo $OTHER['id'];?>" />
<div class="title_general_fw" > <?php echo $T_NETWORK; ?> </div>
<div id="contet_rigth_data">
<div align="right" class="left_name"><u><?php echo $F_NAME;?></u></div>
	<div> <input type="text" size="20" maxlength="20" name="name"  value="<?php if(!empty($_SESSION['EX_NAME'])) { echo $_SESSION['EX_NAME'];} else { echo $ARRAY['name'];}?>" autocomplete="off"/></div>

<div align="right" class="left_name"><u><?php echo $F_CLASS;?></u></div>
	<div> <input type="text" size="20" maxlength="18" name="class" value="<?php if(!empty($_SESSION['EX_CLASS'])) { echo $_SESSION['EX_CLASS'];} else { echo $ARRAY['class'];}?>" autocomplete="off"/></div>
<div align="right" class="left_name"><?php echo $F_MASK;?></div>
	<div> <input type="text" size="20" maxlength="18" name="mask" value="<?php if(!empty($_SESSION['EX_MASK'])) { echo $_SESSION['EX_MASK'];} else { echo $ARRAY['mask'];}?>" autocomplete="off"/></div>

<div align="right" class="left_name"><u><?php echo $F_SELECT_POSITIONFW;?></u></div>
	<div> <select name="positionfw">
				<option> </option>
	<?php
		$SQL = "SELECT id, name FROM cc_firewall.positionfw ORDER BY name";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSN005F"));
		$DATA = mysql_fetch_array($RS);
		$cor = 1;	
		do{
		if (($ARRAY['id_pfw'] == $DATA['id']) or ($_SESSION['EX_POSITIONFW'] == $DATA['id'])) {
			$sel = 'selected="selected"';
		} else {
				$sel = "";
		}
	
		if ( $cor == 1 )
		{
			?>
			<option value="<?php echo $DATA['id'];?>" <?php echo $sel;?> ><?php echo $DATA['name']; $cor=0?></option>
			<?php 
		} else { ?>
			<option style="background:<?php echo $COLOR_LINE_SELECT;?>" value="<?php echo $DATA['id'];?>" <?php echo $sel;?> ><?php echo $DATA['name']; $cor=1;?></option>
			<?php
		} 
	}while ($DATA =  mysql_fetch_array($RS));?>
	</select></div>
	</div>
	<div id="contet_rigth_img">
	<img src="../../@img/icons/globe-Vista-128x128.png" />
	</div>
<div class="title_general_fw">		
	<input type="submit" value="<?php if (empty($ARRAY['id'])){ echo $B_ADD_NEW;} else { echo $B_UPDATE;}?>" />
	<input type="button" value="<?php echo $B_CLEAR;?>" onclick="javascript:window.location=thispage" />
	<?php
	if (($DATA_USER['create_net'] == 1)&&($DATA_USER['read_net'] == 1)){?>
	<input type="button" value="<?php echo $B_DELETE;?>" onClick="javascript:confirmDeleteSelected();" />
	<?php 
	}?>
</div>
</form>
<!--End add-->
<?php }
if ($DATA_USER['read_net'] == 1) {
?>
<!-- Start list-->

<div class="title_general_fw"><?php echo $T_NETWORK_LIST;?></div>
<form class="insert_border" action="<?php echo $THISPAGE;?>" method="post" name="objselect">
<select class="select_list" name="list" size="20" onclick="javascript:document.objselect.submit()">
<?php
$SQL = "SELECT id, name FROM cc_firewall.positionfw ORDER BY name";
$RS1 = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSN006F"));
$OTHER = mysql_fetch_array($RS1);
if(mysql_affected_rows($RS1) > 0){
	do{
		$ID_PFW = $OTHER['id'];
		$SQL = "SELECT id, name FROM cc_firewall.network WHERE id_pfw = '$ID_PFW' ORDER BY name";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSN007F"));
		$ARRAY = mysql_fetch_array($RS);
		if(!empty($ARRAY['id']))
		{
			?>
			<optgroup label="<?php echo $OTHER['name'];?>"><?php
			$cor = 1;	
			do{
			if ($ITEMID == $ARRAY['id']) {
				$sel = 'selected="selected"';
			} else {
					$sel = "";
			}
			
			if ( $cor == 1 )
			{
			?>
				<option value="<?php echo $ARRAY['id'];?>" <?php echo $sel;?> ><?php echo $ARRAY['name']; $cor=0;?></option>
			<?php 
			} else { ?>
				<option style="background:<?php echo $COLOR_LINE_SELECT;?>" value="<?php echo $ARRAY['id'];?>" <?php echo $sel;?> ><?php echo $ARRAY['name']; $cor=1;?></option>
			<?php
			} 
			}while ($ARRAY =  mysql_fetch_array($RS));?>
			</optgroup><?php
		}
	}while ($OTHER = mysql_fetch_array($RS1));
} else {
	$SQL = "SELECT id, name FROM cc_firewall.network ORDER BY name";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSN007F"));
	$ARRAY = mysql_fetch_array($RS);
	do{
		if ( $cor == 1 )
		{
		?>
			<option value="<?php echo $ARRAY['id'];?>" <?php echo $sel;?> ><?php echo $ARRAY['name']; $cor=0;?></option>
		<?php 
		} else { ?>
			<option style="background:<?php echo $COLOR_LINE_SELECT;?>" value="<?php echo $ARRAY['id'];?>" <?php echo $sel;?> ><?php echo $ARRAY['name']; $cor=1;?></option>
		<?php
		} 
	}while ($ARRAY =  mysql_fetch_array($RS));
}?>
</select>
</form>
	</div>
<?php 
}?>
<div class="version_general">
<?php
echo $VERSIONCC;
?>
</div>

</div>
</body>
</html>
<?php
unset($_SESSION['ITEMID']);
unset($_SESSION['EX_NAME']);
unset($_SESSION['EX_CLASS']);
unset($_SESSION['EX_MASK']);
unset($_SESSION['EX_POSITIONFW']);
?>