<?php 
require_once('../../includes/control_session.php');
$DESTINATION_PAGE = $_SESSION['SOURCE_PAGE'];

// Load the profile of user autenticanted
$SQL = "SELECT create_rule, read_rule FROM controlcenter.profilefw WHERE id IN ";
$SQL .= "(SELECT id_profw FROM controlcenter.profile WHERE id IN (SELECT id_pro FROM ";
$SQL .= "controlcenter.user WHERE id = '$USER'))";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR001F"));
$DATA_USER = mysql_fetch_array($RS);

if ($DATA_USER['create_rule'] == 1)
{
	$ID = trim(addslashes($_POST['idrule']));
	if ($ID != "")
	{
		$IDTARGET = $ID + 1;
		$SQL = "SELECT id FROM cc_firewall.rulefw WHERE '$IDTARGET'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR052F"));
		if (mysql_affected_rows() == 0)
		{
			$SQLF = "UPDATE cc_firewall.rulefw SET id = '$IDTARGET' WHERE id = '$ID'";

			// Change the attributes
			$SQL = "UPDATE cc_firewall.rul_atr SET id_rul = '$IDTARGET' WHERE id_rul = '$ID'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR053F"));
		}
		else
		{
			// Change the rule position
			$SQL = "UPDATE cc_firewall.rulefw SET id = '0.1' WHERE id = '$ID'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR054F"));
			// Change the rule position
			$SQL = "UPDATE cc_firewall.rulefw SET id = '$ID' WHERE id = '$IDTARGET'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR055F"));
			// Change the rule position
			$SQLF = "UPDATE cc_firewall.rulefw SET id = '$IDTARGET' WHERE CONCAT_WS('-',id) = '0.1'";
			
			// Change the attributes
			$SQL = "UPDATE cc_firewall.rul_atr SET id_rul = '0.1' WHERE id_rul = '$ID'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR056F"));
			// Change the attributes
			$SQL = "UPDATE cc_firewall.rul_atr SET id_rul = '$ID' WHERE id_rul= '$IDTARGET'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR057F"));
			// Change the attributes
			$SQL = "UPDATE cc_firewall.rul_atr SET id_rul = '$IDTARGET' WHERE CONCAT_WS('-',id_rul) = '0.1'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR058F"));
		}
	}
	$RS = mysql_query($SQLF) or (die("$ME_OCCURREDEERRORINTERNAL IFWUR059F"));
	if (mysql_affected_rows() != 0)
	{
		if($LOG_AUDITOR == 1){
				auditor('IFWUR059S', $ADDRIP, $USER, '0');
		}
		$_SESSION['SHOW_MSG'] = 'F_SUCESS';
	} 
	else 
	{
		if($LOG_AUDITOR == 1){
				auditor('IFWUR059F', $ADDRIP, $USER, '0');
		}
		$_SESSION['SHOW_MSG'] = 'F_FAILURE';
	}
}
else
{
	$_SESSION['SHOW_MSG'] = 'ME_DONTHAVEPERMITION';
}
unset($_SESSION['SOURCE_PAGE']);
header("Location:$DESTINATION_PAGE");
?>