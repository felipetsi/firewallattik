<?php 
require_once('../../includes/control_session.php');

$DESTINATION_PAGE = "network_fw.php";

$ID = trim(addslashes($_POST['id']));
$NAME = substr(trim(addslashes($_POST['name'])),0,20);
$CLASS = substr(trim(addslashes($_POST['class'])),0,18);
$MASK = substr(trim(addslashes($_POST['mask'])),0,18);
$POSITIONFW = substr(trim(addslashes($_POST['positionfw'])),0,2);

if ((empty($NAME)) || (empty($POSITIONFW))) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDFILL';
	$_SESSION['ITEMID'] = $ID;
	$_SESSION['EX_CLASS'] = $CLASS;
	$_SESSION['EX_MASK'] = $MASK;
	$_SESSION['EX_NAME'] = $NAME;
	$_SESSION['EX_POSITIONFW'] = $POSITIONFW;	
	header("Location:$DESTINATION_PAGE");
}
elseif((!empty($CLASS)) && (verifyIp($CLASS) != "ok") && ($CLASS != "0.0.0.0") || (eregi("[^0-9./]", $CLASS, $regs)) || 
((sizeof(explode("/",$CLASS)) > 1) && (!empty($MASK)) )){
	$_SESSION['SHOW_MSG'] = 'ME_INVALIDCLASS';
	$_SESSION['ITEMID'] = $ID;
	$_SESSION['EX_NAME'] = $NAME;
	$_SESSION['EX_CLASS'] = $CLASS;
	$_SESSION['EX_MASK'] = $MASK;
	$_SESSION['EX_POSITIONFW'] = $POSITIONFW;	
	header("Location:$DESTINATION_PAGE");
}
elseif((verifyMask($MASK) != "ok")&&(!empty($MASK))){
	$_SESSION['SHOW_MSG'] = 'ME_INVALIDMASK';
	$_SESSION['ITEMID'] = $ID;
	$_SESSION['EX_NAME'] = $NAME;
	$_SESSION['EX_CLASS'] = $CLASS;
	$_SESSION['EX_MASK'] = $MASK;
	$_SESSION['EX_POSITIONFW'] = $POSITIONFW;	
	header("Location:$DESTINATION_PAGE");
}
else {
	$SQL = "SELECT * FROM cc_firewall.network WHERE (name = '$NAME' OR (class = '$CLASS' AND mask = '$MASK') ) ";
	$SQL .= "AND id != '$ID' AND id_pfw = '$POSITIONFW'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSN008F"));
	if ( mysql_affected_rows() !=0 )
	{
		if($LOG_AUDITOR == 1){
			auditor('IFWSN008F', $ADDRIP, $USER, '0');
		}
		$_SESSION['SHOW_MSG'] = 'ME_NAMEORCLASSEXIST';
		$_SESSION['ITEMID'] = $ID;
		$_SESSION['EX_NAME'] = $NAME;
		$_SESSION['EX_CLASS'] = $CLASS;
		$_SESSION['EX_MASK'] = $MASK;
		$_SESSION['EX_POSITIONFW'] = $POSITIONFW;
		header("Location:$DESTINATION_PAGE");
	}
	else {
		if (empty($ID)) {
				
			$SQL = "INSERT INTO cc_firewall.network (name, class, mask , id_pfw) "; 
			$SQL .= "VALUES ('$NAME', '$CLASS', '$MASK', '$POSITIONFW')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIN009F"));
		}
		else {
			$SQL = "UPDATE cc_firewall.network SET name='$NAME', class='$CLASS', mask='$MASK', ";
			$SQL .= "id_pfw='$POSITIONFW' WHERE id = '$ID' ";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUN010F"));
			}
			if (mysql_affected_rows() != 0) {
				if($LOG_AUDITOR == 1){
					auditor('IFWXN011S', $ADDRIP, $USER, '0');
				}
				$_SESSION['SHOW_MSG'] = 'F_SUCESS';
			} else {
				if($LOG_AUDITOR == 1){
					auditor('IFWXN011F', $ADDRIP, $USER, '0');
				}
				$_SESSION['SHOW_MSG'] = 'F_FAILURE';
			}
			header("Location:$DESTINATION_PAGE");
	}
}
?>