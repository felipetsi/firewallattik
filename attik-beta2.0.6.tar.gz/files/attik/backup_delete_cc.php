<?php 
require_once('includes/control_session.php');
require('configuration/directory.php');

$DESTINATION_PAGE = "backup_cc.php";

$ITEM = $_SESSION['ITEMDELETE'];

if (empty($ITEM)) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDSELECT';
}
else {
	for ($f = 0; $f < sizeof($ITEM); $f++){
		$ID = $ITEM[$f];
		
		$SQL = "DELETE FROM cc_backup.backup WHERE date_created = '$ID'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCDB007F"));
			if (mysql_affected_rows() != 0) {			
				$FILETARGET = str_replace(":","-",str_replace(" ", "_", $ID)).".its";
				// Verify if the file exist
				if (is_file("$DIRBACKUPDB/$FILETARGET")){
					// Remove the file of disc
					if (unlink("$DIRBACKUPDB/$FILETARGET") == true){
						$_SESSION['SHOW_MSG'] = 'F_SUCESS';
						if ($LOG_AUDITOR != 0){
							auditor('ICCDB008S', $ADDRIP, $USER, $ID);
						}
					} else {
						$_SESSION['SHOW_MSG'] = 'F_FAILURE';
						if ($LOG_AUDITOR != 0){
							auditor('ICCDB008F', $ADDRIP, $USER, $ID);
						}
					}
				}
			} else {
				$_SESSION['SHOW_MSG'] = 'F_FAILURE';
				if ($LOG_AUDITOR != 0){
					auditor('ICCDB007F', $ADDRIP, $USER, '0');
				}
		}
	}
	unset($_SESSION['ITEMDELETE']);
	}
header("Location: $DESTINATION_PAGE");
?>