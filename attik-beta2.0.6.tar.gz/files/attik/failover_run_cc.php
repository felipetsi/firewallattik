<?php 
require_once('includes/control_session.php');
require('configuration/directory.php');

$DESTINATION_PAGE = "failover_cc.php";

$ID = substr(trim(addslashes($_POST['id'])),0,15);
$VIRTUALIP = substr(trim(addslashes($_POST['virtual_ip'])),0,15);
$NAME_IFACE = substr(trim(addslashes($_POST['interface'])),0,6);
$IDENTIFICATION = substr(trim(addslashes($_POST['identification'])),0,3);
$SKEW = substr(trim(addslashes($_POST['skew'])),0,3);
$MASTER = substr(trim(addslashes($_POST['master'])),0,3);
$PASSWORD = substr(trim(addslashes($_POST['password'])),0,40);
$REPASSWORD = substr(trim(addslashes($_POST['repassword'])),0,40);

if(empty($IDENTIFICATION)  || empty($VIRTUALIP) || empty($SKEW)) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDFILL';
	$_SESSION['NAME_IFACE'] = $NAME_IFACE;
	$_SESSION['IDENTIFICATION'] = $IDENTIFICATION;
	$_SESSION['SKEW'] = $SKEW;
	$_SESSION['PASSWORD'] = $PASSWORD;
	$_SESSION['REPASSWORD'] = $REPASSWORD;
	$_SESSION['VIRTUALIP'] = $VIRTUALIP;
	$_SESSION['MASTER'] = $MASTER;
}
elseif ($REPASSWORD != $PASSWORD) {
	$_SESSION['SHOW_MSG'] = 'ME_DIFFERENT_PASSWORD';
	$_SESSION['NAME_IFACE'] = $NAME_IFACE;
	$_SESSION['IDENTIFICATION'] = $IDENTIFICATION;
	$_SESSION['SKEW'] = $SKEW;
	$_SESSION['PASSWORD'] = $PASSWORD;
	$_SESSION['REPASSWORD'] = $REPASSWORD;
	$_SESSION['VIRTUALIP'] = $VIRTUALIP;
	$_SESSION['MASTER'] = $MASTER;
}
elseif(verifyIp($VIRTUALIP) != "ok"){
	$_SESSION['SHOW_MSG'] = 'ME_INVALIDIP';
	$_SESSION['NAME_IFACE'] = $NAME_IFACE;
	$_SESSION['IDENTIFICATION'] = $IDENTIFICATION;
	$_SESSION['SKEW'] = $SKEW;
	$_SESSION['PASSWORD'] = $PASSWORD;
	$_SESSION['REPASSWORD'] = $REPASSWORD;
	$_SESSION['VIRTUALIP'] = $VIRTUALIP;
	$_SESSION['MASTER'] = $MASTER;
}else
{
	$SQL = "SELECT name_ifa FROM controlcenter.failover WHERE (virtual_ip = '$VIRTUALIP' OR ";
	$SQL .= "'$VIRTUALIP' IN (SELECT ip FROM controlcenter.interface)) AND virtual_ip != '$VIRTUALIP'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCFI006F"));
	if (mysql_affected_rows() != 0) {
		$_SESSION['SHOW_MSG'] = 'ME_IPASSOCIATED';
		$_SESSION['NAME_IFACE'] = $NAME_IFACE;
		$_SESSION['IDENTIFICATION'] = $IDENTIFICATION;
		$_SESSION['SKEW'] = $SKEW;
		$_SESSION['PASSWORD'] = $PASSWORD;
		$_SESSION['REPASSWORD'] = $REPASSWORD;
		$_SESSION['VIRTUALIP'] = $VIRTUALIP;
		$_SESSION['MASTER'] = $MASTER;
		if($LOG_AUDITOR == 1){
			auditor('ICCFS008F', $ADDRIP, $USER, '0');
		}
	} else {
		$SQL = "SELECT name_ifa FROM controlcenter.failover WHERE name_ifa = '$NAME_IFACE' ";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCFS009F"));
		if (mysql_affected_rows() != 0) {
			$_SESSION['SHOW_MSG'] = 'ME_INTERFACEINUSE';
			$_SESSION['NAME_IFACE'] = $NAME_IFACE;
			$_SESSION['IDENTIFICATION'] = $IDENTIFICATION;
			$_SESSION['SKEW'] = $SKEW;
			$_SESSION['PASSWORD'] = $PASSWORD;
			$_SESSION['REPASSWORD'] = $REPASSWORD;
			$_SESSION['VIRTUALIP'] = $VIRTUALIP;
			$_SESSION['MASTER'] = $MASTER;
			if($LOG_AUDITOR == 1){
				auditor('ICCFS008F', $ADDRIP, $USER, '0');
			}
		}
		else {
			if (empty($MASTER)){
				$MASTER = 1;
			}
	// Ser� gerado um hash da senha mas apenas os 19 primeiros caracteres ser�o armazenados no BD e no arquivo de configura��o.
			$PASSWORD = substr(sha1($REPASSWORD),0,19);
			if(empty($ID)) {
				$SQL = "INSERT INTO controlcenter.failover (name_ifa, identification, skew, master, password, virtual_ip) ";
				$SQL .= "VALUES ('$NAME_IFACE', '$IDENTIFICATION', '$SKEW', '$MASTER', '$PASSWORD','$VIRTUALIP' )";
			} else {
				if (!empty($REPASSWORD)){
					$SQL = "UPDATE controlcenter.failover SET name_ifa='$NAME_IFACE', ";
					$SQL .= "identification='$IDENTIFICATION', ";
					$SQL .= "master='$MASTER', password='$PASSWORD', virtual_ip='$VIRTUALIP', ";
					$SQL .= "skew='$SKEW' WHERE virtual_ip = '$ID'";
				} else {
					$SQL = "UPDATE controlcenter.failover SET name_ifa='$NAME_IFACE', ";
					$SQL .= "identification='$IDENTIFICATION', ";
					$SQL .= "master='$MASTER', virtual_ip='$VIRTUALIP', ";
					$SQL .= "skew='$SKEW' WHERE virtual_ip = '$ID'";
				}
			}
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCFI003F"));
	
			// To failover file
			$COMMAND = "echo '#!/bin/bash' > $FILEFAILOVERCONF";
			exec($COMMAND,$RETURN);
			$COMMAND = "echo 'sudo killall ucarp' >> $FILEFAILOVERCONF";
			exec($COMMAND,$RETURN);
			// To vip-up file
			$COMMAND = "echo '#!/bin/bash' > $FILEVIPUP";
			exec($COMMAND,$RETURN);
			// To vip-down file
			$COMMAND = "echo '#!/bin/bash' > $FILEVIPDOWN";
			exec($COMMAND,$RETURN);
			
			$SQL = "SELECT f.identification, f.skew, f.master, f.password, f.virtual_ip, i.ip, i.name FROM ";
			$SQL .= "controlcenter.failover f, controlcenter.interface i WHERE ";
			$SQL .= "f.name_ifa = i.name";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCFS007F"));
			$ARRAY = mysql_fetch_array($RS);
			do {
				if(!empty($ARRAY['ip'])){$RULEFAILOVER = "sudo ucarp -s ".$ARRAY['ip']; $CONTROLLOOP = 1;}
				if(!empty($ARRAY['virtual_ip'])){$RULEFAILOVER .= " -a ".$ARRAY['virtual_ip'];
						$SCRIPTVIPUP = "/sbin/ip addr add ".$ARRAY['virtual_ip']." dev ".$ARRAY['name'];
						$SCRIPTVIPDOWN = "/sbin/ip addr del ".$ARRAY['virtual_ip']." dev ".$ARRAY['name'];
					}
				if(!empty($ARRAY['identification'])){$RULEFAILOVER .= " -v ".$ARRAY['identification'];}
				if(!empty($ARRAY['skew'])){$RULEFAILOVER .= " -k ".$ARRAY['skew'];}
				if(!empty($ARRAY['master'])){$RULEFAILOVER .= " -b ".$ARRAY['master'];}
				if(!empty($ARRAY['password'])){$RULEFAILOVER .= " -p ".$ARRAY['password'];}
				if(!empty($RULEFAILOVER)){
					$RULEFAILOVER .= " -u $FILEVIPUP";
					$RULEFAILOVER .= " -d $FILEVIPDOWN";
					$RULEFAILOVER .= " -B";
				}
				// To failover file
				if(!empty($RULEFAILOVER)){ 
					$COMMAND = "echo $RULEFAILOVER >> $FILEFAILOVERCONF";
					exec($COMMAND,$RETURN);
				}
				// To vip-up file
				if(!empty($SCRIPTVIPUP)){ 
					$COMMAND = "echo $SCRIPTVIPUP >> $FILEVIPUP";
					exec($COMMAND,$RETURN);
				}
				// To vip-up file
				if(!empty($SCRIPTVIPDOWN)){ 
					$COMMAND = "echo $SCRIPTVIPDOWN >> $FILEVIPDOWN";
					exec($COMMAND,$RETURN);
				}
			}while($ARRAY = mysql_fetch_array($RS));
			
			// To vip-up file
			if(!empty($CONTROLLOOP)){
				$COMMAND = "echo 'echo Master > ".$FILEFAILOVERLOG."' >> $FILEVIPUP";
				exec($COMMAND,$RETURN);
				
				$COMMAND = "echo 'echo Backup > ".$FILEFAILOVERLOG."' >> $FILEVIPDOWN";
				exec($COMMAND,$RETURN);			
			} else {
				$COMMAND = "echo  > $FILEFAILOVERCONF";
				exec($COMMAND,$RETURN);
				$COMMAND = "echo  > $FILEFAILOVERLOG";
				exec($COMMAND,$RETURN);
				$COMMAND = "echo  > $FILEVIPUP";
				exec($COMMAND,$RETURN);
				$COMMAND = "echo  > $FILEVIPDOWN";
				exec($COMMAND,$RETURN);
			}
			
			$COMMAND = "chmod 755 $FILEFAILOVERCONF $FILEVIPUP $FILEVIPDOWN";
			exec($COMMAND,$RETURN);
			
			$COMMAND = "$FILEFAILOVERCONF";
			exec($COMMAND,$RETURN);
			
			if(empty($RETURN))
			{
				if($LOG_AUDITOR == 1){
					auditor('ICCFI003S', $ADDRIP, $USER, '0');
				}
				$_SESSION['SHOW_MSG'] = 'F_SUCESS';
			} else {
				if($LOG_AUDITOR == 1){
					auditor('ICCFI003F', $ADDRIP, $USER, '0');
				}
				$_SESSION['SHOW_MSG'] = 'F_FAILURE';
			}
		}
	}
}
header("Location:$DESTINATION_PAGE");
?>
