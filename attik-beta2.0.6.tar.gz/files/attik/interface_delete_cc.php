<?php 
include('includes/control_session.php');

$DESTINATION_PAGE = "interface_cc.php";

$ID = trim(addslashes($_SESSION['ITEMDELETE']));

if (empty($ID)) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDSELECT';
	header("Location:$DESTINATION_PAGE");
}
else {
	if($_SESSION['INTERFACE'] == 1) {
		$SQL = "DELETE FROM controlcenter.interface WHERE id = '$ID'";
	} else {
		$SQL = "DELETE FROM controlcenter.interface WHERE vid = '$ID'";
	}
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWDI010F"));
	if ( mysql_affected_rows() !=0 )
	{
		if($LOG_AUDITOR == 1){
			auditor('IFWDI010S', $ADDRIP, $USER, '0');
		}
		$_SESSION['SHOW_MSG'] = 'F_SUCESS';
	}else {
		if($LOG_AUDITOR == 1){
			auditor('IFWDI010F', $ADDRIP, $USER, '0');
		}
		$_SESSION['SHOW_MSG'] = 'F_FAILURE';
	}
	unset($_SESSION['ITEMDELETE']);
	header("Location:$DESTINATION_PAGE");
}
?>