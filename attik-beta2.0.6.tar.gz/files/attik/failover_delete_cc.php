<?php 
require_once('includes/control_session.php');
require('configuration/directory.php');

$DESTINATION_PAGE = "failover_cc.php";

$ID = trim(addslashes($_SESSION['ITEMDELETE']));

if (empty($ID)) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDSELECT';
	header("Location: $DESTINATION_PAGE");
}
else {
	$SQL = "DELETE FROM controlcenter.failover WHERE virtual_ip = '$ID'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCFD002F"));
		if (mysql_affected_rows() != 0) {
			if ($LOG_AUDITOR != 0){
				auditor('ICCFD002S', $ADDRIP, $USER, '0');
			}
			
			$COMMAND = "sudo killall ucarp";
			exec($COMMAND,$RETURN);
			
			// To failover file
			$COMMAND = "echo '#!/bin/bash' > $FILEFAILOVERCONF";
			exec($COMMAND,$RETURN);
			$COMMAND = "echo 'sudo killall ucarp' >> $FILEFAILOVERCONF";
			exec($COMMAND,$RETURN);
			// To vip-up file
			$COMMAND = "echo '#!/bin/bash' > $FILEVIPUP";
			exec($COMMAND,$RETURN);
			// To vip-down file
			$COMMAND = "echo '#!/bin/bash' > $FILEVIPDOWN";
			exec($COMMAND,$RETURN);
			
			$SQL = "SELECT f.identification, f.skew, f.master, f.password, f.virtual_ip, i.ip, i.name FROM ";
			$SQL .= "controlcenter.failover f, controlcenter.interface i WHERE ";
			$SQL .= "f.name_ifa = i.name";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCFS007F"));
			$ARRAY = mysql_fetch_array($RS);
			do {
				if(!empty($ARRAY['ip'])){$RULEFAILOVER = "sudo ucarp -s ".$ARRAY['ip']; $CONTROLLOOP = 1;}
				if(!empty($ARRAY['virtual_ip'])){$RULEFAILOVER .= " -a ".$ARRAY['virtual_ip'];
						$SCRIPTVIPUP = "/sbin/ip addr add ".$ARRAY['virtual_ip']." dev ".$ARRAY['name'];
						$SCRIPTVIPDOWN = "/sbin/ip addr del ".$ARRAY['virtual_ip']." dev ".$ARRAY['name'];
					}
				if(!empty($ARRAY['identification'])){$RULEFAILOVER .= " -v ".$ARRAY['identification'];}
				if(!empty($ARRAY['skew'])){$RULEFAILOVER .= " -k ".$ARRAY['skew'];}
				if(!empty($ARRAY['master'])){$RULEFAILOVER .= " -P ";}
				if(!empty($ARRAY['password'])){$RULEFAILOVER .= " -p ".$ARRAY['password'];}
				if(!empty($RULEFAILOVER)){
					$RULEFAILOVER .= " -u $FILEVIPUP";
					$RULEFAILOVER .= " -d $FILEVIPDOWN";
					$RULEFAILOVER .= " -B";
				}
				// To failover file
				if(!empty($RULEFAILOVER)){ 
					$COMMAND = "echo $RULEFAILOVER >> $FILEFAILOVERCONF";
					exec($COMMAND,$RETURN);
				}
				// To vip-up file
				if(!empty($SCRIPTVIPUP)){ 
					$COMMAND = "echo $SCRIPTVIPUP >> $FILEVIPUP";
					exec($COMMAND,$RETURN);
				}
				// To vip-up file
				if(!empty($SCRIPTVIPDOWN)){ 
					$COMMAND = "echo $SCRIPTVIPDOWN >> $FILEVIPDOWN";
					exec($COMMAND,$RETURN);
				}
			}while($ARRAY = mysql_fetch_array($RS));
			
			// To vip-up file
			if(!empty($CONTROLLOOP)){
				$COMMAND = "echo 'echo Master > ".$FILEFAILOVERLOG."' >> $FILEVIPUP";
				exec($COMMAND,$RETURN);
				
				$COMMAND = "echo 'echo Backup > ".$FILEFAILOVERLOG."' >> $FILEVIPDOWN";
				exec($COMMAND,$RETURN);			
			} else {
				$COMMAND = "echo  > $FILEFAILOVERCONF";
				exec($COMMAND,$RETURN);
				$COMMAND = "echo  > $FILEFAILOVERLOG";
				exec($COMMAND,$RETURN);
				$COMMAND = "echo  > $FILEVIPUP";
				exec($COMMAND,$RETURN);
				$COMMAND = "echo  > $FILEVIPDOWN";
				exec($COMMAND,$RETURN);
			}
			
			$COMMAND = "chmod 755 $FILEFAILOVERCONF $FILEVIPUP $FILEVIPDOWN";
			exec($COMMAND,$RETURN);
			
			$COMMAND = "$FILEFAILOVERCONF";
			exec($COMMAND,$RETURN);

			$_SESSION['SHOW_MSG'] = 'F_SUCESS';
		} else {
			if ($LOG_AUDITOR != 0){
				auditor('ICCFD002F', $ADDRIP, $USER, '0');
			}
			$_SESSION['SHOW_MSG'] = 'F_FAILURE';
		}
	unset($_SESSION['ITEMDELETE']);
	header("Location: $DESTINATION_PAGE");
}
?>
