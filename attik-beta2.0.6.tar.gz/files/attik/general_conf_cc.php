<?php 
require_once('includes/control_session.php');
require('configuration/directory.php');

//Variable need becase various moment is use, including the top for change language
$THISPAGE = "general_conf_cc.php";
$DESTINATION_PAGE = "general_conf_run_cc.php";

// Load the profile of user autenticanted
$USER = $_SESSION['USER'];
$SQL = "SELECT change_config FROM controlcenter.profile WHERE ";
$SQL .= "id IN (SELECT id_pro FROM controlcenter.user WHERE id = '$USER')";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSG001F"));
$DATA_USER = mysql_fetch_array($RS);
$PORTHTTPSERVER = (exec("cat $FILEPORTHTTPSERVER",$RETURN));
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $TITLE; ?></title>
<link href="includes/style_cc.css" rel="stylesheet" type="text/css" />
<script language="javascript">
function verifyOptBkp(vi){
	if (vi == 'e' ) {
		document.getElementById('keep_backup').style.visibility="visible";
	} else {
		document.getElementById('keep_backup').style.visibility="hidden";
	}
}
</script>
</head>
<body onload="javascript:verifyOptBkp('<?php if($CREATE_BACKUP_AUTO == 1){ echo "e";} else { echo "d";};?>')">
<?php 
require_once('includes/top.php'); 
?>
<div id="main"> <!--Main-->
<?php require_once('cc_menu_configuration.php');?>

<div id="contet_rigth"> <!-- Rigth -->
<?php
if ($DATA_USER['change_config'] == 1) {
?>
<!--Start add-->
<form class="insert_border" action="<?php echo $DESTINATION_PAGE;?>" method="post" name="frmgeneral">
<div class="title_general" > <?php echo $T_GENERAL_CONFIG;?> </div>
<div id="contet_rigth_data">
<?php /*<div class="sub_title"><?php echo $T_INCTI_SUPORTT;?></div>
<div align="right" class="left_name"><?php echo $F_ENABLE;?></div>
	<div>
	<input type="radio" name="suport" value="1" <?php if ($INCTI_SUPORT_REMOTE == 1){echo 'checked="checked"';}?> />
	</div>
<div align="right" class="left_name"><?php echo $F_DISABLE;?></div>
	<div>
	<input type="radio" name="suport" value="0" <?php if ($INCTI_SUPORT_REMOTE == 0){echo 'checked="checked"';}?> />
	</div>*/?>
<div class="sub_title"><?php echo $T_AUDITORY;?></div>
<div align="right" class="left_name"><?php echo $F_ENABLE;?></div>
	<div>
	<input type="radio" name="audit" value="1" <?php if ($LOG_AUDITOR == 1){echo 'checked="checked"';}?> />
	</div>
<div align="right" class="left_name"><?php echo $F_DISABLE;?></div>
	<div>
	<input type="radio" name="audit" value="0" <?php if ($LOG_AUDITOR == 0){echo 'checked="checked"';}?> />
	</div>

<div class="sub_title"><?php echo $T_ENABLE_FIREWALL_STATE_FULL;?></div>
<div align="right" class="left_name"><?php echo $F_ENABLE;?></div>
	<div>
	<input type="radio" name="fw_state_full" value="1" <?php if ($FW_STATE_FULL == 1){echo 'checked="checked"';}?> />
	</div>
<div align="right" class="left_name"><?php echo $F_DISABLE;?></div>
	<div>
	<input type="radio" name="fw_state_full" value="0" <?php if ($FW_STATE_FULL == 0){echo 'checked="checked"';}?> />
	</div>
<?php /*
<div align="right" class="left_name"><?php echo $F_DISABLE;?></div>
	<div>
	<input type="radio" name="rule" value="0" <?php if ($APPLY_RULE_REAL_TIME == 0){echo 'checked="checked"';}?> />
	</div>

<div class="sub_title"><?php echo $T_CREATE_BACKUP_DAILY_AUTO;?></div>
<div align="right" class="left_name"><?php echo $F_ENABLE;?></div>
	<div>
	<input type="radio" name="backup" value="1" <?php if ($CREATE_BACKUP_AUTO == 1){echo 'checked="checked"';}?> onclick="javascript:verifyOptBkp('e');" />
	</div>
<div align="right" class="left_name"><?php echo $F_DISABLE;?></div>
	<div>
	<input type="radio" name="backup" value="0" <?php if ($CREATE_BACKUP_AUTO == 0){echo 'checked="checked"';}?> onclick="javascript:verifyOptBkp('d');" />
	</div>
	<div id="keep_backup">
	<div class="sub_title"><?php echo $T_KEEP_BACKUP;?></div>
		<div align="right" class="left_name"><?php echo $F_TIME_IN_DAY;?></div>
			<input type="text" name="keepBackup" size="10" maxlength="20" value="<?php echo $TIME_TO_KEEP_BACKUP;?>" autocomplete="off" />
			<?php echo $S_ALLWAY;?>
	</div>

<div class="sub_title"><?php echo $T_KEEP_ADITORY_TIME;?></div>
<div align="right" class="left_name"><?php echo $F_TIME_IN_DAY;?></div>
	<div>
	<input type="text" name="log" size="10" maxlength="20" value="<?php echo $TIME_TO_KEEP_LOG;?>" autocomplete="off" /> <?php echo $S_ALLWAY;?>
	</div>
<div class="sub_title"><?php echo $T_KEEP_GRAPH_TIME;?></div>
<div align="right" class="left_name"><?php echo $F_TIME_IN_DAY;?></div>
	<div>
	<input type="text" name="graph" size="10" maxlength="20" value="<?php echo $TIME_TO_KEEP_GRAPH;?>" autocomplete="off" /> <?php echo $S_ALLWAY;?>
	</div>
	*/?>
<div class="sub_title"><?php echo $T_PASSWORD_USER_DATABASE;?></div>
	<div align="right" class="left_name">*<?php echo $F_PASSWORD;?></div>
		<div> <input type="password" size="20" maxlength="40" name="password" /></div>
	
	<div align="right" class="left_name">*<?php echo $F_REPASSWORD;?></div>
		<div> <input type="password" size="20" maxlength="40" name="repassword" /></div>
		
<div class="sub_title"><?php echo $T_HTTPSERVER_PORT;?></div>
	<div align="right" class="left_name"><?php echo $F_PORT;?></div>
		<div> <input type="text" size="20" maxlength="5" name="porthttpserver" value="<?php echo $PORTHTTPSERVER;?>" /></div>
		
<div class="sub_title"><?php echo $T_TIME_OUT_CONN_DB;?></div>
	<div align="right" class="left_name"><?php echo $F_TIME_OUT_CONN_BD;?></div>
		<div> <input type="text" size="20" maxlength="5" name="timeoutconnbd" value="<?php echo $TIME_OUT_CONN_DB;?>" /></div>
		
<div class="sub_title"><?php echo $T_ADITIONAL_NAME;?></div>
	<div align="right" class="left_name"><?php echo $F_TITLE_ADITIONAL;?></div>
		<div> <input type="text" size="20" maxlength="20" name="title_aditional" value="<?php echo $NAME_ADD_TITLE;?>" /></div>
		
<div class="sub_title"><?php echo $T_DEFAULT_LANG;?></div>
<div align="right" class="left_name"><?php echo $F_LANGUAGE;?></div>
	<div>
	<select name="language">
	<?php
		$SQL = "SELECT * FROM  controlcenter.language ORDER BY name";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSG001F"));
		$DATA = mysql_fetch_array($RS);
		$cor = 1;	
		do{
		if($DATA['file'] == $DEFAULT_LANGUAGE) {
			$sel = 'selected="selected"';
		} else {
				$sel = "";
		}
	
		if ( $cor == 1 )
		{
			?>
			<option value="<?php echo $DATA['file'];?>" <?php echo $sel;?> ><?php echo ($DATA['name']); $cor=0?></option>
			<?php 
		} else { ?>
			<option style="background:<?php echo $COLOR_LINE_SELECT;?>" value="<?php echo $DATA['file'];?>" <?php echo $sel;?> ><?php echo ($DATA['name']); $cor=1;?></option>
			<?php
		} 
	}while ($DATA =  mysql_fetch_array($RS));?>
	</select>
	</div>
</div>
	<div id="contet_rigth_img">

		<img src="@img/icons/suport-128x128.png" />	

	</div>	

<div class="title_general">		
	<input type="submit" value="<?php echo $B_UPDATE;?>" /><font id="small_alert">* <?php echo $S_FILL_JUST_CHANGE;?></font>
</div>
</form>
<!--End add-->
<?php }?>
</div>
<div class="version_general">
<?php
echo $VERSIONCC;
?>
</div>

</div> <!--Main-->

</body>
</html>
<?php
unset($_SESSION['EX_ACTION']);
unset($_SESSION['ITEMID']);
?>