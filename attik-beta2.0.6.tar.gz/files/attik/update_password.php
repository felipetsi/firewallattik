<?php
session_start();
require_once('includes/control_session.php');

$LANG = $_SESSION['language'];

require_once('configuration/general.php');
$FILE_LANG = "general.php";
$LANG = trim(addslashes($_GET['lang']));
if (empty($LANG))
{
	$_SESSION['language'] = $DEFAULT_LANGUAGE;
	$LANG = $_SESSION['language'];
} else 
{
	$_SESSION['language'] = $LANG;
}
require_once("lang/$LANG/$FILE_LANG");

$DESTINATION_PAGE = $DEFAULT_PAGE_MOD;
$THISPAGE = "update_password.php";

$PASSWD = trim(addslashes($_POST['password']));
if (!empty($PASSWD))
{
	$PASSWORD = sha1(substr(trim(addslashes($_POST['password'])),0,39));
	$REPASSWORD = sha1(substr(trim(addslashes($_POST['repassword'])),0,39));
	if ($PASSWORD != $REPASSWORD){
		$_SESSION['SHOW_MSG'] = "ME_DIFFERENT_PASSWORD";
		
		header ("Location: $THISPAGE");
	} else {
		$SQL = "UPDATE controlcenter.user SET password = '$PASSWORD', change_password = '0' WHERE id = '$USER'";
		$RS = mysql_query($SQL);
		if ((mysql_affected_rows() != 1)&&($LOG_AUDITOR == 1))
		{
			auditor('ICCUP001F', $ADDRIP, $USER,'0');
		}elseif($LOG_AUDITOR == 1) {
			auditor('ICCUP001S', $ADDRIP, $USER,'0');
		}
		
		header ("Location: $DESTINATION_PAGE");
	}
} else {
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $TITLE; ?></title>
<link href="includes/style_cc.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="main"> <!--Main-->
<div id="menu_solutions"> <!--TOP -->
	<div id="top"> <!--Logo-->
	<img align="left" src="@img/Logo-incti.jpg" alt="IncTI Solu��es"/>	
		<div align="right">
		<form name="formlanguage" action="<?php echo $THISPAGE;?>" method="get">
			<select name="lang" onChange="javascript:document.formlanguage.submit();">
                <option ></option>
				<?php
				$SQL = "SELECT * FROM controlcenter.language";
				$RS = mysql_query($SQL);
				$ARRAY = mysql_fetch_array($RS);
				do { 
				if ($LANG == $ARRAY['file']){
				$sel = 'selected="selected"';
				}
				else{
				$sel = "";
				}
				?>
                <option <?php echo $sel;?> value="<?php echo $ARRAY['file'];?>">
                    <?php echo $ARRAY['name']; ?>
                </option>
				<?php } while ($ARRAY = mysql_fetch_array($RS));?>
            </select>
		</form>
		</div>
	</div>
</div>

	<?php
	if (!empty($_SESSION['SHOW_MSG'])){?>
		<div align="center" id="show_msg">
			<?php echo ($$_SESSION['SHOW_MSG']); ?>		</div>
	<?php }?><br><br><br><br><br>
	<div class="title_general" > <?php echo $T_CHANGE_PASSWOR; ?> </div>
	<form action="<?php echo $THISPAGE;?>" method="post" >

		<div align="right" class="left_name"><?php echo $F_PASSWORD;?>:</div>
			<div><input type="password" name="password" size="15" maxlength="50" /></div>
		<div align="right" class="left_name"><?php echo $F_REPASSWORD;?>:</div>
			<div><input type="password" name="repassword" size="15" maxlength="50"/></div>
		<div align="right" class="left_name"><input type="submit" value="<?php echo $B_CHANGE;?>" /></div>

	</form>	
</div>	
</body>
</html>
<?php
unset($_SESSION['SHOW_MSG']);
}
?>