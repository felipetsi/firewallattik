<?php 
require_once('includes/control_session.php');
require('configuration/directory.php');

$DESTINATION_PAGE = "firewall_list_cc.php";

$ID = substr(trim(addslashes($_POST['id'])),0,5);
$NAMEFWLIST = substr(trim(addslashes($_POST['name_fw'])),0,200);
$IPFWLIST = substr(trim(addslashes($_POST['ip_fw_list'])),0,15);

if(empty($IPFWLIST)  || empty($NAMEFWLIST)) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDFILL';
	$_SESSION['NAMEFWLIST'] = $NAMEFWLIST;
	$_SESSION['IPFWLIST'] = $IPFWLIST;
} elseif((verifyIp($IPFWLIST) != "ok") || (eregi("[^0-9./]", $IPFWLIST, $regs))) {
		$_SESSION['SHOW_MSG'] = 'ME_INVALIDIP';
		$_SESSION['NAMEFWLIST'] = $NAMEFWLIST;
		$_SESSION['IPFWLIST'] = $IPFWLIST;
}
else
{
	$SQL = "SELECT name,ip FROM controlcenter.firewall_list WHERE (ip = '$IPFWLIST' OR name = '$NAMEFWLIST') ";
	if(!empty($ID)) {
		$SQL .= "AND id != $ID";
	}
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSW003F"));
	if (mysql_affected_rows() != 0) {
		$_SESSION['SHOW_MSG'] = 'ME_TRIED_DUPLICATED';
		$_SESSION['NAMEFWLIST'] = $NAMEFWLIST;
		$_SESSION['IPFWLIST'] = $IPFWLIST;
		if($LOG_AUDITOR == 1){
			auditor('ICCFS008F', $ADDRIP, $USER, '0');
		}
	} else {
		if(empty($ID)) {
			$SQL = "INSERT INTO controlcenter.firewall_list (name, ip) ";
			$SQL .= "VALUES ('$NAMEFWLIST', '$IPFWLIST')";
		} else {
			$SQL = "UPDATE controlcenter.firewall_list SET name='$NAMEFWLIST', ";
			$SQL .= "ip='$IPFWLIST' WHERE id = '$ID'";
		}
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCFI003F"));

		if (mysql_affected_rows() != 0) {
			$_SESSION['SHOW_MSG'] = 'F_SUCESS';
		}
	}
}
header("Location:$DESTINATION_PAGE");
?>