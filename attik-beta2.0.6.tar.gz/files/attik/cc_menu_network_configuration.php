<div id="menu_conf_sub">
<form action="interface_cc.php" method="post" name="menu_iface">
	<a href="javascript:document.menu_iface.submit();">
		<div class="button_gen_obj">
			<input type="hidden" name="interface" value="1" />
			<img src="/attik/@img/icons/ethernet-16x16.png" align="absmiddle"/>
			<?php echo $L_INTERFACE;?>
		</div>
	</a>
</form>
<form action="interface_cc.php" method="post" name="menu_viface">
	<a href="javascript:document.menu_viface.submit();">
		<div class="button_gen_obj">
			<input type="hidden" name="interface" value="2" />
			<img src="/attik/@img/icons/ethernet-16x16.png" align="absmiddle"/>
			<?php echo $L_INTERFACE_VLAN;?>
		</div>
	</a>
</form>
<a href="route_cc.php">
	<div class="button_gen_obj">
		<img src="/attik/@img/icons/routing-16x16.png" align="absmiddle"/>
		<?php echo $L_ROTE;?>
	</div>
</a>
<a href="test_connection_cc.php">
	<div class="button_gen_obj">
		<img src="/attik/@img/icons/connection-16x16.png" align="absmiddle"/>
		<?php echo $L_TEST_CONNECTION;?>
	</div>
</a>
</div>
