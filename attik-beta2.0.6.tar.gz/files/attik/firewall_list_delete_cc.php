<?php 
include('includes/control_session.php');

$DESTINATION_PAGE = "firewall_list_cc.php";

$ID = trim(addslashes($_SESSION['ITEMDELETE']));

if (empty($ID)) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDSELECT';
}
else {
	$SQL = "SELECT id_rul FROM cc_firewall.rule_firewall_list WHERE id_fw='$ID'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSW004F"));
	$ARRAY = mysql_fetch_array($RS);
	if (mysql_affected_rows() != 0)
	{
		$_SESSION['SHOW_MSG'] = 'ME_HAVERULEASSOCIATED';
	}
	else
	{
		$SQL = "DELETE FROM controlcenter.firewall_list WHERE id = '$ID'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCDW005F"));
		if ( mysql_affected_rows() !=0 )
		{
			if($LOG_AUDITOR == 1){
				auditor('ICCDW006S', $ADDRIP, $USER, '0');
			}
			$_SESSION['SHOW_MSG'] = 'F_SUCESS';
		}else {
			if($LOG_AUDITOR == 1){
				auditor('ICCDW006F', $ADDRIP, $USER, '0');
			}
			$_SESSION['SHOW_MSG'] = 'F_FAILURE';
		}
	} 
	unset($_SESSION['ITEMDELETE']);
}
header("Location:$DESTINATION_PAGE");
?>