<?php 
require_once('includes/control_session.php');
require('configuration/directory.php');
$THISPAGE = "backup_cc.php";
$DESTINATION_PAGE = "backup_run_cc.php";

// Load the profile of user autenticanted
$SQL = "SELECT p.change_config, u.fullname FROM controlcenter.profile p, controlcenter.user u WHERE ";
$SQL .= "p.id = u.id_pro and u.id = '$USER'";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSB001F"));
$DATA_USER = mysql_fetch_array($RS);

// Load the item selected
$STARTINTERVAL = substr(trim(addslashes($_POST['startInterval'])),0,10);
$ENDINTERVAL = substr(trim(addslashes($_POST['endInterval'])),0,10);
$ITEMSELECTED = $_POST['list'];
$_SESSION['ITEMDELETE'] = $ITEMSELECTED;
$ITEMID = substr(trim(addslashes($ITEMSELECTED[0])),0,20);
$FILETARGET = str_replace(":","-",str_replace(" ", "_", $ITEMID)).".its";
$ARRAYSTART = explode("/",$STARTINTERVAL);
$ARRAYEND = explode("/",$ENDINTERVAL);

if (!empty($STARTINTERVAL) || !empty($ENDINTERVAL)){
	if (!empty($STARTINTERVAL) && !empty($ENDINTERVAL)){
		if ( ((sizeof($ARRAYSTART) < 3) || (sizeof($ARRAYEND) < 3)) ||
			 ( ($ARRAYSTART[2] > 3000) || ($ARRAYSTART[1] > 31) || ($ARRAYSTART[0] > 12) ))
		{
			$_SESSION['SHOW_MSG'] = 'ME_DATEINVALID';
			$_SESSION['EX_STARTINTERVAL'] = $STARTINTERVAL;
			$_SESSION['EX_ENDINTERVAL'] = $ENDINTERVAL;
			header("Location:$THISPAGE");
		} else {
			$DATE_S = "$ARRAYSTART[2]-$ARRAYSTART[0]-$ARRAYSTART[1]";
			$DATE_E = "$ARRAYEND[2]-$ARRAYEND[0]-$ARRAYEND[1]";
			// Just mount the String SQL
			$SQLBKP = "SELECT b.date_created, b.description, u.fullname as user FROM  cc_backup.backup b, ";
			$SQLBKP .= "controlcenter.user u ";
			$SQLBKP .= "WHERE b.date_created > '$DATE_S' AND b.date_created < '$DATE_E' ";
			$SQLBKP .= "AND b.id_user = u.id ORDER BY b.date_created";
		}
	}
	elseif (!empty($STARTINTERVAL) && empty($ENDINTERVAL)){

		if ( ((sizeof($ARRAYSTART) < 3) || ($ARRAYSTART[2] > 3000) || ($ARRAYSTART[1] > 31) || ($ARRAYSTART[0] > 12) ))
		{
			$_SESSION['SHOW_MSG'] = 'ME_DATEINVALID';
			$_SESSION['EX_STARTINTERVAL'] = $STARTINTERVAL;
			$_SESSION['EX_ENDINTERVAL'] = $ENDINTERVAL;
			header("Location:$THISPAGE");
		} else {
			$DATE_S = "$ARRAYSTART[2]-$ARRAYSTART[0]-$ARRAYSTART[1]";
			$DATE_E = "$ARRAYSTART[2]-$ARRAYSTART[0]-".($ARRAYSTART[1] + 1);
			// Just mount the String SQL
			$SQLBKP = "SELECT b.date_created, b.description, u.fullname as user FROM  cc_backup.backup b, ";
			$SQLBKP .= "controlcenter.user u ";
			$SQLBKP .= "WHERE b.date_created > '$DATE_S' AND b.date_created < '$DATE_E' ";
			$SQLBKP .= "AND b.id_user = u.id ORDER BY b.date_created";
		}
	}
	elseif (empty($STARTINTERVAL) && !empty($ENDINTERVAL)){

		if ( ((sizeof($ENDINTERVAL) < 3) || ($ENDINTERVAL[2] > 3000) || ($ENDINTERVAL[1] > 31) || ($ENDINTERVAL[0] > 12) ))
		{
			$_SESSION['SHOW_MSG'] = 'ME_DATEINVALID';
			$_SESSION['EX_STARTINTERVAL'] = $STARTINTERVAL;
			$_SESSION['EX_ENDINTERVAL'] = $ENDINTERVAL;
			header("Location:$THISPAGE");
		} else {
			$DATE_S = date("Y-m-d")+1;
			$DATE_E = "$ARRAYEND[2]-$ARRAYEND[0]-$ARRAYEND[1]";
			// Just mount the String SQL
			$SQLBKP = "SELECT b.date_created, b.description, u.fullname as user FROM  cc_backup.backup b, ";
			$SQLBKP .= "controlcenter.user u ";
			$SQLBKP .= "WHERE b.date_created > '$DATE_S' AND b.date_created < '$DATE_E' ";
			$SQLBKP .= "AND b.id_user = u.id ORDER BY b.date_created";
		}
	}
}
else
{
	if(!empty($ITEMID)) {
		$SQLBKP = "SELECT b.date_created, b.description, u.fullname as user FROM  cc_backup.backup b, ";
		$SQLBKP .= "controlcenter.user u WHERE b.date_created = '$ITEMID' AND b.id_user = u.id ORDER BY b.date_created ";
		$RSBKP = mysql_query($SQLBKP) or (die("$ME_OCCURREDEERRORINTERNAL ICCSB002F"));
		$ARRAYBKPDESC = mysql_fetch_array($RSBKP);
	}
	$SQLBKP = "SELECT b.date_created, b.description, u.fullname as user FROM  cc_backup.backup b, ";
	$SQLBKP .= "controlcenter.user u WHERE b.id_user = u.id ORDER BY b.date_created";
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $TITLE; ?></title>
<script language="javascript">
var thispage = "backup_cc.php";
var deletepage = "backup_delete_cc.php";

function dateFormat(obj){
	if ((obj.value.length == 2) || (obj.value.length == 5))
	{
		obj.value = obj.value + "/";
	}
}
function lengthFild(){
	var descLen = document.formDescription.description.value.length;
	if (descLen < 201){
		document.formDescription.count.value = (200 - descLen);
	} else {
		document.formDescription.description.value = document.formDescription.description.value.substring(0,200);
	}
}
</script>
<link href="includes/style_cc.css" rel="stylesheet" type="text/css" />
</head>
<body onload="javascript: lengthFild();">
<?php
require_once('includes/top.php');
?>
<div id="main"> <!--Main-->
<?php require_once('cc_menu_configuration.php');?>
	<div id="contet_rigth"><?php
if ($DATA_USER['change_config'] == 1) {
?>
<script language="javascript">
function confirmDeleteSelected()
{
	document.getElementById('box_delete').style.display="table";
}
function yesdeleteSelected()
{
	window.location=deletepage;
}
function nodeleteSelected()
{
	document.getElementById('box_delete').style.display="none";
}
function downloadBackup(file)
{
	document.frmDoload.submit();
}
</script>
<div id="box_delete"><?php echo("$S_WANT_DELETE?");?> 
	<div class="space_confirm_box">
		<input type="button" value="<?php echo $B_YES;?>" onclick="javascript:yesdeleteSelected();" />
		<input type="button" value="<?php echo $B_NO;?>" onclick="javascript:nodeleteSelected();" />
	</div>	
</div>

<!--Start add-->
<form class="insert_border" action="<?php echo $THISPAGE;?>" method="post" name="formDate">
<div class="title_general" > <?php echo $T_BACKUP; ?> </div>
<div align="right" class="left_name_1"><font class="title_option"><?php echo $F_INTERVAL;?> </font> </div>
	<div>
		<input type="text" name="startInterval" onkeypress="javascript: dateFormat(this);" size="10" maxlength="10" value="<?php echo $_SESSION['EX_STARTINTERVAL'];?>" />
		<a href="javascript:void(0)" onClick="if(self.gfPop)gfPop.fPopCalendar(document.formDate.startInterval);return false;" HIDEFOCUS>
			<img name="cal" align="absmiddle" src="@img/calendar.gif" width="34" height="22" border="0">
		</a>
		<input type="text" name="endInterval" onkeypress="javascript: dateFormat(this);" size="10" maxlength="10" value="<?php echo $_SESSION['EX_ENDINTERVAL'];?>" />
		<a href="javascript:void(0)" onClick="if(self.gfPop)gfPop.fPopCalendar(document.formDate.endInterval);return false;" HIDEFOCUS>
			<img name="cal" align="absmiddle" src="@img/calendar.gif" width="34" height="22" border="0">
		</a>
		<input type="submit" value="<?php echo $L_FILTER;?>" />
	</div>
</form>
<form class="insert_border" action="<?php echo $DESTINATION_PAGE;?>" method="post" name="formDescription" >
<input type="hidden" name="id" value="<?php echo $ITEMID;?>" />	

	<?php echo $S_JUST_NUMBER;?>
	<div class="sub_title"><?php echo $T_DESCRIPTION;?></div>
	<div align="right" class="left_name"><?php echo $F_CREATED;?></div>
		<div>
			<input type="text" value="<?php if(!empty($ARRAYBKPDESC['date_created'])){echo formatData($ARRAYBKPDESC['date_created']);} else { 
				echo $S_NOW;}?>" disabled="disabled" size="20" />
		</div>
	<div align="right" class="left_name"><?php echo $F_CREATOR;?></div>
		<div>
			<input type="text" value="<?php if(!empty($ARRAYBKPDESC['user'])){echo $ARRAYBKPDESC['user'];} else {echo $ARRAYBKPDESC['fullname'];}?>" disabled="disabled" size="20" />
		</div>
	<div class="separate_line">
		<div align="right" class="left_name"><?php echo $F_DESCRIPTION;?></div>
			<div>
				<textarea name="description" onkeyup="javascript: lengthFild();" rows="5" cols="30"><?php if(!empty($ARRAYBKPDESC['description'])){echo $ARRAYBKPDESC['description'];}?></textarea>
				<?php echo "$S_REST:";?>
				<input type="text" name="count" size="4" maxlength="3" disabled="disabled" />

			</div>
	</div>
	<div class="title_general">
		<input type="submit" value="<?php if (empty($ARRAYBKPDESC['date_created'])){ echo $B_CREATE_BKP;} else { echo $B_RESTORE_BKP;}?>" />
		<input type="button" value="<?php echo $B_CLEAR;?>" onclick="javascript:window.location=thispage" />
		<input type="button" value="<?php echo $B_DELETE;?>" onClick="javascript:confirmDeleteSelected();" />
		<input type="button" value="<?php echo $B_DOWNLOAD;?>" onClick="javascript:downloadBackup();" />
	</div>
</form>
<form name="frmDoload" action="backupDownload_cc.php" method="post">
	<input type="hidden" name="id" value="<?php echo $ITEMID;?>" />	
</form>
<iframe width=199 height=178 name="gToday:normal:agenda.js" id="gToday:normal:agenda.js" src="includes/calendar/ipopeng.php" scrolling="no" frameborder="0" style="visibility:visible; z-index:999; position:absolute; top:-500px; left:-500px;">
</iframe>

<!-- Start list-->
<div class="title_general"><?php echo $T_BACKUP_LIST; ?></div>
<form action="<?php echo $THISPAGE;?>" method="post" name="formList">
	<select class="select_list_4" name="list[]" size="20" onchange="javascript: document.formList.submit();" multiple="multiple">
		<?php
			$RSBKP = mysql_query($SQLBKP) or (die("$ME_OCCURREDEERRORINTERNAL ICCSB006F"));
			$DATA = mysql_fetch_array($RSBKP);
			$cor = 1;	
			do{
				if(!empty($DATA['date_created']))
				{
					if (in_array($DATA['date_created'], $ITEMSELECTED)) {
						$sel = 'selected="selected"';
					} else {
						$sel = "";
					}?>
					<option value="<?php echo $DATA['date_created'];?>" <?php echo $sel; if(verifyBkp($DATA['date_created'],$DIRBACKUPDB) == "ok"){ if($cor==1){ echo 'style="background-color:'.$COLOR_LINE_SELECT.'"'; $cor=0;}else{$cor=1;} }else{echo 'class="line_obj_list_fail"';}?> ><?php echo (formatData($DATA['date_created']));?></option><?php 
				}
			}while ($DATA =  mysql_fetch_array($RSBKP));?>
	</select>
</form>
<?php 
}?>
</div> <!--content rigth-->
<div class="version_general">
<?php
echo $VERSIONCC;
?>
</div>
</div> <!--Main-->
</body>
</html>
<?php
unset($_SESSION['EX_STARTINTERVAL']);
unset($_SESSION['EX_ENDINTERVAL']);
?>