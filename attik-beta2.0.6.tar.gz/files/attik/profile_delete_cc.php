<?php 
require_once('includes/control_session.php');

$DESTINATION_PAGE = "profile_cc.php";

$ID = trim(addslashes($_SESSION['ITEMDELETE']));

if (empty($ID)) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDSELECT';
	header("Location: $DESTINATION_PAGE");
}
else {
	$SQL = "SELECT id FROM controlcenter.user WHERE id_pro = '$ID'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCDP018F"));
	if (mysql_affected_rows() != 0) {
		$_SESSION['SHOW_MSG'] = 'ME_HAVEUSERASSOCIATED';
	}
	else {
		$SQL = "DELETE FROM controlcenter.profile WHERE id = '$ID'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCDP017F"));
			if (mysql_affected_rows() != 0) {
				if ($LOG_AUDITOR != 0){
					auditor('ICCDP017S', $ADDRIP, $USER, '0');
				}
				$_SESSION['SHOW_MSG'] = 'F_SUCESS';
			} else {
				if ($LOG_AUDITOR != 0){
					auditor('ICCDP017F', $ADDRIP, $USER, '0');
				}
				$_SESSION['SHOW_MSG'] = 'F_FAILURE';
			}
	}
	unset($_SESSION['ITEMDELETE']);
	header("Location: $DESTINATION_PAGE");
}
?>