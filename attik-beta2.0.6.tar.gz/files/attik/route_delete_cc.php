<?php 
include('includes/control_session.php');

$DESTINATION_PAGE = "route_cc.php";

$ID = trim(addslashes($_SESSION['ITEMDELETE']));

if (empty($ID)) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDSELECT';
	header("Location:$DESTINATION_PAGE");
}
else {
	$SQL = "SELECT * FROM controlcenter.route_table WHERE id='$ID'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCRS011S"));
	$ARRAY = mysql_fetch_array($RS);
	if (deleteRoute($ARRAY['destination'],$ARRAY['mask'],$ARRAY['gateway']) == "ok"){
		$SQL = "DELETE FROM controlcenter.route_table WHERE id = '$ID'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCRD007F"));
		if ( mysql_affected_rows() !=0 )
		{
			if($LOG_AUDITOR == 1){
				auditor('ICCRD007S', $ADDRIP, $USER, '0');
			}
			$_SESSION['SHOW_MSG'] = 'F_SUCESS';
		}else {
			if($LOG_AUDITOR == 1){
				auditor('ICCRD007F', $ADDRIP, $USER, '0');
			}
			$_SESSION['SHOW_MSG'] = 'F_FAILURE';
		}
	}
	unset($_SESSION['ITEMDELETE']);
	header("Location:$DESTINATION_PAGE");
}
?>