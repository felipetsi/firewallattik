<?php 
require_once('includes/control_session.php');

$DESTINATION_PAGE = "user_cc.php";

$ID = trim(addslashes($_POST['id']));
$FULLNAME = substr(trim(addslashes($_POST['fullname'])),0,50);
$LOGIN = substr(trim(addslashes($_POST['login'])),0,20);
$PASSWORD = substr(trim(addslashes($_POST['password'])),0,40);
$REPASSWORD = substr(trim(addslashes($_POST['repassword'])),0,40);
$CHANGE_PASSWORD = substr(trim(addslashes($_POST['change_password'])),0,1);
$DEPARTMENT = substr(trim(addslashes($_POST['department'])),0,50);
$ROOM = substr(trim(addslashes($_POST['room'])),0,10);
$IP = substr(trim(addslashes($_POST['ip'])),0,15);
$MAC = replaceMAC(substr(trim(addslashes($_POST['mac'])),0,17));
$PHONE = substr(trim(addslashes($_POST['phone'])),0,13);
$MOBILE = substr(trim(addslashes($_POST['mobile'])),0,13);
$PROFILE = trim(addslashes($_POST['profile']));

if ((empty($FULLNAME)) or (empty($LOGIN)) or (empty($PROFILE)) or (empty($IP)) ) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDFILL';
	$_SESSION['ITEMID'] = $ID;
	$_SESSION['EX_NAME'] = $FULLNAME;
	$_SESSION['EX_LOGIN'] = $LOGIN;
	$_SESSION['EX_PASSWORD'] = $PASSWORD;
	$_SESSION['EX_REPASSWORD'] = $REPASSWORD;
	$_SESSION['EX_PROFILE'] = $PROFILE;
	$_SESSION['EX_CHANGE_PASSWORD'] = $CHANGE_PASSWORD;
	$_SESSION['EX_DEPARTMENT'] = $DEPARTMENT;
	$_SESSION['EX_ROOM'] = $ROOM;
	$_SESSION['EX_IP'] = $IP;
	$_SESSION['EX_MAC'] = $MAC;
	$_SESSION['EX_PHONE'] = $PHONE;
	$_SESSION['EX_MOBILE'] = $MOBILE;
	header("Location:$DESTINATION_PAGE");
}
elseif(($IP != "") && (verifyIp($IP) != "ok") || (eregi("[^0-9./]", $IP, $regs))) {
	$_SESSION['SHOW_MSG'] = 'ME_INVALIDIP';
	$_SESSION['ITEMID'] = $ID;
	$_SESSION['EX_NAME'] = $FULLNAME;
	$_SESSION['EX_LOGIN'] = $LOGIN;
	$_SESSION['EX_PASSWORD'] = $PASSWORD;
	$_SESSION['EX_REPASSWORD'] = $REPASSWORD;
	$_SESSION['EX_PROFILE'] = $PROFILE;
	$_SESSION['EX_CHANGE_PASSWORD'] = $CHANGE_PASSWORD;
	$_SESSION['EX_DEPARTMENT'] = $DEPARTMENT;
	$_SESSION['EX_ROOM'] = $ROOM;
	$_SESSION['EX_IP'] = $IP;
	$_SESSION['EX_MAC'] = $MAC;
	$_SESSION['EX_PHONE'] = $PHONE;
	$_SESSION['EX_MOBILE'] = $MOBILE;
	header("Location:$DESTINATION_PAGE");
}
elseif(($MAC != "") && (verifyMAC($MAC) != "ok")) {
	$_SESSION['SHOW_MSG'] = 'ME_INVALIDMAC';
	$_SESSION['ITEMID'] = $ID;
	$_SESSION['EX_NAME'] = $FULLNAME;
	$_SESSION['EX_LOGIN'] = $LOGIN;
	$_SESSION['EX_PASSWORD'] = $PASSWORD;
	$_SESSION['EX_REPASSWORD'] = $REPASSWORD;
	$_SESSION['EX_PROFILE'] = $PROFILE;
	$_SESSION['EX_CHANGE_PASSWORD'] = $CHANGE_PASSWORD;
	$_SESSION['EX_DEPARTMENT'] = $DEPARTMENT;
	$_SESSION['EX_ROOM'] = $ROOM;
	$_SESSION['EX_IP'] = $IP;
	$_SESSION['EX_MAC'] = $MAC;
	$_SESSION['EX_PHONE'] = $PHONE;
	$_SESSION['EX_MOBILE'] = $MOBILE;
	header("Location:$DESTINATION_PAGE");
}
else {
	$SQL = "SELECT * FROM controlcenter.user WHERE login = '$LOGIN' AND id != '$ID'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSU005F"));
	if ( mysql_affected_rows() !=0 )
	{
		if ($LOG_AUDITOR == 1)
		{
			auditor('ICCSU014F', $ADDRIP, $USER, $LOGIN);
		}
		$_SESSION['SHOW_MSG'] = 'ME_NAMEEXIST';
		$_SESSION['ITEMID'] = $ID;
		$_SESSION['EX_NAME'] = $FULLNAME;
		$_SESSION['EX_LOGIN'] = $LOGIN;
		$_SESSION['EX_PASSWORD'] = $PASSWORD;
		$_SESSION['EX_REPASSWORD'] = $REPASSWORD;
		$_SESSION['EX_PROFILE'] = $PROFILE;
		$_SESSION['EX_CHANGE_PASSWORD'] = $CHANGE_PASSWORD;
		$_SESSION['EX_DEPARTMENT'] = $DEPARTMENT;
		$_SESSION['EX_ROOM'] = $ROOM;
		$_SESSION['EX_IP'] = $IP;
		$_SESSION['EX_MAC'] = $MAC;
		$_SESSION['EX_PHONE'] = $PHONE;
		$_SESSION['EX_MOBILE'] = $MOBILE;
		header("Location:$DESTINATION_PAGE");
	}
	else {
	if ($PASSWORD != $REPASSWORD){
		$_SESSION['SHOW_MSG'] = 'ME_DIFFERENT_PASSWORD';
		$_SESSION['ITEMID'] = $ID;
		$_SESSION['EX_NAME'] = $FULLNAME;
		$_SESSION['EX_LOGIN'] = $LOGIN;
		$_SESSION['EX_PASSWORD'] = $PASSWORD;
		$_SESSION['EX_REPASSWORD'] = $REPASSWORD;
		$_SESSION['EX_PROFILE'] = $PROFILE;
		$_SESSION['EX_CHANGE_PASSWORD'] = $CHANGE_PASSWORD;
		$_SESSION['EX_DEPARTMENT'] = $DEPARTMENT;
		$_SESSION['EX_ROOM'] = $ROOM;
		$_SESSION['EX_IP'] = $IP;
		$_SESSION['EX_MAC'] = $MAC;
		$_SESSION['EX_PHONE'] = $PHONE;
		$_SESSION['EX_MOBILE'] = $MOBILE;
		header("Location:$DESTINATION_PAGE");
	} 
	else {
		if (empty($CHANGE_PASSWORD)) {
			$CHANGE_PASSWORD = 0;
		}
		//$ARRAY = mysql_fetch_array($RS);
		$PASSWORD = sha1($REPASSWORD);
		if (empty($ID)) {
				$SQL = "INSERT INTO controlcenter.user (fullname, login, password, change_password, id_pro, ";
				$SQL .= "department, room, ip, mac, phone, mobile) "; 
				$SQL .= "VALUES ('$FULLNAME', '$LOGIN', '$PASSWORD', '$CHANGE_PASSWORD', '$PROFILE', ";
				$SQL .= "'$DEPARTMENT', '$ROOM', '$IP', '$MAC', '$PHONE', '$MOBILE')";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCIU006F"));
				if ((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1)){
					auditor('ICCIU006S', $ADDRIP, $USER, $NAME);	
				}elseif($LOG_AUDITOR == 1){
					auditor('ICCIU006F', $ADDRIP, $USER, $NAME);
				}
		}
		else {
			$SQL = "SELECT id FROM controlcenter.profile WHERE create_profile = '1' AND read_profile = '1' AND ";
			$SQL .= "read_user = '1' AND create_user = '1' AND id = '$PROFILE'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSU010F"));
			$RESULTP = mysql_affected_rows();
			
			$SQL = "SELECT id FROM controlcenter.user WHERE id_pro IN (SELECT id FROM controlcenter.profile WHERE ";
			$SQL .= "create_profile = '1' AND read_profile = '1' AND read_user = '1' AND create_user = '1' )";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSU011F"));
			$RESULTU = mysql_affected_rows();
			
			if (($RESULTU == 1) && ($RESULTP == 0)) {
				$_SESSION['SHOW_MSG'] = 'ME_THIUNIQUEUSERWITHPRIVILEGIES';
			}
			else {
					if (!empty($REPASSWORD)) {
					$SQL = "UPDATE controlcenter.user SET fullname='$FULLNAME', login='$LOGIN', password='$PASSWORD', ";
					$SQL .= "change_password='$CHANGE_PASSWORD', id_pro='$PROFILE', department='$DEPARTMENT', ";
					$SQL .= "room='$ROOM', ip='$IP', mac='$MAC', phone='$PHONE', mobile='$MOBILE' ";
					$SQL .= "WHERE id = '$ID' ";
					} else {
					$SQL = "UPDATE controlcenter.user SET fullname='$FULLNAME', login='$LOGIN', ";
					$SQL .= "change_password='$CHANGE_PASSWORD', id_pro='$PROFILE', department='$DEPARTMENT', ";
					$SQL .= "room='$ROOM', ip='$IP', mac='$MAC', phone='$PHONE', mobile='$MOBILE' ";
					$SQL .= "WHERE id = '$ID' ";
					}
					$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCIU007F"));
					if ((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1)){
						auditor('ICCIU007S', $ADDRIP, $USER, $NAME);	
					}elseif($LOG_AUDITOR == 1){
						auditor('ICCIU007F', $ADDRIP, $USER, $NAME);
					}		
					if (mysql_affected_rows() != 0) {
						$_SESSION['SHOW_MSG'] = 'F_SUCESS';
					} else {
						$_SESSION['SHOW_MSG'] = 'F_FAILURE';
					}
				}
			}
			header("Location:$DESTINATION_PAGE");
		}
	}
}
?>