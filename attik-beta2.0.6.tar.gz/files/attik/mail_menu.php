<div style="clear:both; float:left; width:800px; height:40px; background-color:#333399"> <!--Main--> Configura&ccedil;&atilde;o | Relat&oacute;rios | Gr&aacute;ficos | Fila de e-mails | 
</div>
