<?php 
require_once('includes/control_session.php');

$DESTINATION_PAGE = "profile_cc.php";

$ID = $_POST['id'];
$ARRAY = explode("@",$ID);
$IDP = trim(addslashes($ARRAY[0]));
$IDPF = trim(addslashes($ARRAY[1]));
$IDPV = trim(addslashes($ARRAY[2]));print_r($IDPV);
$NAME = substr(trim(addslashes($_POST['name'])),0,20);
$M_FW = substr(trim(addslashes($_POST['m_fw'])),0,1);
$M_FW_ID = substr(trim(addslashes($_POST['id_fw'])),0,2);
$M_PROXY = substr(trim(addslashes($_POST['m_proxy'])),0,1);
$M_IDS = substr(trim(addslashes($_POST['m_ids'])),0,1);
$M_SERV_MAIL = substr(trim(addslashes($_POST['m_serv_mail'])),0,1);
$M_MAIL_RELAY = substr(trim(addslashes($_POST['m_mail_relay'])),0,1);
$M_WEB = substr(trim(addslashes($_POST['m_web'])),0,1);
$C_VPN = substr(trim(addslashes($_POST['c_vpn'])),0,1);
$R_VPN = substr(trim(addslashes($_POST['r_vpn'])),0,1);
$C_USER = substr(trim(addslashes($_POST['c_user'])),0,1);
$R_USER = substr(trim(addslashes($_POST['r_user'])),0,1);
$C_PROFILE = substr(trim(addslashes($_POST['c_profile'])),0,1);
$R_PROFILE = substr(trim(addslashes($_POST['r_profile'])),0,1);
$R_LOG = substr(trim(addslashes($_POST['r_log'])),0,1);
$C_CONFIG = substr(trim(addslashes($_POST['c_config'])),0,1);
// Module Firewall
$C_RULE = substr(trim(addslashes($_POST['c_rule'])),0,1);
$R_RULE = substr(trim(addslashes($_POST['r_rule'])),0,1);
$R_REPORT = substr(trim(addslashes($_POST['r_report'])),0,1);
$C_NET = substr(trim(addslashes($_POST['c_net'])),0,1);
$R_NET = substr(trim(addslashes($_POST['r_net'])),0,1);
$C_PROTOCOL = substr(trim(addslashes($_POST['c_protocol'])),0,1);
$R_PROTOCOL = substr(trim(addslashes($_POST['r_protocol'])),0,1);

if (empty($NAME)) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDFILL';
	$_SESSION['EX_NAME'] = $NAME;
	header("Location:$DESTINATION_PAGE");
}
else {
	$SQL = "SELECT name FROM controlcenter.profile WHERE name = '$NAME' AND id != '$IDP'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSP013F"));
	if ( mysql_affected_rows() !=0 )
	{
		$_SESSION['SHOW_MSG'] = 'ME_NAMEEXIST';
		$_SESSION['EX_NAME'] = $NAME;
		if ($LOG_AUDITOR == 1)
		{
			auditor('ICCSP014F', $ADDRIP, $USER, $NAME);
		}
		header("Location:$DESTINATION_PAGE");
	}
	else {
		if (empty($M_FW)) {
			$M_FW = 0;
		}
		if (empty($M_PROXY)) {
			$M_PROXY = 0;
		}
		if (empty($M_IDS)) {
			$M_IDS = 0;
		}
		if (empty($M_SERV_MAIL)) {
			$M_SERV_MAIL = 0;
		}
		if (empty($M_MAIL_RELAY)) {
			$M_MAIL_RELAY = 0;
		}
		if (empty($M_WEB)) {
			$M_WEB = 0;
		}
		if (empty($C_VPN)) {
			$C_VPN = 0;
		}
		if (empty($R_VPN)) {
			$R_VPN = 0;
		}
		if (empty($C_USER)) {
			$C_USER = 0;
		}
		if (empty($R_USER)) {
			$R_USER = 0;
		}
		if (empty($C_PROFILE)) {
			$C_PROFILE = 0;
		}
		if(empty($R_PROFILE)) {
			$R_PROFILE = 0;
		}
		if(empty($R_LOG)) {
			$R_LOG = 0;
		}
		if(empty($C_CONFIG)) {
			$C_CONFIG = 0;
		}
		// Module Firewall
		if (empty($C_RULE)) {
			$C_RULE = 0;
		}
		if (empty($R_RULE)) {
			$R_RULE = 0;
		}
		if (empty($R_REPORT)) {
			$R_REPORT = 0;
		}
		if (empty($C_NET)) {
			$C_NET = 0;
		}
		if (empty($R_NET)) {
			$R_NET = 0;
		}
		if (empty($C_PROTOCOL)) {
			$C_PROTOCOL = 0;
		}
		if (empty($R_PROTOCOL)) {
			$R_PROTOCOL = 0;
		}
		
		if (empty($IDP)) {
			$SQL = "INSERT INTO controlcenter.profilefw (name, create_rule, read_rule, read_report, create_net, read_net, ";
			$SQL .= "create_protocol, read_protocol) "; 
			$SQL .= "VALUES ('$NAME', '$C_RULE', '$R_RULE', '$R_REPORT', '$C_NET','$R_NET' , '$C_PROTOCOL', '$R_PROTOCOL')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCIP006F"));
			$M_FW_ID = mysql_insert_id();

			$SQL = "INSERT INTO controlcenter.profilevpn (name, create_conn, read_conn)";
			$SQL .= "VALUES ('$NAME', '$C_VPN', '$R_VPN')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCIP006F"));
			$M_VPN_ID = mysql_insert_id();
			
			$SQL = "INSERT INTO controlcenter.profile (name, mod_firewall, id_profw, id_provpn, mod_proxy, mod_ids, mod_serv_mail, ";
			$SQL .= "mod_smtp_relay, mod_web, mod_vpn, create_user, read_user, create_profile, read_profile, read_log, ";
			$SQL .= "change_config) "; 
			$SQL .= "VALUES ('$NAME', '$M_FW', '$M_FW_ID', '$M_VPN_ID', '$M_PROXY', '$M_IDS', '$M_SERV_MAIL','$M_MAIL_RELAY', '$M_WEB', ";
			$SQL .= "'$M_VPN', '$C_USER', '$R_USER', '$C_PROFILE', '$R_PROFILE', '$R_LOG', '$C_CONFIG')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCIP015F"));
			if ((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1)){
				auditor('ICCIP015S', $ADDRIP, $USER, $NAME);	
			}elseif($LOG_AUDITOR == 1){
				auditor('ICCIP015F', $ADDRIP, $USER, $NAME);
			}
			if (mysql_affected_rows() != 0) {
				$_SESSION['SHOW_MSG'] = 'F_SUCESS';
			} else {
				$_SESSION['SHOW_MSG'] = 'F_FAILURE';
			}
		}
		else {
			$SQL = "SELECT id FROM controlcenter.profile WHERE create_profile = '1' AND read_profile = '1' AND ";
			$SQL .= "read_user = '1' AND create_user = '1'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSP018F"));
			$ARRAY = mysql_fetch_array($RS);
			if ( (mysql_affected_rows() == 1) && 
				((empty($C_PROFILE)) || (empty($R_PROFILE)) || (empty($C_USER)) || (empty($R_USER))) &&
				($IDP == $ARRAY['id']) ) {
				$_SESSION['SHOW_MSG'] = 'ME_THISUNIQUEPROFILEPRIVILEGIES';
			}
			else {
				$SQL = "UPDATE controlcenter.profilefw SET name='$NAME', create_rule='$C_RULE', read_rule='$R_RULE',";
				$SQL .= "read_report='$R_REPORT', create_net='$C_NET', read_net='$R_NET',";
				$SQL .= "create_protocol='$C_PROTOCOL', read_protocol='$R_PROTOCOL' WHERE id = '$IDPF'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCUP007F"));
				
				$SQL = "UPDATE controlcenter.profilevpn SET name='$NAME', create_conn='$C_VPN', read_conn='$R_VPN' ";
				$SQL .= "WHERE id = '$IDPV'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCUP007F"));

				$SQL = "UPDATE controlcenter.profile SET name='$NAME', ";
				$SQL .= "create_user='$C_USER', read_user='$R_USER', ";
				$SQL .= "create_profile='$C_PROFILE', read_profile='$R_PROFILE', read_log='$R_LOG', change_config='$C_CONFIG' ";
				$SQL .= "WHERE id = '$IDP'";
				$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCUP016F"));
				if ((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1)){
					auditor('ICCUP016S', $ADDRIP, $USER, $NAME);	
				}elseif($LOG_AUDITOR == 1){
					auditor('ICCUP016F', $ADDRIP, $USER, $NAME);
				}
				if (mysql_affected_rows() != 0) {
					$_SESSION['SHOW_MSG'] = 'F_SUCESS';
				} else {
					$_SESSION['SHOW_MSG'] = 'F_FAILURE';
				}
			}
		}
		header("Location:$DESTINATION_PAGE");
	}
}
?>