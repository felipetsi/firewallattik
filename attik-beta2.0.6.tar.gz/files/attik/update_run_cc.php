<?php 
//require_once('includes/control_session.php');

//Variable need becase various moment is use, including the top for change language
$DESTINATION_PAGE = "update_cc.php";

$COMMAND = "tar -czvf /var/www/.ControlCenter-last-old.tar.gz /var/www/controlcenter";
exec($COMMAND,$RETURN);

$COMMAND = "rm -rf /var/www/controlcenter";
exec($COMMAND,$RETURN);

$COMMAND = "cd /var/www/; wget http://10.1.1.3/incti/controlcenter/update_current.tar.gz";
exec($COMMAND,$RETURN);

$COMMAND = "tar -xzvf /var/www/update_current.tar.gz";
exec($COMMAND,$RETURN);

$COMMAND = "mv /var/www/update_current /var/www/controlcenter";
exec($COMMAND,$RETURN);

//copy("http://10.1.1.3/oficinadasbotas/index.php", "/var/www");
header("Location:$DESTINATION_PAGE");
?>