<?php
session_start();
require_once('configuration/general.php');
require_once('includes/conn_db_cc.php');
$DESTINATION_PAGE = "authentication.php";
$THISPAGE = "logon.php";

require_once('configuration/general.php');
$FILE_LANG = "general.php";
$LANG = trim(addslashes($_GET['lang']));
if (empty($LANG))
{
	$_SESSION['language'] = $DEFAULT_LANGUAGE;
	$LANG = $_SESSION['language'];
} else 
{
	$_SESSION['language'] = $LANG;
}
require_once("lang/$LANG/$FILE_LANG");
require_once('includes/functions.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $TITLE; ?></title>

<link href="includes/style_cc.css" rel="stylesheet" type="text/css" />
<script language="javascript">
function setFocus()
{
	document.autentic.login.focus();
}
</script>
</head>
<body onload="javascript:setFocus();">
<?php
	if (!empty($_SESSION['SHOW_MSG'])){?>
		<div align="center" id="show_msg">
			<?php echo($$_SESSION['SHOW_MSG']);?>
		</div>
	<?php 
		}
	?>
	<div id="main"> <!--Main-->
	<div id="menu_solutions"> <!--TOP -->
		<div id="top"> <!--Logo-->
		<img align="left" src="@img/Logo-incti.jpg" alt="IncTI Solu��es"/>	
			<div align="right">
			<form name="formlanguage" action="<?php echo $THISPAGE;?>" method="get">
				<select name="lang" onchange="javascript:document.formlanguage.submit();">
					<option ></option>
					<?php
					$SQL = "SELECT * FROM controlcenter.language";
					$RS = mysql_query($SQL);
					$ARRAY = mysql_fetch_array($RS);
					do { 
					if ($LANG == $ARRAY['file']){
					$sel = 'selected="selected"';
					}
					else{
					$sel = "";
					}
					?>
					<option <?php echo $sel;?> value="<?php echo $ARRAY['file'];?>">
						<?php echo $ARRAY['name']; ?>
					</option>
					<?php } while ($ARRAY = mysql_fetch_array($RS));?>
				</select>
			</form>
			</div>
		</div>
	</div>

	<div class="title_general" > <?php echo $T_AUTENTICATION;?> </div>
	
	<form action="<?php echo $DESTINATION_PAGE;?>" method="post" name="autentic">
		<div align="right" class="left_name"><?php echo $F_LOGIN;?></div>
			<div><input type="text" name="login" size="15" maxlength="20" value="<?php if (!empty($_SESSION['EX_NAME'])){ echo $_SESSION['EX_NAME'];}?>" autocomplete="off"/></div>
		<div align="right" class="left_name"><?php echo $F_PASSWORD;?></div>
			<div><input type="password" name="passwd" size="15" maxlength="50"/></div>
		<div align="right" class="left_name"><input type="submit" value="<?php echo $B_LOGON;?>" /></div>
	
	</form>
	</div>
</body>
</html>
<?php
session_unset();
session_destroy();
?>