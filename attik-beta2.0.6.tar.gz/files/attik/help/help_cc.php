<?php
require_once('../includes/control_session.php');
$W_IMAGE = "Imagem - ";?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title><?php echo $TITLE; ?></title>
<link href="../includes/style_cc.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style1 {font-size: xx-large}
-->
</style>
</head>

<body style="width:795px" >
<a name="top_help"><img src="../@img/Logo-incti.jpg" /></a>
<a href="javascript:history.back();">
<div id="toback_button">
	  <img src="../@img/icons/toback-32x32.png"/>Voltar
</div>
</a>
<p>______________________________________________________________________________________________________________________________________</p>
<p>Antes de ler o manual de ajuda, &eacute; importante se atentar a seguinte regra: a sequ&ecirc;ncia de clique no bot&otilde;es deve se d&aacute; de cima para baixo. Quando houver alguma excepcionalidade estar&aacute; descrita no texto. </p>
<p><strong>Autentica&ccedil;&atilde;o no sistema (Logon)</strong></p>
<p><img src="@img/img-1.0_logon.png" width="806" height="245" /><br />
  <em><?php echo $W_IMAGE;?> 1.0</em></p>
<p>Digite o login e senha previamente cadastrado no <?php echo $TITLE_NAME_SOLUTION;?>. Caso seja o primeiro acesso, digite o usu&aacute;rio &quot;attikadmin&quot; e senha &quot;attikadmin&quot;, na sequ&ecirc;ncia ser&aacute; solicitado a altera&ccedil;&atilde;o da senha que &eacute; padr&atilde;o, conforme a imagem 1.1.</p>
<p><img src="@img/img-1.1_alter_password.png" width="806" height="197" /><br />
  <em><?php echo $W_IMAGE;?> 1.1</em></p>
<p>Ap&oacute;s a autentica&ccedil;&atilde;o ser&aacute; exibido a tela padr&atilde;o, que &eacute; a tela de regras do m&oacute;dulo Firewall.</p>
      <div style="text-align: right;"><a href="#top_help"><span style="color:blue;">Top</span></a></div>
<p><strong>Gerenciamento de perfil e usu&aacute;rio </strong></p>
<p>Antes de criar usu&aacute;rios, &eacute; interessante criar os perfis de acesso que deseja. Por padr&atilde;o vem criado o perfil &quot;Administrador&quot; que possui acesso total. &Eacute; importante saber que o <?php echo $TITLE_NAME_SOLUTION;?> exige que se tenha ao menos um perfil e um usu&aacute;rio com privil&eacute;gios de administrador, tirando esta regra, a quantidade de perfis e usu&aacute;rios pode ser definida de acordo com o necess&aacute;rio.</p>
      <div style="text-align: right;"><a href="#top_help"><span style="color:blue;">Top</span></a></div>
<p><em><strong>Cadastrar/Editar/Remover Perfil</strong></em></p>
<p>Clique nos bot&otilde;es conforme indicado na imagem 2.0. </p>
<p><img src="@img/img-2.0_manager_user.png" width="810" height="606" /><br />
<em><?php echo $W_IMAGE;?> 2.0</em> </p>
<p>Para cadastrar um novo perfil preencha o formul&aacute;rio com o nome do perfil e as permiss&otilde;es que este ter&aacute;. Um exemplo de perfil com permiss&otilde;es completa pode ser observado na imagem 2.1. Selecione de acordo com as necessidades e com o nome que achar mais pertinente. </p>
<p><img src="@img/img-2.1_manager_user.png" width="810" height="606" /><br />
  <em><?php echo $W_IMAGE;?> 2.1</em></p>
<p>Caso deseje editar qualquer perfil ap&oacute;s cadastrado, selecione e edite de acordo com o desejado. Um exemplo de sele&ccedil;&atilde;o pode ser observado na imagem 2.2</p>
<p><img src="@img/img-2.2_manager_user.png" width="810" height="606" /> <br />
  <em><?php echo $W_IMAGE;?> 2.2</em></p>
<p>Para remover algum perfil basta clicar no bot&atilde;o &quot;Remover&quot; ap&oacute;s ter selecionado um. </p>
<p><em><strong>Cadastrar/Editar/Remover Usu&aacute;rio</strong></em></p>
<p>Clique nos bot&otilde;es conforme indicado na imagem 2.3. </p>
<p><img src="@img/img-2.3_manager_user.png" width="807" height="454" /><br />
  <em><?php echo $W_IMAGE;?> 2.3</em></p>
<p>Para cadastrar um novo usu&aacute;rio preencha o formul&aacute;rio conforme exigido nos campos dispostos na imagem 2.3. Se atente aos campos sublinhados, pois eles s&atilde;o de preechimento obrigat&oacute;rio. Caso queira que o usu&aacute;rio modifique sua senha no pr&oacute;ximo logon, maque a op&ccedil;&atilde;o indicada na tela. Um detalhe importante est&aacute; no campo onde se preenche o endere&ccedil;o IP do usu&aacute;rio, se ele for preenchido, no momento da aplica&ccedil;&atilde;o das regras de firewall, o <?php echo $TITLE_NAME_SOLUTION;?> ir&aacute; permitir o acesso apenas para os IPs dos usu&aacute;rios que est&atilde;o cadastrados, mas se o campo ficar em branco, ser&aacute; permitido o acesso a partir de qualquer host da rede.</p>
<p>Importante observar que mesmo que se cadastre o IP, &eacute; poss&iacute;vel a cria&ccedil;&atilde;o de regras no m&oacute;dulo Firewall do <?php echo $TITLE_NAME_SOLUTION;?> que permita o acesso do jeito que se desejar, podendo ser a uma sub-rede, por exemplo. </p>
<p>Para editar, basta selecionar o usu&aacute;rio desejado e alterar as suas propriedades. A imagem 2.4 ilustra uma sele&ccedil;&atilde;o. Conforme mostrado, edite os campos de senha apenas se realmente quiser alter&aacute;-los. </p>
<p><img src="@img/img-2.4_manager_user.png" width="809" height="456" /><br />
  <em><?php echo $W_IMAGE;?> 2.4</em></p>
<p>Para remover algum usu&aacute;rio, ap&oacute;s selecionado o usu&aacute;rio, clique no bot&atilde;o &quot;Remover&quot;, ser&aacute; exigido na tela a confirma&ccedil;&atilde;o de exclus&atilde;o, se realmente  desejar prossegrir clique em &quot;Sim&quot;, conforme ilustra a figura 2.5.</p>
<p><img src="@img/img-2.5_manager_user.png" width="806" height="499" /><em><br />
<?php echo $W_IMAGE;?> 2.4</em></p>
      <div style="text-align: right;"><a href="#top_help"><span style="color:blue;">Top</span></a></div>
<p><strong>Auditoria</strong></p>
<p>O <?php echo $TITLE_NAME_SOLUTION;?> divide a sua auditoria em duas camadas, a primeira se refere aos acessos bem e mau sucedidos que foram feitos e a seguran s&atilde;o as opera&ccedil;&otilde;es realizadas pelos usu&aacute;rios quando autenticados. Para facilitar a visualiza&ccedil;&atilde;o, &eacute; disponibilizado duas telas, uma para cada tipo de auditoria. Segue ent&atilde; o detalhamento da primeira e na sequ&ecirc;ncia o da segunda.</p>
      <div style="text-align: right;"><a href="#top_help"><span style="color:blue;">Top</span></a></div>
<p><em><strong>Acessos </strong></em></p>
<p>A imagem 3.0 mostra os acesso e tentativas de acesso que foram realizados no <?php echo $TITLE_NAME_SOLUTION;?>. As linhas em verde representam as tentativas bem sucedidas, j&aacute; as vermelhas representam as tentativas mau sucedidas seja por conta do login, senha ou mesmo os dois ao mesmo tempo incorretos.</p>
<p><img src="@img/img-3.0_access.png" width="808" height="499" /><br />
<em><?php echo $W_IMAGE;?> 3.0 </em></p>
<p>Para facilitar a visualiza&ccedil;&atilde;o de tentativas de acesso durante um determinado per&iacute;odo, &eacute; poss&iacute;vel selecionar o filtro informando a data de in&iacute;cio e a data de fim do per&iacute;odo que se deseja visualizar. A imagem 3.1 mostra um exemplo de sele&ccedil;&atilde;o de per&iacute;odo. </p>
<p><img src="@img/img-3.1_access.png" width="811" height="498" /><br />
  <em><?php echo $W_IMAGE;?> 3.1 </em><em> </em></p>
      <div style="text-align: right;"><a href="#top_help"><span style="color:blue;">Top</span></a></div>
<p><em><strong>Auditoria</strong></em></p>
<p>Na tela de auditoria s&atilde;o exibidas todas as opera&ccedil;&otilde;es realizadas por todos os usu&aacute;rios quando logado no <?php echo $TITLE_NAME_SOLUTION;?>. As opera&ccedil;&otilde;es s&atilde;o exibidas uma por linhas conforme mostra a imagem 3.2.</p>
<p><img src="@img/img-3.2_auditory.png" width="808" height="517" /> <br />
  <em><?php echo $W_IMAGE;?> 3.2</em></p>
<p><em> </em>Para saber a a&ccedil;&atilde;o que foi executada, clique em uma linha e ser&aacute; mostrado a opera&ccedil;&atilde;o realizada conforme mostra a figura 3.3.</p>
<p><img src="@img/img-3.3_auditory.png" width="807" height="535" /> <br />
  <em><?php echo $W_IMAGE;?> 3.3</em></p>
<p>Assim como na tela de Acesso, nessa tamb&eacute;m &eacute; poss&iacute;vel visualizar as a&ccedil;&otilde;es durante um determinado per&iacute;odo, basta selecionar a data de in&iacute;cio e a data de fim do per&iacute;odo que se deseja visualizar. A imagem 3.4 mostra um exemplo de sele&ccedil;&atilde;o de per&iacute;odo. </p>
<p><img src="@img/img-3.4_auditory.png" width="809" height="535" /><br />
  <em><?php echo $W_IMAGE;?> 3.4</em></p>
      <div style="text-align: right;"><a href="#top_help"><span style="color:blue;">Top</span></a></div>
<p><strong>Backup</strong></p>
<p>As configura&ccedil;&otilde;es de um mecanismo de seguran&ccedil;a &eacute; a parte mais importante  e deve ser devidamente salva. Diante de tamanha import&acirc;ncia o <?php echo $TITLE_NAME_SOLUTION;?> disponibiliza na tela de Backup a poss&iacute;bilidade de gerar c&oacute;pias de seguran&ccedil;a bem como o download do arquivo gerado. Este Backup cont&eacute;m todas as informa&ccedil;&otilde;es j&aacute; configuradas no <?php echo $TITLE_NAME_SOLUTION;?>, &eacute; uma c&oacute;pia completa do sistema. </p>
<p>Para criar um backup &eacute; poss&iacute;vel a inser&ccedil;&atilde;o de um texto com at&eacute; 200 caracteres caso deseje. A imagem 4.0 mostra um exemplo de cria&ccedil;&atilde;o de um backup.</p>
<p><img src="@img/img-4.0_backup.png" width="806" height="504" /><br />
  <em><?php echo $W_IMAGE;?> 4.0 </em> </p>
<p>Ap&oacute;s a digita&ccedil;&atilde;o da descri&ccedil;&atilde;o do backup, se desejado, clique no bot&atilde;o de cria&ccedil;&atilde;o do backup conforme indicado na imagem 4.0. Os campos desabilitados s&atilde;o automaticamente preenchidos n&atilde;o necessitando de nenhuma interven&ccedil;&atilde;o.<br />
  Quando um backup j&aacute; tiver sido gerado ele estar&aacute; listado na lista na parte inferior da tela e a qualquer momento &eacute; poss&iacute;ve a sua sele&ccedil;&atilde;o para visualiza&ccedil;&atilde;o, restaura&ccedil;&atilde;o ou mesmo download do backup. Um exemplo pode ser observado na imagem 4.1 que mostra inclusive o valor dos campos que ficam desabilitados preenchidos com os valores que a c&oacute;pia de seguran&ccedil;a foi gerada.</p>
<p><img src="@img/img-4.1_backup.png" width="808" height="501" /><br />
  <em><?php echo $W_IMAGE;?> 4.1 </em></p>
      <div style="text-align: right;"><a href="#top_help"><span style="color:blue;">Top</span></a></div>
<p><strong>Rede</strong></p>
<p>Na tela de Rede &eacute; disponibilizada as configura&ccedil;&otilde;es de rede e teste de conectividade dividida em quatro categorias representadas por interfaces f&iacute;sicas, l&oacute;gicas, rotas e ping (teste de conectividade). </p>
<p>Embora n&atilde;o obrigat&oacute;rio, &eacute; importante que as configura&ccedil;&otilde;es de rede sejam cadastradas no <?php echo $TITLE_NAME_SOLUTION;?> conforme o Sistema Operacional. Al&eacute;m de uma documenta&ccedil;&atilde;o sobre este ativo, &eacute; por este cadastro em que &eacute; reconhecida as interfaces tanto f&iacute;sicas quanto l&oacute;gicas ent&atilde;o na tela de regras de firewall &eacute; poss&iacute;vel a cria&ccedil;&atilde;o de regras especificando as interfaces aqui cadastradas.<br />
  Uma observa&ccedil;&atilde;o muito importante &eacute; que o 
<?php echo $TITLE_NAME_SOLUTION;?> apenas permite o cadastramento de interfaces f&iacute;sicas que realmente existam no Sistema Operacional n&atilde;o sendo poss&iacute;vel a cria&ccedil;&atilde;o de interfaces de teste inexistentes. </p>
<p><img src="@img/img-5.0_network.png" width="698" height="414" /><br />
<em><?php echo $W_IMAGE;?> 5.0 </em></p>
<p>A imagem 4.2 mostra a tela de configura&ccedil;&atilde;o com uma interface f&iacute;sica cadastrada. Caso apare&ccedil;a uma linha vermelha significa que n&atilde;o foi poss&iacute;vel aplicar as configura&ccedil;&otilde;es corretamente no sistema operacional.</p>
      <div style="text-align: right;"><a href="#top_help"><span style="color:blue;">Top</span></a></div>
<p><strong>Configura&ccedil;&atilde;o Geral</strong></p>
<p>Na tela de Geral &eacute; poss&iacute;vel determinar as prefer&ecirc;ncias de configura&ccedil;&atilde;o. Um exemplo de configura&ccedil;&atilde;o pode ser observado na imagem 6.0 </p>
<p><img src="@img/img-6.0_general.png" width="696" height="264" /><br />
<em><?php echo $W_IMAGE;?> 6.0 </em></p>
      <div style="text-align: right;"><a href="#top_help"><span style="color:blue;">Top</span></a></div>
<br /> <br /> <br /> <br /><br /> <br /> <br /> <br />
<table width="50%" height="116" border="1" align="center" bordercolor="#003399">
  <tr>
    <td height="68" colspan="2"><div align="center" class="style1"><?php echo $TITLE_NAME_SOLUTION;?></div></td>
  </tr>
  <tr>
    <th width="36%" scope="col"><em>Desenvolvedor: </em></th>
    <th width="64%" scope="col"><em>Felipe Pereira da Silva </em></th>
  </tr>
  <tr>
    <th scope="col"><em>Contato: </em></th>
    <th scope="col"><em>(61) 8135-2829 </em></th>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>
