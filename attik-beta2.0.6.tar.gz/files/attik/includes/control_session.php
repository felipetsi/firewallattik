<?php
session_start();
require_once('/var/www/attik/includes/functions.php');
if (!empty($_SESSION['USER']))
{
	$USER = $_SESSION['USER'];
	$ADDRIP = $_SERVER['REMOTE_ADDR'];
	require_once('functions.php');
	require_once('/var/www/attik/configuration/general.php');
	require_once('/var/www/attik/includes/conn_db_cc.php');
}else {
	header("Location:/attik/logon.php");
}
?>
