<?php
$FILE = $_SESSION['FILE_LANG'];
$LANG = $_POST['language'];
if ((empty($LANG)) AND (empty($_SESSION['language'])))
{
	$_SESSION['language'] = $DEFAULT_LANGUAGE;
	$LANG = $_SESSION['language'];
}elseif (!empty($LANG))
{
	$_SESSION['language'] = $LANG;
}
 else 
{
	$LANG = $_SESSION['language'];
}
if (!empty($FILE)) {
	require_once("/var/www/attik/lang/$LANG/$FILE");
}
require_once("/var/www/attik/lang/$LANG/general.php");
?>
<div id="menu_solutions"> <!--Main -->
	<div id="top"> <!--Logo-->
	<img align="left" src="/attik/@img/Logo-incti.jpg" alt="<?php echo $TITLE;?>"/>	
		<a href="/attik/logon.php">
		<div id="obj_out">
		<img src="/attik/@img/icons/logoff-32x32.png" alt="<?php echo $L_OUT;?>" align="absmiddle" />
		<?php echo $L_OUT;?>
		</div>
		</a>
		<a href="/attik/help/help_cc.php">
		<img  id="contet_rigth_img" src="/attik/@img/icons/help-32x32.png" align="absmiddle" />	
		</a>
		<div id="obj_select_lang">
		<form name="formlanguage" action="<?php echo $THISPAGE;?>" method="post">
			<select name="language" onchange="javascript:document.formlanguage.submit();">
				<option selected></option>
				<?php
				$SQL = "SELECT * FROM controlcenter.language";
				$RS = mysql_query($SQL);
				$ARRAY = mysql_fetch_array($RS);
				do { 
				if ($LANG == $ARRAY['file']){
				$sel = 'selected="selected"';
				}
				else{
				$sel = "";
				}			
				?>
				<option <?php echo $sel;?> value="<?php echo $ARRAY['file'];?>">
					<?php echo $ARRAY['name']; ?>
				</option>
				<?php } while ($ARRAY = mysql_fetch_array($RS));?>
			</select>

		</form>
		</div>
	</div>
<?php require_once('menu_top.php');?>
</div>
<?php
if (!empty($_SESSION['SHOW_MSG'])){?>
	<div align="center" id="show_msg">
		<?php echo($$_SESSION['SHOW_MSG']);?>
	</div>
<?php 
	}
unset($_SESSION['FILE_LANG']);
unset($_SESSION['SHOW_MSG']);
?>