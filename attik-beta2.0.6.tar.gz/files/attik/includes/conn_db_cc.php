<?php 
require_once('/var/.incti/.access/.access_exec.php');
$hostname = "127.0.0.1";
$username = "attikuser";
$url = mysql_connect($hostname,$username,$INCTIPW);
?>
