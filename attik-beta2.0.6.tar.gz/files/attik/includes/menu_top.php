<div class="menu_top"><!--Menus-->
	<a href="/attik/modules/firewall/firewall.php">
		<div class="button_top">
			<img src="/attik/@img/icons/firewall-server-16x16.png" align="absmiddle"/>
			Firewall
		</div>
	</a>
	<a href="/attik/modules/vpn/vpn.php">
		<div class="button_top">
			<img src="/attik/@img/icons/proxy-server-24x24.gif" align="absmiddle"/>
			VPN
		</div>
	</a>
		<div class="button_top" style="float:left; width:199px;"> 
			
		</div>
	<a href="<?php echo $DEAFULT_CONF_CC;?>">
		<div class="button_top" style="float:left;">
			<img src="/attik/@img/icons/build-16x16.gif" align="absmiddle"/>
			<?php echo $L_CONFIGURATIONG_CC;?>
		</div>
	</a>
</div>
