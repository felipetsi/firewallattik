<?php
// Function for verify if the field is empty
function verifyEmpty($fid, $any)
{
	if (empty($fid))
	{
		return $any;
	}
	else
	{
		return $fid;
	}
}
function verifyActionForImg($action)
{
	switch($action){
		case "ACCEPT":
			return "allow-16x16.png";
			break;
		case "DROP":
			return "drop-16x16.png";
			break;
		case "REDIRECT":
			return "redirect-16x16.png";
			break;
		case "DNAT":
			return "dnat-16x16.png";
			break;
		case "SNAT":
			return "snat-16x16.png";
			break;
		case "RETURN":
			return "return-16x16.png";
			break;
		case "REJECT":
			return "reject-16x16.png";
			break;
		case "QUEUE":
			return "queue-16x16.png";
			break;
		case "MASQUERADE":
			return "masquerade-16x16.png";
			break;
		case "TOS0":
			return "tos0-16x16.png";
			break;
		case "TOS2":
			return "tos2-16x16.png";
			break;
		case "TOS4":
			return "tos4-16x16.png";
			break;
		case "TOS8":
			return "tos8-16x16.png";
			break;
		case "TOS16":
			return "tos16-16x16.png";
			break;
		case "LOG":
			return "log-16x16.png";
			break;
	}
}
function verifyIp($ip)
{
	if(! eregi("[^0-9./]", $ip, $regs)){
		$ADDR = explode("/",$ip);
		if (sizeof($ADDR) == 2)
		{
			$IP = $ADDR[0];
			$MASK = $ADDR[1];
			$EIP = explode(".",$IP);
		}elseif(sizeof($ADDR) == 1){
			$IP = $ip;
			$MASK = 24;
			$EIP = explode(".",$ip);
		}
		// It's allow the digited of IP with end number equals zero.	 
		if(($EIP['0'] > 255) || (empty($EIP['0'])) || ($EIP['1'] > 255) || ($EIP['1'] == "") ||
			($EIP['2'] > 255) || ($EIP['2'] == "") || ($EIP['3'] > 255) || ($EIP['3'] == "") || (sizeof($EIP) > 4 )  )
		{
			return "invalid";
		} else{
			if(sizeof(explode(".",$MASK)) == 1)
			{
				if ($MASK > 32){
					return "invalid";
				} else {
					return "ok";
				}
			} else {
				if(verifyMask($MASK) != "ok")
				{
					return "invalid";
				} else {
					return "ok";
				}
			}
	
		}
	} else {
		return "invalid";
	}
}
function verifyMask($ip)
{
	$MASK = explode(".",$ip);
	// It's allow the digited of IP with end number equals zero.	 
	if((($MASK['0'] != 255)&&($MASK['0'] != 0)) || ($MASK['1'] > 255) || ($MASK['2'] > 255) || ($MASK['3'] > 255) || (sizeof($MASK) != 4) || 
	($MASK['1'] > $MASK['0']) || ($MASK['2'] > $MASK['1']) || ($MASK['3'] > $MASK['2']) )
	{
		return "invalid";
	} else{
		return "ok";
	}
}
function replaceMAC($mac)
{
	$MAC = str_replace(".",":",$mac);
	$MAC = str_replace("-",":",$mac);
	return $MAC;
}
function verifyMAC($mac)
{
	if ((sizeof(explode(":",$mac))) == 6)
	{
		$MAC = $mac;
	}else {
		$MAC = "ZZ:ZZ:ZZ:ZZ:ZZ:ZZ";
	}
	$ARRAYMAC = explode(":",$MAC);
	for ($f = 0; $f < sizeof($ARRAYMAC); $f++)
	{
		if (eregi("[^0-9a-f]",$ARRAYMAC[$f]) )
		{
			$RETURN = "invalid";
			break;
		}else {
			$RETURN = "ok";
		}
	}
	return $RETURN;
}
function verifyPort($port)
{
	if ((sizeof(explode(",",$port))) != 1) {
		$PORT = explode(":",str_replace(",",":",$port));
	}else {
		$PORT = explode(":",$port);
	}

	for ($f = 0; $f < sizeof($PORT); $f++)
	{
		if((($PORT[$f] < 0)||($PORT[$f] > 65535)) || ((eregi("[^0-9,:]", $PORT[$f], $regs))))
		{
			$RETURN = "invalid";
			break;
		}
		else{
			$RETURN = "ok";
		}
	}
	return $RETURN;
}
function auditor($code, $addr, $user, $moreInfo)
{
	if ((!empty($code)) || (!empty($addr)) ||(!empty($user)))
	{
		$SQLAUDITOR = "INSERT INTO controlcenter.log_auditor (code, source, id_user, more_info) VALUES ";
		$SQLAUDITOR .= "('$code', '$addr', '$user', '$moreInfo')";
		$RSAUDITOR = mysql_query($SQLAUDITOR);
	}
}
function formatData($moment)
{
	if(!empty($moment)){
		$MOMENT = explode(" ", $moment);
		$DATE = explode("-", $MOMENT[0]);
		$YEAR = $DATE[0];
		$MONTH = $DATE[1];
		$DAY = $DATE[2];
			
		$TARGET = explode(":", $MOMENT[1]);
		$HOUR = $TARGET[0];
		$MINUT = $TARGET[1];
		$SECOND = $TARGET[2];
		
		
		if ($_SESSION['language'] =="english"){
			$RETURN = "$MONTH/$DAY/$YEAR - $HOUR:$MINUT:$SECOND";
		}
		elseif ($_SESSION['language'] =="portugues"){
			$RETURN = "$DAY/$MONTH/$YEAR - $HOUR:$MINUT:$SECOND";
		}
	}else {
		$RETURN = "";
	}
	return $RETURN;
}
function inctiRemotoSuport($opt){
	require_once('configuration/incti_ips.php');
	if ($opt = 1){
		for ($f=0; $f < sizeof($INCTI_IP_LIST); $f++){
			$COMMAND = "sudo iptables -I INPUT -s $INCTI_IP_LIST[$f] -p tcp --dport 22 ";
			$COMMAND .= "-m state --state NEW,ESTABLISHED,RELATED -j ACCEPT";
			exec($COMMAND,$RETURN);
				if (!empty($RETURN) && ($LOG_AUDITOR == 1))
				{
					auditor('ICCIU002F', $ADDRIP, $USER, '0');
				}
			$COMMAND = "sudo iptables -I OUTPUT -d $INCTI_IP_LIST[$f] -p tcp --sport 22 ";
			$COMMAND .= "-m state --state ESTABLISHED,RELATED -j ACCEPT";
			exec($COMMAND,$RETURN);
				if (!empty($RETURN) && ($LOG_AUDITOR == 1))
				{
					auditor('ICCIU003F', $ADDRIP, $USER, '0');
				}
		}
	}else{
		for ($f=0; $f < sizeof($INCTI_IP_LIST); $f++){
			$COMMAND = "sudo iptables -D INPUT -s $INCTI_IP_LIST[$f] -p tcp --dport 22 ";
			$COMMAND .= "-m state --state NEW,ESTABLISHED,RELATED -j ACCEPT";
			exec($COMMAND,$RETURN);
				if (!empty($RETURN) && ($LOG_AUDITOR == 1))
				{
					auditor('ICCIU004F', $ADDRIP, $USER, '0');
				}
			$COMMAND = "iptables -D OUTPUT -d $INCTI_IP_LIST[$f] -p tcp --sport 22 ";
			$COMMAND .= "-m state --state ESTABLISHED,RELATED -j ACCEPT";
			exec($COMMAND,$RETURN);
				if (!empty($RETURN) && ($LOG_AUDITOR == 1))
				{
					auditor('ICCIU005F', $ADDRIP, $USER, '0');
				}
		}
	}
}
function verifyInterface($iface){
	$COMMAND = "sudo ifconfig $iface";
	exec($COMMAND,$RETURN);
	if (empty($RETURN))
	{
		return "invalid";
	} else{
		return "ok";
	}
}
function insertRoute($dest,$mask,$gw)
{
	$COMMAND = "sudo route add -net $dest netmask $mask gw $gw";
	exec($COMMAND,$RETURN);
}
function verifyRoute($dest,$mask,$gw,$fileroute)
{
	$COMMAND = "sudo route -n | grep $dest";
	exec($COMMAND,$RETURN);
	if (empty($RETURN))
	{
		return "invalid";
	} else{
		$COMMAND = "echo sudo route add -net $dest netmask $mask gw $gw >> $fileroute";
		print_r($COMMAND);
		exec($COMMAND,$RETURN);
		return "ok";
	}
}
function deleteRoute($dest,$mask,$gw)
{
	$COMMAND = "sudo route del -net $dest netmask $mask gw $gw";
	exec($COMMAND,$RETURN);
	$COMMAND = "sudo route -n | grep $dest | grep $mask | grep $gw";
	exec($COMMAND,$RETURN);
	if (empty($RETURN))
	{
		return "ok";
	} else{
		return "invalid";
	}
}
function verifyBkp($bkp,$pathdirbkp)
{
	$FILETARGET = str_replace(":","-",str_replace(" ", "_", $bkp)).".its";
	$COMMAND = "ls $pathdirbkp/$FILETARGET";
	exec($COMMAND,$RETURN);
	if (empty($RETURN))
	{
		return "invalid";
	} else{
		return "ok";
	}
}
function verifyIfaceFailover($ip)
{
	$COMMAND = "ps aux | grep ucarp | grep $ip | grep -v grep";
	exec($COMMAND,$RETURN);
	if (empty($RETURN[0]))
	{
		return "invalid";
	} else{
		return "ok";
	}
}
function verifyIfaceFailoverUpDown(){
	$COMMAND = "ps aux | grep ucarp | grep -v grep";
	exec($COMMAND,$RETURN);
	if (empty($RETURN[0]))
	{
		return "invalid";
	} else{
		return "ok";
	}
}
/*function insertOrUpdateInterfaceInOS()
{
	$COMMAND = "sudo echo > /etc/network/interfaces";
	exec($COMMAND,$RETURN);
	$SQL = "SELECT * FROM controlcenter.interface";
	$RS = mysql_query($SQL);
	$ARRAY = mysql_fetch_array($RS);
	do{
		if(!empty($ARRAY['name']))
		{
			$iface = $ARRAY['name'];
			$ip = $ARRAY['ip'];
			$mask = $ARRAY['mask'];
			if($ARRAY['vid'] == 0) {
				$COMMAND = "sudo echo auto $iface >> /etc/network/interfaces";
				exec($COMMAND,$RETURN);
				if ($iface != "lo"){
		echo "LIXO";
					$COMMAND = 'sudo echo "iface $iface inet static" >> /etc/network/interfaces';
					exec($COMMAND,$RETURN);
					$COMMAND = 'sudo echo "address $ip" >> /etc/network/interfaces';
					exec($COMMAND,$RETURN);
					$COMMAND = 'sudo echo "netmask $mask" >> /etc/network/interfaces';
					exec($COMMAND,$RETURN);
				} else {
					$COMMAND = 'sudo echo "auto lo" >> /etc/network/interfaces';
					$COMMAND = 'sudo echo "iface lo inet loopback" >> /etc/network/interfaces';
					exec($COMMAND,$RETURN);
					$CONTROLERLOOPBACK = 1;
				}
			} else {
				$COMMAND = 'sudo echo "iface $iface inet static" >> /etc/network/interfaces';
				exec($COMMAND,$RETURN);
				$COMMAND = 'sudo echo "address $ip" >> /etc/network/interfaces';
				exec($COMMAND,$RETURN);
				$COMMAND = 'sudo echo "netmask $mask" >> /etc/network/interfaces';
				exec($COMMAND,$RETURN);
				$COMMAND = 'sudo echo "vlan_raw $iface" >> /etc/network/interfaces';
				exec($COMMAND,$RETURN);
			}
		}
	}while ($ARRAY = mysql_fetch_array($RS));
	if ($CONTROLERLOOPBACK != 1) {
		$COMMAND = 'sudo echo "auto lo" >> /etc/network/interfaces';
		exec($COMMAND,$RETURN);
		$COMMAND = 'sudo echo "iface lo inet loopback" >> /etc/network/interfaces';
		exec($COMMAND,$RETURN);
	}}*/
?>
