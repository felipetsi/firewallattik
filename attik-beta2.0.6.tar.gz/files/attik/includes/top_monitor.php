<?php
session_start();
require_once('configuration/general.php');
require_once('../../includes/conn_db_cc.php');
$THISPAGE = "monitor_fw.php";

require_once('configuration/general.php');
$FILE_LANG = $_SESSION['FILE_LANG'];
$LANG = trim(addslashes($_GET['lang']));
if (empty($LANG))
{
	$_SESSION['language'] = $DEFAULT_LANGUAGE;
	$LANG = $_SESSION['language'];
} else 
{
	$_SESSION['language'] = $LANG;
}
require_once("../../lang/$LANG/$FILE_LANG");
require_once("/var/www/attik/lang/$LANG/general.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $TITLE; ?></title>

<link href="../../includes/style_cc.css" rel="stylesheet" type="text/css" />
<script language="javascript">
function setFocus()
{
	document.autentic.login.focus();
}
</script>
</head>
<body onload="javascript:setFocus();">
<?php
if (!empty($_SESSION['SHOW_MSG'])){?>
	<div align="center" id="show_msg">
		<?php echo($$_SESSION['SHOW_MSG']);?>
	</div>
<?php 
	}
?>
<div id="main"> <!--Main-->
<div id="menu_solutions"> <!--TOP -->
	<div id="top"> <!--Logo-->
	<img align="left" src="../../@img/Logo-incti.jpg" alt="IncTI Solu��es"/>	
		<div align="right">
		<form name="formlanguage" action="<?php echo $THISPAGE;?>" method="get">
			<select name="lang" onchange="javascript:document.formlanguage.submit();">
                <option ></option>
				<?php
				$SQL = "SELECT * FROM controlcenter.language";
				$RS = mysql_query($SQL);
				$ARRAY = mysql_fetch_array($RS);
				do { 
				if ($LANG == $ARRAY['file']){
				$sel = 'selected="selected"';
				}
				else{
				$sel = "";
				}
				?>
                <option <?php echo $sel;?> value="<?php echo $ARRAY['file'];?>">
                    <?php echo $ARRAY['name']; ?>
                </option>
				<?php } while ($ARRAY = mysql_fetch_array($RS));?>
            </select>
		</form>
		</div>
	</div>
</div>