<?php 
require_once('includes/control_session.php');
require('configuration/directory.php');
$THISPAGE = "firewall_list_cc.php";
$DESTINATION_PAGE = "firewall_list_run_cc.php";
require_once('lang/portugues/firewall.php');
$_SESSION['FILE_LANG'] = "firewall.php";

// Load the profile of user autenticanted
$SQL = "SELECT change_config FROM controlcenter.profile WHERE ";
$SQL .= "id IN (SELECT id_pro FROM controlcenter.user WHERE id = '$USER')";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSU001F"));
$DATA_USER = mysql_fetch_array($RS);

// Load the item selected
if (!empty($_POST['list']))
{
	$_SESSION['ITEMID'] = $_POST['list'];
	$ITEMID = $_SESSION['ITEMID'];
} else {
	$ITEMID = $_SESSION['ITEMID'];
}
$_SESSION['ITEMDELETE'] = $ITEMID;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $TITLE; ?></title>
<script language="javascript">
	var thispage = "firewall_list_cc.php";
	var deletepage = "firewall_list_delete_cc.php";
</script>
<link href="includes/style_cc.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
require_once('includes/top.php'); 
?>
<div id="main"> <!--Main-->
<?php require_once('cc_menu_configuration.php');?>
	<div id="contet_rigth"><?php
if ($DATA_USER['change_config'] == 1) {

// Load the user selected
$SQL = "SELECT * FROM controlcenter.firewall_list WHERE id = '$ITEMID'";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSW001F"));
	//Auditor
	if ((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1))
	{
		auditor('ICCSU002S', $ADDRIP, $USER, '0');
	}
$DATA = mysql_fetch_array($RS);
?>
<script language="javascript">
function confirmDeleteSelected()
{
	document.getElementById('background_transparent').style.display="inline";
	document.getElementById('box_delete').style.display="table";	
}
function yesdeleteSelected()
{
	window.location=deletepage;
}
function nodeleteSelected()
{
	document.getElementById('box_delete').style.display="none";
	document.getElementById('background_transparent').style.display="none";
}
function clickBackgroudTrabsparent()
{
	nodeleteSelected();
}
</script>
<div id="background_transparent" onclick="javascript:clickBackgroudTrabsparent();"></div>
<div id="box_delete"><?php echo("$S_WANT_DELETE?");?> 
	<div class="space_confirm_box">
		<input type="button" value="<?php echo $B_YES;?>" onclick="javascript:yesdeleteSelected();" />
		<input type="button" value="<?php echo $B_NO;?>" onclick="javascript:nodeleteSelected();" />
	</div>	
</div>
<!--Start add-->
<form class="insert_border" action="<?php echo $DESTINATION_PAGE;?>" method="post">

<input type="hidden" name="id" value="<?php echo $ITEMID;?>" />
		<div class="title_general"><?php echo $T_FIREWALL_LIST_DETAILS;?></div>

		<div id="object">
			<div align="right" class="left_name"><u><?php echo $F_NAME;?></u></div>
				<div> <input type="text" size="20" maxlength="200" name="name_fw" value="<?php if (!empty($_SESSION['NAMEFWLIST'])){echo $_SESSION['NAMEFWLIST'];} else {echo $DATA['name'];}?>" /></div>

			<div align="right" class="left_name"><u><?php echo $F_IP;?></u></div>
				<div> <input type="text" size="20" maxlength="15" name="ip_fw_list" value="<?php if (!empty($_SESSION['IPFWLIST'])){echo $_SESSION['IPFWLIST'];} else {echo $DATA['ip'];}?>" /></div>
			<br /><br />
				
<div class="title_general">
	<input type="submit" value="<?php if (empty($ITEMID)){ echo $B_ADD_NEW;} else { echo $B_UPDATE;}?>" />
	<input type="button" value="<?php echo $B_CLEAR;?>" onclick="javascript:window.location=thispage" />
	<input type="button" value="<?php echo $B_DELETE;?>" onClick="javascript:confirmDeleteSelected();" />
</div>
</form>
<form action="<?php echo $THISPAGE;?>" method="post" name="formdown">
	<input type="hidden" name="ifacedown" value="1" />
</form>
<!--End add-->
<?php }
if ($DATA_USER['change_config'] == 1) {
?>
<!-- Start list-->
<div class="title_general"><?php echo $$T_FIREWALL_LIST;?></div>
<form class="insert_border" action="<?php echo $THISPAGE;?>" method="post" name="objselect">
<select class="select_list_1" name="list" size="20" ondblclick="javascript:document.objselect.submit()">
<?php
	$SQL = "SELECT * FROM controlcenter.firewall_list ORDER BY name";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSW002F"));
	$ARRAY = mysql_fetch_array($RS);
	$cor = 0;	
	do{
	if(!empty($ARRAY['id'])){
		if ($ITEMID == $ARRAY['id']) {
			$sel = 'selected="selected"';
		} else {
				$sel = "";
		}?>
			<option <?php if($cor==1){ echo 'style="background-color:'.$COLOR_LINE_SELECT.'"'; $cor=0;}else{$cor=1;}?>  value="<?php echo $ARRAY['id'];?>" <?php echo $sel;?> ><?php echo $ARRAY['name']." - ".$ARRAY['ip'];?></option>
			<?php
		}
	}while ($ARRAY =  mysql_fetch_array($RS));?>
</select>
<?php 
}?>
</form>
</div> <!--content rigth-->
<div class="version_general">
<?php
echo $VERSIONCC;
?>
</div>
</div> <!--Main-->
</body>
</html>
<?php
unset($_SESSION['SHOW_MSG']);
unset($_SESSION['ITEMID']);
unset($_SESSION['NAMEFWLIST']);
unset($_SESSION['IPFWLIST']);
?>