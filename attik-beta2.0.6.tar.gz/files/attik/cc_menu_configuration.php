<div id="left_menu"><!-- Sub-menu -->
<a href="profile_cc.php">
	<div class="button_conf" >
		<img src="@img/icons/user-group-16x16.gif" /><?php echo $L_PROFILE;?>
	</div>
</a>
<a href="user_cc.php">
	<div class="button_conf" >
	 	<img src="@img/icons/user-16x16.gif" /><?php echo $L_USER;?>
	</div>
</a>
<a href="last_access_cc.php">
	<div class="button_conf" >
	 	<img src="@img/icons/history-16x16.png" /><?php echo $L_LASTACCESS;?>
	</div>
</a>
<a href="auditory_cc.php">
	 <div class="button_conf" >
	 	<img src="@img/icons/auditor-16x16.png" /><?php echo $L_AUDITORY;?>
	</div>
</a>
<a href="backup_cc.php">
	<div class="button_conf" >
	 	<img src="@img/icons/backup-16x16.png" /><?php echo $L_BACKUP;?>
	</div>
</a>
<a href="interface_cc.php">
	<div class="button_conf" >
		<img src="@img/icons/network-16x16.png" /><?php echo $L_NETWORK;?>
	</div>
</a>
<a href="failover_cc.php">
	<div class="button_conf" >
	 	<img src="@img/icons/failover-16x16.png" /><?php echo $L_FAILOVER;?>
	</div>
</a>
<a href="firewall_list_cc.php">
	<div class="button_conf" >
	 	<img src="@img/icons/suport-16x16.png" /><?php echo $L_FIREWALLS;?>
	</div>
</a>
<a href="general_conf_cc.php">
	<div class="button_conf" >
	 	<img src="@img/icons/suport-16x16.png" /><?php echo $L_GENERAL;?>
	</div>
</a>

<?php /*
<a href="update_cc.php">
	 <div class="button_conf" >
	 	<img src="@img/icons/update-16x16.png" /><?php echo $L_UPDATE;?>
	</div>
</a>*/ ?>
</div> <!-- Sub-menu -->