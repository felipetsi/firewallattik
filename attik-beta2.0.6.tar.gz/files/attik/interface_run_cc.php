<?php 
require_once('includes/control_session.php');

$DESTINATION_PAGE = "interface_cc.php";

$IDSELECT = trim(addslashes($_POST['id']));
$DESCRIPTION = substr(trim(addslashes($_POST['description'])),0,30);
$IP = substr(trim(addslashes($_POST['ip'])),0,15);
$MASK = substr(trim(addslashes($_POST['mask'])),0,15);
if ($_SESSION['INTERFACE'] == 1) {
	$NAME = substr(trim(addslashes($_POST['name'])),0,6);
	$ID = $IDSELECT;
	$VID = 0;
} else {
	$VID = substr(trim(addslashes($_POST['vlanid'])),0,4);
	$ID = trim(addslashes($_POST['iface']));
	$NAME = "vlan".$VID;
}

if (((empty($NAME)) || (empty($IP)) || (empty($DESCRIPTION))) && ($_SESSION['INTERFACE'] == 1)) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDFILL';
	$_SESSION['ITEMID'] = $ID;
	$_SESSION['EX_DESCRIPTION'] = $DESCRIPTION;
	$_SESSION['EX_NAME'] = $NAME;
	$_SESSION['VID'] = $VID;
	$_SESSION['EX_IP'] = $IP;
	$_SESSION['EX_MASK'] = $MASK;
	header("Location:$DESTINATION_PAGE");
}
elseif (((empty($NAME)) || (empty($IP)) || (empty($ID)) || (empty($DESCRIPTION))) && ($_SESSION['INTERFACE'] != 1)) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDFILL';
	$_SESSION['ITEMID'] = $ID;
	$_SESSION['EX_DESCRIPTION'] = $DESCRIPTION;
	$_SESSION['EX_NAME'] = $NAME;
	$_SESSION['VID'] = $VID;
	$_SESSION['EX_IP'] = $IP;
	$_SESSION['EX_MASK'] = $MASK;
	header("Location:$DESTINATION_PAGE");
}
elseif(($IP != "") && (verifyIp($IP) != "ok") || (eregi("[^0-9./]", $IP, $regs))) {
	$_SESSION['SHOW_MSG'] = 'ME_INVALIDIP';
	$_SESSION['ITEMID'] = $ID;
	$_SESSION['EX_DESCRIPTION'] = $DESCRIPTION;
	$_SESSION['EX_NAME'] = $NAME;
	$_SESSION['VID'] = $VID;
	$_SESSION['EX_IP'] = $IP;
	$_SESSION['EX_MASK'] = $MASK;
	header("Location:$DESTINATION_PAGE");
}
elseif((verifyInterface($NAME) != "ok")&&($_SESSION['INTERFACE'] == 1)){
	$_SESSION['SHOW_MSG'] = 'ME_INVALIDINTERFACE';
	$_SESSION['ITEMID'] = $ID;
	$_SESSION['EX_DESCRIPTION'] = $DESCRIPTION;
	$_SESSION['EX_NAME'] = $NAME;
	$_SESSION['VID'] = $VID;
	$_SESSION['EX_IP'] = $IP;
	$_SESSION['EX_MASK'] = $MASK;
	header("Location:$DESTINATION_PAGE");
}
else {
	$SQL = "SELECT * FROM controlcenter.interface WHERE (name = '$NAME' OR ip = '$IP') AND id != '$ID'";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSI005F"));
	if ( mysql_affected_rows() !=0 )
	{
		if($LOG_AUDITOR == 1){
			auditor('IFWSI005F', $ADDRIP, $USER, $NAME);
		}
		$_SESSION['SHOW_MSG'] = 'ME_NAMEORIPEXIST';
		$_SESSION['ITEMID'] = $ID;
		$_SESSION['EX_DESCRIPTION'] = $DESCRIPTION;
		$_SESSION['EX_NAME'] = $NAME;
		$_SESSION['VID'] = $VID;
		$_SESSION['EX_IP'] = $IP;
		$_SESSION['EX_MASK'] = $MASK;
		header("Location:$DESTINATION_PAGE");
	}
	else {
		if (empty($IDSELECT)) {
			if($_SESSION['INTERFACE'] == 1) {
				$SQL = "INSERT INTO controlcenter.interface (vid, description, name, ip, mask) ";
				$SQL .= "VALUES ('$VID', '$DESCRIPTION', '$NAME', '$IP', '$MASK')";
			} else {
				$SQL = "INSERT INTO controlcenter.interface (id_iface, vid, description, name, ip, mask) ";
				$SQL .= "VALUES ('$ID', '$VID', '$DESCRIPTION', '$NAME', '$IP', '$MASK')";
			}
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWII006F"));
		}
		else {
			if($_SESSION['INTERFACE'] == 1) {
				$SQL = "UPDATE controlcenter.interface SET description='$DESCRIPTION', name='$NAME', ip='$IP', ";
				$SQL .= "mask='$MASK', vid = '$VID' WHERE id = '$IDSELECT' AND vid = '$VID'";
			} else {
				$SQL = "UPDATE controlcenter.interface SET description='$DESCRIPTION', name='$NAME', ip='$IP', ";
				$SQL .= "mask='$MASK', vid = '$VID', id = '$ID' WHERE vid = '$IDSELECT' ";
			}
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWUI007F"));
			}
			if (mysql_affected_rows() != 0) {
				if($LOG_AUDITOR == 1){
					auditor('IFWXI008S', $ADDRIP, $USER, '0');
				}
				$_SESSION['SHOW_MSG'] = 'F_SUCESS';
			} else {
				if($LOG_AUDITOR == 1){
					auditor('IFWXI008F', $ADDRIP, $USER, '0');
				}
				$_SESSION['SHOW_MSG'] = 'F_FAILURE';
			}
			header("Location:$DESTINATION_PAGE");
	}
}
?>