<?php 
require_once('includes/control_session.php');

$DESTINATION_PAGE = "user_run_cc.php";
$THISPAGE = "user_cc.php";

// Load the profile of user autenticanted
$SQL = "SELECT create_user, read_user FROM controlcenter.profile WHERE ";
$SQL .= "id IN (SELECT id_pro FROM controlcenter.user WHERE id = '$USER')";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSU001F"));
$DATA_USER = mysql_fetch_array($RS);

// Load the item selected
if (!empty($_POST['list']))
{
	$_SESSION['ITEMID'] = $_POST['list'];
	$ITEMID = $_SESSION['ITEMID'];
} else {
	$ITEMID = $_SESSION['ITEMID'];
}
$_SESSION['ITEMDELETE'] = $ITEMID;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $TITLE; ?></title>
<script language="javascript">
	var thispage = "user_cc.php";
	var deletepage = "user_delete_cc.php";
</script>
<link href="includes/style_cc.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
require_once('includes/top.php'); 
?>
<div id="main"> <!--Main-->
<?php require_once('cc_menu_configuration.php');?>
	<div id="contet_rigth"><?php
if ($DATA_USER['create_user'] == 1) {

// Load the user selected
$SQL = "SELECT * FROM controlcenter.user WHERE id = '$ITEMID'";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSU002F"));
	//Auditor
	if ((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1))
	{
		auditor('ICCSU002S', $ADDRIP, $USER, '0');
	}
$ARRAY = mysql_fetch_array($RS);
?>
<script language="javascript">
function confirmDeleteSelected()
{
	document.getElementById('background_transparent').style.display="inline";
	document.getElementById('box_delete').style.display="table";	
}
function yesdeleteSelected()
{
	window.location=deletepage;
}
function nodeleteSelected()
{
	document.getElementById('box_delete').style.display="none";
	document.getElementById('background_transparent').style.display="none";
}
function clickBackgroudTrabsparent()
{
	nodeleteSelected();
}
</script>
<div id="background_transparent" onclick="javascript:clickBackgroudTrabsparent();"></div>
<div id="box_delete"><?php echo("$S_WANT_DELETE?");?> 
	<div class="space_confirm_box">
		<input type="button" value="<?php echo $B_YES;?>" onclick="javascript:yesdeleteSelected();" />
		<input type="button" value="<?php echo $B_NO;?>" onclick="javascript:nodeleteSelected();" />
	</div>	
</div>
<!--Start add-->
<form class="insert_border" action="<?php echo $DESTINATION_PAGE;?>" method="post">
<input type="hidden" name="id" value="<?php echo $ARRAY['id'];?>" />
<div class="title_general" > <?php echo $T_USER; ?> </div>
<div align="right" class="left_name_1"><u><?php echo $F_FULLNAME;?></u></div>
	<div> <input type="text" size="25" maxlength="50" name="fullname" value="<?php if(!empty($_SESSION['EX_NAME'])) { echo $_SESSION['EX_NAME'];} else { echo $ARRAY['fullname'];}?>" autocomplete="off"/></div>

<div align="right" class="left_name_1"><u><?php echo $F_LOGIN;?></u></div>
	<div> <input type="text" size="25" maxlength="20" name="login" value="<?php if (!empty($_SESSION['EX_LOGIN'])) { echo $_SESSION['EX_LOGIN'];} else { echo $ARRAY['login'];}?>" autocomplete="off"/></div>
	
<div align="right" class="left_name_1"><u>*<?php echo $F_PASSWORD;?></u></div>
	<div> <input type="password" size="25" maxlength="40" name="password" value="<?php if (!empty($_SESSION['EX_PASSWORD'])) { echo $_SESSION['EX_PASSWORD'];}?>"/></div>

<div align="right" class="left_name_1"><u>*<?php echo $F_REPASSWORD;?></u></div>
	<div> <input type="password" size="25" maxlength="40" name="repassword" value="<?php if (!empty($_SESSION['EX_REPASSWORD'])) { echo $_SESSION['EX_REPASSWORD'];}?>"/></div>	

<div align="right" class="left_name_1"><?php echo $F_CHANGE_PASSWORD;?></div>
	<div> <input type="checkbox" name="change_password" value="1"
		<?php if (($ARRAY['change_password'] == 1) or ($_SESSION['EX_CHANGE_PASSWORD'] == 1)){ 
		echo 'checked="checked"'; }?> /><?php echo $S_CHANGE_PASSOWRD;?>
	</div>

<div align="right" class="left_name_1"><?php echo $D_DEPARTMENT;?></div>
	<div> <input type="text" size="25" maxlength="50" name="department" value="<?php if(!empty($_SESSION['EX_DEPARTMENT'])) { echo $_SESSION['EX_DEPARTMENT'];} else { echo $ARRAY['department'];}?>"/></div>
	
<div align="right" class="left_name_1"><?php echo $F_ROOM;?></div>
	<div> <input type="text" size="25" maxlength="10" name="room" value="<?php if(!empty($_SESSION['EX_ROOM'])) { echo $_SESSION['EX_ROOM'];} else { echo $ARRAY['room'];}?>"/></div>
	
<div align="right" class="left_name_1"><u><?php echo $F_IP;?></u></div>
	<div> <input type="text" size="25" maxlength="15" name="ip" value="<?php if(!empty($_SESSION['EX_IP'])) { echo $_SESSION['EX_IP'];} else { echo $ARRAY['ip'];}?>"/><?php echo $S_ATENTION_FIIL_ADDRES;?></div>
	
<div align="right" class="left_name_1"><?php echo $F_MAC;?></div>
	<div> <input type="text" size="25" maxlength="17" name="mac" value="<?php if(!empty($_SESSION['EX_MAC'])) { echo $_SESSION['EX_MAC'];} else { echo $ARRAY['mac'];}?>"/></div>
	
<div align="right" class="left_name_1"><?php echo $F_PHONE;?></div>
	<div> <input type="text" size="25" maxlength="13" name="phone" value="<?php if(!empty($_SESSION['EX_PHONE'])) { echo $_SESSION['EX_PHONE'];} else { echo $ARRAY['phone'];}?>"/></div>
	
<div align="right" class="left_name_1"><?php echo $F_MOBILE;?></div>
	<div> <input type="text" size="25" maxlength="13" name="mobile" value="<?php if(!empty($_SESSION['EX_MOBILE'])) { echo $_SESSION['EX_MOBILE'];} else { echo $ARRAY['phone'];}?>"/></div>
	
<div align="right" class="left_name_1"><u><?php echo $F_SELECT_PROFILE;?></u></div>
	<div> <select name="profile">
		<option> </option>
	<?php
		$SQL = "SELECT id, name FROM controlcenter.profile ORDER BY name";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSU003F"));
		$DATA = mysql_fetch_array($RS);
		$cor = 1;	
		do{
		if (($ARRAY['id_pro'] == $DATA['id']) or ($_SESSION['EX_PROFILE'] == $DATA['id'])) {
			$sel = 'selected="selected"';
		} else {
				$sel = "";
		}
	
		if ( $cor == 1 )
		{
			?>
			<option value="<?php echo $DATA['id'];?>" <?php echo $sel;?> ><?php echo $DATA['name']; $cor=0?></option>
			<?php 
		} else { ?>
			<option style="background:<?php echo $COLOR_LINE_SELECT;?>" value="<?php echo $DATA['id'];?>" <?php echo $sel;?> ><?php echo $DATA['name']; $cor=1;?></option>
			<?php
		} 
	}while ($DATA =  mysql_fetch_array($RS));?>
	</select>
	</div>
<div class="title_general">
	<input type="submit" value="<?php if (empty($ARRAY['id'])){ echo $B_ADD_NEW;} else { echo $B_UPDATE;}?>" />
	<input type="button" value="<?php echo $B_CLEAR;?>" onclick="javascript:window.location=thispage" />
	<?php
	if (($DATA_USER['create_user'] == 1)&&($DATA_USER['read_user'] == 1)){?>
	<input type="button" value="<?php echo $B_DELETE;?>" onClick="javascript:confirmDeleteSelected();" />
	<?php if(!empty($ITEMID)){ ?> <font id="small_alert">* <?php echo $S_FILL_JUST_CHANGE;?></font><?php }
	}?>
</div>
</form>
<!--End add-->
<?php }
if ($DATA_USER['read_user'] == 1) {
?>
<!-- Start list-->
<div class="title_general"><?php echo $T_USER_LIST?></div>
<form class="insert_border" action="<?php echo $THISPAGE;?>" method="post" name="objselect">
<select class="select_list_2" name="list" size="20" ondblclick="javascript:document.objselect.submit()">
<?php
	$SQL = "SELECT id, fullname FROM controlcenter.user ORDER BY fullname";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCSU004F"));
	$ARRAY = mysql_fetch_array($RS);
	$cor = 1;	
	do{
	if ($ITEMID == $ARRAY['id']) {
		$sel = 'selected="selected"';
	} else {
			$sel = "";
	}
	
	if ( $cor == 1 )
		{
		?>
		<option value="<?php echo $ARRAY['id'];?>" <?php echo $sel;?> ><?php echo $ARRAY['fullname']; $cor=0?></option>
		<?php 
		} else { ?>
		<option style="background:<?php echo $COLOR_LINE_SELECT;?>" value="<?php echo $ARRAY['id'];?>" <?php echo $sel;?> ><?php echo $ARRAY['fullname']; $cor=1;?></option>
		<?php
		} 
	}while ($ARRAY =  mysql_fetch_array($RS));?>
</select>
<?php 
}?>
</form>
</div> <!--content rigth-->
<div class="version_general">
<?php
echo $VERSIONCC;
?>
</div>
</div> <!--Main-->
</body>
</html>
<?php
unset($_SESSION['EX_NAME']);
unset($_SESSION['EX_LOGIN']);
unset($_SESSION['EX_PASSWORD']);
unset($_SESSION['EX_REPASSWORD']);
unset($_SESSION['EX_PROFILE']);
unset($_SESSION['EX_CHANGE_PASSWORD']);
unset($_SESSION['EX_MOBILE']);
unset($_SESSION['EX_PHONE']);
unset($_SESSION['EX_MAC']);
unset($_SESSION['EX_IP']);
unset($_SESSION['EX_ROOM']);
unset($_SESSION['EX_DEPARTMENT']);
unset($_SESSION['SHOW_MSG']);
unset($_SESSION['ITEMID']);
?>