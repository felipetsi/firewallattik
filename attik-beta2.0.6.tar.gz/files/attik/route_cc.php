<?php 
require_once('includes/control_session.php');
require('configuration/directory.php');

$DESTINATION_PAGE = "route_run_cc.php";
$THISPAGE = "route_cc.php";

// Load the profile of user autenticanted
$SQL = "SELECT change_config FROM controlcenter.profile WHERE ";
$SQL .= "id IN (SELECT id_pro FROM controlcenter.user WHERE id = '$USER')";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCRS001S"));
$DATA_USER = mysql_fetch_array($RS);

// Load the item selected
if (!empty($_POST['list']))
{
	$_SESSION['ITEMID'] = $_POST['list'];
	$ITEMID = $_SESSION['ITEMID'];
} else {
	$ITEMID = $_SESSION['ITEMID'];
}
$_SESSION['ITEMDELETE'] = $ITEMID;

// Clear and set permition in file of routes
$COMMAND = "echo > $FILEROUTESH";
exec($COMMAND,$RETURN);
$COMMAND = "chmod 755 $FILEROUTESH";
exec($COMMAND,$RETURN);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>..:: IncTI - Firewall ::..</title>
<script language="javascript">
var thispage = "route_cc.php";
var deletepage = "route_delete_cc.php";
</script>
<link href="includes/style_cc.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php 
require_once('includes/top.php');
?>
<script language="javascript">
function confirmDeleteSelected()
{
	document.getElementById('background_transparent').style.display="inline";
	document.getElementById('box_delete').style.display="table";	
}
function yesdeleteSelected()
{
	window.location=deletepage;
}
function nodeleteSelected()
{
	document.getElementById('box_delete').style.display="none";
	document.getElementById('background_transparent').style.display="none";
}
function clickBackgroudTrabsparent()
{
	nodeleteSelected();
}
</script>
<div id="background_transparent" onclick="javascript:clickBackgroudTrabsparent();"></div>
<div id="box_delete"><?php echo("$S_WANT_DELETE?");?> 
	<div class="space_confirm_box">
		<input type="button" value="<?php echo $B_YES;?>" onclick="javascript:yesdeleteSelected();" />
		<input type="button" value="<?php echo $B_NO;?>" onclick="javascript:nodeleteSelected();" />
	</div>	
</div>
<div id="main"> <!--Main-->
<?php require_once('cc_menu_configuration.php');?>
<?php require_once('cc_menu_network_configuration.php');?>
	<div id="contet_rigth">
<?php
if ($DATA_USER['change_config'] == 1) {

// Load the user selected
$SQL = "SELECT * FROM controlcenter.route_table WHERE id = '$ITEMID'";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCRS002S"));
if((mysql_affected_rows() == 1) && ($LOG_AUDITOR == 1)){
		auditor('IFWSI002S', $ADDRIP, $USER, '0');
}
$ARRAY = mysql_fetch_array($RS);
?>

<!--Start add-->
<form class="insert_border" action="<?php echo $DESTINATION_PAGE;?>" method="post">
<input type="hidden" name="id" value="<?php echo $ARRAY['id'];?>" />
<div class="title_general" > <?php echo $T_ROUTE_TABLE; ?> </div>
<div id="contet_rigth_data">
<div align="right" class="left_name"><u><?php echo $F_NETWORK;?></u> </div>
	<div> <input type="text" name="destination" size="20" maxlength="15" value="<?php if(!empty($_SESSION['EX_DESTINATION'])) { echo $_SESSION['EX_DESTINATION'];} else { echo $ARRAY['destination'];}?>"  autocomplete="off" /></div>
	
<div align="right" class="left_name"><u><?php echo $F_MASK;?></u> </div>
	<div> <input type="text" name="mask" size="20" maxlength="15" value="<?php if(!empty($_SESSION['EX_MASK'])) { echo $_SESSION['EX_MASK'];} else { echo $ARRAY['mask'];}?>"  autocomplete="off" /></div>

<div align="right" class="left_name"><u><?php echo $F_GATEWAY;?></u> </div>
	<div> <input type="text" name="gateway" size="20" maxlength="15" value="<?php if(!empty($_SESSION['EX_GW'])) { echo $_SESSION['EX_GW'];} else { echo $ARRAY['gateway'];}?>"  autocomplete="off" /></div>
	</div>
	<div id="contet_rigth_img">

		<img src="@img/icons/routing-128x128.png" />	

	</div>	
<div class="title_general">
	<input type="submit" value="<?php if (empty($ARRAY['id'])){ echo $B_ADD_NEW;} else { echo $B_UPDATE;}?>" />
	<input type="button" value="<?php echo $B_CLEAR;?>" onclick="javascript:window.location=thispage" />
	<input type="button" value="<?php echo $B_DELETE;?>" onClick="javascript:confirmDeleteSelected();" />
</div>
</form>
<!--End add-->

<!-- Start list-->
<div class="title_general"><?php echo $T_ROUTE_LIST;?></div>
<form class="insert_border" action="<?php echo $THISPAGE;?>" method="post" name="objselect">
<div class="line_title_div_check">
	<div class="space_address_check_title"></div>
	<div class="space_address_title"><?php echo $T_DESTINATION;?></div>
	<div class="space_address_title"><?php echo $T_MASK; ?></div>
	<div class="space_address_title"><?php echo $T_GATEWAY; ?></div>
</div>
<script language="javascript">
function selectRoute()
{
	document.objselect.submit();
}
</script>

<div class="box_space_list_obj">
<?php
	$SQL = "SELECT * FROM controlcenter.route_table";
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCRS003S"));
	$ARRAY = mysql_fetch_array($RS);
	$cor = 1;	
	do{
		if(!empty($ARRAY['destination'])){ ?>
		<div class="<?php if(verifyRoute($ARRAY['destination'],$ARRAY['mask'],$ARRAY['gateway'],$FILEROUTESH) != "ok"){ echo 'line_obj_list_fail'; } else {echo 'line_obj_list';}?>">
			<div class="space_address_check"><input type="checkbox" id="<?php echo $ARRAY['id'];?>" name="list" value="<?php echo $ARRAY['id'];?>" <?php if($ITEMID == $ARRAY['id']) { echo 'checked="checked"'; } ?> onchange="javascript:selectRoute();" /></div>
			<label for="<?php echo $ARRAY['id'];?>">
				<a href="javascript:selectRoute();">
					<div class="space_address"><?php echo $ARRAY['destination'];?></div>
				</a>
			</label>
			<label for="<?php echo $ARRAY['id'];?>">
				<a href="javascript:selectRoute();">
					<div class="space_address"><?php echo $ARRAY['mask']; ?></div>
				</a>
			</label>
			<label for="<?php echo $ARRAY['id'];?>">
				<a href="javascript:selectRoute();">
					<div class="space_address"><?php echo $ARRAY['gateway']; ?></div>
				</a>
			</label>
		</div>
			<?php
		}
	}while ($ARRAY =  mysql_fetch_array($RS));?>
</form>
	</div>
<?php 
}?>
</div>
<div class="version_general">
<?php
echo $VERSIONCC;
?>
</div>

</div>
</body>
</html>
<?php
unset($_SESSION['ITEMID']);
unset($_SESSION['EX_DESTINATION']);
unset($_SESSION['EX_MASK']);
unset($_SESSION['EX_GW']);
?>