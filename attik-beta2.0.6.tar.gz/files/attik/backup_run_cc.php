<?php 
require_once('includes/control_session.php');
require('configuration/directory.php');
require_once('/var/.incti/.access/.access_exec.php');

$DESTINATION_PAGE = "backup_cc.php";
$USER_DB = "attikuser";

$ID = trim(addslashes($_POST['id']));

if (empty($ID)) {
	$DESCRIPTTION = substr(trim(addslashes($_POST['description'])),0,200);
}

// Create the backup
	$DATENOWTS = date("Y-m-d H:i:s");
	$DATENOW = str_replace(":","-",str_replace(" ", "_", $DATENOWTS));
	$COMMAND = "mysqldump --opt -u $USER_DB -p\"$INCTIPW\" --database controlcenter cc_firewall | gzip > $DIRBACKUPDB/$DATENOW.its";
	exec($COMMAND,$RETURN);
	if (!empty($RETURN) && ($LOG_AUDITOR == 1))
	{
		auditor('ICCXB003F', $ADDRIP, $USER, '0');
		$_SESSION['SHOW_MSG'] = 'F_FAILURE';
	}
	else {
		$SQL = "INSERT INTO  cc_backup.backup (date_created, description, id_user) "; 
		$SQL .= "VALUES ('$DATENOWTS', '$DESCRIPTTION', '$USER')";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCIB004F"));
		if (mysql_affected_rows() == 1){
			$_SESSION['SHOW_MSG'] = 'F_SUCESS';
			if ($LOG_AUDITOR == 1) {
				auditor('ICCIB004S', $ADDRIP, $USER, $NAME);
			}
		}else {
			$_SESSION['SHOW_MSG'] = 'F_FAILURE';
			if($LOG_AUDITOR == 1){
				auditor('ICCIB004F', $ADDRIP, $USER, $NAME);
			}
		}
	}
if (!empty($ID)) {
	if ($_SESSION['SHOW_MSG'] == 'F_SUCESS'){
		if(verifyBkp($ID,$DIRBACKUPDB) == "ok"){
			$SQL = "DROP DATABASE controlcenter";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCIB005F"));
			$SQL = "DROP DATABASE cc_firewall";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCIB005F"));
			$FILETARGET = str_replace(":","-",str_replace(" ", "_", $ID)).".its";
	
			$COMMAND = "gzip -dc $DIRBACKUPDB/$FILETARGET | mysql -p\"$INCTIPW\" -u $USER_DB";
			
			exec($COMMAND,$RETURN);
			
			$SQL = "UPDATE cc_firewall.rulefw SET applied = '0'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCIB010F"));
			
			if (empty($RETURN)){
				$_SESSION['SHOW_MSG'] = 'F_SUCESS';
				if ($LOG_AUDITOR == 1){
					auditor('ICCXB006S', $ADDRIP, $USER, $ID);
				}
			}else {
				$_SESSION['SHOW_MSG'] = 'F_FAILURE';
				if($LOG_AUDITOR == 1){
					auditor('ICCXB006F', $ADDRIP, $USER, $ID);
				}
			}
		} else {
			$_SESSION['SHOW_MSG'] = 'ME_NOT_EXIST_FILE_BKP';
			if($LOG_AUDITOR == 1){
				auditor('ICCXB012F', $ADDRIP, $USER, $ID);
			}
		}
	}
}
header("Location:$DESTINATION_PAGE");
?>