-- phpMyAdmin SQL Dump
-- version 3.4.5deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 17, 2012 at 06:27 PM
-- Server version: 5.1.58
-- PHP Version: 5.3.6-13ubuntu3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cc_backup`
--
CREATE DATABASE `cc_backup` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `cc_backup`;

-- --------------------------------------------------------

--
-- Table structure for table `backup`
--

CREATE TABLE IF NOT EXISTS `backup` (
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `description` varchar(200) NOT NULL,
  `id_user` int(2) NOT NULL,
  PRIMARY KEY (`date_created`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
--
-- Database: `cc_firewall`
--
CREATE DATABASE `cc_firewall` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `cc_firewall`;

-- --------------------------------------------------------

--
-- Table structure for table `action`
--

CREATE TABLE IF NOT EXISTS `action` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `in_policy` varchar(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

--
-- Dumping data for table `action`
--

INSERT INTO `action` (`id`, `name`, `in_policy`) VALUES
(1, 'ACCEPT', '1'),
(2, 'DROP', '1'),
(3, 'REDIRECT', '0'),
(4, 'DNAT', '0'),
(5, 'SNAT', '0'),
(12, 'RETURN', '0'),
(6, 'TOS16', '0'),
(11, 'REJECT', '0'),
(7, 'TOS8', '0'),
(8, 'TOS4', '0'),
(9, 'TOS2', '0'),
(10, 'TOS0', '0'),
(13, 'QUEUE', '0'),
(14, 'MASQUERADE', '0'),
(15, 'MARK', '0'),
(16, 'LOG', '0');

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE IF NOT EXISTS `application` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `port` varchar(11) NOT NULL,
  `description` varchar(50) DEFAULT NULL,
  `id_pro` int(2) NOT NULL,
  `report` char(1) NOT NULL,
  PRIMARY KEY (`id`,`name`,`port`,`id_pro`),
  KEY `id_pro` (`id_pro`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

--
-- Dumping data for table `application`
--

INSERT INTO `application` (`id`, `name`, `port`, `description`, `id_pro`, `report`) VALUES
(1, 'HTTP', '80', 'Web protocol', 1, '1'),
(2, 'FTP', '21', 'Transfer File Protocol', 1, '1'),
(3, 'SMTP', '25', 'Simple Mail Transfer Protocol', 1, '1'),
(4, 'DNS', '53', 'DNS', 1, '1'),
(5, 'TELNET', '23', 'Remote administration', 1, '1'),
(6, 'SSL', '443', 'Secure soquete level', 1, '1'),
(7, 'NETBIOS-SS', '139', 'Netbios Session Service', 1, '1'),
(8, 'TFTP', '69', 'Trivial FTP', 2, '1'),
(9, 'SMNP', '161', 'Manager of net', 2, '1'),
(10, 'IMAP', '143', 'E-mail', 1, '1'),
(11, 'POP3', '110', 'POP-3', 1, '1'),
(12, 'SSH', '22', 'SSH', 1, '1'),
(101, '', '', '', 0, ''),
(14, 'FTP-DATA', '20', '', 1, '0'),
(15, 'NETBIOS-NS', '137', 'Netbios Datagrama Service', 1, '0'),
(16, 'NETBIOS-DGM', '138', 'Netbios Datagrama Service', 1, '0'),
(17, 'TS', '3389', 'Terminal Service', 1, '0'),
(18, 'MICROSOFT-DS', '445', 'Microsoft Naked CIFS', 1, '0'),
(19, 'SSMTP', '465', 'SMTP over SSL', 1, '0'),
(20, 'POP3S', '995', 'POP-3 over SSL', 1, '0'),
(21, 'MYSQL', '3306', 'Mysql Database', 1, '1'),
(22, 'POSTGRESQL', '5432', 'PostgreSQL Database', 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `atribute_module`
--

CREATE TABLE IF NOT EXISTS `atribute_module` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `id_mod` int(1) NOT NULL,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

--
-- Dumping data for table `atribute_module`
--

INSERT INTO `atribute_module` (`id`, `id_mod`, `name`) VALUES
(1, 2, 'NEW'),
(2, 2, 'ESTABLISHED'),
(3, 2, 'RELATED'),
(4, 2, 'INVALID');

-- --------------------------------------------------------

--
-- Table structure for table `attack`
--

CREATE TABLE IF NOT EXISTS `attack` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `description` varchar(50) NOT NULL,
  `status` varchar(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

--
-- Dumping data for table `attack`
--

INSERT INTO `attack` (`id`, `name`, `description`, `status`) VALUES
(1, 'SynCookies', 'Dsyncookies', '0'),
(2, 'Netbus', 'Dnetbus', '0'),
(3, 'Trin00', 'Dtrin00', '0'),
(4, 'TraceRoute', 'Dtraceroute', '0'),
(5, 'SynFlood', 'DsynFlood', '1'),
(6, 'ShealtScan', 'Dhealtscan', '0'),
(7, 'IPSpoofing', 'Dipspoofing', '0'),
(8, 'cmd', 'Dcmd', '0');

-- --------------------------------------------------------

--
-- Table structure for table `command`
--

CREATE TABLE IF NOT EXISTS `command` (
  `name` varchar(1) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `command`
--

INSERT INTO `command` (`name`) VALUES
('A'),
('I'),
('S');

-- --------------------------------------------------------

--
-- Table structure for table `direction`
--

CREATE TABLE IF NOT EXISTS `direction` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(11) NOT NULL,
  `have_policy` varchar(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

--
-- Dumping data for table `direction`
--

INSERT INTO `direction` (`id`, `name`, `have_policy`) VALUES
(1, 'INPUT', '1'),
(2, 'OUTPUT', '1'),
(3, 'FORWARD', '1'),
(4, 'PREROUTING', '0'),
(5, 'POSTROUTING', '0');

-- --------------------------------------------------------

--
-- Table structure for table `module`
--

CREATE TABLE IF NOT EXISTS `module` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `definitive` varchar(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

--
-- Dumping data for table `module`
--

INSERT INTO `module` (`id`, `name`, `definitive`) VALUES
(1, 'limit', '0'),
(2, 'state', '1'),
(3, 'mac', '0'),
(4, 'string', '0');

-- --------------------------------------------------------

--
-- Table structure for table `needapply`
--

CREATE TABLE IF NOT EXISTS `needapply` (
  `name` char(1) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `needapply`
--

INSERT INTO `needapply` (`name`) VALUES
('0');

-- --------------------------------------------------------

--
-- Table structure for table `network_address`
--

CREATE TABLE IF NOT EXISTS `network_address` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `ip` varchar(18) NOT NULL,
  `mask` varchar(18) DEFAULT NULL,
  `mac` varchar(17) DEFAULT NULL,
  `description` varchar(100) NOT NULL,
  `img` varchar(100) NOT NULL,
  `global` char(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

-- --------------------------------------------------------

--
-- Table structure for table `policyfw`
--

CREATE TABLE IF NOT EXISTS `policyfw` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `id_dir` int(1) NOT NULL,
  `id_act` int(2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_dir` (`id_dir`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

--
-- Dumping data for table `policyfw`
--

INSERT INTO `policyfw` (`id`, `id_dir`, `id_act`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `protocol`
--

CREATE TABLE IF NOT EXISTS `protocol` (
  `id` int(3) NOT NULL,
  `name` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `protocol`
--

INSERT INTO `protocol` (`id`, `name`) VALUES
(0, ''),
(1, 'tcp'),
(2, 'udp'),
(3, 'icmp'),
(4, 'gre'),
(5, 'esp'),
(6, 'ah'),
(7, 'l2tp');

-- --------------------------------------------------------

--
-- Table structure for table `rul_atr`
--

CREATE TABLE IF NOT EXISTS `rul_atr` (
  `id_rul` float NOT NULL,
  `id_atr` int(6) NOT NULL,
  KEY `id_rul` (`id_rul`),
  KEY `id_atr` (`id_atr`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rul_net`
--

CREATE TABLE IF NOT EXISTS `rul_net` (
  `id_rul` float NOT NULL,
  `id_net` int(10) NOT NULL,
  `position` char(1) NOT NULL,
  PRIMARY KEY (`id_rul`,`id_net`,`position`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rul_vartime`
--

CREATE TABLE IF NOT EXISTS `rul_vartime` (
  `id_rul` float NOT NULL,
  `id_vartime` int(2) NOT NULL,
  `status_order` varchar(1) NOT NULL,
  PRIMARY KEY (`id_rul`,`id_vartime`,`status_order`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rule_app`
--

CREATE TABLE IF NOT EXISTS `rule_app` (
  `id_rul` float NOT NULL,
  `id_app` int(10) NOT NULL,
  `position` char(1) NOT NULL,
  PRIMARY KEY (`id_rul`,`id_app`,`position`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rule_firewall_list`
--

CREATE TABLE IF NOT EXISTS `rule_firewall_list` (
  `id_rul` float NOT NULL,
  `id_fw` int(5) NOT NULL,
  `id_rul_fw_exported` float NOT NULL,
  `status` char(1) NOT NULL,
  PRIMARY KEY (`id_rul`,`id_fw`,`id_rul_fw_exported`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rule_mangle_value`
--

CREATE TABLE IF NOT EXISTS `rule_mangle_value` (
  `id_rul` float NOT NULL,
  `setmark` varchar(19) NOT NULL,
  PRIMARY KEY (`id_rul`,`setmark`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rule_nat_app`
--

CREATE TABLE IF NOT EXISTS `rule_nat_app` (
  `id_rul` float NOT NULL,
  `id_app` int(10) NOT NULL,
  PRIMARY KEY (`id_rul`,`id_app`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rule_nat_net`
--

CREATE TABLE IF NOT EXISTS `rule_nat_net` (
  `id_rul` float NOT NULL,
  `id_net` int(10) NOT NULL,
  PRIMARY KEY (`id_rul`,`id_net`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rulefw`
--

CREATE TABLE IF NOT EXISTS `rulefw` (
  `id` float NOT NULL AUTO_INCREMENT,
  `id_s_iface` int(6) DEFAULT '0',
  `id_d_iface` int(6) DEFAULT '0',
  `id_pro` int(3) DEFAULT '0',
  `command` char(1) NOT NULL,
  `id_tab_dir_act` int(6) NOT NULL DEFAULT '0',
  `s_iface_condition` char(1) NOT NULL DEFAULT '0',
  `d_iface_condition` char(1) NOT NULL DEFAULT '0',
  `source_condition` char(1) NOT NULL DEFAULT '0',
  `destination_condition` char(1) NOT NULL DEFAULT '0',
  `sport_condition` char(1) NOT NULL DEFAULT '0',
  `dport_condition` char(1) NOT NULL DEFAULT '0',
  `proto_condition` char(1) NOT NULL DEFAULT '0',
  `mac_condition` char(1) NOT NULL DEFAULT '0',
  `string_condition` char(1) NOT NULL DEFAULT '0',
  `state_condition` char(1) NOT NULL DEFAULT '0',
  `id_user` int(2) NOT NULL DEFAULT '0',
  `commentfw` varchar(150) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `use_assistant` char(1) NOT NULL,
  `status` char(1) NOT NULL,
  `applied` char(1) NOT NULL,
  `exported` char(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

-- --------------------------------------------------------

--
-- Table structure for table `rulefwrun`
--

CREATE TABLE IF NOT EXISTS `rulefwrun` (
  `id` float NOT NULL,
  `name` varchar(500) NOT NULL,
  `refer` float NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`refer`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tab_dir_act`
--

CREATE TABLE IF NOT EXISTS `tab_dir_act` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `id_tab` int(1) NOT NULL,
  `id_dir` int(3) NOT NULL,
  `id_act` int(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_tab` (`id_tab`),
  KEY `id_dir` (`id_dir`),
  KEY `id_act` (`id_act`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

--
-- Dumping data for table `tab_dir_act`
--

INSERT INTO `tab_dir_act` (`id`, `id_tab`, `id_dir`, `id_act`) VALUES
(1, 1, 1, 1),
(2, 1, 1, 2),
(3, 1, 2, 1),
(4, 1, 2, 2),
(5, 1, 3, 1),
(6, 1, 3, 2),
(7, 2, 2, 3),
(8, 2, 4, 4),
(43, 1, 3, 11),
(10, 2, 4, 3),
(42, 1, 2, 11),
(40, 2, 2, 4),
(41, 1, 1, 11),
(14, 2, 5, 5),
(15, 3, 1, 6),
(16, 3, 1, 7),
(17, 3, 1, 8),
(18, 3, 1, 9),
(19, 3, 1, 10),
(20, 3, 2, 6),
(21, 3, 2, 7),
(22, 3, 2, 8),
(23, 3, 2, 9),
(24, 3, 2, 10),
(25, 3, 3, 6),
(26, 3, 3, 7),
(27, 3, 3, 8),
(28, 3, 3, 9),
(29, 3, 3, 10),
(30, 3, 4, 6),
(31, 3, 4, 7),
(32, 3, 4, 8),
(33, 3, 4, 9),
(34, 3, 4, 10),
(35, 3, 5, 6),
(36, 3, 5, 7),
(37, 3, 5, 8),
(38, 3, 5, 9),
(39, 3, 5, 10),
(44, 1, 1, 12),
(45, 1, 2, 12),
(46, 1, 3, 12),
(47, 2, 2, 12),
(48, 2, 4, 12),
(49, 2, 5, 12),
(50, 1, 1, 13),
(51, 1, 2, 13),
(52, 1, 3, 13),
(53, 2, 2, 13),
(54, 2, 4, 13),
(55, 2, 5, 13),
(56, 2, 5, 14),
(57, 3, 1, 9),
(59, 4, 4, 4),
(64, 3, 4, 15),
(63, 3, 4, 15),
(62, 3, 3, 15),
(61, 3, 2, 15),
(60, 3, 1, 15),
(65, 1, 1, 16),
(66, 1, 2, 16),
(67, 1, 3, 16),
(68, 2, 2, 16),
(69, 2, 4, 16),
(70, 2, 5, 16),
(71, 3, 1, 16),
(72, 3, 2, 16),
(73, 3, 3, 16),
(74, 3, 4, 16),
(75, 3, 5, 16);

-- --------------------------------------------------------

--
-- Table structure for table `tablefw`
--

CREATE TABLE IF NOT EXISTS `tablefw` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `name` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

--
-- Dumping data for table `tablefw`
--

INSERT INTO `tablefw` (`id`, `name`) VALUES
(1, 'filter'),
(2, 'nat'),
(3, 'mangle');

-- --------------------------------------------------------

--
-- Table structure for table `unit_time`
--

CREATE TABLE IF NOT EXISTS `unit_time` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `name` varchar(1) NOT NULL,
  `description` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

--
-- Dumping data for table `unit_time`
--

INSERT INTO `unit_time` (`id`, `name`, `description`) VALUES
(1, 's', 'SECOND'),
(2, 'm', 'MINUTE'),
(3, 'h', 'HOUR'),
(4, 'd', 'DAY');

-- --------------------------------------------------------

--
-- Table structure for table `variable_time`
--

CREATE TABLE IF NOT EXISTS `variable_time` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `name` varchar(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

--
-- Dumping data for table `variable_time`
--

INSERT INTO `variable_time` (`id`, `name`) VALUES
(1, '01:00'),
(2, '02:00'),
(3, '03:00'),
(4, '04:00'),
(5, '05:00'),
(6, '06:00'),
(7, '07:00'),
(8, '08:00'),
(9, '09:00'),
(10, '10:00'),
(11, '11:00'),
(12, '12:00'),
(13, '13:00'),
(14, '14:00'),
(15, '15:00'),
(16, '16:00'),
(17, '17:00'),
(18, '18:00'),
(19, '19:00'),
(20, '20:00'),
(21, '21:00'),
(22, '22:00'),
(23, '23:00'),
(24, '24:00');
--
-- Database: `cc_vpn`
--
CREATE DATABASE `cc_vpn` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `cc_vpn`;

-- --------------------------------------------------------

--
-- Table structure for table `algorithm`
--

CREATE TABLE IF NOT EXISTS `algorithm` (
  `id` int(3) NOT NULL,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
--
-- Database: `controlcenter`
--
CREATE DATABASE `controlcenter` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `controlcenter`;

-- --------------------------------------------------------

--
-- Table structure for table `failover`
--

CREATE TABLE IF NOT EXISTS `failover` (
  `name_ifa` varchar(6) NOT NULL,
  `identification` int(3) NOT NULL,
  `master` int(3) NOT NULL,
  `skew` int(3) NOT NULL,
  `password` varchar(40) NOT NULL,
  `virtual_ip` varchar(15) NOT NULL,
  PRIMARY KEY (`name_ifa`),
  UNIQUE KEY `virtual_ip` (`virtual_ip`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `firewall_list`
--

CREATE TABLE IF NOT EXISTS `firewall_list` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `ip` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`ip`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

-- --------------------------------------------------------

--
-- Table structure for table `interface`
--

CREATE TABLE IF NOT EXISTS `interface` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `id_iface` int(6) NOT NULL,
  `vid` int(4) NOT NULL,
  `name` varchar(11) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `mask` varchar(15) NOT NULL,
  `description` varchar(30) NOT NULL,
  PRIMARY KEY (`id`,`vid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

-- --------------------------------------------------------

--
-- Table structure for table `language`
--

CREATE TABLE IF NOT EXISTS `language` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `file` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`file`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

--
-- Dumping data for table `language`
--

INSERT INTO `language` (`id`, `name`, `file`) VALUES
(1, 'English', 'english'),
(2, 'Português (BR)', 'portugues');

-- --------------------------------------------------------

--
-- Table structure for table `log_access`
--

CREATE TABLE IF NOT EXISTS `log_access` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `moment` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `address` varchar(15) NOT NULL,
  `login` varchar(20) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ;

-- --------------------------------------------------------

--
-- Table structure for table `log_auditor`
--

CREATE TABLE IF NOT EXISTS `log_auditor` (
  `code` varchar(10) NOT NULL,
  `moment` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `source` varchar(18) NOT NULL,
  `id_user` int(2) NOT NULL,
  `more_info` varchar(50) NOT NULL,
  PRIMARY KEY (`code`,`moment`,`source`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `module`
--

CREATE TABLE IF NOT EXISTS `module` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `status` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`id`,`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

--
-- Dumping data for table `module`
--

INSERT INTO `module` (`id`, `name`, `status`) VALUES
(1, 'firewall', '1'),
(2, 'proxy', '0'),
(3, 'ips', '0'),
(4, 'serveremail', '0'),
(5, 'spamfilter', '0'),
(6, 'serverweb', '0'),
(7, 'vpn', '0');

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `mod_firewall` varchar(1) NOT NULL,
  `id_profw` int(2) DEFAULT NULL,
  `id_propx` varchar(5) NOT NULL,
  `id_provpn` int(2) NOT NULL,
  `mod_proxy` varchar(1) NOT NULL,
  `mod_ids` varchar(1) NOT NULL,
  `mod_serv_mail` varchar(1) NOT NULL,
  `mod_smtp_relay` varchar(1) NOT NULL,
  `mod_web` varchar(1) NOT NULL,
  `mod_vpn` varchar(1) NOT NULL,
  `create_user` varchar(1) NOT NULL,
  `read_user` varchar(1) NOT NULL,
  `create_profile` varchar(1) NOT NULL,
  `read_profile` varchar(1) NOT NULL,
  `read_log` varchar(1) NOT NULL,
  `change_config` varchar(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`id`, `name`, `mod_firewall`, `id_profw`, `id_propx`, `id_provpn`, `mod_proxy`, `mod_ids`, `mod_serv_mail`, `mod_smtp_relay`, `mod_web`, `mod_vpn`, `create_user`, `read_user`, `create_profile`, `read_profile`, `read_log`, `change_config`) VALUES
(1, 'Administrador', '1', 1, '1', 0, '0', '0', '0', '0', '0', '0', '1', '1', '1', '1', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `profilefw`
--

CREATE TABLE IF NOT EXISTS `profilefw` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `create_rule` varchar(1) NOT NULL,
  `read_rule` varchar(1) NOT NULL,
  `read_report` varchar(1) NOT NULL,
  `create_net` varchar(1) NOT NULL,
  `read_net` varchar(1) NOT NULL,
  `create_protocol` varchar(1) NOT NULL,
  `read_protocol` varchar(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

--
-- Dumping data for table `profilefw`
--

INSERT INTO `profilefw` (`id`, `name`, `create_rule`, `read_rule`, `read_report`, `create_net`, `read_net`, `create_protocol`, `read_protocol`) VALUES
(1, 'Administrador', '1', '1', '1', '1', '1', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `profilepx`
--

CREATE TABLE IF NOT EXISTS `profilepx` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `create_rule` varchar(1) NOT NULL,
  `read_rule` varchar(1) NOT NULL,
  `read_report` varchar(1) NOT NULL,
  `create_item` varchar(1) NOT NULL,
  `read_item` varchar(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

--
-- Dumping data for table `profilepx`
--

INSERT INTO `profilepx` (`id`, `name`, `create_rule`, `read_rule`, `read_report`, `create_item`, `read_item`) VALUES
(1, 'Administrador', '1', '1', '1', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `profilevpn`
--

CREATE TABLE IF NOT EXISTS `profilevpn` (
  `id` int(2) NOT NULL,
  `name` varchar(20) NOT NULL,
  `create_conn` varchar(1) NOT NULL,
  `read_conn` varchar(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `route_table`
--

CREATE TABLE IF NOT EXISTS `route_table` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `destination` varchar(15) NOT NULL,
  `mask` varchar(15) NOT NULL,
  `gateway` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(50) NOT NULL,
  `login` varchar(20) NOT NULL,
  `password` varchar(40) NOT NULL,
  `change_password` varchar(1) NOT NULL,
  `department` varchar(50) DEFAULT NULL,
  `room` varchar(10) DEFAULT NULL,
  `ip` varchar(15) NOT NULL,
  `mac` varchar(17) DEFAULT NULL,
  `phone` varchar(13) DEFAULT NULL,
  `mobile` varchar(13) DEFAULT NULL,
  `id_pro` int(2) NOT NULL,
  PRIMARY KEY (`id`,`login`),
  KEY `id_pro` (`id_pro`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `fullname`, `login`, `password`, `change_password`, `department`, `room`, `ip`, `mac`, `phone`, `mobile`, `id_pro`) VALUES
(1, 'Administrador', 'attikadmin', '06b41e765cc5b2fddfaff942ffa9c6a76c98a021', '0', '', '', '', '', '', '', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
