<?php 
require_once('includes/control_session.php');

$DESTINATION_PAGE = "test_connection_cc.php";
$THISPAGE = "test_connection_cc.php";

// Load the profile of user autenticanted
$SQL = "SELECT change_config FROM controlcenter.profile WHERE ";
$SQL .= "id IN (SELECT id_pro FROM controlcenter.user WHERE id = '$USER')";
$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCRS001S"));
$DATA_USER = mysql_fetch_array($RS);

// Load the item selected
$ITEMID = substr(trim(addslashes($_POST['destination'])),0,15);
if(verifyIp($ITEMID) == "ok"){
	$IP = $ITEMID;
	$COUNT = substr(trim(addslashes($_POST['count'])),0,3);
} elseif(!empty($ITEMID)) {
	$_SESSION['SHOW_MSG'] = 'ME_INVALIDIP';
	unset($IP);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>..:: IncTI - Firewall ::..</title>
<script language="javascript">
var thispage = "test_connection_cc.php";
function clearField(){
	document.getElementById('destination').value = "";
}
</script>
<link href="includes/style_cc.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php 
require_once('includes/top.php');
?>
<div id="main"> <!--Main-->
<?php require_once('cc_menu_configuration.php');?>
<?php require_once('cc_menu_network_configuration.php');?>
<div id="contet_rigth">
<?php
if ($DATA_USER['change_config'] == 1) {?>

<!--Start add-->
<form class="insert_border" action="<?php echo $DESTINATION_PAGE;?>" method="post">
<div class="title_general" > <?php echo $T_TEST_CONNECTION; ?> </div>
<div id="contet_rigth_data">
<div align="right" class="left_name"><u><?php echo $T_DESTINATION;?></u> </div>
	<div> <input type="text" id="destination" name="destination" size="20" maxlength="15" autocomplete="off" /></div>
<div align="right" class="left_name"><u><?php echo $T_COUNT;?></u> </div>
	<div> <input type="text" id="count" name="count" size="5" value="2" maxlength="3" autocomplete="off" /></div>
</div>
<div id="contet_rigth_img">
	<img src="@img/icons/connection-128x128.png" />	
</div>
<div class="title_general">
	<input type="submit" value="<?php echo $B_RUN; ?>" />
	<input type="button" value="<?php echo $B_CLEAR;?>" onclick="javascript:clearField();" />
</div>
</form>
<!--End add-->

<!-- Start list-->
<div class="title_general"><?php echo $T_RESULT;?></div>

<div class="box_space_list_obj">
	<font class="font_normal">
		<?php 
		if (!empty($IP)){
			if(empty($COUNT)){
				$COUNT = 2;
			}
			$COMMAND = "ping $IP -c $COUNT";
			exec($COMMAND,$RETURN);
			for ($f=0; $f < sizeof($RETURN); $f++)
			{
				echo $RETURN[$f]."<br>";
			}
		}?>
	</font>
</div>
<?php 
}?>
</div>
<div class="version_general">
<?php
echo $VERSIONCC;
?>
</div>

</div>
</body>
</html>