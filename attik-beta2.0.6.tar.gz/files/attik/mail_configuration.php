<%@ page contentType="text/html; charset=windows-1252" language="java" import="java.sql.*" errorPage="" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title><% System.out.print(VALOR_PRESENTE_NO_BD) %></title>
</head>
<body>
<ul>
<li>Lista de dom�nios</li>
<li>Lista de usu�rios</li>
<li>Acrescentar dom&iacute;nios</li>
<li>Apagar dom&iacute;nio </li>
<li>Acrescentar conta de e-mail </li>
</ul><!-- Aqui ser� direcionado par auma outra p�gina onde ser� selecionado o dom�nio-->
<ul>
<li>Arquivos de controle</li>
</ul>

</body>
</html>
