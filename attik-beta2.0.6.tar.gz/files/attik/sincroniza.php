<?php
require_once('includes/conn_db_cc.php');
$SQL = "SELECT r.*, t.name as tablefw, d.name as direction FROM cc_firewall.rulefw r, cc_firewall.tablefw t, ";
$SQL .= "cc_firewall.direction d WHERE r.id_tab_dir_act IN ";
$SQL .= "(SELECT id FROM cc_firewall.tab_dir_act WHERE id_tab IN (SELECT id FROM cc_firewall.tablefw WHERE id = t.id)) ";
$SQL .= "AND r.id_tab_dir_act IN ";
$SQL .= "(SELECT id FROM cc_firewall.tab_dir_act WHERE id_dir IN (SELECT id FROM cc_firewall.direction WHERE id = d.id))";
echo $SQL;
$RSRULE = mysql_query($SQL);
$ARRAYRULE = mysql_fetch_array($RSRULE);
do{
	$ID_RULE = $ARRAYRULE['id'];
	$TABLE = $ARRAYRULE['tablefw'];
	$ACTION = $ARRAYRULE['action'];
	$COMMANDADD = $ARRAYRULE['command'];
	$DIRECTION = $ARRAYRULE['direction'];
	
	$SIFACENAME = $ARRAYRULE['id_s_iface'];
	$SQL = "SELECT name FROM controlcenter.interface WHERE id = '$SIFACENAME'";
	$RSTEMP = mysql_query($SQL);
	$ARRAYTEMP = mysql_fetch_array($RSTEMP);
	$SIFACENAME = $ARRAYTEMP['name'];
	
	$DIFACENAME = $ARRAYRULE['id_d_iface'];
	$SQL = "SELECT name FROM controlcenter.interface WHERE id = '$DIFACENAME'";
	$RSTEMP = mysql_query($SQL);
	$ARRAYTEMP = mysql_fetch_array($RSTEMP);
	$DIFACENAME = $ARRAYTEMP['name'];
	
	$PROTOCOL = $ARRAYRULE['id_pro'];
	$SQL = "SELECT name FROM cc_firewall.protocol WHERE id = '$PROTOCOL'";
	$RSTEMP = mysql_query($SQL);
	$ARRAYTEMP = mysql_fetch_array($RSTEMP);
	$PROTOCOL = $ARRAYTEMP['name'];
	
	$SQL ="SELECT name FROM cc_firewall.atribute_module WHERE id_mod IN (SELECT id FROM cc_firewall.module WHERE ";
	$SQL .= "name = 'smultiport') AND id IN (SELECT id_atr FROM cc_firewall.rul_atr WHERE id_rul = '$ID_RULE')";
	$RSTEMP = mysql_query($SQL) or print(mysql_error());
	$ARRAYTEMP = mysql_fetch_array($RSTEMP);
	$MSMULTIPORT = $ARRAYTEMP['name'];

	$SPORT = $ARRAYRULE['sport'];
	
	$SQL ="SELECT name FROM cc_firewall.atribute_module WHERE id_mod IN (SELECT id FROM cc_firewall.module WHERE ";
	$SQL .= " name = 'dmultiport') AND id IN (SELECT id_atr FROM cc_firewall.rul_atr WHERE id_rul = '$ID_RULE')";
	$RSTEMP = mysql_query($SQL);
	$ARRAYTEMP = mysql_fetch_array($RSTEMP);
	$MDMULTIPORT = $ARRAYTEMP['name'];
	
	$DPORT = $ARRAYRULE['dport'];
	
	$SQL ="SELECT name FROM cc_firewall.atribute_module WHERE id_mod IN (SELECT id FROM cc_firewall.module WHERE ";
	$SQL .= "name = 'limit') AND id IN (SELECT id_atr FROM cc_firewall.rul_atr WHERE id_rul = '$ID_RULE')";
	$RSTEMP = mysql_query($SQL);
	$ARRAYTEMP = mysql_fetch_array($RSTEMP);
	$MDMULTIPORT = $ARRAYTEMP['name'];
	
	$SQL ="SELECT name FROM cc_firewall.atribute_module WHERE id_mod IN (SELECT id FROM cc_firewall.module WHERE ";
	$SQL .= "name = 'mac') AND id IN (SELECT id_atr FROM cc_firewall.rul_atr WHERE id_rul = '$ID_RULE')";
	$RSTEMP = mysql_query($SQL);
	$ARRAYTEMP = mysql_fetch_array($RSTEMP);
	$MDMULTIPORT = $ARRAYTEMP['name'];
	
	$SQL ="SELECT name FROM cc_firewall.atribute_module WHERE id_mod IN (SELECT id FROM cc_firewall.module WHERE ";
	$SQL .= "name = 'string') AND id IN (SELECT id_atr FROM cc_firewall.rul_atr WHERE id_rul = '$ID_RULE')";
	$RSTEMP = mysql_query($SQL);
	$ARRAYTEMP = mysql_fetch_array($RSTEMP);
	$MDMULTIPORT = $ARRAYTEMP['name'];
	
	$SQL ="SELECT id FROM cc_firewall.atribute_module WHERE id_mod IN (SELECT id FROM cc_firewall.module WHERE ";
	$SQL .= "name = 'state') AND id IN (SELECT id_atr FROM cc_firewall.rul_atr WHERE id_rul = '$ID_RULE')";
	$RSTEMP = mysql_query($SQL);
	$ARRAYTEMP = mysql_fetch_array($RSTEMP);
	$f=0;
	do {
		$MSTATE[$f] = $ARRAYTEMP['id'];
		$f++;
	} while($ARRAYTEMP = mysql_fetch_array($RSTEMP));
	
	// Mount the rule in one line
	$RULE = "-t $TABLE -$COMMANDADD $DIRECTION ";
	if (!empty($ARRAYRULE['s_address'])){ $RULE .= "-s ".$ARRAYRULE['s_address']." ";}
	if (!empty($ARRAYRULE['d_address'])){ $RULE .= "-d ".$ARRAYRULE['d_address']." ";}
	if (!empty($SIFACENAME)){ $RULE .= "-i $SIFACENAME ";}
	if (!empty($DIFACENAME)){ $RULE .= "-o $DIFACENAME ";}
	if (!empty($PROTOCOL)){ $RULE .= "-p $PROTOCOL ";}
	if (!empty($MSMULTIPORT)){ $RULE .= "-m multiport --sport $MSMULTIPORT ";}
		elseif (!empty($SPORT)){ $RULE .= "-m multiport --sport $SPORT ";}
	if (!empty($MDMULTIPORT)){ $RULE .= "-m multiport --dport $MDMULTIPORT ";}
		elseif (!empty($DPORT)){ $RULE .= "-m multiport --dport $DPORT ";}
	if (!empty($MLIMIT)){ $RULE .= "-m limit --limit $MLIMIT ";}
	if (!empty($MMAC)){ $RULE .= "-m mac --mac-source $MMAC ";}
	if (!empty($MSTRING)){ $RULE .= '-m string --algo bm --string "'.$MSTRING.'" ';}
	if (!empty($MSTATE[0])){ 
		for ($f = 0; $f < sizeof($MSTATE); $f++)
		{
			$ID = $MSTATE[$f];
			$SQL = "SELECT name FROM cc_firewall.atribute_module WHERE id = '$ID'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWSR054F"));
			$ARRAY = mysql_fetch_array($RS);
			if ($f != (sizeof($MSTATE)-1)) {
				$STATE .= $ARRAY['name'].",";
			} else {
				$STATE .= $ARRAY['name'];
			}
		}
		$RULE .= "-m state --state $STATE ";
	}
	if (($TABLE == "nat") || ($TABLE == "filter")) {
		if (!empty($ACTION)){ $RULE .= "-j $ACTION ";}
		if ($TABLE == "nat") {
			$SQL = "SELECT extend1,extend2 FROM cc_firewall.rule_extend WHERE id_rul = '$ID_RULE'";
			$RSTEMP = mysql_query($SQL);
			$ARRAYTEMP = mysql_fetch_array($RSTEMP);
			$TOADDRESS = $ARRAYTEMP['extend1'];
			$TOPORT = $ARRAYTEMP['extend2'];
			
			if ((!empty($TOADDRESS))&&(!empty($TOPORT))){ 
				if($ACTION == "SNAT"){
					$RULE .= "--to-source $TOADDRESS:$TOPORT";
					}
				elseif($ACTION == "DNAT"){
					$RULE .= "--to-destination $TOADDRESS:$TOPORT";
					}
				elseif($ACTION == "REDIRECT") {
					$RULE .= "--to $TOADDRESS:$TOPORT";
				}
			}
			elseif ((!empty($TOADDRESS))&&(empty($TOPORT))){
				if($ACTION == "SNAT"){
					$RULE .= "--to-source $TOADDRESS";
					}
				elseif($ACTION == "DNAT"){
					$RULE .= "--to-destination $TOADDRESS";
					}
				elseif($ACTION == "REDIRECT") {
					$RULE .= "--to $TOADDRESS";
				}
			}
			elseif((empty($TOADDRESS))&&(!empty($TOPORT))) {
				$RULE .= "--to-port $TOPORT";
			}
		}
	}
	else{
		if (!empty($ACTION)){
			$RULE .= "-j ".substr($ACTION,0,3)." --set-tos ".substr($ACTION,3,4);
		}
	}
	// Insert the rule in table to execute
	$SQL = "INSERT INTO cc_firewall.rulefwrun (id, name) VALUES ('$ID_RULE', '$RULE')";
	echo $SQL;
	$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL IFWIR055F"));
} while ($ARRAYRULE=mysql_fetch_array($RSRULE));
?>