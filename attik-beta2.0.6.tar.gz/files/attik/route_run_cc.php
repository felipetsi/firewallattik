<?php 
require_once('includes/control_session.php');
require_once('includes/functions.php');
require('configuration/directory.php');

$DESTINATION_PAGE = "route_cc.php";

$ID = trim(addslashes($_POST['id']));
$DESTINATION = substr(trim(addslashes($_POST['destination'])),0,15);
$MASK = substr(trim(addslashes($_POST['mask'])),0,15);
$GATEWAY = substr(trim(addslashes($_POST['gateway'])),0,15);

if ((empty($DESTINATION)) || (empty($MASK)) || (empty($GATEWAY))) {
	$_SESSION['SHOW_MSG'] = 'ME_NEEDFILL';
	$_SESSION['ITEMID'] = $ID;
	$_SESSION['EX_DESTINATION'] = $DESTINATION;
	$_SESSION['EX_MASK'] = $MASK;
	$_SESSION['EX_GW'] = $GATEWAY;
	header("Location:$DESTINATION_PAGE");
}
elseif((verifyIp($DESTINATION) != "ok") || (verifyMask($MASK) != "ok") || (verifyIp($GATEWAY) != "ok")){
	$_SESSION['SHOW_MSG'] = 'ME_INVALIDMASK';
	$_SESSION['ITEMID'] = $ID;
	$_SESSION['EX_DESTINATION'] = $DESTINATION;
	$_SESSION['EX_MASK'] = $MASK;
	$_SESSION['EX_GW'] = $GATEWAY;
	header("Location:$DESTINATION_PAGE");
}
else {
	
	if (empty($ID)) {
		$SQL = "SELECT id FROM controlcenter.route_table WHERE destination='$DESTINATION' AND ";
		$SQL .= "mask='$MASK' AND gateway='$GATEWAY'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCRS008S"));
		if (mysql_affected_rows() == 0) {
			insertRoute($DESTINATION,$MASK,$GATEWAY);
			$SQL = "INSERT INTO controlcenter.route_table (destination, mask, gateway) ";
			$SQL .= "VALUES ('$DESTINATION', '$MASK', '$GATEWAY')";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCRI004S"));
		} else {
			if($LOG_AUDITOR == 1){
				auditor('ICCRS010F', $ADDRIP, $USER, '0');
			}
		}
	}
	else {
		$SQL = "SELECT * FROM controlcenter.route_table WHERE id='$ID'";
		$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCRS009S"));
		$ARRAY = mysql_fetch_array($RS);
		if (deleteRoute($ARRAY['destination'],$ARRAY['mask'],$ARRAY['gateway']) == "ok"){
			insertRoute($DESTINATION,$MASK,$GATEWAY);
			$SQL = "UPDATE controlcenter.route_table SET destination='$DESTINATION', mask='$MASK', gateway='$GATEWAY' ";
			$SQL .= "WHERE id = '$ID'";
			$RS = mysql_query($SQL) or (die("$ME_OCCURREDEERRORINTERNAL ICCRI005S"));
		} else {
			if($LOG_AUDITOR == 1){
				auditor('ICCRS011F', $ADDRIP, $USER, '0');
			}
		}
	}
	if (mysql_affected_rows() != 0) {
		if($LOG_AUDITOR == 1){
			auditor('ICCRI006S', $ADDRIP, $USER, '0');
		}
		$_SESSION['SHOW_MSG'] = 'F_SUCESS';
	} else {
		if($LOG_AUDITOR == 1){
			auditor('ICCRI006F', $ADDRIP, $USER, '0');
		}
		$_SESSION['SHOW_MSG'] = 'F_FAILURE';
	}
	header("Location:$DESTINATION_PAGE");
}
?>